int
enum net_attach_type	attach_type
