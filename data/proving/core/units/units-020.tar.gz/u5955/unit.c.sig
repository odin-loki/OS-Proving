size_t
int	type
int	seg
