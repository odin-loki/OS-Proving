int
struct bcm2835_chip *	chip
const char *	name
int	idx
enum snd_bcm2835_route	route
u32	numchannels
bool	spdif
