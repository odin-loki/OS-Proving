bool
unsigned char	count
