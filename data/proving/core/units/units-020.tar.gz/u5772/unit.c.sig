int
struct s5c73m3 *	state
u32	value
unsigned int	delay
unsigned int	steps
