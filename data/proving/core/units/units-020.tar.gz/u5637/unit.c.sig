unsigned int
struct radeon_device *	rdev
int	ring
