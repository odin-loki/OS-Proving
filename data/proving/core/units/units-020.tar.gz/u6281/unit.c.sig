int
struct clk *	clk
struct notifier_block *	nb
