int
struct aead_request *	req
enum ocs_instruction	instruction
enum ocs_mode	mode
