s16
int	temp
