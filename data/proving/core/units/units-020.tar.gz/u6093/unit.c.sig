bool
u32	addr
