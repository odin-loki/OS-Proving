int
struct ida *	ida
unsigned int	min
gfp_t	gfp
