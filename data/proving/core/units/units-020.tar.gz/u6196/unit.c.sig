int
struct bnxt *	bp
