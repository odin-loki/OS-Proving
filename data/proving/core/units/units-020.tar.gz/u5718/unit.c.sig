u32
u16	irq
