int
struct mana_ib_cq *	cq
int	nwc
struct ib_wc *	wc
