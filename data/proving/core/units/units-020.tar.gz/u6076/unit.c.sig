bool
enum hv_interrupt_type	type
