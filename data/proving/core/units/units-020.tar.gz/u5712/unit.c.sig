int
struct ubi_device *	ubi
struct ubi_wl_entry *	e
int	vol_id
int	lnum
int	torture
bool	nested
