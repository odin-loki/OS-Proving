u8
u8	major
u8	hw_port_id
