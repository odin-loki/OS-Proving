int
volatile uint8_t *	_ptr
uint8_t	_old
uint8_t	_new
