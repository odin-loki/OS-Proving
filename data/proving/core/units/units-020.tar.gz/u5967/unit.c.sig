int
const struct gpio_desc *	desc
