int
char *	data
int	family
int	cmd
int	version
