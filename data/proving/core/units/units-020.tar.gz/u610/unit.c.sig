int
struct device *	dev
int	trip_temp
