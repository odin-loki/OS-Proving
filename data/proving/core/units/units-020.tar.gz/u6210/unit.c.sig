int
struct adapter *	Adapter
