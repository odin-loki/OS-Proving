pcg128_t
struct pcg_state_128*	rng
pcg128_t	bound
