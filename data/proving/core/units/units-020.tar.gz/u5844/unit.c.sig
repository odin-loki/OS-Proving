int
struct intel_guc *	guc
