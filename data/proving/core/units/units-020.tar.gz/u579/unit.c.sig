int
struct rockchip_pcie *	rockchip
u64	pci_addr
size_t	size
