int
struct lbs_private *	priv
