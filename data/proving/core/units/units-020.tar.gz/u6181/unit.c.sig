u32
struct net *	net
int	dir
u32	index
