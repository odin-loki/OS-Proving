int
vmci_mutex *	mutex
