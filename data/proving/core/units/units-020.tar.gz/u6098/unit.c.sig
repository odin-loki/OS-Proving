int
enum ice_pcie_link_width	width
