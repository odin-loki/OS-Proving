int
struct dm_pool_metadata *	pmd
