int
struct virtchnl_version_info *	ver
u32	v_opcode
u8 *	msg
u16	msglen
