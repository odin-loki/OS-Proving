bool
blk_status_t	error
