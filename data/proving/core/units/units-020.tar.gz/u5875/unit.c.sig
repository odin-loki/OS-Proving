bool
int	mode
