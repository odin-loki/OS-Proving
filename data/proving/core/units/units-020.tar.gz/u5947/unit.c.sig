int
struct xfrm_translator *	xtr
