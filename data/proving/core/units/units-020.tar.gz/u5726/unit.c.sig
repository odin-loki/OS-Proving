int
struct ubifs_wbuf *	wbuf
int	lnum
int	offs
