unsigned int
struct clk *	clk
unsigned int	scale
