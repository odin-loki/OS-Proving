int
struct xlgmac_pdata *	pdata
