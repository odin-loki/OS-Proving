u16
enum hash_alg	hash_alg
enum hash_mode	hash_mode
u32	chunksize
u16	hash_block_size
