bool
struct hl_device *	hdev
u64	addr
u64	size
bool *	is_host
