a_sle32
s32	val
