int
uint16_t	thflags
