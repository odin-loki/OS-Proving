bool
u8	status
