enum pin_config_param
unsigned long	config
