ssize_t
struct regmap *	regmap
u8 *	buf
size_t	size
unsigned int	offset
