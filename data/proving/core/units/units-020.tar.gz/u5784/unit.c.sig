u16
u16	tx_last
u16	tx_next
