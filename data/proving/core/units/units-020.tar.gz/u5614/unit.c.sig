bool
u32	ioc_status
u32	ioc_config
