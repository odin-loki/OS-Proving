int
struct imgu_device *	imgu
struct imgu_css_map *	map
size_t	size
