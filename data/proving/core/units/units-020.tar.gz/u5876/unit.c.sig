uLong
uLong	adler1
uLong	adler2
off_t	len2
