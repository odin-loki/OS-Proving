int
long	addr
