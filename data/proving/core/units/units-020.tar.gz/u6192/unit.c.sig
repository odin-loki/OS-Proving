_Bool
unsigned long	nr
const unsigned long *	ptr
