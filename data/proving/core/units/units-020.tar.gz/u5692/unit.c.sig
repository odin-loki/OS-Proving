int
struct vnic_dev *	vdev
