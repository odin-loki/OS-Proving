unsigned int
struct sk_buff *	skb
unsigned int *	bd_size
u8	max_non_tso_bd_num
unsigned int	bd_num
unsigned int	recursion_level
