resource_size_t
struct pci_dev *	dev
const struct resource *	res
resource_size_t	start
resource_size_t	size
resource_size_t	align
