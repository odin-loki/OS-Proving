int
unsigned int	dummy
