bool
unsigned int	channel
unsigned int	id
