int
struct xfrm4_protocol *	handler
unsigned char	protocol
