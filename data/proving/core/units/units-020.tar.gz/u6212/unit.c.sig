int
struct scsi_qla_host *	vha
int	vha_locked
