int
useconds_t	usec
