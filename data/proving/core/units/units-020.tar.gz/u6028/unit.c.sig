void
u32	i
u32	r_c
u32	p_b
u32 *	p
u32 *	u
