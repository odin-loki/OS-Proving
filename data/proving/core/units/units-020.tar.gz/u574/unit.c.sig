int
struct pruss *	pruss
enum pru_type	pru_type
bool	enable
