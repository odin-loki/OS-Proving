int
int	fd
char *	buf
size_t	bufsz
