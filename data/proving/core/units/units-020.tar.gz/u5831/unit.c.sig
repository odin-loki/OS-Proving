int
struct net_device *	ndev
unsigned int	entry
