u32
u32	floor
u32	ceil
