bool
dm_block_t	block_size
