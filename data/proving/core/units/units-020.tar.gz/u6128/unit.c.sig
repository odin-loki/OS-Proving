uint32_t
struct x86emu *	emu
uint32_t	d
uint8_t	s
