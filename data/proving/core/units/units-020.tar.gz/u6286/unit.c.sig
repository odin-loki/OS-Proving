int
int	brand1
int	brand2
