int
struct ipa *	ipa
size_t	size
