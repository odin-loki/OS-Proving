int
struct atmel_ssc_info *	ssc_p
