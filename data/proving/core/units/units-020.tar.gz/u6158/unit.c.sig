int
struct b43legacy_wl *	wl
