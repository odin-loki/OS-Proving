u32
u32	adm
