bool
u64	device_addr
