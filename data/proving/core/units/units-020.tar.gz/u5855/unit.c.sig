int
struct rnd_state *	rnd
int	min
int	max
