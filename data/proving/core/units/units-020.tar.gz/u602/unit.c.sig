int
struct mlx5_fs_pool *	pr_pool
struct mlx5_core_dev *	dev
size_t	encap_data_size
enum mlx5hws_action_type	reformat_type
