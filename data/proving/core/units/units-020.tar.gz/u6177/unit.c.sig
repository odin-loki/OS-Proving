bool
struct fwnet_partial_datagram *	pd
