int
struct ttyoutq *	to
const void *	buf
size_t	nbytes
