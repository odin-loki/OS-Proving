int
struct pci_dev *	pdev
unsigned int	min_vecs
