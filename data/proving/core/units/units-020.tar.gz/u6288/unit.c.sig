int
u32	wdtmode
