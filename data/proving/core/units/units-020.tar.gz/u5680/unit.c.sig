void
int	fatal
u32	errors
int *	error_found
int	handle_error
