int
int	op_bytes
