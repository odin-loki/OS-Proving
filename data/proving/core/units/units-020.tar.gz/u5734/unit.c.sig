int
struct ahash_request *	req
int	blen
int	plen
char *	out
int	secs
