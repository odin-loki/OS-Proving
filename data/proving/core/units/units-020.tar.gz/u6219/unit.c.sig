u64
u64	rate
