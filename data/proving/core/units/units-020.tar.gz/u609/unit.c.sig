netdev_features_t
struct net_device *	netdev
netdev_features_t	features
