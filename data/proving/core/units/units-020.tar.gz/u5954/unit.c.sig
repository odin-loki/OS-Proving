u32
const struct aw200xx *const	chip
u32	led_imax_uA
