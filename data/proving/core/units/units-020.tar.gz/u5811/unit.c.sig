int
struct lpfc_hba *	phba
uint64_t	time
uint32_t	size
struct Scsi_Host *	shost
