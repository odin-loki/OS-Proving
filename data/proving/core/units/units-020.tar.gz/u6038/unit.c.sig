int
struct wcd939x_sdw_priv *	wcd
struct snd_pcm_substream *	substream
struct snd_pcm_hw_params *	params
struct snd_soc_dai *	dai
