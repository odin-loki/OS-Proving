unsigned long
struct semid64_ds *	out
void *	buf
int	version
