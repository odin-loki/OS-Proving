int
struct btrfs_device *	device
bool	populate_cache
