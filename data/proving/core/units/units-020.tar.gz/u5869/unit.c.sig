int
struct xlog *	log
struct xlog_rec_header *	rhead
xfs_daddr_t	blkno
int	bufsize
