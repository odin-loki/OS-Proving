int
uint32_t	val
unsigned int *	pll_mode
