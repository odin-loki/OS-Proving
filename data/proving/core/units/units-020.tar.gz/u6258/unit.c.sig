int
struct amdgpu_device *	adev
int	atom_mem_type
