int
struct ib_mad_agent_private *	map
u16	pkey_index
