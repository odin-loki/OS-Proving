int
struct xvtc_device *	xvtc
