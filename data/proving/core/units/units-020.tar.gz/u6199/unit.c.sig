bool
unsigned int	assoclen
