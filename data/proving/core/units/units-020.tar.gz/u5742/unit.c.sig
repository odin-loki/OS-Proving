int
struct acpi_device *	adev
int	index
