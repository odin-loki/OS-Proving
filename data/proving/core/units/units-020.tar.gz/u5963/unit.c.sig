int
struct device *	dev
u32	microamp
