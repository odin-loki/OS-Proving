s64
u32	rate
