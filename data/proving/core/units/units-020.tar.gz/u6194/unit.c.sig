int
struct hclge_dev *	hdev
