int
struct nitrox_kcrypt_request *	nkreq
struct scatterlist *	dst
int	ivsize
int	buflen
