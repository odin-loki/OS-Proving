int
struct usb_hub *	hub
int	port1
int	type
u16 *	status
u16 *	change
u32 *	ext_status
