unsigned int
unsigned int	headroom
