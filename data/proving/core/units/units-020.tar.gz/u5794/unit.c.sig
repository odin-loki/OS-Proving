int
struct platform_device *	pdev
int	pool
int	size
int	elements
