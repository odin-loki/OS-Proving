bool
unsigned int	mtu
