int
enum cp2615_i2c_status	status
