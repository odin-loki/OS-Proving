u32
struct intel_guc_slpc *	slpc
