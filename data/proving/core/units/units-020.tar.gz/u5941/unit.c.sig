u32
u64	periods
u32	d1
u32	d3
