acpi_status
acpi_object_type	type_needed
acpi_object_type	this_type
void *	object
