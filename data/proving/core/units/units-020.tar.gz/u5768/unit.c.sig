int
const char *	name
struct device *	dev
struct ramoops_context *	cxt
struct persistent_ram_zone ***	przs
phys_addr_t *	paddr
size_t	mem_sz
ssize_t	record_size
unsigned int *	cnt
u32	sig
u32	flags
