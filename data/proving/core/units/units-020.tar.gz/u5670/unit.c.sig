u64
u64	vaddr
u8	vaddr_bits
