int
struct i3c_hci *	hci
struct hci_xfer *	xfer_list
int	n
