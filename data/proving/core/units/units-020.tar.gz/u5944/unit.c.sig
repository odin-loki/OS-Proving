int
struct ast_vhub *	vhub
void *	buf
size_t	size
