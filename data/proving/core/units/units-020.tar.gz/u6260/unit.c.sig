u8
u8	int_mask
u8	sts_mask
