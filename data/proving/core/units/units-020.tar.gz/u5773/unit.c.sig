int
char **	linep
const char *	delims
char *	delimp
char *	buf
int	lim
