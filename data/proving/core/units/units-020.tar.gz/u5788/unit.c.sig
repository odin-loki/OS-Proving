int
struct i40e_hw *	hw
struct i40e_dma_mem *	mem
u64	size
u32	alignment
