int
int	step_size
int	strength
