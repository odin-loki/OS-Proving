int
struct asd_ha_struct *	asd_ha
u16	ddb_site_no
u16	offs
u16	oldval
u16	newval
