int
tid_t	x
tid_t	y
