u8
int	vddvib
int	vibdrv_res
int	motor_res
int	speed
int	direction
