int
struct octep_vf_device *	oct
struct octep_vf_oq *	oq
