int
struct nilfs_segment_buffer *	segbuf
