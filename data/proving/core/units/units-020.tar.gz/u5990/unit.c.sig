bool
__le32	list
u8	feature
