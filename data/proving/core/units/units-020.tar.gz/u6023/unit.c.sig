u16
s16	lineargain
