int
struct rproc *	rproc
struct rproc_mem_entry *	mem
u32	da
u32	len
