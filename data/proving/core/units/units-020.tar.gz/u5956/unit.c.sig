snd_pcm_uframes_t
struct snd_soc_component *	component
struct snd_pcm_substream *	substream
