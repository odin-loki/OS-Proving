blk_status_t
struct scsi_cmnd *	cmd
unsigned char	op
bool	all
