double
Jim_Interp *	interp
