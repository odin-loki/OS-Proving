bool
struct intel_guc_ct *	ct
u32	len_dw
