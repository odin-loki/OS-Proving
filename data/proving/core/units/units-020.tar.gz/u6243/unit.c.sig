int
kobj_t	obj
void *	c_devinfo
