struct clip_tbl *
unsigned int	clipt_start
unsigned int	clipt_end
