int
struct ocfs2_protocol_version *	existing
struct ocfs2_protocol_version *	request
