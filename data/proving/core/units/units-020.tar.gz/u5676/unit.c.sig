int
struct rzg2l_du_vsp *	vsp
struct device_node *	np
unsigned int	crtcs
