int
struct sk_buff *	skb
const struct nfnl_info *	info
?	?
