int
enum tc_setup_type	type
void *	type_data
void *	cb_priv
