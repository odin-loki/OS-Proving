ssize_t
const struct tty_struct *	tty
