int
int	bsd_status
