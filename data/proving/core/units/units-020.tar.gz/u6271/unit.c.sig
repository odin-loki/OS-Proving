bool
struct bnge_hw_rings *	hwr
