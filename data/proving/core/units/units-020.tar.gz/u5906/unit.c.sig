int
struct mps_softc *	sc
