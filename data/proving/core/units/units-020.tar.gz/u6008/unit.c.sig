int
unsigned long *	word
unsigned long	depth
unsigned int	hint
bool	wrap
