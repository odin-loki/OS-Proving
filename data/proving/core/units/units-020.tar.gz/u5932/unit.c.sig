int
struct device *	dev
struct ispstat_buffer *	buf
unsigned int	size
