int
char *	buf
unsigned int	total_read
struct TCP_Server_Info *	server
