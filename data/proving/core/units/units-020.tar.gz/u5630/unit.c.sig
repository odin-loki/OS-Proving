seqc_t
const seqc_t *	seqcp
