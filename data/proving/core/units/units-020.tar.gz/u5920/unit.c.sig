u32
u32	fail_stats
