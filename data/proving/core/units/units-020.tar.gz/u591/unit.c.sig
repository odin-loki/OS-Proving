int
const struct pinctrl_map *	map
int	i
