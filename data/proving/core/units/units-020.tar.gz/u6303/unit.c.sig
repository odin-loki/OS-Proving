u32
u8	epnum
