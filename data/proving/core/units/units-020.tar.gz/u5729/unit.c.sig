int
struct mlxsw_sp *	mlxsw_sp
void *	priv
struct mlxsw_sp_acl_tcam *	tcam
