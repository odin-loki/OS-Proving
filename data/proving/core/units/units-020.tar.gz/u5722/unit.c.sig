int
struct iio_buffer *	r
size_t	n
const char *	buf
