ssize_t
struct file *	file
const char *	buf
size_t	datalen
loff_t *	ppos
