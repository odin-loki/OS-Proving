int
struct vchiq_instance *	instance
unsigned int	handle
short *	peer_version
