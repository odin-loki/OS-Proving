int
struct crypto_shash *	tfm_cmac
struct crypto_kpp *	tfm_ecdh
