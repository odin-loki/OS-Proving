u32
u32	pureq
