int
int32_t	hhook_type
int32_t	hhook_id
