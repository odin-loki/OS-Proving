int
struct vringh *	vrh
struct vringh_kiov *	riov
struct vringh_kiov *	wiov
u16 *	head
gfp_t	gfp
