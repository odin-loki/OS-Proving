int
suspend_state_t	state
