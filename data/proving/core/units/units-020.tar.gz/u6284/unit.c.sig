int
struct gdma_queue *	cq
struct gdma_comp *	comp
int	num_cqe
