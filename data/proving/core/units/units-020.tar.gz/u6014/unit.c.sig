long
struct sock *	other
long	timeo
