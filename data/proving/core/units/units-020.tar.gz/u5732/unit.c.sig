int
struct saa7146_dev *	dev
enum v4l2_field	field
int	in_y
int	out_y
u32*	hps_v_scale
u32*	hps_v_gain
