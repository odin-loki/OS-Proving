int
struct al_hal_eth_adapter *	adapter
