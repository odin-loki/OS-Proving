int
struct writer *	wr
struct rc *	rc
struct cstate *	cst
uint16_t *	p
int	pos_state
uint16_t *	prob
