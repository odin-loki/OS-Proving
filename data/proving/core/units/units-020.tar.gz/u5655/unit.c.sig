int
phys_addr_t	addr
