int
struct sk_buff *	skb
struct Qdisc *	sch
struct sk_buff **	to_free
