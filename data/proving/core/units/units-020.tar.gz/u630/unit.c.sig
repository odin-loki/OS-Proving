int
struct fb_var_screeninfo *	var
struct fb_info *	info
