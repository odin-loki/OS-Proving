u_short
struct mbuf *	m
int	len
int	skip
