int
struct ucred *	creds
