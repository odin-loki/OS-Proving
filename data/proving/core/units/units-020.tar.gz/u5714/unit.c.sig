int
const struct pinctrl_map *	map
struct pinctrl_setting *	setting
