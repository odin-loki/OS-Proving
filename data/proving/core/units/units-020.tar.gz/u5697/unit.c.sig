int
struct arpt_entry *	e
struct net *	net
const char *	name
unsigned int	size
struct xt_percpu_counter_alloc_state *	alloc_state
