int
unsigned int	nr
pid_t *	pids
