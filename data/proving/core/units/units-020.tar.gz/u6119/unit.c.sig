int
struct pci_dev *	dev
struct msix_entry *	entries
int	nvec
struct irq_affinity *	affd
