int
u_int	supported
u_int	alg_id
struct sadb_alg *	alg0
