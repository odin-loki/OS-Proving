int
struct device *	dev
int	dst
int	src
