int
struct nbd_device *	nbd
