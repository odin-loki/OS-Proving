int
struct device *	dev
struct exynos_ufs *	ufs
