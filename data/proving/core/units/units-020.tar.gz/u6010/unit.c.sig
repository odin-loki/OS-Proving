int
const struct ng_parse_type *	type
int	index
enum comptype	ctype
int	posn
