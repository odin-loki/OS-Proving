int
struct i915_address_space *	vm
u64	offset
u64	size
bool	intr
