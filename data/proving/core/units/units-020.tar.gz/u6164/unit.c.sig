int
int	first_minor
