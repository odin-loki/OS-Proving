vm_offset_t
vm_offset_t	loc
int	xin
