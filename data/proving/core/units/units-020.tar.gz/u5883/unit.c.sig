int
u64	boot_addr
