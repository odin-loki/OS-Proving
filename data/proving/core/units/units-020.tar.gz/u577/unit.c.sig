int
struct snd_card *	card
struct snd_es18xx *	chip
