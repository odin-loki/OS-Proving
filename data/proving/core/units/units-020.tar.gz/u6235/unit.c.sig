int
u_char *	ch
