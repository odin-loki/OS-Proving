int
s64	a
