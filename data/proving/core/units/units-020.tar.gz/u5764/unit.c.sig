int
struct sctp_tcb *	stcb
struct mbuf *	m
int	offset
int	limit
struct sockaddr *	src
struct sockaddr *	dst
struct sockaddr *	altsa
uint16_t	port
