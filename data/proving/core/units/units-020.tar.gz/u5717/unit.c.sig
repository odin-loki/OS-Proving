int
s8	val
