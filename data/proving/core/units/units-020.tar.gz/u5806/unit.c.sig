bool
int	off
int	size
enum bpf_access_type	type
const struct bpf_prog *	prog
struct bpf_insn_access_aux *	info
