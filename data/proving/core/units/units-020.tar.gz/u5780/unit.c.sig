unsigned char
int	host_strength
