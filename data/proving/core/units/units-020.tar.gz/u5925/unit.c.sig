int
struct usb_interface *	intf
int	board_id
