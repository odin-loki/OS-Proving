size_t
const struct termp *	p
int	c
