u16
struct airoha_qdma *	qdma
u16	qid
