int
struct optee *	optee
u_int	key
