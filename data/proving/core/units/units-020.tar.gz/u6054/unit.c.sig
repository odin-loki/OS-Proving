unsigned long
u8	triggering
u8	polarity
u8	shareable
u8	wake_capable
