int
int	alg
