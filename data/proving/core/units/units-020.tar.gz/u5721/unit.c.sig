int
const struct nvkm_i2c_pad_func *	func
struct nvkm_i2c *	i2c
int	id
struct nvkm_i2c_pad **	ppad
