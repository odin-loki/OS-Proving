int
struct sk_buff *	skb
const struct ethtool_mm_stats *	stats
