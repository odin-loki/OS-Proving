u16
int	field
int	line
u16	set
int	is_pal
