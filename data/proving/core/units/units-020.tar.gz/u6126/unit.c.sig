int
struct device *	dev
struct regmap *	regmap
struct bd96801_regulator_data *	data
int	num
