long
u8	clock
unsigned long	rate
