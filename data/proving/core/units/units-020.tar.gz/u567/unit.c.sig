int
struct tps6586x *	tps6586x
int	irq
int	irq_base
