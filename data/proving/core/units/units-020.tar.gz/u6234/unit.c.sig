int
u8	timing
