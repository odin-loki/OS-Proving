int
struct ucred *	cred
struct proc *	p
int	signum
