void
int	flags
