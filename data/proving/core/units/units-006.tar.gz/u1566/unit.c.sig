int
struct kprobe *	ap
