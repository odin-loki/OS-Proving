int
struct inode *	inode
bool	sync
