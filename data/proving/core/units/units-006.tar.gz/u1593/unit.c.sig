int
struct rpc_clnt *	clnt
struct rpc_xprt_iter *	xpi
