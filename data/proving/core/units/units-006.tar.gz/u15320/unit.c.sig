bool
u64	addr
u64	next
struct xe_pt_stage_bind_walk *	xe_walk
