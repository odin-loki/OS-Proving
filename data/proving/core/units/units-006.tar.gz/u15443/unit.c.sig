int
Jim_Interp *	interp
Jim_Obj *	listPtr
int	idx
Jim_Obj **	objPtrPtr
int	flags
