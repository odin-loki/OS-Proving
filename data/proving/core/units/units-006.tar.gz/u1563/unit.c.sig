u16
dma_addr_t	base
dma_addr_t	dma
