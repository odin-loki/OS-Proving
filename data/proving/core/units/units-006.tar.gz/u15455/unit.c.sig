unsigned int
unsigned int	count
