unsigned long
const wchar_t * restrict	nptr
wchar_t ** restrict	endptr
int	base
locale_t	locale
