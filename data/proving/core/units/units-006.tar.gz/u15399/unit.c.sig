int
struct em28xx *	dev
unsigned int	bus
enum em28xx_i2c_algo_type	algo_type
