int
int	tid
