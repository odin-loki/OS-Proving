u32
struct pnfs_layout_segment *	lseg
u32	commit_index
