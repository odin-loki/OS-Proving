int
struct erdma_cq *	cq
