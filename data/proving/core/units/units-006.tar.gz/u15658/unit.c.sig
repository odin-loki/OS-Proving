int
struct nvmet_ctrl *	ctrl
