int
struct stm32_fmc2_ebi *	ebi
const struct stm32_fmc2_prop *	prop
int	cs
