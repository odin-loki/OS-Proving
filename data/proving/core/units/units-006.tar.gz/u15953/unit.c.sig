int
struct isl7998x *	isl7998x
