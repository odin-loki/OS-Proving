int
struct spi_device *	spi
