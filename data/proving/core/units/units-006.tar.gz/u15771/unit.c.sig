int
struct pcpu_chunk *	chunk
int	alloc_bits
size_t	align
int	start
