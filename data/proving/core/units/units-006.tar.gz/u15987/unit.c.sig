int
enum efx_encap_type	type
