int
struct rt2x00_dev *	rt2x00dev
int	d1
int	d2
