bool
int	panel_type
