int
long	from
long	to
int	gflag
