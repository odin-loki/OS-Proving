bool
u32	status
u32	capctl
