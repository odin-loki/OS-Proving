int
struct trace_probe *	tp
void *	regs
void *	edata
