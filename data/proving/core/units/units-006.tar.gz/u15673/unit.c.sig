__u16
__u8	addr
__u16	port
