int
struct twl4030_usb *	twl
u8	module
u8	data
u8	address
