int
struct ice_tx_ring *	tx_ring
