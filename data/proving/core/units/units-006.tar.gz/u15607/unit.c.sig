u16
long	temp
