int
struct cx88_core *	core
