int
struct tpm_chip *	chip
