int
struct ths_device *	tmdev
int	id
int	reg
