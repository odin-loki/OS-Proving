int
struct mii_bus *	bus
int	phy_id
int	regnum
u16	value
