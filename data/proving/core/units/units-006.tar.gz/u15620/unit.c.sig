int
int	vactive
