int
struct ttm_device *	bdev
unsigned int	type
