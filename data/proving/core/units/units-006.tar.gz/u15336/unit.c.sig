int
int	fd
int	flags
mode_t	mode
