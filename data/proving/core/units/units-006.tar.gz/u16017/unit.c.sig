int
struct nls_table *	nls
