int
struct snd_mixer *	m
