int
struct inode *	sufile
__u64	newnsegs
