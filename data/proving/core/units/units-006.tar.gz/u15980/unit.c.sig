int
struct ubi_attach_info *	ai
int	pnum
struct ubi_vid_hdr *	vid_hdr
int	ec
