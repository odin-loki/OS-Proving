int
const unsigned int	xid
struct cifs_ses *	ses
struct smb_hdr *	in_buf
struct smb_hdr *	out_buf
int *	pbytes_returned
const int	flags
