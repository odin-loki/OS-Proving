unsigned int
unsigned int	channels
