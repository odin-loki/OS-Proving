int
int	idx
