int
union lock_subject *	subj
int	flags
int	silent
