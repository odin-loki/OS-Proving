void
struct vc_data *	vc
unsigned int	nr
