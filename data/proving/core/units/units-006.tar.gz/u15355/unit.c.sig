int
int	qdly
int	maxqdly
