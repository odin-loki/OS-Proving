int
int	sec
