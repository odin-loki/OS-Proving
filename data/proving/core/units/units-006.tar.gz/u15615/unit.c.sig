int
struct watchdog_device *	wdd
char *	buf
