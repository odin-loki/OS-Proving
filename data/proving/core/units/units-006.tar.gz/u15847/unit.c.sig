bool
enum spi_nor_protocol	proto
