int
struct dw_dma_chip *	chip
