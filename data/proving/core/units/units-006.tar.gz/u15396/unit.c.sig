int
struct c4iw_dev *	dev
struct sk_buff *	skb
