int
struct amdgpu_ip_block *	ip_block
