int
struct clkdom *	clkdom
struct ti_clk_dpll_def *	clkdef
