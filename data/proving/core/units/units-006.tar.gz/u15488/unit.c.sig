u32
u32	weight_min
u32	weight
