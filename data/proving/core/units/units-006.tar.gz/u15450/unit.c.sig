int
int	cpupid
