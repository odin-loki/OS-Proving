u32
u32	index
u32	inc
u32	sz
