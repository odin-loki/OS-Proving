int
struct idt_ntb_dev *	ndev
unsigned int	reg
spinlock_t *	reg_lock
u64	valid_mask
u64	set_bits
