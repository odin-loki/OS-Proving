int
PCOMMAND	pCmd
PSG	pSg
int	logical
