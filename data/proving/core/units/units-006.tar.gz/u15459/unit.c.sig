int
struct vmw_private *	dev_priv
int	type
