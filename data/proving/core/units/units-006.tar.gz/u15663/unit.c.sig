int
device_t	dev
