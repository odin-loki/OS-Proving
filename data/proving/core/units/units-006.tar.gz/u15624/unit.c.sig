int
int	fd
struct file *	filep
int	mode
