xfs_daddr_t
xfbno_t	blkno
