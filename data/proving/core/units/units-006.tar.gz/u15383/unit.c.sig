void
const u8 *	src
unsigned long *	rising
unsigned long *	falling
