int
struct device *	dev
struct nct7802_data *	data
