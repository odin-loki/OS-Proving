int
enum display_flags	flags
enum display_flags	high
enum display_flags	low
