int
struct cobalt *	cobalt
