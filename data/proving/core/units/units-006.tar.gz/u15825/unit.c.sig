int
void *	ptr
