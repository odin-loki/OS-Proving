enum nl80211_band
enum rtw89_band	hw_band
