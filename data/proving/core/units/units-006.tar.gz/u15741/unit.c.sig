u8
enum led_ids	id
enum led_colors	color
u8	reg_offset
