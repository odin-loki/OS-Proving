int
struct mbuf *	m
struct mbuf **	mlast
