ssize_t
struct rpmsg_endpoint *	ept
