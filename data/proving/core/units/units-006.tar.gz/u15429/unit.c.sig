long
unsigned long	insn
ppc_cpu_t	dialect
int *	invalid
