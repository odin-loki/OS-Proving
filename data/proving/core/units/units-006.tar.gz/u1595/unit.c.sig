int
struct usbnet *	dev
struct usb_interface *	intf
