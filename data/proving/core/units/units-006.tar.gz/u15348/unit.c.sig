int
struct simplefb_par *	par
struct platform_device *	pdev
