int
smp_call_func_t	fn
struct sdei_event *	event
