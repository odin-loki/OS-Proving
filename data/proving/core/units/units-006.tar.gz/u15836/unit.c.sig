int
struct drbd_connection *	connection
