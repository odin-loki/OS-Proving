int
struct iommu_domain *	domain
bool	enable
