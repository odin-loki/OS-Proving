u32
u32	reg_val
u32	shift
u32	width
