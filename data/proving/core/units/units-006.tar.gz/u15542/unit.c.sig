int
struct rds_sock *	rs
struct rds_connection *	conn
struct rds_conn_path *	cp
struct rds_message *	rm
__be16	sport
__be16	dport
int *	queued
