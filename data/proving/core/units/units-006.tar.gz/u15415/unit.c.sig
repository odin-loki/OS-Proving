int inline_size
EV_P_ int	flags
