int
__be64	a
__be64	b
