int
struct regulator_dev *	rdev
unsigned int	old_selector
unsigned int	new_selector
