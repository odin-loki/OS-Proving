u8
unsigned int	channel
