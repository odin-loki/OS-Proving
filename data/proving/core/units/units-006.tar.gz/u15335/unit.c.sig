int
struct inode *	inode
