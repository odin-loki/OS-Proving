bool
int	address
