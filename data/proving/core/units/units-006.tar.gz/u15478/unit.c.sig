__be32
__be32	vni
