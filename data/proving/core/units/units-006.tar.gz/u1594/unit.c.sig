u32
u32	imm31_12
u8	rd
u8	opcode
