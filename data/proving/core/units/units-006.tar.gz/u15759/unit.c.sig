int
struct pipe_inode_info *	pipe
struct pipe_buffer *	buf
