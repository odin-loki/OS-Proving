int
struct socket *	sock
int	level
int	optname
sockptr_t	optval
unsigned int	optlen
