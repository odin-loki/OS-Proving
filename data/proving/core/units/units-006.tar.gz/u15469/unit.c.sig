u32
fixed20_12	A
