unsigned int
sector_t	dividend
u32	divisor
