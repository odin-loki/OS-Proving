s16
s16	op1
s16	op2
