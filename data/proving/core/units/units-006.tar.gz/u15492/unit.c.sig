uint64_t
pmap_t	pmap
struct pmap_pcid *	pcidp
