int
u32	hwrm_err
