int
struct ves1820_state *	state
u32	symbolrate
