u32
u32	size
u32	elem_size
u64	flags
