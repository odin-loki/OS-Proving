long
key_serial_t	id
int	watch_queue_fd
int	watch_id
