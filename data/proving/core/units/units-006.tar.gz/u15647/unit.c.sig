u64
const u8	cos
const u8	pri_set
