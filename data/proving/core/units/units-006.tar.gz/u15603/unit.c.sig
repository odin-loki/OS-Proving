int
struct device *	dev
const char *	name
int	irq
struct regmap *	regmap
