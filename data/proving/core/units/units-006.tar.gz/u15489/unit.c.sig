int
struct device *	dev
