unsigned int
struct device *	dev
u8	reg
