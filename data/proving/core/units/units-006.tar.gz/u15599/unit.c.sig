u16
struct ice_vf *	vf
