bool
unsigned long	flags
