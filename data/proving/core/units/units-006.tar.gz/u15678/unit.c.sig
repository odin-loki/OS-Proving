void
struct lru_cache *	lc
