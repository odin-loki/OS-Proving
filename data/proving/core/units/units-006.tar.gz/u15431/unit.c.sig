bool
unsigned int	supported
unsigned int	requested
