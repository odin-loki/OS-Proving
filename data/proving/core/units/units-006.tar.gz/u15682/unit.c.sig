bool
loff_t	pos
size_t	count
