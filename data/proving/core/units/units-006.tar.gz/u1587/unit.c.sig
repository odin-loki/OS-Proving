int
int	ffd
int	tfd
const struct group *	gr
struct group *	old_gr
