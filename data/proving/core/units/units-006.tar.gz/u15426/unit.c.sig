int
struct gpio_chip *	gc
