int
u8	node_num
