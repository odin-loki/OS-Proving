int
struct snd_emu10k1 *	emu
