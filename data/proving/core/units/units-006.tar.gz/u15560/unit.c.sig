int
struct iio_dev *	indio_dev
struct stm32_adc *	adc
struct iio_chan_spec *	channels
int	nchans
