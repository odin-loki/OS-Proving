int
int	node
int *	adist
