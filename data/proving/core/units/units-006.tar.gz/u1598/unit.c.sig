s32
int	degrees
