int
u32	raw_temp
int	temp_factor
