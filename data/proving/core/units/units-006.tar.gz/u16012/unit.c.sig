int
struct i2c_adapter *	adap
