bool
u32	key
