int
struct lcp *	lcp
u_short	proto
