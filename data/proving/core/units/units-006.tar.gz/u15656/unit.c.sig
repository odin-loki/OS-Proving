int
struct bcm_qspi *	qspi
struct qspi_trans *	qt
int	flags
