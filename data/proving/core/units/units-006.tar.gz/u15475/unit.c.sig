unsigned long
const int *	ip
