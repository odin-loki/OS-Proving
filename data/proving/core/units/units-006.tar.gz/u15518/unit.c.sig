int
struct iio_buffer *	buffer
int	bit
