int
struct platform_device *	pdev
struct vpdma_data *	vpdma
?	?
