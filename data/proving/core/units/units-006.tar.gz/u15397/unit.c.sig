int
struct max8925_power_info *	info
int	type
