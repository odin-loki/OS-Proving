int
const char * restrict	fmt
va_list	ap
