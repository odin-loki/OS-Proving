u32
u32	frame_width
u32	frame_height
u32	num_vpp_pipes
