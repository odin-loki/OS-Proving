bool
struct vmw_private *	dev_priv
u64	pitch
u64	height
