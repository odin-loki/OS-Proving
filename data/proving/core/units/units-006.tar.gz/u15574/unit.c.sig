bool
unsigned long	val
