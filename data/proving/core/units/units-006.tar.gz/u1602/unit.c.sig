long
u8	reg
u8	nr
const u16 *	scales
