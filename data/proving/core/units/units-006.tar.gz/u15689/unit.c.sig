int
struct sock *	sk
