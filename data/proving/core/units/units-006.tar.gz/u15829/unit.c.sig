int
struct hid_device *	hdev
