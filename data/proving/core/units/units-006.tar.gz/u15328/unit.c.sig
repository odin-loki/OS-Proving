int
struct platform_device *	pdev
struct cygnus_audio *	cygaud
