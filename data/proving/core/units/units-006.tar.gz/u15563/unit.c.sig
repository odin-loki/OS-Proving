int
struct clk *	clk
