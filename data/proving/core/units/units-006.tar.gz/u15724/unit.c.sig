int
struct snd_pcxhr *	chip
