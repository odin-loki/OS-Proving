size_t
const struct symbol *	sym
