unsigned int
int	len
int	enh_desc
