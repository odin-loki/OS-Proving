int
const struct wiimod_ops *	ops
struct wiimote_data *	wdata
