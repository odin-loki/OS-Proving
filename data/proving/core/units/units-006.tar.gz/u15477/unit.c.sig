int
struct nvkm_fifo *	fifo
