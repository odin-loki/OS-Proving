u16
u8 *	pdata
int	length
