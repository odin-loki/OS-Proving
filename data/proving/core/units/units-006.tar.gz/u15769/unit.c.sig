int
unsigned long	start
unsigned long	end
unsigned long	flags
