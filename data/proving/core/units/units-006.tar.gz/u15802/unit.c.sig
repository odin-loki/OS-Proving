ssize_t
struct file *	filp
struct kobject *	kobj
const struct bin_attribute *	attr
char *	buf
loff_t	offset
size_t	count
