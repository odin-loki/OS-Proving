int
u64	mask
