int
const struct bpf_insn *	insn
int	dst_reg
struct rv_jit_context *	ctx
