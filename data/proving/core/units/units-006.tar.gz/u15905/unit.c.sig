void
u64 *	cntr
