unsigned int
unsigned long	clk_rate
unsigned int	cycles
