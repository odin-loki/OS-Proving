int
const int	type
const int	status
