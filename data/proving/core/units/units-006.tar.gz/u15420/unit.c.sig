int
struct dlm_lock_resource *	res
struct dlm_master_list_entry *	mle
int	to
