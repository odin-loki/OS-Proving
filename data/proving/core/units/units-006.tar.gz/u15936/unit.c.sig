unsigned int
unsigned int	mode
