int
const struct netmap_adapter *	na
unsigned	mtu
