int
struct virtqueue *	vq
spinlock_t *	lock
