int
unsigned int	mask
int	a
int	b
