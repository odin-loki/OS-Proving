bool
u16	flag
