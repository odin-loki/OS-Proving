int
unsigned long	num_pages
