u32
int	cpu
