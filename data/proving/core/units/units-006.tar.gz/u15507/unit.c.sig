int
int	mc_seq_vram_type
