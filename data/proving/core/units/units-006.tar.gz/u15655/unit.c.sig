int
struct hfi1_devdata *	dd
u16	first
u16	last
bool	set
