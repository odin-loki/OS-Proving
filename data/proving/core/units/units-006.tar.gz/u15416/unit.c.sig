int
enum ib_qp_type	qp_type
u32	create_flags
