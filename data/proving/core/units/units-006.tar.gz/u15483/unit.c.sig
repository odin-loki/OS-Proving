int
struct irq_data *	data
unsigned int	on
