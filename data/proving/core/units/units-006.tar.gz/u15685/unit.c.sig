int
int64_t	a
uint64_t	b
