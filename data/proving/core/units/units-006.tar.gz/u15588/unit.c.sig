bool
u32	adckt
u32	if_freq
