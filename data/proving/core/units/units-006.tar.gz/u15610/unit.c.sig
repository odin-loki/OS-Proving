int
struct scsi_device *	sdev
struct gendisk *	unused
sector_t	capacity
?	?
