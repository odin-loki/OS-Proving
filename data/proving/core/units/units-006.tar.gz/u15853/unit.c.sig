int
lba_t	blk
size_t	sz
off_t	ofs
int	fd
