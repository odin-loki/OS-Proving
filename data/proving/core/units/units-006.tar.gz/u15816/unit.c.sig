u32
struct radeon_device *	rdev
