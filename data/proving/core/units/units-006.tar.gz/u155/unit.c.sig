int
struct rpc_xprt *	xprt
unsigned int	min_reqs
