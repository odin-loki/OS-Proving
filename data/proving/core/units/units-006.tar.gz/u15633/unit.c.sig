int
struct cqspi_softc *	sc
