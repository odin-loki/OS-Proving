int
struct bpf_prog *	prog
struct bpf_jit_poke_descriptor *	poke
