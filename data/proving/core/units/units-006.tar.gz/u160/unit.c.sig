int
const unsigned char *	buf
unsigned int	step_size
unsigned char *	code
bool	sm_order
