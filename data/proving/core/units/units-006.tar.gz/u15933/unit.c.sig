int
struct intel_pmc_dev *	pmc
u32	offset
u32	mask
u32	val
