int
struct mlx4_ib_dev *	dev
struct mlx4_ib_cq_buf *	buf
struct ib_umem **	umem
u64	buf_addr
int	cqe
