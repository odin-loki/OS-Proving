int
u_long	cmd
struct ieee80211vap *	vap
struct ifnet *	ifp
