bool_t
AUTH *	auth
XDR*	xdrs
xdrproc_t	xdr_args
void *	args_ptr
