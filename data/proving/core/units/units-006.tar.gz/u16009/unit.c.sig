bool
long	v
long	min
long	max
