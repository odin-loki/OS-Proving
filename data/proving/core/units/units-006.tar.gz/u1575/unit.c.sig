int
int	val
u8	vrm
