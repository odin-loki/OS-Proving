int
struct fb_info *	fbi
unsigned long	size
unsigned long	paddr
