int
struct batadv_priv *	bat_priv
