int
struct cs35l41_hda *	cs35l41
const char *	hid
int	id
