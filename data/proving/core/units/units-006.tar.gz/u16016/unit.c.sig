int
struct mii_bus *	bus
int	phy
