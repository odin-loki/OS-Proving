bool
unsigned int *	childnotready
