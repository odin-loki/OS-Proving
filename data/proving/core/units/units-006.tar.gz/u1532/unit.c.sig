int
long	val
