int
struct block_device *	bdev
int	mirror
