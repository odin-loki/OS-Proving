int
struct ipu6_device *	isp
const void *	metadata
u32	meta_size
