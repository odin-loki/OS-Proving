int
struct i40e_hw *	hw
