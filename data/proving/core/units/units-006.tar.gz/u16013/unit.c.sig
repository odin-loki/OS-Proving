int
struct echoaudio *	chip
u16	device_id
u16	subdevice_id
