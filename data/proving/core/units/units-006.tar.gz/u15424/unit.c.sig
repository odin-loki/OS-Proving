short
struct hpi_adapter_obj *	pao
u8 *	p_data
u32	data_size
int	operation
