int
struct rtwn_softc *	sc
