u16
u32	key
