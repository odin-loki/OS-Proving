int
volatile u_long *	_ptr
u_long *	_old
u_long	_new
