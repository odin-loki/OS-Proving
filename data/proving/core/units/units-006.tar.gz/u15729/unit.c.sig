int
enc_softc_t *	enc
enc_cache_t *	enc_cache
uint8_t *	buf
int	bufsiz
int	eip
int	nobj
