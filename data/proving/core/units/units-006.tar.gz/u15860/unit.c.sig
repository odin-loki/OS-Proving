bool
struct vringh *	vrh
