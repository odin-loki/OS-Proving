void
const char * restrict	p
size_t * restrict	len
