u32
u16	n
