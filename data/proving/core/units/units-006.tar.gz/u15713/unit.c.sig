unsigned long
unsigned long	npages
