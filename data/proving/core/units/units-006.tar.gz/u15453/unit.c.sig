int
struct qed_dev *	cdev
