int
struct ptp_clock_info *	info
s64	delta
