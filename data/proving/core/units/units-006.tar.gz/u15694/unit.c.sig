int
struct amdgpu_device *	adev
