bool
unsigned int	mclk
unsigned int	base_freq
