int
struct stm_data *	data
unsigned int	master
unsigned int	channel
