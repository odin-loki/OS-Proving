int
const char *	fname
