int
int	i
atomic_t *	v
