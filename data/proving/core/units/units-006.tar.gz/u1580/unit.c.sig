int
struct ptp_clock_info *	ptp
long	scaled_ppm
