unsigned int
char	c
