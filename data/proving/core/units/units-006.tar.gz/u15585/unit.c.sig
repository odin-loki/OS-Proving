u8
u8	ca_ack_delay
u8	packet_life_time
