int
struct hda_codec *	codec
