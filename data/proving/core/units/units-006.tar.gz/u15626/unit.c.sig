u64
u64	start
u64	max_addr
u64	size
