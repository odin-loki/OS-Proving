int
cnd_t *	cnd
