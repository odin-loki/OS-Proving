int
struct rt2x00_dev *	rt2x00dev
