u32
u32	startup_time
u32	adc_clk_khz
