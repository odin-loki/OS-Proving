u8
struct hostapd_data *	hapd
