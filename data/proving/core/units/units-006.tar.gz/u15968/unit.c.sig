int
struct xlog *	log
struct list_head *	buffer_list
struct xlog_recover_item *	item
xfs_lsn_t	lsn
