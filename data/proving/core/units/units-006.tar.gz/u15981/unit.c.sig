int
struct av7110 *	av7110
char *	buf
unsigned int	len
int	nonblock
