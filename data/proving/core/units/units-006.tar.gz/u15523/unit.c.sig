bool
__be32	addr
