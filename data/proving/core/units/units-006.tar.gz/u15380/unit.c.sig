int
struct xfs_btree_cur *	cur
const union xfs_btree_ptr *	start
union xfs_btree_ptr *	new
int *	stat
