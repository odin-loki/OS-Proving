int
struct amdgpu_device *	adev
const char *	chip_name
