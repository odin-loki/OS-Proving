int
struct adapter *	adapter
int	reg
u32	mask
int	polarity
int	attempts
int	delay
