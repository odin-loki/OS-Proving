int
struct device *	dev
struct tas2764_priv *	tas2764
