int
struct mtk_scp *	scp
