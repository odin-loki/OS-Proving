u64
u64	maxtime
