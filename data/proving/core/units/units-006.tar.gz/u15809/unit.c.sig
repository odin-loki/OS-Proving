bool
s64	value
