int
struct pvscsi_adapter *	adapter
