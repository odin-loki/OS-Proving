unsigned long
unsigned long	a
unsigned long	bits
const struct word_at_a_time *	c
