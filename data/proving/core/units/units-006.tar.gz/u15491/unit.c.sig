int
struct amdgpu_ring *	ring
