int
struct snd_rawmidi_substream *	substream
