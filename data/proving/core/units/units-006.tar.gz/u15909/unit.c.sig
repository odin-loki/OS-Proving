void
unsigned *	head
unsigned short *	list
unsigned short	id
