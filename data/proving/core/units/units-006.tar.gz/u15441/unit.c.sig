u32
u8	phy_map
u8	type
