int
int	percent
