int
struct sysconfig_priv *	priv
