__u64
const void *	ptr
