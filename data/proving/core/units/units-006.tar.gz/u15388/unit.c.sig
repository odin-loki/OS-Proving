bool
u32	flags
