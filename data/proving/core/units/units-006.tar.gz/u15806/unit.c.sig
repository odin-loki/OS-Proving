int
struct ib_ah *	ah
u32	flags
