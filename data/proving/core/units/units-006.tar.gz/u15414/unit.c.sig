int
u32 *	compose
u32	crop
u32	flags
