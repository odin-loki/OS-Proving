int
union ccb *	ccb
