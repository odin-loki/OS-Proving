int
struct ath_softc *	sc
