bool
u32	val
