int
const struct qe_firmware *	firmware
