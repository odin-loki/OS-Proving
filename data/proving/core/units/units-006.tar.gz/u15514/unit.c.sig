int
struct device_node *	np
struct at91_pin_group *	grp
struct at91_pinctrl *	info
u32	index
