enum ice_fc_mode
u8	caps
