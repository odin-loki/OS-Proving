int
int	c
