int
const struct uverbs_attr_bundle *	bundle
size_t	idx
