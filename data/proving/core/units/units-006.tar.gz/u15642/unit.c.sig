unsigned long
struct nvme_ctrl *	ctrl
bool	is_admin
