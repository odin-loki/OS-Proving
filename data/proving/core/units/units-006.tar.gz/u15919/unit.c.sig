int
struct ci_hw_req *	hwreq
int	index
bool	copy
unsigned int *	bounced
