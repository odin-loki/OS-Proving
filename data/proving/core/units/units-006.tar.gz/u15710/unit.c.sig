int
bool	unresolved
int	maxvif
