int
vortex_t *	chip
int	idx
int	nr
