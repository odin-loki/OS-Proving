u8
unsigned int	a
unsigned int	b
