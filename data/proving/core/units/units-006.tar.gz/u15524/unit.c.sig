uint32_t
uint32_t *	rfBuf
uint32_t	numBits
uint32_t	firstBit
uint32_t	column
