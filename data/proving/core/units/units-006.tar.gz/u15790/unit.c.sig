int
int	blanks
int	blanke
int	total
int	line
