unsigned int
struct cdns2_endpoint *	pep
u64	addr
u64	len
