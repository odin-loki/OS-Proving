enum req_op
u32	dpf
