int
s16	val
