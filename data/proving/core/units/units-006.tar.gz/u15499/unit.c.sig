int
struct ipmi_softc *	sc
