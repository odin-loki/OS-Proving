int
u32	kprec
