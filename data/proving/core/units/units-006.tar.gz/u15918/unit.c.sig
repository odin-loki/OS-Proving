int
int	cam_status
int	x_status
