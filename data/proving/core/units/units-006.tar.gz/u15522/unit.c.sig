int
struct elf64_hdr *	hdr
