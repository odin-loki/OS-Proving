int
struct task_struct *	t
unsigned long	which
unsigned long	ctrl
