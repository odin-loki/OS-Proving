int
struct velocity_info *	vptr
int	budget_left
