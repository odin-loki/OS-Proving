int
struct fis_image_desc *	img
