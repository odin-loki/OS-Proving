int
struct tty_struct *	tty
struct usb_serial_port *	port
const unsigned char *	buf
int	count
