int
struct scsi_cmnd *	scp
unsigned long long	lba
unsigned int	num
bool	write
