u32
u32	adv
