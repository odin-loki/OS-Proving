int
struct iwl_fw_runtime *	fwrt
u32 *	value
