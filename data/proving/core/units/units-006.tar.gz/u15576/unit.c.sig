uint16_t
uint32_t	state
