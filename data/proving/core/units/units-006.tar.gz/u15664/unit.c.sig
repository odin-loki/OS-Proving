int
struct ptp_clock_info *	ptp_info
s64	delta_ns
