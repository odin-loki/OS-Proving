unsigned int
enum intel_vgpu_edid	id
