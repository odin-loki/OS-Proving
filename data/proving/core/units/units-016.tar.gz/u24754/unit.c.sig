int
struct regmap_field *	field
unsigned int	bits
