unsigned
int	namelen
secno	down_ptr
