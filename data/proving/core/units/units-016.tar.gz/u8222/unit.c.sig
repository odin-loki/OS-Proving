int
struct cdns *	cdns
