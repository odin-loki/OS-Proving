int
unsigned int	phys_addr
unsigned int	fn
unsigned int	sz
