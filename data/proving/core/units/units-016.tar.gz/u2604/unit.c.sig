uint8_t
struct rtsx_softc *	sc
uint32_t	phase_map
