int
struct ena_ring *	ring
u16	req_id
struct ena_tx_buffer *	tx_info
bool	is_xdp
