int
const char *	buf
const char *	fmt
va_list	args
