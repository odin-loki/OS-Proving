int
struct ice_port_info *	pi
u32	agg_id
