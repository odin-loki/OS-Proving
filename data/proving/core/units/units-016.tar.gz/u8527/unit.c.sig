bool
unsigned int	status
