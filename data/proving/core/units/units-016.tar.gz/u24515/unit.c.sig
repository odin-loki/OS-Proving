int
struct mmc_spi_host *	host
unsigned int	len
