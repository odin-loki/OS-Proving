bool
struct cma *	cma
const struct folio *	folio
