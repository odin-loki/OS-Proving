bool
struct NTFS_RECORD_HEADER *	rhdr
size_t	bytes
