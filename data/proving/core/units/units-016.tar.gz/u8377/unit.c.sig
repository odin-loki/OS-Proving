int
char *	buf
