int
struct fimc_ctx *	ctx
int	sw
int	sh
int	dw
int	dh
int	rotation
