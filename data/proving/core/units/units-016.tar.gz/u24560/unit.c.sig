unsigned int
struct rnd_state *	rng
unsigned int	max_len
