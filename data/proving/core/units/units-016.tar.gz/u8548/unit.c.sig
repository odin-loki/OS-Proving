int
int	ringval
