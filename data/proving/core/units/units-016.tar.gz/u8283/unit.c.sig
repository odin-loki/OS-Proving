u8
int	val
