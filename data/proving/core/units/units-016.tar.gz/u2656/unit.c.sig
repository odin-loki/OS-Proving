int
struct tbl_node *	tbl
int	still_open
