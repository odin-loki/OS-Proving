u64
struct xe_gt *	gt
