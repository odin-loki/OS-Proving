int
long	timeo
