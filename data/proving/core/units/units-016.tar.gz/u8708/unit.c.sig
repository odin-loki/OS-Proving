int
int	sock
_Bool	quite
