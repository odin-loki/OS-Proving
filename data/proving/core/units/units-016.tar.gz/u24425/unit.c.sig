int
struct clk_hw *	hw
