u16
int	s_hum
u16	curr_thresh
