u32
const struct net *	net
const struct in6_addr *	addr
