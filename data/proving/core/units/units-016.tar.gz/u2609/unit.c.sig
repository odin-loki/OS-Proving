int
int	tx_size
