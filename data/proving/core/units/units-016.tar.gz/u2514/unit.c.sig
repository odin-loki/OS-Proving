int
struct scd4x_state *	state
enum scd4x_cmd	cmd
uint16_t	arg
void *	response
int	response_sz
