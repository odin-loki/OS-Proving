bits64
float64	a
