unsigned long
unsigned long	mask
