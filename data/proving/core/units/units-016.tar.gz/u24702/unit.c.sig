int
struct dma_xfer *	xfer
struct wrapper_list *	wrappers
struct ioctl_resources *	resources
u32	msg_hdr_len
u32 *	size
struct wire_trans_dma_xfer **	out_trans
