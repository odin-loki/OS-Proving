int
struct scsi_host_template *	SHT
