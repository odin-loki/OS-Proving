unsigned int
unsigned int	fun_fec
