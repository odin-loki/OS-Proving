int
struct clknode *	clk
uint64_t *	freq
