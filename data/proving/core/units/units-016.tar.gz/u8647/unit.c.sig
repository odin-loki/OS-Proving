long
struct file *	file
struct cifs_tcon *	tcon
unsigned long long	offset
unsigned long long	len
bool	keep_size
