int
struct stmmac_priv *	priv
