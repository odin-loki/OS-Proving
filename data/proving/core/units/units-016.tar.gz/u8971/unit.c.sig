bool
struct nl_writer *	nw
int	attr
const struct sockaddr *	sa
