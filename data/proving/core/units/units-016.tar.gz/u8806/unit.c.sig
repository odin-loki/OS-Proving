int
struct nand_device *	nand
const unsigned char *	buf
unsigned char *	code
