int
struct em28xx *	dev
int	expected_feat
