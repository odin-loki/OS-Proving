int
int	delta
int	prob
