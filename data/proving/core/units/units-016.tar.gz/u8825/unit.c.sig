int
struct kvm_vcpu *	vcpu
struct kvm_run *	run
struct kvm_cpu_trap *	trap
