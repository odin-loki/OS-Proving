efx_rc_t
efx_nic_t *	enp
