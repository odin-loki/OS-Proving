bool
__be16	sid
