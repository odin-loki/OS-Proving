int
int32_t	opmask
