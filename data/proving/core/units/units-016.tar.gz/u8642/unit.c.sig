int
unsigned char *	buf
size_t	buf_size
