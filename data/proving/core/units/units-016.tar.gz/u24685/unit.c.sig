unsigned int
struct dw_pcie_ep *	ep
u8	func_no
