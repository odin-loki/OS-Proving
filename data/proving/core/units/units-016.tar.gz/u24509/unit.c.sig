bool
struct inode *	inode
struct folio *	ifolio
