unsigned
const seqcount_latch_t *	s
