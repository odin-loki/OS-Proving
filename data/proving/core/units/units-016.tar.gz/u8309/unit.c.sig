int
struct flex_spi_softc *	sc
uint32_t	rate
