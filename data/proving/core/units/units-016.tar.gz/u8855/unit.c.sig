unsigned int
unsigned int	mode
unsigned int	channels
