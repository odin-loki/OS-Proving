int
struct tegra_xusb *	tegra
