bool
struct ghcb *	ghcb
struct pt_regs *	regs
