int
struct lcd_device *	dev
int	value
