int
struct lpfc_hba *	phba
