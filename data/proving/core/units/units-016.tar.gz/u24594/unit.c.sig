u8
u32	memory_clock
bool	strobe_mode
