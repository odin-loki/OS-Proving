int
struct spmi_pmic_arb_bus *	bus
int	index
