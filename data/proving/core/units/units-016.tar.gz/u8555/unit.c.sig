uint8_t
usb_size_t *	ptr
uint8_t	start
uint8_t	end
uint8_t	mask
