pteval_t
pte_t	pte
