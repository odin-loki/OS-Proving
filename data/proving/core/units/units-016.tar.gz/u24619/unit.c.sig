int
struct dma_chan *	dchan
