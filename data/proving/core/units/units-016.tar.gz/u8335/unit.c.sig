unsigned int
int	space
int	wscale_ok
int	win_clamp
