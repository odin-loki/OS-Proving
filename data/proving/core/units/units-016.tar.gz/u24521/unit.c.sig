int
struct dma_buf *	dma_buf
struct vm_area_struct *	vma
