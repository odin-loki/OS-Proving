ssize_t
struct vmci_qpair *	qpair
void *	iov
size_t	iov_size
int	buf_type
