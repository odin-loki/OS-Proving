int
struct pcache_cache *	cache
