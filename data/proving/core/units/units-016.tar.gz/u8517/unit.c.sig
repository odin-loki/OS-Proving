bool
int	page_type
