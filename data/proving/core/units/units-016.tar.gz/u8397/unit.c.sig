unsigned long
struct n_tty_data *	ldata
