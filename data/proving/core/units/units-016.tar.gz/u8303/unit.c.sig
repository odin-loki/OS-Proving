unsigned int
u32	seq
unsigned int	hmask
