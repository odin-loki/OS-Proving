int
struct ixl_pf_qmgr *	qmgr
u16	num
struct ixl_pf_qtag *	qtag
