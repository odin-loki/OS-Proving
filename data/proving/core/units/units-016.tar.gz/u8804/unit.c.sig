unsigned int
u32	cmd
