bool
u32	a
u32	b
