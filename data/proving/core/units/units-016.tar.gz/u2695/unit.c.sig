int
struct gve_priv *	priv
