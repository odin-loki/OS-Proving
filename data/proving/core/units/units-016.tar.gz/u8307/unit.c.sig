int
ipf_main_softc_t *	softc
void *	arg
int	otype
int	unit
void *	data
