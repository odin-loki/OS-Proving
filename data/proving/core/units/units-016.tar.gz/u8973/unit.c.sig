int
struct sock *	sk
struct sk_buff *	skb
int *	ns
int *	nr
int *	q
int *	d
int *	m
