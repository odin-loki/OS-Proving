u32
u32	bitsize
