u_int
u_int	addrspace
