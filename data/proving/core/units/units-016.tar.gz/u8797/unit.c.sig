int
struct service_processor *	sp
struct event_reader *	reader
