int
struct tpm_chip *	chip
struct tpm_buf *	buf
