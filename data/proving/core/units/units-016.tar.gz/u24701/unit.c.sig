u32
u16	image_width_roundup
u8	bytespp
