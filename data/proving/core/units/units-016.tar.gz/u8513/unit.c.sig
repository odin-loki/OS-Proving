arm_v7s_iopte
arm_v7s_iopte	pte
int	lvl
