int
struct lsm_prop *	prop
u32	field
u32	op
void *	lsmrule
