bool
unsigned int	type
