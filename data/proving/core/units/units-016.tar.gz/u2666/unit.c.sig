int
struct aq_nic_s *	aq_nic
struct aq_hw_rx_fltrs_s *	rx_fltrs
struct ethtool_rx_flow_spec *	fsp
