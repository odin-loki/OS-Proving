int
struct futex_vector *	v
int	count
