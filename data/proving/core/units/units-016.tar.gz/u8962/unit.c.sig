int
s32	mode
int	tempo1
int	tempo2
int	tempo3
