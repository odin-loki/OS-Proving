int
struct uart_softc *	sc
