int
unsigned int	step
