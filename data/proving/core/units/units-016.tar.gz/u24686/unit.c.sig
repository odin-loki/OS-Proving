int
int	safe_needed
