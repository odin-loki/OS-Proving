int
struct device_node *	node
struct device_node *	parent
