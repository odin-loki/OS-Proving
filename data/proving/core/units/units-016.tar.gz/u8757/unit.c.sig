unsigned long
unsigned long	ticks
unsigned long	nsec
int	shift
