struct pruss *
struct rproc *	rproc
