int
unixFile *	pFile
int	lockType
int	ofst
int	n
