int
struct imx_tve *	tve
