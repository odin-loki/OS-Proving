u32
int	rate
