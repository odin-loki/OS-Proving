u32
u16	bitrate
bool	short_pre
bool	cck
int	len
