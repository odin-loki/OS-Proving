int
struct pci_dev *	ubox_dev
int	nodeid_loc
int	idmap_loc
int *	nodeid
int *	groupid
