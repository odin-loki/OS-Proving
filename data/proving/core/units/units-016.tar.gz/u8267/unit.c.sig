int
long	shuffint
