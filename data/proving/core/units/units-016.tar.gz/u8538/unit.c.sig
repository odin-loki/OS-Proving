int
u32 *	uaddr1
unsigned int	flags1
u32 *	uaddr2
unsigned int	flags2
int	nr_wake
int	nr_requeue
u32 *	cmpval
int	requeue_pi
