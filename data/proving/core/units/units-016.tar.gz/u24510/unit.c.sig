int
uint8_t	ringsize
uint8_t	first
uint8_t	last
