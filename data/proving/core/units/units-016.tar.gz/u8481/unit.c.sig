int
struct ks8851_net *	ks
