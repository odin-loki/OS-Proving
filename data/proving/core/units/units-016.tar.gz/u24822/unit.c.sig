u32
unsigned int	cpu
