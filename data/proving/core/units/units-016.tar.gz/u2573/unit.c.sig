u32
u32	prev
