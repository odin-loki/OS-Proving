int
struct apr_device *	adev
