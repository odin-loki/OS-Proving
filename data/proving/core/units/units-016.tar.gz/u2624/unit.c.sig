bool
u8	flags
