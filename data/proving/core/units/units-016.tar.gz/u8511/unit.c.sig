int
struct ccp_cmd *	cmd
