unsigned int
unsigned int	input_rate
unsigned int	output_rate
