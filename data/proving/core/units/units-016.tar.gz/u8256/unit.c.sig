int
struct cmdq_pkt *	pkt
