int
struct xdab_bitmap *	bitmap
xfs_dablk_t	dabno
xfs_extlen_t	len
