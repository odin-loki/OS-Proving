int
struct tegra_emc *	emc
