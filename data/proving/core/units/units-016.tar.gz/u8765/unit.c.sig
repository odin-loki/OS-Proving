unsigned long
struct regmap *	regmap
unsigned long	parent_rate
