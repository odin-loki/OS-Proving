enum cc_fec
fw_port_cap32_t	fw_fec
