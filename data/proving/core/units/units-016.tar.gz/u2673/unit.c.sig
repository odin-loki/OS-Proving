int
int	var
