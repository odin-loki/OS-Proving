int
struct ptp_clock_info *	info
long	scaled_ppm
