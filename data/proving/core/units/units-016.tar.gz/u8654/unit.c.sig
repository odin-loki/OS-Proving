int
unsigned long	pfn
unsigned long	nr_pages
