int
struct kunit *	test
int	wmfw_ver
