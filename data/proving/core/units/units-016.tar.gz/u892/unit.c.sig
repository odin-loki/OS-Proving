int
int	min_id
int	max_id
