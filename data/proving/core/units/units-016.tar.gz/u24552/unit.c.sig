unsigned long
unsigned long	freq
