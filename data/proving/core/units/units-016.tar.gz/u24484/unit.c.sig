u32
enum sparx5_core_clockfreq	cclock
