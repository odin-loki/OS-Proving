int
struct nx_host_sds_ring *	sds_ring
int	max
