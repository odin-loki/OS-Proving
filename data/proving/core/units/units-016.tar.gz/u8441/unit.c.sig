int
MPT_ADAPTER *	ioc
int	nonblock
