void
ktime_t	absexp
enum alarmtimer_type	type
