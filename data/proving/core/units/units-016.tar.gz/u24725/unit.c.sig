int
int	p1_pt
int	p2_pt
