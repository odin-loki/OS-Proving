int
const struct nft_ctx *	ctx
const struct nft_expr *	expr
?	?
