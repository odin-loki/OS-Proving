bool
atomic_t *	v
