int
struct arm_smmu_domain *	smmu_domain
struct arm_smmu_device *	smmu
struct device *	dev
