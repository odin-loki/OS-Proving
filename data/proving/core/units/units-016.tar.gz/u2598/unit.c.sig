pcg128_t
struct pcg_state_setseq_128*	rng
pcg128_t	bound
