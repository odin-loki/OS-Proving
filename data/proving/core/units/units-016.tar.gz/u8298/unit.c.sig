u32
struct bcma_drv_cc *	cc
