unsigned long
unsigned long	rate
