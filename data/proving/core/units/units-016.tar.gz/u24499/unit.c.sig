int
u16	a
u16	b
