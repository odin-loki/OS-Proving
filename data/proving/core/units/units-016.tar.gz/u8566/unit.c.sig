u64
unsigned int	threshold
int	accel_hz
int	accel_uhz
