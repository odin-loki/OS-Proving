enum insn_type
bool	null
bool	tail
