bool
u32	user
enum ip_defrag_users	lower_bond
enum ip_defrag_users	upper_bond
