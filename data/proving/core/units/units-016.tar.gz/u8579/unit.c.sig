u32
u32	full_range
