int
sqlite3_file *	pJfd
sqlite_int64	size
