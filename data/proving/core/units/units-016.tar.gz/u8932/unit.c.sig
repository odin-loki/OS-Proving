int
struct snd_rme9652 *	s
