int
struct pfn_batch *	batch
size_t	max_pages
void *	backup
size_t	backup_len
