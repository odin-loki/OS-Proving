int
struct wl1271 *	wl
struct wl12xx_vif *	wlvif
struct cfg80211_sched_scan_request *	req
