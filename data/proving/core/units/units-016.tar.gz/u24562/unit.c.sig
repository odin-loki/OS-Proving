int32_t
ocs_domain_t *	domain
