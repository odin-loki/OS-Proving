int
journal_t *	journal
