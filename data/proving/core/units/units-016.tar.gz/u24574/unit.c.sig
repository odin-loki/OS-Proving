bool
struct zspage *	zspage
