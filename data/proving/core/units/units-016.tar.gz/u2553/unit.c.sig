ssize_t
struct file *	file
struct kobject *	kobj
const struct bin_attribute *	attr
char *	buf
loff_t	off
size_t	count
