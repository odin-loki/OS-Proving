bool
unsigned int	fid_mode
u32	mask
