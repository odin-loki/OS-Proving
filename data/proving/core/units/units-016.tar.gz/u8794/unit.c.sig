bool
struct cxl_dev_state *	cxlds
void *	ras_base
