int
struct adis *	adis
