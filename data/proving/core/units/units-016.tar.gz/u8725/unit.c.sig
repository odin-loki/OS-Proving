unsigned int
unsigned long	x
unsigned long	y
