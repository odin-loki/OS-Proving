int
struct wil6210_vif *	vif
int	ringid
