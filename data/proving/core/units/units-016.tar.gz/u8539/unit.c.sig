int
struct st_buffer *	STbp
const unsigned int	max_pages
unsigned long	uaddr
size_t	count
int	rw
