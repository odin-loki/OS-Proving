int
struct g_provider *	pp
int	dr
int	dw
int	de
