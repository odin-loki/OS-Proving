int
struct my_softc *	sc
struct my_chain_onefrag *	c
