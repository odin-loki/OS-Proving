size_t
size_t	srcSize
ZSTD_strategy	strat
