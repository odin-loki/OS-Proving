_Bool
const struct list *	list
