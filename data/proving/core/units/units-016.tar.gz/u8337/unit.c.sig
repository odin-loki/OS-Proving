unsigned int
struct raid_set *	rs
