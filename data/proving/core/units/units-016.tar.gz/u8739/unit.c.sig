u32
u64	val
unsigned int	bits
