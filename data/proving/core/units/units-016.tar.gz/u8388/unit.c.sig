int
struct tsl2591_chip *	chip
const u8	als_gain
