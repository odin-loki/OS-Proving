int
struct cache_detail *	cd
char *	mesg
int	mlen
