int
struct b43legacy_wldev *	dev
