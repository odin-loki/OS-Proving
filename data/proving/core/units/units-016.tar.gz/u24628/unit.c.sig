int
unsigned char	si1
unsigned char	si2
