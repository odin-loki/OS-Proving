int
struct platform_device *	pdev
int	vid_num
bool	static_vrfb_allocation
