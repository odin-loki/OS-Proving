int
void *	p
int	len
