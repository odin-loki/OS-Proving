int
int	size
