int
struct iio_dev *	iio_dev
int *	val
