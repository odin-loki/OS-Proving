int
struct thread *	td
pid_t	pid
struct linux_pt_regset *	l_regset
