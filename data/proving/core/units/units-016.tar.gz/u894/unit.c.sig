xfs_fsblock_t
int	k
