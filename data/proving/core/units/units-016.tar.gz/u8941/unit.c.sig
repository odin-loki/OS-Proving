unsigned int
int	nid
