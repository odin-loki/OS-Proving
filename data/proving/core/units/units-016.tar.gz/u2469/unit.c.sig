int
struct ice_softc *	sc
