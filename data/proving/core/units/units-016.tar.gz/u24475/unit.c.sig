int
enum mei_cl_connect_status	status
