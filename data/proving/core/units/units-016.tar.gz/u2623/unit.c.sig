bool
u32	msg
