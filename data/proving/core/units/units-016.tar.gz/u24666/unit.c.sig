unsigned long
u16	reg
