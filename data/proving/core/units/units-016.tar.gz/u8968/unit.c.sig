int
struct fsl_asrc *	easrc
unsigned int	ctx_id
