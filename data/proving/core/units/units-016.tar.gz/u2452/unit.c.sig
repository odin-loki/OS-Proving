bool_t
XDR *	xdrs
u_int	pos
