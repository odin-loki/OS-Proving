unsigned long
unsigned long	left
unsigned long	right
int	bits
