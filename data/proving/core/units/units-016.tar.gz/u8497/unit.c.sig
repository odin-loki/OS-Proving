u64
u64	avg
u64	sample
u32	shift
