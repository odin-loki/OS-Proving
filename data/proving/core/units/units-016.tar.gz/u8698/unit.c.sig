int
struct nvkm_engine *	engine
enum nvkm_suspend_state	suspend
