int
struct mlx5_core_dev *	dev
struct mlx5_fs_bulk *	fs_bulk
int	bulk_len
