int
bool	percpu
size_t	size
