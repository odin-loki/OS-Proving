u32
u16	itr_idx
u16	itr
