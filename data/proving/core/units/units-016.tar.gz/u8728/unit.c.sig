uint8_t
struct bxe_softc *	sc
uint32_t	resource
