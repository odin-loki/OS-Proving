int
struct iris_core *	core
u32	intr_status
