bool
u32	app_info_bitmap
u16	proto_id
bool	ieee
