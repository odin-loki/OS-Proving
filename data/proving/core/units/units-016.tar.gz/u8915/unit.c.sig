unsigned int
unsigned int *	val
const u8 *	data
int	dlen
