bool
u16	ring_len
