int
struct uio *	uio
const struct mbuf *	m
int	len
