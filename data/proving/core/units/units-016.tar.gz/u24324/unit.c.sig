int
struct rsi_common *	common
struct rsi_thread *	thread
void *	func_ptr
u8 *	name
