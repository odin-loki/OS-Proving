int
dev_t	dev
