int
char *	buf
size_t	nbytes
struct file *	file
struct dir_context *	ctx
