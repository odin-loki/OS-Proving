int
struct ddr_pmu *	pmu
int	event
int	counter
