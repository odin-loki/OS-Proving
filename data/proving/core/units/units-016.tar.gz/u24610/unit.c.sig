u16
u16	number
