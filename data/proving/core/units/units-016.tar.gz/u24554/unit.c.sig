int
struct platform_device *	pdev
enum brcmusb_reg_sel	regs
struct brcm_usb_init_params *	ini
bool	optional
