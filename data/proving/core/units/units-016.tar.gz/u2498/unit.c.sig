bool
int	new_generation
int	old_generation
