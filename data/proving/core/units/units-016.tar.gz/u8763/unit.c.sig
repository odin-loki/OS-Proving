int
struct input_dev *	dev
unsigned int	axis
int	val
