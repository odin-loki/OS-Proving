int
struct i2c_client *	client
int	irq
