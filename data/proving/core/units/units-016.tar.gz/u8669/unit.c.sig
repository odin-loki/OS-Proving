pmc_value_t
pmc_value_t	rlc
