unsigned int
unsigned int	syt_offset
unsigned int	cycle
unsigned int	transfer_delay
