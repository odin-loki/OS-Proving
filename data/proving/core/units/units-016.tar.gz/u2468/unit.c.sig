int
u8	mask
