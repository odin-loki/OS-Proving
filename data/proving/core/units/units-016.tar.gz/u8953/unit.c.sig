int
struct mpr_softc *	sc
