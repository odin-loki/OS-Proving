bool
struct device *	dev
struct page *	pages
int	count
