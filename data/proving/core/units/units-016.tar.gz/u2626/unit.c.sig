blk_status_t
u16	status
