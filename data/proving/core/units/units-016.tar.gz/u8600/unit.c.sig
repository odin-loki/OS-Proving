int
struct nf_conn *	tmpl
struct sk_buff *	skb
unsigned int	dataoff
const struct nf_hook_state *	state
