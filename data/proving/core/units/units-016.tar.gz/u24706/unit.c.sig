unsigned int
unsigned int	mem_size
unsigned int	pg_size
