int
quad_t	a
quad_t	b
