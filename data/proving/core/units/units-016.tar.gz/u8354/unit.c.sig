int
const enum aq_macsec_sc_sa	sc_sa
const int	sc_idx
