int
struct nvkm_pmu *	pmu
int	ver
const struct nvkm_pmu_fwif *	fwif
