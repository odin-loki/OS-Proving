int
struct vx_core *	chip
