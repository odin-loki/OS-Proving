int
adapter_t *	adap
struct sge_txq *	q
struct mbuf *	m
unsigned int	ndesc
unsigned int	qid
