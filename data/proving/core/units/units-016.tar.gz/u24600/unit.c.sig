u32
const u32	sc_idx
const enum aq_macsec_sc_sa	sc_sa
