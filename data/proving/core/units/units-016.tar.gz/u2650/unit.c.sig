JEMALLOC_ALWAYS_INLINE bool
nstime_t *	time
