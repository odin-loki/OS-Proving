int
int	fd
unsigned int	mask
