int
u64	flags
