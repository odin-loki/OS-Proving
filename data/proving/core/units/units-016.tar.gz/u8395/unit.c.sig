void
unsigned long long	crash_size
unsigned long long	crash_base
unsigned long long	crash_low_size
bool	high
