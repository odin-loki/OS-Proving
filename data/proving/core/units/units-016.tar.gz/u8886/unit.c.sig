int
struct list_head *	list
struct usb_ep *	ep
unsigned	n
