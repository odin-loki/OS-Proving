int
struct pci_dev *	pdev
struct plat_stmmacenet_data *	plat
