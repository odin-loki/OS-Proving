unsigned
int	bpc
