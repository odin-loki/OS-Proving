int
struct mtk_base_afe *	afe
