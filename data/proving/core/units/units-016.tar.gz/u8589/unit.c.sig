int
const unsigned int	xid
struct cifs_tcon *	tcon
struct cifs_sb_info *	cifs_sb
const char *	full_path
struct cifs_open_info_data *	data
