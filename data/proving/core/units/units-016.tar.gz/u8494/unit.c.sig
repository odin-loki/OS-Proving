unsigned int
unsigned int	channel
