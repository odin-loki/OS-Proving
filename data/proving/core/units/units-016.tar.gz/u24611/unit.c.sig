int
struct coda_dev *	dev
