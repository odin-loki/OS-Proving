int
int	akm
