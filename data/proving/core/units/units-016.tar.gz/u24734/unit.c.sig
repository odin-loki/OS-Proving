int
struct ht *	h
