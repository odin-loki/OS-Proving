u8
u16	ird_size
