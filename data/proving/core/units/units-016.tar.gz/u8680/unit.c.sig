ptrdiff_t
ptrdiff_t	a
ptrdiff_t	b
