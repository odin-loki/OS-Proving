int
struct spi_controller *	ctlr
