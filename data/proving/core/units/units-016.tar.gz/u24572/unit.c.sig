int
struct fetch_insn *	code
unsigned long	val
void *	dest
void *	base
