int
struct mmc_host *	host
u32	ocr
struct mmc_card *	card
