s16
a_sle16	val
