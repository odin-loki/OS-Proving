enum ice_ddp_state
enum ice_aq_err	aq_err
