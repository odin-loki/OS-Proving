int
fr_info_t *	fin
ip_t *	ip
ap_session_t *	aps
int	inc
