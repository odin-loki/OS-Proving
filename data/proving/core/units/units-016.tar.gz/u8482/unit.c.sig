int
u32	flags
u8	hw_rev
