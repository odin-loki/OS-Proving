int
struct mlx4_dev *	dev
int	slave
struct mlx4_vhcr *	vhcr
struct mlx4_cmd_mailbox *	inbox
struct mlx4_cmd_mailbox *	outbox
struct mlx4_cmd_info *	cmd
