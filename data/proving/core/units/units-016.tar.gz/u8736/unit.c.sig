u32
const struct net *	net
const __u16	lport
const u32	bhash_size
