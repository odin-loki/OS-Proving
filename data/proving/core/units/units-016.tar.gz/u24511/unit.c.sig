int
struct inode *	inode
struct ufs_inode *	ufs_inode
