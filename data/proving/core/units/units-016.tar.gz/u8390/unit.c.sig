u16
struct bnx2x *	bp
u32	mf_cfg
