int
struct b43legacy_wldev *	dev
u8	channel
