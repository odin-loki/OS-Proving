int
int	voltage
