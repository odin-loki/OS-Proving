int
u8	cellinfo
