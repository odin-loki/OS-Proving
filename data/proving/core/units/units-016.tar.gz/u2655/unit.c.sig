unsigned int
unsigned int	cpu
