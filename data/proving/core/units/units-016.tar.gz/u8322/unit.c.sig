void
qla_host_t *	ha
const char *	str
