int
struct clknode *	clknode
int	depth
