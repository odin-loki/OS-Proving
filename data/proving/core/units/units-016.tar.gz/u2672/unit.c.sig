int
char	ch
int *	flags
