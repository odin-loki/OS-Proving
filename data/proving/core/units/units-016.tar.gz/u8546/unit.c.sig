u16
struct v4l2_subdev *	sd
u32	numerator
u32	denominator
