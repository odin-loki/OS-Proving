void
struct ttm_resource_manager *	man
u64	size
