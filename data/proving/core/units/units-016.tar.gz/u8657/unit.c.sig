int
struct pch_gpio *	chip
unsigned int	irq_start
unsigned int	num
