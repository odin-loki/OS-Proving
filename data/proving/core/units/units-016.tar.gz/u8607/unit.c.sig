int
enum telemetry_unit	telem_unit
u32 *	evtmap
u8	len
enum telemetry_action	action
