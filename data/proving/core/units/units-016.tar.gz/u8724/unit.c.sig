unsigned long
size_t	offset
size_t	count
