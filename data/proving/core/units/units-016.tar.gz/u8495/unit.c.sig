int
int	pri
int	cpri
int	remote
