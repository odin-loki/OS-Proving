int
struct list_head *	head
const char *	type
const char *	name
int	offset
int	size
int	is_signed
int	filter_type
int	len
int	need_test
