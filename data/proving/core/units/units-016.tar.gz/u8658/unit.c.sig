int
struct vcap_admin *	admin
int	size
