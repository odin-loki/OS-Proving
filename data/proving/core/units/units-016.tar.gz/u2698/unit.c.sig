int
const struct netlbl_dom_map *	entry
