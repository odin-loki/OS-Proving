bool
enum iwl_fw_ini_time_point	tp_id
