int
struct mt76_dev *	dev
struct mt76_queue *	q
struct urb *	urb
int	nsgs
