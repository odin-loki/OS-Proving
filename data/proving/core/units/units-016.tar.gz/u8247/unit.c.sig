bool
struct drm_i915_private *	i915
u32	guc_wopcm_base
u32	guc_wopcm_size
