int
int	input
int	dir
