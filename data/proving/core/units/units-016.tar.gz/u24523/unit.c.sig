int
struct bnxt *	bp
struct bnxt_cp_ring_info *	cpr
int	budget
