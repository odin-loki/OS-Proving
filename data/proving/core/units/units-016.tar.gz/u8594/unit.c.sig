int
struct regulator_dev *	rdev
unsigned int	selector
