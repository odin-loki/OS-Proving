unsigned int
u32	mvd
