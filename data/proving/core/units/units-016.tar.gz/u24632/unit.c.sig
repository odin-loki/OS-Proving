int
struct perf_event *	event
struct bpf_prog *	prog
u64	bpf_cookie
