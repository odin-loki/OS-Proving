int
struct mtk_wed_device *	dev
