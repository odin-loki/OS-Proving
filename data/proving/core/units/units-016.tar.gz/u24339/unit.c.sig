int
struct tps6594 *	tps
bool	enable_crc
