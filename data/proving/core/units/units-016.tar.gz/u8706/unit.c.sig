int
qla_host_t *	ha
int	ridx
