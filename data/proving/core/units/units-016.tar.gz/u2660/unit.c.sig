u8
struct vc_data *	conp
u8	color
enum vc_intensity	intens
bool	blink
bool	underline
bool	reverse
bool	italic
