int
u32	left
u32	op
u32	right
