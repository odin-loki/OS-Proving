int
u32	opcode
void *	data
u16	size
