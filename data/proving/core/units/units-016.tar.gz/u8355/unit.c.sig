int
char *	buf
int	buflen
const struct bitmask *	bmp
