u32
u32	reg_sz
u32	ctr_idx
