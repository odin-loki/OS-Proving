bool
u8	id
