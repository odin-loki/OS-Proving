s16
s16	prev_avg
s16	val
u8	depth
