int
unsigned long	flags
