bits32
int16	aExp
bits32	a
