int
__u32	idx
__u32	max_elems
