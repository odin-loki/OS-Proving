int
struct asd_ha_struct *	asd_ha
u16	ddb_site_no
u16	offs
u8	_oldval
u8	_newval
