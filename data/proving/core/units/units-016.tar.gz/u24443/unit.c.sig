u16
const struct mlxsw_sp_port *	mlxsw_sp_port
u16	vid
bool	is_pvid
