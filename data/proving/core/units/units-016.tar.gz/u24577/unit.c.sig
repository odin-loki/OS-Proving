long
struct clk *	clk
