size_t
wint_t *	wi
const char *	s
size_t	n
mbstate_t *	mbs
wint_t	dummy
