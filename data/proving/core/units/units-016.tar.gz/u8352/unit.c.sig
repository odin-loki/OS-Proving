int
struct bnx2fc_cmd *	orig_io_req
u32	offset
enum fc_rctl	r_ctl
