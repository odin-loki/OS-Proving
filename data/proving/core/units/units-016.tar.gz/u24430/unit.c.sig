u16
u32	odr_millihz
