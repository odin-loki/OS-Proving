int
struct hwrng *	rng
