ssize_t
struct file *	file
const char *	ubuf
size_t	count
loff_t *	ppos
