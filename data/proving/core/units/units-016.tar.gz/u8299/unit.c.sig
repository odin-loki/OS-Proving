uint32_t
dm_cblock_t	b
