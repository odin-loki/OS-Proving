int
struct ksignal *	ksig
sigset_t *	set
struct pt_regs *	regs
