int
struct device_node *	np
u8 *	mac
