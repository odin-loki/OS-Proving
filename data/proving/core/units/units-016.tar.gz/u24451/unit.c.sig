int
struct dm_exception_store *	store
char *	options
