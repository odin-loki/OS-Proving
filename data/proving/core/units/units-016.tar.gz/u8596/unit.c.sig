int
struct pci_dev *	pdev
