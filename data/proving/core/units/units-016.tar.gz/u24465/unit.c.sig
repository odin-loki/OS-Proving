bool
unsigned int	type
unsigned int	role
