u8
u8	static_rate
