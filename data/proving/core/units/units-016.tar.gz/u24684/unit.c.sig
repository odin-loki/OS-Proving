bool
unsigned long	bitmap
u8	tc
