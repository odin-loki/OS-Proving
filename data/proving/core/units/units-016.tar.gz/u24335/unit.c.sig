int
cnd_t *	cnd
mtx_t *	mtx
