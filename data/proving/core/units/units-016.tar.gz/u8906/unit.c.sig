enum sas_linkrate
u8	link_rate
