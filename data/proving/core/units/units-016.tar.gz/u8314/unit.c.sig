int
int	type
int	code
