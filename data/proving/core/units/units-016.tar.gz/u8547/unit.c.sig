int
struct nlattr *	attr
u8 *	dest
u8	min
u8	max
