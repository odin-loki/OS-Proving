u64
u64	dividend
u64	divisor
