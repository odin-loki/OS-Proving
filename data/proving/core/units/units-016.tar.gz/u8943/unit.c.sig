bool
loff_t	p
