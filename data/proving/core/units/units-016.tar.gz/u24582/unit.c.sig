int
struct cas *	cp
unsigned char *	dev_addr
const int	offset
