int
struct thermal_cooling_device *	cdev
unsigned long	state
u32 *	power
