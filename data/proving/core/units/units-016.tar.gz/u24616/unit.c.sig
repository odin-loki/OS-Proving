void
int	fatal
u8	errors
int *	error_found
int	handle_error
