int
struct cedrus_ctx *	ctx
