long
struct bpf_map *	map
void *	value
u64	flags
