u_int
u_int	i
