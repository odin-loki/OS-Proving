bool
unsigned long	metalen
