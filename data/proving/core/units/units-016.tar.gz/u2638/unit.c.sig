int
struct mddev *	mddev
struct r10bio *	r10_bio
