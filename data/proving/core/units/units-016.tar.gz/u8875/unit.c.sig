int
struct msm_dp_link_private *	link
int const	addr
