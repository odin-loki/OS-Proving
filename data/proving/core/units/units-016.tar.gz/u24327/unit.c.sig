bool
u64	config
