bool
const struct pipe_inode_info *	pipe
