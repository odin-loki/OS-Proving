u32
struct rnd_state *	rng
u32	floor
u32	ceil
