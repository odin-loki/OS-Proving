int
struct comedi_device *	dev
struct comedi_subdevice *	s
