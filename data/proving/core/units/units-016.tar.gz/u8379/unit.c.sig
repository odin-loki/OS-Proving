int
struct hv_device *	device
const struct hv_vmbus_device_id *	dev_id
