int
struct qtnf_bus *	bus
unsigned int	macid
