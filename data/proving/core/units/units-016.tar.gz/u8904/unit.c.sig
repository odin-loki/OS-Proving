u8
long	val
