uint32_t
unsigned int	vmid
uint32_t	flush_type
