int
struct ib_cq *	ibcq
int	num_entries
struct ib_wc *	wc
