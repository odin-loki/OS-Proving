int
const void *	a
const void *	b
