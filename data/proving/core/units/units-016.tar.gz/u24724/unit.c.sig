int
qla_host_t *	ha
struct mbuf *	mp
q80_tx_cmd_t *	tx_cmd
uint8_t *	hdr
