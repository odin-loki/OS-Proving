int
int	value
int	num
