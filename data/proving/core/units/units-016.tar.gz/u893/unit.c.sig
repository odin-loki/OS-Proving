int
const int	use_bix
struct acpi_battery *	battery
const struct acpi_buffer *	buffer
