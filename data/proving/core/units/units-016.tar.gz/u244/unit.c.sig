struct irq_domain *
struct gpio_chip *	gc
