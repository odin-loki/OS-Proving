bool
u64	mask
u64	field
