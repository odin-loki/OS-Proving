int
struct nct6775_data *	data
