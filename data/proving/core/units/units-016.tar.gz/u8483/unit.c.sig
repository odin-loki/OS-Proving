int
enum rc_proto	protocol
u32	scancode
struct ir_raw_event *	events
unsigned int	max
