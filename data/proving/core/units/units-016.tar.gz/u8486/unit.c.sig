size_t
int	compressionLevel
