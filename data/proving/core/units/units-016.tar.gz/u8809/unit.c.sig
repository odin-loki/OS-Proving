int
u32	n1
u32	n2
