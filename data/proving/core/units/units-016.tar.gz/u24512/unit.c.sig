u8
u8	color
u8	done_color
