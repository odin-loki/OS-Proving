u8
u32	ae_state
