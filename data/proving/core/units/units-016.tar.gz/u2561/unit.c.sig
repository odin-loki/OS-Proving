int
unixFile *	pFile
int *	piOut
