int
const char *	fname
u_int	val
const char *	msg
