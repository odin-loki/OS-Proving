size_t
struct tty_port *	port
u8 **	chars
size_t	size
