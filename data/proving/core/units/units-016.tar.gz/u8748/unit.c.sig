u32
u32	width
u32	height
bool	is_interlaced
