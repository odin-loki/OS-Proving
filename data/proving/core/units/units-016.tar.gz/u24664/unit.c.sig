_Bool
double	lhs
ComparisonOp	op
double	rhs
