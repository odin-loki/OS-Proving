s16
u16	val
