bool
u64	bytenr
u64	blockstart
u32	blocksize
