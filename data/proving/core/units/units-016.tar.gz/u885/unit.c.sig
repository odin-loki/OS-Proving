u32
struct radeon_device *	rdev
u32	unscaled_count
u32	unit
