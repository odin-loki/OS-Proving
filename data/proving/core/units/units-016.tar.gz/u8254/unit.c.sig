int
struct jpeg_stream *	stream
size_t	len
