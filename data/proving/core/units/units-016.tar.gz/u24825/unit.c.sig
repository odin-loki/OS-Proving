int
struct amdgpu_ras_eeprom_control *	control
