unsigned int
unsigned int	head
unsigned int	tail
