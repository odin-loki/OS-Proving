unsigned int
struct cpufreq_policy *	policy
