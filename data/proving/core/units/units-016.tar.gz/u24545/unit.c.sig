int
struct intel_iommu *	iommu
bool	first_stage
