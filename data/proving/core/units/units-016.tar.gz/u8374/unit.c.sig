void
struct vnic_wq *	wq
unsigned int	cq_index
unsigned int	error_interrupt_enable
unsigned int	error_interrupt_offset
