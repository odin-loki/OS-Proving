int
struct vmxnet3_rx_queue *	rq
u32	ring_idx
int	num_to_alloc
struct vmxnet3_adapter *	adapter
