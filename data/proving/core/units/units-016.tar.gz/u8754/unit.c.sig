int
struct mpi3mr_softc *	sc
