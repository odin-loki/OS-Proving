int
struct qed_hwfn *	p_hwfn
struct qed_ptt *	p_ptt
