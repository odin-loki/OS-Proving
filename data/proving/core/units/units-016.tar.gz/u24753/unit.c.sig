int
struct ubi_attach_info *	ai
int	pnum
int	ec
