int
uint32_t	fw_version
