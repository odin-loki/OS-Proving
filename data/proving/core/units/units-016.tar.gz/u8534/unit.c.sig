int
struct adapter *	adap
int	win
int	mtype
u32 *	mem_off
u32 *	mem_base
u32 *	mem_aperture
