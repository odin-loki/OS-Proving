int
u32	buf_size
