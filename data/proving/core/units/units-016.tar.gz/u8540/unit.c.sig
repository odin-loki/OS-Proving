int
unsigned long	size
