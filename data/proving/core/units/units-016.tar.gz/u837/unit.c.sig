int
uint8_t	ssi
