int
struct hid_device *	hdev
u8	type
u8 *	buf
size_t	size
unsigned int	retries
