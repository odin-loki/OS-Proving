int
struct thread *	td
