int
struct bstp_state *	bs
struct bstp_port *	bp
struct ifnet *	ifp
