int
struct s_smc *	smc
