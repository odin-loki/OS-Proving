int
struct pl330_dmac *	pl330
unsigned	dry_run
?	?
const struct _xfer_spec *	pxs
