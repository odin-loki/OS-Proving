int
struct platform_device *	pdev
struct dfl_feature *	feature
