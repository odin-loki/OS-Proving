u64
u64	dividend
u32	divisor
