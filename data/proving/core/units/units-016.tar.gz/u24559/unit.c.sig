int
struct airoha_ppe *	ppe
