size_t
size_t	prev_offset
size_t	prev_size
size_t	size
size_t	align
size_t	offset
