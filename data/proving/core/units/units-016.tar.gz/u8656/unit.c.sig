int
int	mac_speed
