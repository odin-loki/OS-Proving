int
struct eventtimer *	et
int	freq
