int
double	a
