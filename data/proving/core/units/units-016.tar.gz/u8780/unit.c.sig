void
struct snd_pcm_substream *	substream
snd_pcm_uframes_t	hw_ptr
