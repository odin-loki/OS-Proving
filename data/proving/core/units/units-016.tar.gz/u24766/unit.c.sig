int
const struct pipe_inode_info *	pipe
struct splice_pipe_desc *	spd
