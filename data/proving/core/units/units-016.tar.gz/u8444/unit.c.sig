u8
u16	value
