unsigned int
uint64_t	status
