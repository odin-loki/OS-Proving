int
struct platform_device *	op
struct pxad_device *	pdev
unsigned int	nr_phy_chans
unsigned int	nr_requestors
