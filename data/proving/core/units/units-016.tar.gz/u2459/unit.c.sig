bool
int	channel
