void
const zic_t	x
