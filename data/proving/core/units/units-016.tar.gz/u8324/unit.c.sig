bool
const struct nf_queue_entry *	entry
