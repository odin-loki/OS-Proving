bool
const u64 *	features
unsigned int	bit
