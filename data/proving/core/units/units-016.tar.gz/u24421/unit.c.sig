int
struct pruss *	pruss
bool	enable
