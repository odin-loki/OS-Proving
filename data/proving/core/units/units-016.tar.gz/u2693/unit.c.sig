size_t
const struct gen_pool_chunk *	chunk
