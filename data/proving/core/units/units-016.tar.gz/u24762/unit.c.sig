int
struct rcar_du_vsp *	vsp
struct drm_framebuffer *	fb
?	?
