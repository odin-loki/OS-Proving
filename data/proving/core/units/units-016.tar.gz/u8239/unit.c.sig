unsigned char
struct mb86a16_state *	state
int	smrt
