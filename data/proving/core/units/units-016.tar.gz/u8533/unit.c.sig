int
const u32	eax
