u32
enum spu_cipher_alg	cipher_alg
enum spu_cipher_mode	cipher_mode
unsigned int	blocksize
