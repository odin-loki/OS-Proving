u32
u32	val
u32	min
u32	max
u32	step
