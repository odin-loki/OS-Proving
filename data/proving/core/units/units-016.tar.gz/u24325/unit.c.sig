bool
int	layout
