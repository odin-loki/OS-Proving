int
struct mbuf *	m
struct tcphdr *	th
struct socket *	so
struct tcpcb *	tp
int	tlen
