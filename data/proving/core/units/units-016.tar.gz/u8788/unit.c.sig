int
struct xe_uc_fw *	uc_fw
const void *	fw_data
size_t	fw_size
