bool
u64	power
