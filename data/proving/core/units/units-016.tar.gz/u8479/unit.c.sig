int
device_t	dev
uint8_t *	status
