unsigned int
struct tty_struct *	tty
