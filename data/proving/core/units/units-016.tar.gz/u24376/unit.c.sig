int
resource_size_t	start
size_t	size
unsigned long	flags
unsigned long	desc
