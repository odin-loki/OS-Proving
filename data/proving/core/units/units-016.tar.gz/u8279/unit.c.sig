int
struct klist_node *	n
