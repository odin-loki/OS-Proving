unsigned long
unsigned long	nr_pages
unsigned long	avail_normal
