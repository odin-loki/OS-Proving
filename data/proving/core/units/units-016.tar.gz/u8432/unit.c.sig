int
struct mpi3mr_softc *	sc
struct mpi3mr_irq_context *	irq_ctx
