int
struct gsm_mux *	gsm
unsigned int	addr
unsigned int	cr
const struct gsm_dlci_param_bits *	params
