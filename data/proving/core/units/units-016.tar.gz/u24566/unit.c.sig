int
struct tegra_bpmp *	bpmp
