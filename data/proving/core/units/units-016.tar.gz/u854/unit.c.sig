int
struct iqs621_als_private *	iqs621_als
