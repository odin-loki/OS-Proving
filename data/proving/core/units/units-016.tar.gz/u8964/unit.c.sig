int
struct device *	dev
dma_addr_t	dma_addr
