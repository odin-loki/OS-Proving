bool
unsigned int	div
