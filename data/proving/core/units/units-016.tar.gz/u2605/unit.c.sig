ktime_t
clockid_t	clockid
ktime_t	tim
struct timens_offsets *	ns_offsets
