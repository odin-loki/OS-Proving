int
struct bt878 *	bt
