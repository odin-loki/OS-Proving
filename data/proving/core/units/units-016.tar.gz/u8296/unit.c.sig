bool
struct dm_writecache *	wc
