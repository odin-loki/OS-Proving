int
struct hisi_hba *	hisi_hba
