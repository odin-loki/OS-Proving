int
char	nibble
