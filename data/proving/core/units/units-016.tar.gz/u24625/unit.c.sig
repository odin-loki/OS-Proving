int
uint64_t	mapreg
