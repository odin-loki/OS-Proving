bool
int	vclock
