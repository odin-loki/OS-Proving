int
struct iio_kfifo *	buf
size_t	bytes_per_datum
unsigned int	length
