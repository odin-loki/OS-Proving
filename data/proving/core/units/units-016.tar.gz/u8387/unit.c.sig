int
u8	ptype
