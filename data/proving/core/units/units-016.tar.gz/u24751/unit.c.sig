int
struct ds1307 *	ds1307
bool	enable
