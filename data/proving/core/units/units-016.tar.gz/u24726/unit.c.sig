int
struct iwl_fw_runtime *	fwrt
enum iwl_dsm_funcs	func
u32 *	value
