int
char *	date
int *	yearp
int *	monthp
int *	dayp
int *	flags
char **	edp
