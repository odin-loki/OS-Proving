bool
struct io_kiocb *	req
struct io_buffer_list *	bl
int	len
int	nr
