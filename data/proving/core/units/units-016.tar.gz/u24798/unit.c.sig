long
s32	value
int	data_type
