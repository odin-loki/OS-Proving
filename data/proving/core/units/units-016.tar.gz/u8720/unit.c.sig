int
unsigned int	wcaps
