bool
unsigned int	irq
struct irq_desc *	desc
irqreturn_t	action_ret
