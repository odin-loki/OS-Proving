int
struct bdc_ep *	ep
struct bdc_req *	req
