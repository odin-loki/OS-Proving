void
void *	ptr
