int8
bits32	a
