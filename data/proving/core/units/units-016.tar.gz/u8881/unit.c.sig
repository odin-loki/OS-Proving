u32
__u32	bitrate
