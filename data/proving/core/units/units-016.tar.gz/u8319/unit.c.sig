int
int	flags
