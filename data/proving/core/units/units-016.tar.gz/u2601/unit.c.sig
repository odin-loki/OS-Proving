u8
u8	log_cap
u16	config
