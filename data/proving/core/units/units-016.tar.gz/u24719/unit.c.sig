int
struct bpf_map *	map
void *	key
void *	next_key
