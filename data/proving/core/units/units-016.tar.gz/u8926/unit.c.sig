quad_t
quad_t	a
quad_t	b
