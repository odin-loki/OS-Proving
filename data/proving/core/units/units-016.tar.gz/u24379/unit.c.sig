int
struct clkdom *	clkdom
struct aw_clk_nm_def *	clkdef
