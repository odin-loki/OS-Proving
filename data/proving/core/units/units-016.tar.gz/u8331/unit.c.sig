u32
int	idx
