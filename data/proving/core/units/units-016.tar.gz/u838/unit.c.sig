int
phys_addr_t	size
phys_addr_t	base
phys_addr_t	limit
struct cma **	res_cma
bool	fixed
