int
struct icp_qat_fw_loader_handle *	handle
struct icp_qat_suof_filehdr *	suof_ptr
int	suof_size
