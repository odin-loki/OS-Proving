int16_t
uint8_t	coefficient_bits
uint16_t	fe
