unsigned int
unsigned int	sample_rate
