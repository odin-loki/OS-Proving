int
struct serio *	serio
struct serio_driver *	drv
