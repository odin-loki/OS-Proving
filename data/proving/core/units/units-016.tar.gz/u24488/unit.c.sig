int
struct mlx4_ib_demux_pv_ctx *	ctx
enum ib_qp_type	qp_type
int	is_tun
