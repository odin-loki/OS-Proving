u8
enum spu_cipher_mode	cipher_mode
u16	iv_len
