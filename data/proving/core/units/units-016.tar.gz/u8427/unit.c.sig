int
struct htc_target *	target
struct ath6kl_htc_credit_info *	info
