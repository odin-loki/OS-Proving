int
unsigned long	phys
