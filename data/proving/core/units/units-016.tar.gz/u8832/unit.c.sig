flag
bits64	a0
bits64	a1
bits64	b0
bits64	b1
