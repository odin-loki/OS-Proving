int
struct ocelot *	ocelot
