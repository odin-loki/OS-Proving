long
struct bpf_map *	map
void *	key
void *	value
u64	flags
