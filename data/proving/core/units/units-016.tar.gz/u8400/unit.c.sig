int
struct scatterlist *	sg
unsigned int	nents
