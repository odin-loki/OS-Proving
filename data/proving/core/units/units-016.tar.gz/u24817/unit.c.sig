int
struct pruss *	pruss
enum pruss_pru_id	pru_id
u8	mux
