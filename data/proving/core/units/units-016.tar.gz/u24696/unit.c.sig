int
struct nvkm_subdev *	privring
