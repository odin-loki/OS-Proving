bool
u64	p
