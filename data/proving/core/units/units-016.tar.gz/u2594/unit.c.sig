int
struct adapter *	adapter
int	budget
