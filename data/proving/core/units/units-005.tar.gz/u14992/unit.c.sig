int
struct et131x_adapter *	adapter
struct pci_dev *	pdev
