int
struct kvm *	kvm
u64	pfn
enum pg_level	level
