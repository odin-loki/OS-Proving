int
struct xhci_hcd *	xhci
struct urb *	urb
int	index
