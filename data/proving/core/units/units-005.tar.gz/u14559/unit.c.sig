int
struct adapter *	adapter
const void *	cmd
int	size
void *	rpl
bool	sleep_ok
