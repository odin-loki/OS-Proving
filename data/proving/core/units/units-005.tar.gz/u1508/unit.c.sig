unsigned int
unsigned int	alarm
