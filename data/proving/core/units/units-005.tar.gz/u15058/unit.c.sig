HAL_BOOL
int	alt_ratio
int	maxdelta
int	mindelta
int	main_rssi_avg
int	alt_rssi_avg
int	pkt_count
