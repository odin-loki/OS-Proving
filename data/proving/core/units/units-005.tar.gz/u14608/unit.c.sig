int
enum key_flag	key_flag
