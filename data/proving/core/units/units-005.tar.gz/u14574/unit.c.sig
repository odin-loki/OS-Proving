unsigned int
u32	index
unsigned int	hmask
