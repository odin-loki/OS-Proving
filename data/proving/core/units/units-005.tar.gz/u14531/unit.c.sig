int
struct icp_qat_fw_loader_handle *	handle
struct icp_qat_uof_initmem *	init_mem
unsigned int	size_range
unsigned int *	ae
