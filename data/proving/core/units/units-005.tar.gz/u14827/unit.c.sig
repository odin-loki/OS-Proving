bool
struct block_device *	part
unsigned int	bytes
