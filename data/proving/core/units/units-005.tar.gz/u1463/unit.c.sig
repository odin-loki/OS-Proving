int
struct irq_desc *	desc
int	node
