int
int	verdict
bool	redir
