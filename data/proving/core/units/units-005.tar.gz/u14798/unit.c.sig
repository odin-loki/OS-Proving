unsigned int
struct isp_mmu *	mmu
phys_addr_t	phys
