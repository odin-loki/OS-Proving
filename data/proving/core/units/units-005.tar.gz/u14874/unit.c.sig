int
struct device *	dev
u64 *	limit
