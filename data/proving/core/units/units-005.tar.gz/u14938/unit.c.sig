long
struct ieee80211_hw *	hw
u8	signal_strength_index
