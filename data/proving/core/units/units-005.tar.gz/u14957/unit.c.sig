int
struct pi_desc *	pi_desc
u64 *	pold
u64	new
