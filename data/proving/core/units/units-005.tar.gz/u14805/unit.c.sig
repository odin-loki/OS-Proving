int
struct request_sock *	req
const struct sock *	sk_listener
struct sk_buff *	skb
