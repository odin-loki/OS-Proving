unsigned
unsigned	maxTableLog
size_t	srcSize
unsigned	maxSymbolValue
unsigned	minus
