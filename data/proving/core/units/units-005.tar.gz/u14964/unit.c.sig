int
struct ida *	ida
unsigned int	max
gfp_t	gfp
