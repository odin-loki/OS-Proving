uint16_t
enum scale_mode	mode
uint32_t	src
uint32_t	dst
bool	is_horizontal
int	vsu_mode
int *	vskiplines
