int
u8	rd
s64	rvoff
bool	fixed_addr
struct rv_jit_context *	ctx
