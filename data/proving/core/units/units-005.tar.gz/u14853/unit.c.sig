int
struct inode *	inode
u32	logical_start
u32	clusters_to_add
int	mark_unwritten
