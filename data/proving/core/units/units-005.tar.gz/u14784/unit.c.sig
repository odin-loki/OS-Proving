int
struct reloc_control *	rc
int	err
