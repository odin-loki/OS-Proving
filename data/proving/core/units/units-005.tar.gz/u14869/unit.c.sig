int
int	width
int	bpp
