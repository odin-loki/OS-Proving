int
struct ena_adapter *	adapter
