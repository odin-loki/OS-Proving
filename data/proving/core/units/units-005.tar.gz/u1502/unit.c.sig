unsigned
unsigned	bits
unsigned	blocksize
