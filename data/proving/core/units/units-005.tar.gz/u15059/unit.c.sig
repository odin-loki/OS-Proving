int
struct bnx2x *	bp
struct bnx2x_virtf *	vf
int	qid
