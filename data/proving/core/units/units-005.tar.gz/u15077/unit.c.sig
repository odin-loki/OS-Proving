int
struct snd_opl3 *	opl3
int	timer1_dev
int	timer2_dev
