int
struct snd_dummy *	dummy
int	device
int	substreams
