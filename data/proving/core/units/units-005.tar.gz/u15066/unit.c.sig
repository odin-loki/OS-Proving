int
struct transport_class *	tclass
