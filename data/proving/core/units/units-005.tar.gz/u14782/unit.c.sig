u32
u32	div
