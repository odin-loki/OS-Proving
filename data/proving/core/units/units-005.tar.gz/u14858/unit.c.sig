int
struct bnxt *	bp
int	tx
int	tx_sets
int	tx_xdp
