bool
ktime_t	t1
rxrpc_seq_t	seq1
ktime_t	t2
rxrpc_seq_t	seq2
