int
struct fw_device *	fwdev
int	offset
uint32_t *	quad
int	length
