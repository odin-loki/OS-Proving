uint64_t
uint64_t	rtt
uint64_t	bw
