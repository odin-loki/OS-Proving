bool
struct adf_rl_sla_input_data *	sla_in
struct rl_sla *	sla
