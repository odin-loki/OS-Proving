int
struct parport *	port
signed long	timeout
