u64
u64	fd
u64	__ur_1
u64	__ur_2
u64	__ur_3
u64	__ur_4
