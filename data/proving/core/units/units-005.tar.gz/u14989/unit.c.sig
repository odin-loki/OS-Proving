int
enum port_type	index
struct nozomi *	dc
