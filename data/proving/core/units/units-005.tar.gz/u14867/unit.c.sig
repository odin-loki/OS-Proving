int
struct pci_dev *	pdev
struct proc_thermal_device *	proc_priv
