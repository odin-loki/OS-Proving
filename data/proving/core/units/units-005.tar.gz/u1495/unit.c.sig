unsigned char
int	seconds
