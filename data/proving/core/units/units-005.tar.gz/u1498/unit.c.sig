int
struct snd_card *	card
unsigned int	count
