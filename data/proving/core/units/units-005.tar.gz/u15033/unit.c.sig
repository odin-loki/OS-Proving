int
struct imx6ul_tsc *	tsc
