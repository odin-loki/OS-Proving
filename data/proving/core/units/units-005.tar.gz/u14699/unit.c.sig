int
void *	priv
bool	enable
