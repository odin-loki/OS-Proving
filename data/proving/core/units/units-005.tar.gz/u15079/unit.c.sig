int
struct vudc *	udc
