int
unsigned int	verdict
