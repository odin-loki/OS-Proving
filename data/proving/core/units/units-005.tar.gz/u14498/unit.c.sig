int
struct altera_ci_config *	config
int	ci_nr
