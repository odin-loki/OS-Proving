int
struct rtrs_srv_stats *	stats
bool	enable
