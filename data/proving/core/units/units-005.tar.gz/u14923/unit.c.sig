int
struct cphy *	phy
int	mmd
int	reg
unsigned int *	valp
