int
struct sdricoh_host *	host
