int
unsigned int	from
unsigned int	cnt
