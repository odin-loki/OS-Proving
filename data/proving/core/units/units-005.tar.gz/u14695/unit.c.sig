blk_status_t
struct request *	req
int	rc
