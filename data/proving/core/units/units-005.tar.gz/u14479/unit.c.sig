bool
struct kvm *	kvm
kvm_pfn_t	pfn
int	order
