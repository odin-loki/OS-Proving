int
struct ieee80211_hw *	hw
struct ieee80211_vif *	vif
int	sset
