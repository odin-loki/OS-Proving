unsigned int
const unsigned long	j
