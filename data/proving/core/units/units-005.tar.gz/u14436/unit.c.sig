u32
struct brcmf_msgbuf *	msgbuf
bool	event_buf
u32	count
