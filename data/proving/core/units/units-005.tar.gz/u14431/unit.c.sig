enum mipi_dsi_pixel_format
unsigned int	format
