int
struct ov8865_sensor *	sensor
