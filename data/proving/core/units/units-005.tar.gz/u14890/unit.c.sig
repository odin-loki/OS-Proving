u64
LogEst	x
