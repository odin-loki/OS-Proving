unsigned long
struct mem_ctl_info *	mci
unsigned long	page
