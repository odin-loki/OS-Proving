uint32_t
uint32_t	pi
uint32_t	ci
uint32_t	elem_in_q
