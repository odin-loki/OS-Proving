unsigned int
struct comedi_device *	dev
struct comedi_subdevice *	s
unsigned int	n_raw_samples
