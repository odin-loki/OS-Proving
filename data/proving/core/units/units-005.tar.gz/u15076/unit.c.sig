int
struct rt1011_priv *	rt1011
struct device *	dev
