int
struct ixgbevf_adapter *	adapter
int	v_idx
int	txr_count
int	txr_idx
int	xdp_count
int	xdp_idx
int	rxr_count
int	rxr_idx
