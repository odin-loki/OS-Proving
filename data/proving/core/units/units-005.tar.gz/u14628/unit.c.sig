int
struct scmi_device *	sdev
