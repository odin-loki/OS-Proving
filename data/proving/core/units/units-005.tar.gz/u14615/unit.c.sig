int
struct netfs_io_request *	rreq
struct file *	file
