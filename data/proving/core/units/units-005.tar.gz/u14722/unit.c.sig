int
int	fd
char *	buffer
int	count
