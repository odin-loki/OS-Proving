long
key_serial_t	id
key_serial_t	from_ringid
key_serial_t	to_ringid
unsigned int	flags
