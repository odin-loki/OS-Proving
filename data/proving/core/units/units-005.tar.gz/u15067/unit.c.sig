int
struct pinctrl_dev *	pctldev
struct device_node *	np
struct device_node *	parent
struct pinctrl_map **	map
unsigned int *	num_maps
unsigned int *	index
