int
BTREE *	t
pgno_t	pg
