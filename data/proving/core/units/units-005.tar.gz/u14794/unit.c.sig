u32
struct bnx2x *	bp
u32	command
u32	param
