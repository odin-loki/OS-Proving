s32
s32	eeprom_voltage
s32	current_voltage
