int
struct iowarrior *	dev
