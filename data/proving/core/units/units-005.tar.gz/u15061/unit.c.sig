enum iwl_mvm_traffic_load
struct iwl_mvm *	mvm
u32	airtime
unsigned long	elapsed
