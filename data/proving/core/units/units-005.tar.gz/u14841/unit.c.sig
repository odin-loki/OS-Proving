int
struct thread *	td
struct sysarch_args *	uap
