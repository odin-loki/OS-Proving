int
struct usb_hcd *	hcd
struct usb_device *	udev
struct usb_host_endpoint **	eps
unsigned int	num_eps
gfp_t	mem_flags
