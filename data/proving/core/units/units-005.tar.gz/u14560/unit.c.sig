unsigned int
unsigned int	n_bits
