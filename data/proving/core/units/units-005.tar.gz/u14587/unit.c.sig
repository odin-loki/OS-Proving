int
struct ufs_hba *	hba
