bool
u8	opcode
u16	base_status
u16	addl_status
