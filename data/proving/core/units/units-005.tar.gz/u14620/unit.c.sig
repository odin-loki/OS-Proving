int
struct dlm_ctxt *	dlm
u8	dead_node
