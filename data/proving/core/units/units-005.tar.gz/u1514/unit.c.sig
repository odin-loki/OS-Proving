unsigned long
unsigned long	bits
