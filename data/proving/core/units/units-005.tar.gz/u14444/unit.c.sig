int
struct platform_device *	pdev
int	num
