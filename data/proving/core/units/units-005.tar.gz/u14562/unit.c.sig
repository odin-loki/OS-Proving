unsigned long
enum of_gpio_flags	flags
