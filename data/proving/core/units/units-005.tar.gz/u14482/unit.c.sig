int
int	pool
const __u8 *	key
int	key_size
const __u8 *	value
int	value_size
