int
struct snd_trident *	trident
unsigned long	ptr
