bhnd_clock
bhnd_clock	a
bhnd_clock	b
