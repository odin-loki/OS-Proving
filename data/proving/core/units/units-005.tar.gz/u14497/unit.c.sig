int
struct xgmac_priv *	priv
int	limit
