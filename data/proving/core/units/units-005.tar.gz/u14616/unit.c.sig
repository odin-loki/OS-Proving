int
struct xfs_mount *	mp
int	whichfork
