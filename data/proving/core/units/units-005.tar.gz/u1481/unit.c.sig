int
struct ipu_ic *	ic
const struct ipu_ic_csc *	csc
int	csc_index
