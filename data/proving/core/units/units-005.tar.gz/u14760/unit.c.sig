int
struct nlattr *	attr
struct vtunnel_info *	tinfo
