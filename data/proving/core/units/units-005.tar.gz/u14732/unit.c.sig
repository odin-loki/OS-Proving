size_t
void *	sequenceProducerState
ZSTD_Sequence *	outSeqs
size_t	outSeqsCapacity
const void *	src
size_t	srcSize
const void *	dict
size_t	dictSize
int	compressionLevel
size_t	windowSize
