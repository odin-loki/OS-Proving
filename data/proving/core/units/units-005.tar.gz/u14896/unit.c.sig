long
unsigned int	dfd
const char *	filename
struct old_timeval32 *	t
