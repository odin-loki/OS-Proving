int
const struct f_uac2_opts *	uac2_opts
u8	bint
unsigned int	factor
bool	is_playback
