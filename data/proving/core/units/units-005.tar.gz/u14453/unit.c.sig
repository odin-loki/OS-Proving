int
struct gf100_gr *	gr
int	ver
const struct gf100_gr_fwif *	fwif
