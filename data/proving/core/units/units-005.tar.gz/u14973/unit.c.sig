int
struct cifs_ses *	ses
int	base_size
