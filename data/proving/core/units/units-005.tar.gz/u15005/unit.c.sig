int
struct nfs4_slot_table *	tbl
u32	max_reqs
u32	ivalue
