bool
u32	type
u32	flags
