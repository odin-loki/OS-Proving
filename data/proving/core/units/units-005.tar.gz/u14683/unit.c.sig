ib_sa_comp_mask
int	index
