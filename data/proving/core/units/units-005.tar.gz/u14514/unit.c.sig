enum nl80211_band
int	ch_idx
