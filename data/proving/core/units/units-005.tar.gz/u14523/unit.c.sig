bool
const void *	ptr
unsigned long	size
