size_t
SeqStore_t const*	seqStore
const SeqDef*	sequences
size_t	nbSeqs
size_t	litSize
int	lastSubBlock
