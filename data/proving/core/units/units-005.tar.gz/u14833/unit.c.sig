int
struct btrfs_trans_handle *	trans
struct btrfs_root *	quota_root
u64	qgroupid
