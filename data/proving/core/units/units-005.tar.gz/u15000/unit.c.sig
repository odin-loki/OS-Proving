unsigned long
int	nid
unsigned long	zone_type
unsigned long	node_start_pfn
unsigned long	node_end_pfn
unsigned long *	zone_start_pfn
unsigned long *	zone_end_pfn
