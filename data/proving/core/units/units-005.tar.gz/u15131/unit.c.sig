int
struct ceph_connection *	con
bool	encrypt
struct scatterlist *	src
struct scatterlist *	dst
int	src_len
