unsigned int
unsigned int	len
size_t	recsize
