int
u32	dimms
