int
bool	mixdev
