struct agp_memory *
device_t	dev
int	type
vm_size_t	size
