int
const char *	expression_string
const char *	file_name
int	line_number
const char *	format
?	?
