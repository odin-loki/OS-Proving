u16
u8	fbin
bool	is2GHz
