int
struct module *	me
u32 *	location
Elf64_Addr	v
bool	rela
