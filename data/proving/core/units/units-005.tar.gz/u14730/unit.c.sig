int
void *	mmio_base
u16	hctl
