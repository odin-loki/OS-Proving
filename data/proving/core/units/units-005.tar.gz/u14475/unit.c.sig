u32
struct hns_roce_dev *	dev
struct hns_roce_srq *	hr_srq
bool	user
