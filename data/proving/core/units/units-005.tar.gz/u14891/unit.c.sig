uint64_t
uint64_t	dividend
uint64_t	divisor
