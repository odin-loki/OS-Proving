int
struct ath_softc *	sc
int	flush
bool	hp
