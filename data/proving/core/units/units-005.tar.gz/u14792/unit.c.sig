int
struct fs_context *	fc
struct rpc_clnt *	client
