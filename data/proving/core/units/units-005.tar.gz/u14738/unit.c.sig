int
struct fb_info *	p
