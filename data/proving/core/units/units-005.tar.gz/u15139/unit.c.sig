long
unsigned long	from
unsigned long	num
int	turn_on
