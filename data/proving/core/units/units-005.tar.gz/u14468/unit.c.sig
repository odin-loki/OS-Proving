int
u32	inv_w
unsigned int	maxlen
u32	min_slot_shift
