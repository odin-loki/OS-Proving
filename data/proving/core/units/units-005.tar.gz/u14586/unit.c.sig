int
const grant_ref_t *	private_head
