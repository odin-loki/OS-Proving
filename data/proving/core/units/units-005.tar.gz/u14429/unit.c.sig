bool
struct hfi1_packet *	packet
