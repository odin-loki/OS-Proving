xfs_extlen_t
struct xfs_inode *	ip
