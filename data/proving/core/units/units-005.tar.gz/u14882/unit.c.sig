int
char **	mesg
char *	buf
struct nfsd4_fs_locations *	fsloc
