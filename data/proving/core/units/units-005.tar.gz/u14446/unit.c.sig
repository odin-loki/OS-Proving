int
struct cxl_cper_sec_prot_err *	prot_err
