int
struct dsaf_device *	dsaf_dev
