int
journal_t *	journal
struct buffer_head *	bh
