int
u16	cdc_filter
