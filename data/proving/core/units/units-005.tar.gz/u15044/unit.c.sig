int
struct hns3_enet_ring *	ring
struct sk_buff *	skb
unsigned int	bd_num
