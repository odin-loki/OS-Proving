int
struct dw_i3c_master *	master
struct platform_device *	pdev
