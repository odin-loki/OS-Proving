int
struct htc_target *	target
enum htc_endpoint_id	endpoint
