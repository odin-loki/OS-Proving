blk_status_t
u8	status
