unsigned int
unsigned int	cfg_width
bool	encrypt
bool	compress
