uint32_t
uint32_t	reg1
bool	ss
uint32_t	ramdac580
