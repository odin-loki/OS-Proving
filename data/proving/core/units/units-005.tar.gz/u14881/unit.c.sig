U32
U64	sequence
tableType_t const	tableType
