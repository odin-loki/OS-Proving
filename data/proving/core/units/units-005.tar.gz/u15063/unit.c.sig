bool
unsigned int	mbs
