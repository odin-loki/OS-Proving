int
struct device *	dev
struct device *	master
void *	data
