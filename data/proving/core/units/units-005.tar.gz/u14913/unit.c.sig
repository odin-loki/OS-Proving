int
struct sock *	sk
int	flags
int	err
