int
struct iio_dev *	indio_dev
struct iio_buffer *	buffer
int	bit
