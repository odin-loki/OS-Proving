int
struct sock *	sk
int	optname
sockptr_t	optval
int	optlen
