void
u32 *	location
u32	base
Elf64_Addr	v
