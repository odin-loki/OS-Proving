long
uid_t	uid
key_serial_t	destring
