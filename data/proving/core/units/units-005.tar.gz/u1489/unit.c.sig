bool
int	behavior
