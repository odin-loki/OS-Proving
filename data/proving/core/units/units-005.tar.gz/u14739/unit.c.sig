int
struct drm_device *	dev
unsigned int	num_crtcs
