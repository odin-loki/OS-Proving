u_int8_t
int	spd
