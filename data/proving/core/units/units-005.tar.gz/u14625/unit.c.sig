int
unsigned	major
