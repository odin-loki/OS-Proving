bool
u32	link
u32	target
