u16
unsigned int	freq
