u32
struct amdgpu_device *	adev
u32	data
bool	high
