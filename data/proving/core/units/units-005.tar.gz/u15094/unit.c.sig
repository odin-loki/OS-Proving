int
struct mpi3mr_ioc *	mrioc
