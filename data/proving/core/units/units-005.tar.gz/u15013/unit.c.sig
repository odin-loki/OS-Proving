int
struct resource *	res
