int
struct sdw_slave *	peripheral
u8	mask
u8	match
