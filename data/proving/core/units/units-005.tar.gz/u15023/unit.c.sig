int
struct cxl_cper_work_data *	wd
