int
struct stm_file *	stmf
void *	arg
