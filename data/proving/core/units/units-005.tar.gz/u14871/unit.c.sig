u64
size_t	len
