s32
s32	tmax
s32	tmin
s32	percent
s32	min_result
bool	even
