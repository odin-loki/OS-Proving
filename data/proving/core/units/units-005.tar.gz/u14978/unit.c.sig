bool
const ktime_t	timestamp
