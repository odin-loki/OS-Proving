int
struct qedr_dev *	dev
struct qedr_pbl_info *	pbl_info
u32	num_pbes
int	two_layer_capable
