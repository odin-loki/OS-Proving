u_int
u_int	hash
