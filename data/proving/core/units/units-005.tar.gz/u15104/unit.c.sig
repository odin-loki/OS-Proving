u_int
u_short	sock
u_int	mask0
