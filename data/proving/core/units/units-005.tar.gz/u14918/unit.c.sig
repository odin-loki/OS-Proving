unsigned int
unsigned int	irq
int	cpu
