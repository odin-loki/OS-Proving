int
const struct nvkm_event_func *	func
struct nvkm_subdev *	subdev
int	types_nr
int	index_nr
struct nvkm_event *	event
