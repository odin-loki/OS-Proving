u16
u32	bit_rate
