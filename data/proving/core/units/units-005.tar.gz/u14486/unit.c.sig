u64
u32	stripe_nr
