int
Wal *	pWal
