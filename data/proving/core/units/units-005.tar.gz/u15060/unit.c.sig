unsigned int
int	start_addr
int	keyid
