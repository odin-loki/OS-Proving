int
struct fsa4480 *	fsa
