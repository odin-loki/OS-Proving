int
struct device *	dev
struct rtc_time *	tm
