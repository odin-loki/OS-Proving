int
struct cyapa *	cyapa
bool	enable
