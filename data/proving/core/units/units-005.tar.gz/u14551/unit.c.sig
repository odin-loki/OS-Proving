unsigned long
const struct inode *	sufile
