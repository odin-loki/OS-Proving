int
struct acpi_resource *	res
void *	data
