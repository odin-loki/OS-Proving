bool
struct kfd_dev *	kfd
const struct kgd2kfd_shared_resources *	gpu_resources
