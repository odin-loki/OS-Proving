int
struct iio_dev *	indio_dev
unsigned int	sample_freq
unsigned int	spi_freq
