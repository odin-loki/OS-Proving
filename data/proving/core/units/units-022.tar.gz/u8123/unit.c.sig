int
int	sd
__u16	fid
__u32	pid
int	dev_id
struct msgtemplate *	msg
