int
struct scsi_qla_host *	vha
struct qla_qpair *	qpair
uint16_t	loop_id
uint64_t	lun
uint8_t	type
