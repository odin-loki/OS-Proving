s64
unsigned int	len
s64	slope
s64	port_rate
