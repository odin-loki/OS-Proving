u32
struct amd64_pvt *	pvt
u8	dct
int	csrow_nr
