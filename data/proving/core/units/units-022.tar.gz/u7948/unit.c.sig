int
int	start
unsigned	length
unsigned	last
