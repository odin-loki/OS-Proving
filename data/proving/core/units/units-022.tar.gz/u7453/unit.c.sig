unsigned long
struct file *	file
unsigned long	uaddr
unsigned long	len
unsigned long	pgoff
unsigned long	flags
