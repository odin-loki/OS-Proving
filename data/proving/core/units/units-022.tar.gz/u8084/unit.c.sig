int
struct snd_card *	card
enum snd_device_type	type
void *	device_data
const struct snd_device_ops *	ops
