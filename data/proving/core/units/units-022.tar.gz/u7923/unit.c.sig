unsigned short
unsigned short	dimension
