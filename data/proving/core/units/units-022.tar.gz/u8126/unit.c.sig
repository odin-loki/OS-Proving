ssize_t
struct file *	filp
const char *	buf
size_t	count
loff_t *	ppos
