u16
u16	beacon_val
u16	max_beacon_val
