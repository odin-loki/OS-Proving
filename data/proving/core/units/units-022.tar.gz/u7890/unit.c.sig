int
u64	a
void *	b
short	c
int	d
void *	e
u64	f
