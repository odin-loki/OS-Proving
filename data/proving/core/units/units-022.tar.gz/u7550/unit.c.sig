int
u8	dramcr
