int
struct pci_bus *	bus
