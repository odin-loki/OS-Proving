u32
struct ssb_mipscore *	mcore
