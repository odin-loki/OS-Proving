unsigned int
unsigned int	ratio
