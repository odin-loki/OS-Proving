int
struct mem_ctl_info *	mci
