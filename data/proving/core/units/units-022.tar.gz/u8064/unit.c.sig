int
struct nvkm_instmem *	imem
u32	size
u32	align
bool	zero
struct nvkm_memory **	pmemory
