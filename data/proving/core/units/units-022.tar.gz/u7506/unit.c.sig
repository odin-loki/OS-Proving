int
dm_oblock_t	lhs
dm_oblock_t	rhs
