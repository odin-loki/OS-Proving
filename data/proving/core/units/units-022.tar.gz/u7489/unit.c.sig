bool
u64	error_code
