int
struct intel_display *	display
int	min_cdclk
