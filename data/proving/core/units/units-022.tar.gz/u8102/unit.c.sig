int
u32	lval
u32	rval
