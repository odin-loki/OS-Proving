int
int	a_out
