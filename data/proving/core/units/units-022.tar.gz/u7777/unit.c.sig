s8
struct b43legacy_wldev *	dev
s8	tssi
