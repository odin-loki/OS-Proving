int
struct comedi_device *	dev
int	dma_index
int	n
