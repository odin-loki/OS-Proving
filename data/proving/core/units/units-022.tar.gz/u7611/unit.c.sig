bool
u8	mask
