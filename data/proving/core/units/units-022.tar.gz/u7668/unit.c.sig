void
struct idpf_vport *	vport
u16 *	num_txq
u16 *	num_rxq
