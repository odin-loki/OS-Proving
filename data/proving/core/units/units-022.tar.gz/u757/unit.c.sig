int
struct nfp_app *	app
u8	mask_id
