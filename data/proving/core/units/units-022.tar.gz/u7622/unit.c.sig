int
struct file *	file
loff_t	lstart
loff_t	lend
