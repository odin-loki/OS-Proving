bool
enum criteria	cr
