int
int	dump_type
