int
struct mtdswap_dev *	d
unsigned int	eblocks
unsigned int	spare_cnt
