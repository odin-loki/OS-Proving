unsigned char
unsigned	offset
