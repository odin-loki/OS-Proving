unsigned long
int	cpu
unsigned long	actual
unsigned long	min
unsigned long	max
