ptrdiff_t
ptrdiff_t	nitems
ptrdiff_t	itemsize
