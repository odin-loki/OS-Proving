unsigned int
unsigned int	u_ctrl_val
unsigned int	vol_max
unsigned int	vol_gain_sft
