int
device_t	dev
xdma_channel_t *	xchan
uint32_t *	capacity
