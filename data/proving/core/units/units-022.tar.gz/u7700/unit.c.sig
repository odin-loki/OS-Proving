unsigned int
struct slgt_info *	info
