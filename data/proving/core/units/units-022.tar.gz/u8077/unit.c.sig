uint8_t
uint16_t	state
