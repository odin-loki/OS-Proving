int
bool	is_log
int	psize
