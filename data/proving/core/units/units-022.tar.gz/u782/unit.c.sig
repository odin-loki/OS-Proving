int
struct tda8083_state*	state
u32	srate
