bool
struct kvm *	kvm
