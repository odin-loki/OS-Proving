bool
swreg	reg
