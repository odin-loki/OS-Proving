int
struct platform_device *	pdev
struct spear_pinctrl_machdata *	machdata
