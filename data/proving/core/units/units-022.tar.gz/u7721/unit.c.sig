unsigned int
int	mult
