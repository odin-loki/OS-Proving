uint64_t
const uint8_t	cos
const uint8_t	pri_set
