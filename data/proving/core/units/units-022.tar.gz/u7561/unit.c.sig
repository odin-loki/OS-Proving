int
int	degrees
int	factor
