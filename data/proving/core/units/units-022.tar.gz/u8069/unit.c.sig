int
const char	c
