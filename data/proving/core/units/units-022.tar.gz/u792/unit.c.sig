bool
u8	seq1
u8	seq2
