int
int	bit
