bool
int	minor
