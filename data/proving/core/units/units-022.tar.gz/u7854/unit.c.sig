unsigned int
struct dw_i2s_dev *	dev
struct snd_pcm_runtime *	runtime
unsigned int	rx_ptr
bool *	period_elapsed
