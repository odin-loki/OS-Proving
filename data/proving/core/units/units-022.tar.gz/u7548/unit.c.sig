int
u32	reg
int	lobit
int	hibit
int	add
int	minval
int	maxval
const char *	name
