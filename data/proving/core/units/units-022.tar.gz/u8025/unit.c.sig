int
struct mlx5e_priv *	priv
struct mlx5e_params *	params
struct mlx5e_xsk_param *	xsk
struct xsk_buff_pool *	pool
struct mlx5e_channel *	c
