void
u64 *	arg
u32	val
