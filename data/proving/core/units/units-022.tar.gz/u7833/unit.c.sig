int
struct wil6210_priv *	wil
const struct wil_fw_record_concurrency *	conc
