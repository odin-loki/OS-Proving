int
unsigned char	u_val
