int
struct gbaudio_module_info *	module
struct gb_audio_topology *	tplg_data
