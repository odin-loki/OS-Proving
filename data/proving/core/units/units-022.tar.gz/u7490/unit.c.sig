u32
struct snd_emux_voice *	vp
