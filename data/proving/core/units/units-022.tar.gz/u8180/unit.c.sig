size_t
struct nfs_pageio_descriptor *	pgio
struct nfs_page *	prev
struct nfs_page *	req
