int
struct pbs_dev *	pbs
u8	bitmap
