int
struct idtcm *	idtcm
u32	index
