unsigned int
__le16	i_xattr_icount
