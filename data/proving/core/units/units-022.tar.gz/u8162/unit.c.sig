bool
struct qed_hwfn *	p_hwfn
u32 *	disabled_vfs
