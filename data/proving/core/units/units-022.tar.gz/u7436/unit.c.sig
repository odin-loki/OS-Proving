int
struct nct6775_data *	data
const u16 *	regp
int *	available
int *	mask
