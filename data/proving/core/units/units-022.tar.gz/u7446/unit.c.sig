bool
struct xe_device *	xe
u32	wopcm_size
u32	guc_wopcm_base
u32	guc_wopcm_size
u32	guc_fw_size
u32	huc_fw_size
