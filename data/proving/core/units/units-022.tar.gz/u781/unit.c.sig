int
struct dw_mci *	host
bool	sample
int	degrees
