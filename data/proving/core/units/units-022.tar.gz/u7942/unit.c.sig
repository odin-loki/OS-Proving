int
xen_pfn_t *	frames
unsigned long	nr_gframes
unsigned long	max_nr_gframes
void **	__shared
