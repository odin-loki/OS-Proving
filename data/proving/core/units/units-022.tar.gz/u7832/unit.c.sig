int
struct qlcnic_adapter *	adapter
int	sem
u32	id_reg
