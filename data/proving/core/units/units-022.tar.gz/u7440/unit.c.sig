int
const struct nvkm_i2c_aux_func *	func
struct nvkm_i2c_pad *	pad
int	index
u8	drive
struct nvkm_i2c_aux **	paux
