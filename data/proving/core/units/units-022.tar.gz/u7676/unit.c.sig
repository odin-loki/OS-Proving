int
int	pxm
