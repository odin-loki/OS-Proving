int
struct stmmac_priv *	priv
int	phyaddr
int	phyreg
u32	mask
u32	val
