bool
int	preempt_offset
