int
int	raw_volt
