int
int	dim
