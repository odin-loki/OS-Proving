unsigned int
const struct starfive_pinctrl *	sfp
unsigned int	pin
