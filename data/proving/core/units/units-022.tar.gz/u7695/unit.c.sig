int
struct qlcnic_sriov *	sriov
struct qlcnic_vf_info *	vf
struct qlcnic_bc_trans *	trans
