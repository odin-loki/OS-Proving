int32_t
sli4_t *	sli4
?	?
uint32_t	num_cqs
uint32_t	n_entries
?	?
