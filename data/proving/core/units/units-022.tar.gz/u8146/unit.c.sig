int
struct clk *	clock
void *	base
unsigned int	irq
