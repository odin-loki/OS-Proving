int
u32	psn_a
u32	psn_b
