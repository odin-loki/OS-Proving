int
const struct snd_soc_dai_link *	dai_link
int	stream
