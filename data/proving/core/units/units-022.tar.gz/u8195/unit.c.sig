int
int	n_ports
