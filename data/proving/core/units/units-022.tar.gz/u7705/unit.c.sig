int
u32	n
