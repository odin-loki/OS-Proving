uint32_t
uint32_t	index
uint32_t	count
uint32_t	max
