unsigned int
struct gpib_board *	board
struct tms9914_priv *	priv
unsigned int	nano_sec
