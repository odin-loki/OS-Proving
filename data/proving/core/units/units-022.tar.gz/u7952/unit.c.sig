bool
u8	len
