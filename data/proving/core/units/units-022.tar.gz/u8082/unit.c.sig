int
int	err_type
struct llcc_drv_data *	drv
