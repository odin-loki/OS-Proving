u64
u64	map
u64	size
u64	flags
u64	__ur_1
u64	__ur_2
