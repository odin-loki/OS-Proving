u8
struct rtw89_dev *	rtwdev
u8	gain
enum rtw89_rf_path	path
