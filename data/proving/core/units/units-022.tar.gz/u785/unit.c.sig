u32
u32	rate
u16	cpsdvsr
u16	scr
