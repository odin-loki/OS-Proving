bool
enum kobj_ns_type	type
