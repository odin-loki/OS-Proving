int
void *	buf
struct semid64_ds *	in
int	version
