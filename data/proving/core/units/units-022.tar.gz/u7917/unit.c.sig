bool
const void *	e
