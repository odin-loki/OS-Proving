u32
struct ipw_priv *	priv
