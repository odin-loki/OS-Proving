uint64_t
int64_t	val
