int
MPT_ADAPTER *	ioc
int	size
