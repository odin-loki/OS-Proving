int
struct file *	file
int	lock
struct ucounts *	ucounts
