int
struct intel_guc *	guc
struct __guc_capture_bufstate *	buf
u32 *	dw
