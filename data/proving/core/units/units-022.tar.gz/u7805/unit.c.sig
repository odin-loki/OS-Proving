u32
u32	dclk
u32	xres
