int
struct bnx2x_fastpath *	fp
int	rx_ring_size
