int
int	temp
int	offset
int	slope
