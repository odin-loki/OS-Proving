s32
s32	delta
s32	max_delta
