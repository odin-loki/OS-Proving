int
struct ath10k *	ar
const struct ath10k_mem_region *	mem_region
u8 *	buf
size_t	buf_len
