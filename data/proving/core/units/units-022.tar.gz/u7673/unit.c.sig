int
unsigned long	addr
unsigned long	start
unsigned long	end
