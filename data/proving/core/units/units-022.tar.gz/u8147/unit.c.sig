int
struct x86_emulate_ctxt *	ctxt
struct operand *	op
unsigned	size
bool	sign_extension
