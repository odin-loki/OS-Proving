int
struct mtip_port *	port
struct host_to_dev_fis *	fis
int	fis_len
dma_addr_t	buffer
int	buf_len
u32	opts
unsigned long	timeout
