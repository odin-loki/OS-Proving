unsigned int
unsigned int	brightness
