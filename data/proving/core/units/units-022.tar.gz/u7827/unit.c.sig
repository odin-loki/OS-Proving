int
struct imx334 *	imx334
u32	exposure
u32	gain
