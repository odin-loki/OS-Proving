int
struct cc_drvdata *	p_drvdata
