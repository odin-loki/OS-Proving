u8
u8	channel
u8	chnl_bw
u8	chnl_offset
