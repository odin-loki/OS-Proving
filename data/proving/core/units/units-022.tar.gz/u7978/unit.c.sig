int
struct dsa_switch *	ds
int	port
int	new_mtu
