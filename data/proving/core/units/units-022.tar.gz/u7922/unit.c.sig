u32
struct net_device *	netdev
