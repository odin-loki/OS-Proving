u32
struct xsk_queue *	q
u32	max
