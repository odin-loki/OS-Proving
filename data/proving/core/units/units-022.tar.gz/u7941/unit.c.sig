int
struct rpc_xprt *	xprt
unsigned int	reqs
