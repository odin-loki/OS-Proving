int
struct efx_rx_queue *	rx_queue
bool	atomic
