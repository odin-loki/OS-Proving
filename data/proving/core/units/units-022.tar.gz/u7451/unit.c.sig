int
struct em_sti_priv *	p
