int
struct folio **	foliop
struct mm_struct *	mm
struct collapse_control *	cc
