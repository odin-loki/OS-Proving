unsigned int
struct qcom_ice *	ice
unsigned int	slot
