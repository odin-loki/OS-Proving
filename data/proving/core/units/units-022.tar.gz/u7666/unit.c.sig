int
struct acpi_power_meter_resource *	resource
u16	trip_idx
unsigned long	trip
