int
struct ice_hw *	hw
bool	enable_mib_change
