int
int	irq
unsigned int	from
unsigned int	cnt
int	node
struct module *	owner
const struct irq_affinity_desc *	affinity
