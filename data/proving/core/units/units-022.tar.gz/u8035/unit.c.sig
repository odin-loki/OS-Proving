u32
struct i810fb_par *	par
int	xres_virtual
int	bpp
