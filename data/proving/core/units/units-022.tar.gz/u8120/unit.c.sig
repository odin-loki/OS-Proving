int
int	nr
int	age
int *	contention
