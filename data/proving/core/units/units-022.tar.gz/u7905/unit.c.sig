unsigned int
struct b43_wldev *	dev
