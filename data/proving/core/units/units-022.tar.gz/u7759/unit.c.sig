void
struct ip_fw_chain *	ch
int	last
