int
struct amd_mp2_dev *	privdata
