u_int
u_int	data
u_int	shift
