int
struct ath11k *	ar
u32	ant
bool	is_tx_ant
