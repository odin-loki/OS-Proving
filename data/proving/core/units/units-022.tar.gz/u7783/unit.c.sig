bool
unsigned int	arg
