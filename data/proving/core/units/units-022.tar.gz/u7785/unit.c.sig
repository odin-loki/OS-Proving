u8
struct device *	dev
struct sx_common_reg_default *	reg_def
const char *	prop
