enum v4l2_fwnode_orientation
struct acpi_device *	adev
