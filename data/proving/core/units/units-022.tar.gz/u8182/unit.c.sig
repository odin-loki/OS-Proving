sbit32
smRoot_t *	smRoot
sbit32 volatile *	Addend
