int
const struct ubi_device *	ubi
const struct ubi_vid_hdr *	vid_hdr
const struct ubi_ainf_volume *	av
int	pnum
