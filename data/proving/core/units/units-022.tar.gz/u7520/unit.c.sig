bool
int	axis
