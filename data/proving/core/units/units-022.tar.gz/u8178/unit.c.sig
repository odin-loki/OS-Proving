int
unsigned int	flags
