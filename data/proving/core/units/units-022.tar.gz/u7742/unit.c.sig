u32
u8	vcu
