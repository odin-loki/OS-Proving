int
struct mii_bus *	bus
int	phy_id
int	regnum
