int
char *	data
int	swidth
int	sheight
int	sdepth
