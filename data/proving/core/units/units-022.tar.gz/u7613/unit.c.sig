unsigned int
uint32_t	ports
uint32_t	adat_width
