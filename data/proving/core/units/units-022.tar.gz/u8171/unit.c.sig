bool
unsigned long	address
