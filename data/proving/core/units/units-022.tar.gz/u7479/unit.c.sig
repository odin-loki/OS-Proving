enum hnae3_reset_type
struct hnae3_ae_dev *	ae_dev
unsigned long *	addr
