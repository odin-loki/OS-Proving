int
struct gve_rx_ring *	rx
int	budget
netdev_features_t	feat
