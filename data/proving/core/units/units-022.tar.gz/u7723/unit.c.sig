int
struct nge_softc *	sc
