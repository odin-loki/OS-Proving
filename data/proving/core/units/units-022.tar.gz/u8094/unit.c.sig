int
struct sock *	sk
long *	timeo
