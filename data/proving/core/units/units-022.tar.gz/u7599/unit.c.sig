int
struct iio_dev *	indio_dev
unsigned int	scan_index
