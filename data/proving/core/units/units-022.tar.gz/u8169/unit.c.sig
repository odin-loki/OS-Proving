uint64_t
ispsoftc_t *	isp
int	chan
int	isactive
int	iswwnn
