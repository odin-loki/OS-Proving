int
u8 *	dst
u8 *	p
