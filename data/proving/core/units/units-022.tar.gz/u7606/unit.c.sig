u32
u32	bit_width
