int
struct gsc_context *	ctx
u32	src
u32	dst
u32 *	ratio
