int
struct pipe_inode_info *	pipe
