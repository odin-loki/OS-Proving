int
struct hid_device *	hdev
struct hid_report *	report
u8 *	data
int	size
bool	nested
