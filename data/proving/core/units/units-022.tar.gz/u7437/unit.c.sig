u64
const u64	j
