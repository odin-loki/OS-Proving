int
struct virtio_pcm_substream *	vss
unsigned long	offset
unsigned long	bytes
