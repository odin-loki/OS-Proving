int
struct r5l_log *	log
struct stripe_head *	sh
