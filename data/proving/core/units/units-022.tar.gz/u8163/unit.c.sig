int
enum mc_cmd_status	status
