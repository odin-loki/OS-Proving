int
struct dm_kcopyd_client *	kc
unsigned int	nr
struct page_list **	pages
