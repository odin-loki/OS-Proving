int
struct inode *	inode
struct file *	filep
