int
struct sk_buff *	msg
const struct net_dm_hw_entry *	hw_entry
