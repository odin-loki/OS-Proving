int
struct rc5t583 *	rc5t583
struct rc5t583_platform_data *	pdata
