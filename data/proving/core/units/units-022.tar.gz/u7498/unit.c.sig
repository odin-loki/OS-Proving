int
struct cros_ec_keyb *	ckdev
