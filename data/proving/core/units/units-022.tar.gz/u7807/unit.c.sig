bool
struct hinic_hwdev *	hwdev
u16	func_idx
void *	buf_in
u16	in_size
