enum dma_slave_buswidth
u32	buf_len
dma_addr_t	buf_addr
u32	threshold
