int
struct clkdom *	clkdom
device_t	fw
struct zynqmp_clk *	clkdef
