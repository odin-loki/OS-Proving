bool
u32	base
u32	num
