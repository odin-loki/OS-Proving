int
const seqcount_latch_t *	s
unsigned	start
