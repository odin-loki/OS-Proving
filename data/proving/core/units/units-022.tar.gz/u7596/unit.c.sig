int
struct atmel_pmecc_user *	user
int	sector
void *	data
void *	ecc
