void
u32 *	cr1
u32 *	cr3
u32	delay_ADE
u32	delay_DDE
u32	baud
