int
unsigned long	addr
