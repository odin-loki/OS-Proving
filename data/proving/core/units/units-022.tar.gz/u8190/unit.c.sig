u32
struct hfi1_ctxtdata *	rcd
