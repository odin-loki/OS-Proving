int
int	word_len
