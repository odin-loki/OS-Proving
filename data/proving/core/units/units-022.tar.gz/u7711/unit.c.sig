int
struct vmbus_channel *	chan
int	data_len
uint32_t	skip
vmbus_br_copy_callback_t	cb
void *	cbarg
