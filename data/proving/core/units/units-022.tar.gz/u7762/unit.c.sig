int
CHAR_T	c
