int
struct se_wwn *	se_wwn
struct se_portal_group *	se_tpg
int	proto_id
