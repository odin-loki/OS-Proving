int
struct hnae3_handle *	nic
struct hnae3_ae_dev *	ae_dev
struct hclge_comm_rss_cfg *	rss_cfg
