uint32_t
uint32_t	maxseg
