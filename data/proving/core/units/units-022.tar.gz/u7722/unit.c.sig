int
struct wpa_global *	global
struct wpa_supplicant *	wpa_s
