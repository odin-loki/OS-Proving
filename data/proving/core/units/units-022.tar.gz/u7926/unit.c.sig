int
sector_t	sector
