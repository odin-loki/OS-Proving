int
struct ieee80211_tx_data *	tx
struct sk_buff *	skb
int	hdrlen
int	frag_threshold
