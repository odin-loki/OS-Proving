int
struct virtio_mem *	vm
