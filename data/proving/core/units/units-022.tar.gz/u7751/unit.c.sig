int
struct device_node *	np
struct device *	dev
unsigned int **	pid
unsigned int **	pmux
unsigned int *	npins
