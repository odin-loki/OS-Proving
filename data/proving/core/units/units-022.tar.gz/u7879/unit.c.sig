unsigned int
struct packet_fanout *	f
struct sk_buff *	skb
unsigned int	num
