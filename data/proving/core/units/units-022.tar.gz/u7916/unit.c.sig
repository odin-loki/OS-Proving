unsigned long long
u64	cookie
