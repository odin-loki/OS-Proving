bool
u32	mask
