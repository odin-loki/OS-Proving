int
struct mem_ctl_info *	mci
int	dev_idx
