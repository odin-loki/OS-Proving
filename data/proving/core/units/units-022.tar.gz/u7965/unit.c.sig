unsigned int
const struct mem_ctl_info *	mci
unsigned int	csrow
