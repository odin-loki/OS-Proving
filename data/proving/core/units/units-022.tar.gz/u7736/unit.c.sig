int
struct clk *	clk
unsigned int	num
unsigned int	den
