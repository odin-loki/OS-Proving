int
int	num
int	den
