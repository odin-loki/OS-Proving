int
int	theta
