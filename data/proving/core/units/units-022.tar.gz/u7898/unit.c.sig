bool
unsigned long	old
unsigned long	new
