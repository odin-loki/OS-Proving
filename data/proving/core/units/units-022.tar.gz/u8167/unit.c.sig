int
struct qla_qpair *	qpair
uint32_t	req_cnt
