int
struct nilfs_segment_buffer *	segbuf
struct buffer_head **	bhp
