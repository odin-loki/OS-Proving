bool
u64	rcd
