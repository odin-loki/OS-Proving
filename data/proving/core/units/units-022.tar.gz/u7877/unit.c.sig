loff_t
int	bits
int	has_huge_files
