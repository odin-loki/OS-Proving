int
int	expn
int	N
