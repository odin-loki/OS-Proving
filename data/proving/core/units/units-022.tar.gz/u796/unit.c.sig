int
struct wcd_mbhc *	mbhc
uint32_t *	zl
uint32_t *	zr
