int
char	n
