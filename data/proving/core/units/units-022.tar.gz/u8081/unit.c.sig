uint32_t
struct ath_hal *	ah
const HAL_RATE_TABLE *	rates
uint32_t	frameLen
uint16_t	rateix
HAL_BOOL	isht40
HAL_BOOL	shortPreamble
HAL_BOOL	includeSifs
