bool
const struct xfs_inode *	ip
