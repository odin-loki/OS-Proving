u32
enum spu_cipher_mode	cipher_mode
unsigned int	data_size
