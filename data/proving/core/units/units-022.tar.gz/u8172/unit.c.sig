int
struct gspca_dev *	gspca_dev
__s32	val
