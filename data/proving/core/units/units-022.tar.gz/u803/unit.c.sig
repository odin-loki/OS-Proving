bool
dev_t	dev
