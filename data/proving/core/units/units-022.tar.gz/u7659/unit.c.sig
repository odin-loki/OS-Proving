ssize_t
struct pipe_inode_info *	ipipe
struct pipe_inode_info *	opipe
size_t	len
unsigned int	flags
