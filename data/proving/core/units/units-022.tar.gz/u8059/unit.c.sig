int
struct vma_iterator *	vmi
struct vm_area_struct *	vma
unsigned long	addr
int	new_below
