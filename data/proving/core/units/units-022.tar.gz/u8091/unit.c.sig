int
struct device *	dev
int	num_paths
struct icc_bulk_data *	paths
