bool
int	value
