unsigned char
unsigned char	group
