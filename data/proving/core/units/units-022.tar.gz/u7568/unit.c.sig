loff_t
int	blkbits
int	has_huge_files
