int
vm_offset_t	addr
