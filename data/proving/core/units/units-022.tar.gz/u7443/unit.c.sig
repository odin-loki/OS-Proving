unsigned int
u32	iops_limit
unsigned long	jiffy_elapsed
