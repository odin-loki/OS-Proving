u8
unsigned int	opb
