int
struct wiphy *	wiphy
struct iface_combination_params *	params
