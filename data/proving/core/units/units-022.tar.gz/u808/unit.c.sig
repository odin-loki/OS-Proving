int
u32	perm
