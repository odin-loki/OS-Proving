unsigned long
unsigned long	usage
unsigned long	parent_usage
unsigned long	setting
unsigned long	parent_effective
unsigned long	siblings_protected
bool	recursive_protection
