int
bus_addr_t	lowaddr
bus_addr_t	highaddr
