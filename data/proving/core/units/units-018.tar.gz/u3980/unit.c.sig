int
struct usb_gadget *	g
