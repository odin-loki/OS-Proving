u32
u8	opcode
u8	groupid
u8	version
