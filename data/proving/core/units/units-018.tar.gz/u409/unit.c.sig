bool
ino_t	ino
