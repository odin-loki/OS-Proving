int
struct imgu_device *	imgu
struct imgu_css_pool *	pool
size_t	size
