int
struct nvkm_fb *	fb
struct nvkm_ram **	pram
