int
struct netfront_queue *	queue
