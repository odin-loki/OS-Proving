int
fmode_t	md
