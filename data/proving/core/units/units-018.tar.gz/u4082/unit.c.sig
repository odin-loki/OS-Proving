bool
int	total
int	young
