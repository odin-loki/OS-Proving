int
unsigned long	offset
u32 *	value
