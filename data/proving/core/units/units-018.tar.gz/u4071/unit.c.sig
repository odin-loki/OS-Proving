int
struct ida *	ida
int *	p_id
