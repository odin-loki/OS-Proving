bool
int	shift
