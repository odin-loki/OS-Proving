int
struct scsi_device *	sdev
