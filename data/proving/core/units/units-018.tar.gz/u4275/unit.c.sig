code_int
struct s_zstate *	zs
