int
struct iscsi_node_acl *	acl
u32	random_r2t_offsets
