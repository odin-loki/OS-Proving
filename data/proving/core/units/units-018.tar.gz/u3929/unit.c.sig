bool
int	old
int	new
int	threshold
