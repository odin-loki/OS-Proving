bool
int	a
int	b
int	window
int	intval
