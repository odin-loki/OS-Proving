int
struct ath12k_base *	ab
struct ath12k_ce_ring *	ce_ring
int	ce_id
enum hal_ring_type	type
