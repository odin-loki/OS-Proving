int
int	old
int	new
