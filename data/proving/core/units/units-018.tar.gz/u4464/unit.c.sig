u32
int *	x
int *	y
unsigned int	tile_width
unsigned int	tile_height
unsigned int	tile_size
unsigned int	pitch_tiles
u32	old_offset
u32	new_offset
