void
long *	value
