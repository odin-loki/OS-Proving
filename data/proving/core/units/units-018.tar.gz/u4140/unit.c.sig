unsigned int
unsigned int	x
unsigned int	min
unsigned int	max
unsigned int	alignment
