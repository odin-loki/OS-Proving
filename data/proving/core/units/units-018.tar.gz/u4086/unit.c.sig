int
u64	paddr
unsigned long	size
enum page_cache_mode	pcm
enum page_cache_mode	new_pcm
