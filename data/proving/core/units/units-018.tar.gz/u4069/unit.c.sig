bool
sector_t	block_size
uint32_t	n
