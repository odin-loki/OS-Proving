int
struct mtk_base_afe *	afe
int	id
int	priv_size
const void *	priv_data
