fmode_t
int	flags
