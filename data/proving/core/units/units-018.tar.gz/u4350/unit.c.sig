int
struct adapter *	adapter
