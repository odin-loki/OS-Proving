unsigned long long
unsigned int	blkbits
