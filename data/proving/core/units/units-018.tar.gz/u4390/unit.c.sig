int
struct ath10k_htt *	htt
bool	is_mgmt
bool	is_presp
