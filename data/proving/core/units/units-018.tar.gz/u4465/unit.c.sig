bool
struct f2fs_sb_info *	sbi
int	type
