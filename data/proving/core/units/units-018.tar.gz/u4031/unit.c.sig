u8
s32	rgb_ctrl_val
