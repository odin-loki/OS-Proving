bool
u32	algtype
