unsigned int
dma_addr_t	addr
