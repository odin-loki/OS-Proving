int
const char *	type
char *	buf
size_t	bufsz
