u_int
u_int	addr
