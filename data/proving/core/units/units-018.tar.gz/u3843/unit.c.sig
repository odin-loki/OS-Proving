u32
struct ti_sci_resource *	res
