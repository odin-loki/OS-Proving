int
struct platform_device *	pdev
struct ssusb_mtk *	ssusb
