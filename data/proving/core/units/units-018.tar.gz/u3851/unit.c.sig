float32
flag	zSign
int16	zExp
bits32	zSig
