unsigned int
unsigned int	rate
