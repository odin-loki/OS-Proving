ptrdiff_t
size_t	a
size_t	b
