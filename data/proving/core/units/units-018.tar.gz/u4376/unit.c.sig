uint32_t
uint32_t	tick_ms
unsigned long	clk_rate_khz
