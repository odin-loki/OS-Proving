int
const struct krb5_enctype *	krb5
struct crypto_aead *	aead
void **	_data
unsigned int *	_len
int *	_error_code
