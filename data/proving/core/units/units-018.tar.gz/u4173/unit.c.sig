u8
long	mdegC
