u32
u32	speed_hz
u32	ref_clk_hz
