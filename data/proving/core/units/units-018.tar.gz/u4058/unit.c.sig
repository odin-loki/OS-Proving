int
struct megasas_instance *	instance
