bool
__u32	seq1
__u32	seq2
