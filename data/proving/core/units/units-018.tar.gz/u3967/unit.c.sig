u64
u64	j
