unsigned long
unsigned long	ref_clk
unsigned long	div
