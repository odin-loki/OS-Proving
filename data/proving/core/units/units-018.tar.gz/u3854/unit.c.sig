int
struct bpf_prog *	prog
const union bpf_attr *	kattr
union bpf_attr *	uattr
