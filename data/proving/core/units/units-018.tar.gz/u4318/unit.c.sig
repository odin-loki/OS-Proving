bool
int	portno
