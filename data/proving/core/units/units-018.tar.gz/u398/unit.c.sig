int
struct apm_user *	as
