int
unsigned int	sample_flag
