int
struct device *	dev
struct wiz *	wiz
