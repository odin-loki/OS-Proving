int
int	outsize
