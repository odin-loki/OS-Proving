bool
s8	level
