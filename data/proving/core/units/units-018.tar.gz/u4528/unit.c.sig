int
struct acomp_alg *	alg
