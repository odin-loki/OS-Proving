int
z_streamp	strm
