void
atomic_t *	v
