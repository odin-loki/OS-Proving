int
struct thermal_zone_device *	tz
