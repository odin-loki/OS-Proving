int
struct rcar_pwm_chip *	rp
int	period_ns
