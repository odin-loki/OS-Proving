unsigned int
struct ath5k_hw *	ah
unsigned int	clock
