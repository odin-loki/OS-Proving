ktime_t
ktime_t	lhs
ktime_t	rhs
