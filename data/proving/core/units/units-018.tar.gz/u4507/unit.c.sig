int
struct bm_portal *	portal
