s32
int	pixels
u8	ps
