s32
struct i2c_client *	client
u8	command
