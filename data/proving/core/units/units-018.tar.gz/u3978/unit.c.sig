___u64
enum num_t	t
___u64	x
