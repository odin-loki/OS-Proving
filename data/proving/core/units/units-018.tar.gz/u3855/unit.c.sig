pci_ers_result_t
struct pci_dev *	dev
