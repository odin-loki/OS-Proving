__be64
bool	atomic
