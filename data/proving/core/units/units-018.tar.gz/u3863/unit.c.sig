int
struct rtl_fw *	rtl_fw
