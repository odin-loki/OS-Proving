int
u32	val
u8	counter
