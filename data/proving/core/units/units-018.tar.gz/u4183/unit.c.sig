int
barrier_t *	bar
