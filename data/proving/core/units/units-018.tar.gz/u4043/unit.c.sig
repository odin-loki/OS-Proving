int
struct ifnet *	ifp
struct mbuf *	m
