unsigned int
bool	sci_present
