u32
struct mlx5_core_dev *	mdev
u64	nbytes
