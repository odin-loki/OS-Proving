bool
u64	start
u64	end
u64	len
bool	io
