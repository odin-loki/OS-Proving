bool
uint32_t	a
uint32_t	b
