int
struct fsi_priv *	fsi
