u16
u8	mac_proto
