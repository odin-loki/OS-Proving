enum iavf_status
struct iavf_hw *	hw
struct iavf_dma_mem *	mem
