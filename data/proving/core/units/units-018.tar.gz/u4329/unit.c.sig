int
struct cx88_core *	core
u32	state
