u32
struct msm_dp_panel *	msm_dp_panel
u32	mode_edid_bpp
u32	mode_pclk_khz
