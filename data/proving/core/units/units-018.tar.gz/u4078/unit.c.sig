int
struct btrfs_path *	path
struct btrfs_key *	key
struct btrfs_inode *	inode
struct can_nocow_file_extent_args *	args
