u8
s64	link_freq
u32	timer_clk_rate
