bool
int	table_type
int	type
