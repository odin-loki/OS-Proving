int
struct bcm_vk *	vk
enum pci_barno	bar
u64	offset
u32	mask
u32	value
unsigned long	timeout_ms
