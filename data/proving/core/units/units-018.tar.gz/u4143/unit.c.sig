int
struct fc_lport *	lport
struct fc_fcp_pkt *	fsp
unsigned int	id
unsigned int	lun
