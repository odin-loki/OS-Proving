int
const int	status
