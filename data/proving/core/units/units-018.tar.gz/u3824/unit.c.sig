bool
struct acpi_resource *	ares
struct acpi_resource_gpio **	agpio
