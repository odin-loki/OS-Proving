u8
struct ice_fltr_info *	fi
