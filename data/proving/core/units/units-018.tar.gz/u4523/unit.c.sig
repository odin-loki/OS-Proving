int
struct pci_dev *	dev
int	type
int	ret
