int
int	pipe_child
int	pipe_parent
