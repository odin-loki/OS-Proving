u16
u8	funct3
u32	imm_hi
u8	rs1
u32	imm_lo
u8	rd
u8	op
