bool
int	nid
