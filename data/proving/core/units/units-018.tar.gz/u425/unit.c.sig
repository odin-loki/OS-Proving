u32
struct stv0367_state *	state
u32	mclk_hz
