int
struct amd_pmf_dev *	dev
