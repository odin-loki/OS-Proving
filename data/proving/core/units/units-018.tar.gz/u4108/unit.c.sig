_Bool
int	duplicate
int	original
