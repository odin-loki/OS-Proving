int
struct rpmsg_endpoint *	ept
bool	pause
u32	dst
