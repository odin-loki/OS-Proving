unsigned
unsigned int	usb_rate
