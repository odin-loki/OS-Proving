unsigned int
unsigned int	buf_len
unsigned int	buf_idx
