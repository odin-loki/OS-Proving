int
int	dir
