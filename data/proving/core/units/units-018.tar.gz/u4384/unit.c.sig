u32
u8	intrl
u8	gran
