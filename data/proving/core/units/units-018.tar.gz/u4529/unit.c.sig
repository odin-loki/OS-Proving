bool
enum ib_wr_opcode	op
