int
struct smc_connection *	conn
size_t	len
size_t	src_off
size_t	src_len
size_t	dst_off
size_t	dst_len
