int
long *	timeout
bool	interruptible
