bool
struct xhci_hcd *	xhci
int	num_tds
int	i
struct xhci_interrupter *	ir
