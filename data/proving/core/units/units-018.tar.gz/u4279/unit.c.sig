bool
stateid_t *	a
stateid_t *	b
