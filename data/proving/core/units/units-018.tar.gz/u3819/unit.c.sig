bool
struct packet_fanout *	f
u16	flag
