int
struct ocelot *	ocelot
int	grp
u32 *	xfh
