u16
u16	a
u16	b
