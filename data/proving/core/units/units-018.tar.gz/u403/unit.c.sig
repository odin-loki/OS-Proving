enum kvm_bus
__u32	flags
