bool
u64	value
