u32
u32	caps
bool	is_25g
