u64
struct cpudata *	cpudata
int	pstate
