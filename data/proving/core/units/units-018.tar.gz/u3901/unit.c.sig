int
int	uvtype
