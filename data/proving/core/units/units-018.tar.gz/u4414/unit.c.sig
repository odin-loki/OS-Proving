int
struct usb_serial_port *	port
int	has_headers
char *	packet
int	len
