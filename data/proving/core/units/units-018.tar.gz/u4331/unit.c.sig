int
struct ixgbe_hw *	hw
u32	mask
