int
const pcell_t *	data
int	addr_cells
int	size_cells
u_long *	start
u_long *	count
