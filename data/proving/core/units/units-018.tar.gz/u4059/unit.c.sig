uint64_t
device_t	dev
