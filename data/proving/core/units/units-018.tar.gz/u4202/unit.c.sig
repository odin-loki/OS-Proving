bool
struct etnaviv_gpu *	gpu
u32 *	stream
unsigned int	size
struct drm_etnaviv_gem_submit_reloc *	relocs
unsigned int	reloc_size
