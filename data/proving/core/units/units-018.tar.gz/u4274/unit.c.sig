unsigned int
unsigned int	bits
