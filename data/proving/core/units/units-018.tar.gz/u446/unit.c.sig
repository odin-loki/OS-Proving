int
pinfo_t *	pinfo
int	phy_addr
const struct mdio_ops *	mdio_ops
