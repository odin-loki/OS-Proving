bool
unsigned int	count
