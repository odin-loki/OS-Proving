int
struct scsi_cmnd *	cmd
