int
int	_timeoutpacket
int	_timeoutnetwork
int	_maxtimeouts
