u16
u8	funct3
u32	uimm
u8	rd
u8	op
