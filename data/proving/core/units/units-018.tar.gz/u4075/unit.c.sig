int
unsigned long	offset
