unsigned long
unsigned long	parent_rate
u32	fod_1st_int
u64	fod_frac
