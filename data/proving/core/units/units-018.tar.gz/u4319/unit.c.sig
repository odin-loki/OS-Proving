int
struct ddb_port *	port
