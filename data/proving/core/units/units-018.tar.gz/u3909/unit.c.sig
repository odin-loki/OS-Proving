enum dma_data_direction
u32	op
