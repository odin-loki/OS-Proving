u8
enum vpfe_ccdc_gamma_width	width
