unsigned long int
const char *	nptr
char **	endptr
int	base
