long
struct pvt_device *	pvt
u32	nbs
