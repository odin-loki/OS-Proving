u32
u32	cur
