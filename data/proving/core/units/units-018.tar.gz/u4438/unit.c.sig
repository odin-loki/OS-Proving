int
struct hdmi_avi_infoframe *	frame
void *	buffer
