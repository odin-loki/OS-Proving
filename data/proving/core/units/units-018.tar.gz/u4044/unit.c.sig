int
struct lan743x_adapter *	adapter
