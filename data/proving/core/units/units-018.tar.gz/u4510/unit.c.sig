int
struct dm_writecache *	wc
