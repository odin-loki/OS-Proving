u16
u16	cur_value
u8	new_value
