bool
u32	caps
