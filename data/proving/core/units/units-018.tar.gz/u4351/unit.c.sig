bool
const char *	fname
struct bpf_verifier_env *	env
struct nfp_insn_meta *	meta
u32	helper_tgt
const struct bpf_reg_state *	reg1
