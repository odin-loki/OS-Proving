enum num_t
enum num_t	t
