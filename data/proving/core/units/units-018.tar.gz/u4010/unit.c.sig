int __used
unsigned	n
