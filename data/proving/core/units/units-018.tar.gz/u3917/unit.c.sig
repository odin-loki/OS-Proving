int
struct i2c_client *	i2c_client
