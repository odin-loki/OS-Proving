void
struct ttm_resource_manager *	man
u64 *	avail
u64 *	visible_avail
