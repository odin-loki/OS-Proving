int
const struct device_node *	np
enum drm_panel_orientation *	orientation
