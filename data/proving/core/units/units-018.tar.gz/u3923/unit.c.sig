int
struct cache_disk_superblock *	disk_super
