bool
struct virtio_mem *	vm
uint64_t	size
