int
struct bnad *	bnad
