int
busdma_tag_t	tag
u_int	flags
busdma_md_t *	out_p
