u32
u32	wcpu_addr
