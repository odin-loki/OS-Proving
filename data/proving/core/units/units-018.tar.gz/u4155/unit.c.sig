int
struct safexcel_crypto_priv *	priv
