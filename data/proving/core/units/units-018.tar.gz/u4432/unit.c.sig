u32
int	max_burst
