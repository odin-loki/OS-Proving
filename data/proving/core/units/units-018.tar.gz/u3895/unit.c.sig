int
void *	base
int	timer_irq
unsigned int	timer_freq
