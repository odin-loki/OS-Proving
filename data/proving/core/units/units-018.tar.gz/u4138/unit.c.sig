bool
device_t	dev
uint64_t	feature
