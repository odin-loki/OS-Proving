int
struct genl_info *	info
u8	cmd
struct sk_buff **	skbp
size_t	size
