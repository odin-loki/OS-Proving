uint64_t
struct radeon_device *	rdev
