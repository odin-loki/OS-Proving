int
struct ptp_qoriq *	ptp_qoriq
struct device_node *	node
