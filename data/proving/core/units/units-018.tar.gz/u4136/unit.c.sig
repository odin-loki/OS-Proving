int
struct pmc_mdep *	md
int	cpu
