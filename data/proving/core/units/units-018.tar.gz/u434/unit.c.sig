u8
unsigned long	state
