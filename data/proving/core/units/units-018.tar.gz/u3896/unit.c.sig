int
struct bcm_vk *	vk
