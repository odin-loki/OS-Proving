int
struct snd_soc_component *	component
struct snd_pcm_substream *	substream
