int
struct keembay_pinctrl *	kpc
unsigned int	pin
unsigned int	drive
