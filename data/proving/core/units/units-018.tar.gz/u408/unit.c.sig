u64
struct request *	rq
struct ioc *	ioc
