unsigned int
unsigned char	a
unsigned char	b
