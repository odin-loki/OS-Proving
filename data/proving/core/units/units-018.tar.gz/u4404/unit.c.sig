int
struct ionic_v1_stat *	hw_stats
int	hw_stats_count
