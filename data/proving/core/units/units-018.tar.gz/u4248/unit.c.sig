int
struct kvm_vcpu *	vcpu
int	err
