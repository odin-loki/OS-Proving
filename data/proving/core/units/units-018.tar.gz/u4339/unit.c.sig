bool
__le16	addr
