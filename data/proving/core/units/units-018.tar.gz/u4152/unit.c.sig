int
u_char	c
