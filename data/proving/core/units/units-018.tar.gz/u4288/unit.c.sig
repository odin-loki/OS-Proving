bit32
bit32	a
bit32	b
