u32
struct stv0367_state *	state
u32	adc_hz
u32	mclk_hz
u32	SymbolRate
enum stv0367cab_mod	QAMSize
