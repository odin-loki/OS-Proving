int
struct cfi_softc *	sc
u_int	ofs
