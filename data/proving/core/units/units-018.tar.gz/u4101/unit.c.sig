int
int	mc
u64	ecclog
