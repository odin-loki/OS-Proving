unsigned int
struct ef4_nic *	efx
