unsigned int
unsigned int	max_cstate
