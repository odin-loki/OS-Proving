int
int	mask
