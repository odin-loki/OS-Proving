long
const char *	nptr
char **	endptr
int	base
