int
HPT_DPC	dpc
IAL_ADAPTER_T *	pAdapter
void *	arg
UCHAR	flags
