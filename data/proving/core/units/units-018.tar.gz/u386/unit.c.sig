int
struct mtk_wed_device *	dev
int	idx
void *	regs
bool	reset
