int
int	num_consumers
struct regulator_bulk_data *	consumers
