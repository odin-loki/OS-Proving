s16
s16	feat_val
s16	feature_data
bool	absolute
u8	clip
