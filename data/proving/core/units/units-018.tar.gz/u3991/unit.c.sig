bool
unsigned int	fmt
