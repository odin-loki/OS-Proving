int
struct btrfs_trans_handle *	trans
struct btrfs_fs_info *	fs_info
u64	bytenr
u64	offset
int	metadata
u64 *	refs
u64 *	flags
u64 *	owning_root
