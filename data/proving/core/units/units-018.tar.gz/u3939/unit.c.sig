bool
struct bpf_queue_stack *	qs
