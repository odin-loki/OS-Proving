int
struct ata_port *	ap
unsigned int	clk
