int
int	domain
int	type
int	protocol
