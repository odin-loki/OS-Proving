bool
u32	cmd
