u16
u16	idx
u16	ring_sz
