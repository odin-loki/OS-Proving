uint32_t
int32_t	sc_offset
uint32_t	val
bool	minus49
