int
struct rt2x00_dev *	rt2x00dev
struct rt2x00lib_crypto *	crypto
struct ieee80211_key_conf *	key
