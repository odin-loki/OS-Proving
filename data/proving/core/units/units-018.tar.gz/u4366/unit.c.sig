int
struct platform_device *	op
struct pxad_device *	pdev
unsigned int	nb_phy_chans
