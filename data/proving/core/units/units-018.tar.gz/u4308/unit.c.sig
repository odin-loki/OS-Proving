int
struct qla_tgt *	tgt
