int
struct optee *	optee
u_int	max_key
