size_t
size_t	x_orig
fxp_t	frac
