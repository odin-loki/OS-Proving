u32
struct ivpu_device *	vdev
u32	flags
