int
struct device *	dev
phys_addr_t	phys_addr
dma_addr_t	device_addr
size_t	size
