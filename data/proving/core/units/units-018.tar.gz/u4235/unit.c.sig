int
struct quotafile *	qf
int	wordsize
