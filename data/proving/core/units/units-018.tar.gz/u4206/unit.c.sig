int
struct lbs_private *	priv
u8 *	data
u32	len
