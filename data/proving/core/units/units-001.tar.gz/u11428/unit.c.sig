u16
u8	funct3
u32	imm6
u8	rd
u8	op
