unsigned int
unsigned int	a
unsigned int	b
