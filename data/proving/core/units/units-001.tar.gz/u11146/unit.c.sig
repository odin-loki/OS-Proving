int
struct ice_qs_cfg *	qs_cfg
