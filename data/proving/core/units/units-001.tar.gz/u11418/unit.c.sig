u64
struct bnxt_ptp_cfg *	ptp
u32	ts
