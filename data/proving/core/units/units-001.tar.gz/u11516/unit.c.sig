int
int	disable_power_well
