int
struct acpi_device *	adev
u32	event
