unsigned long
u16	ch0
u16	ch1
