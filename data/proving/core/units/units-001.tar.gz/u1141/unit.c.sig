u32
struct rtw89_dev *	rtwdev
u32	reg_base
u8	band
