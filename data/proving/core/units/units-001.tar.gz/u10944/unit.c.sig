s16
s64	coef
