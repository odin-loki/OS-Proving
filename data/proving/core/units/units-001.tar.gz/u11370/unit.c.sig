unsigned long
unsigned long	pfn
unsigned long	end_pfn
