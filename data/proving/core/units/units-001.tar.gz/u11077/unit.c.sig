bool
size_t	size
u32	add_key_flags
