int
struct iconv_converter_class *	dcp
