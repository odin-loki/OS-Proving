u16
int	code
