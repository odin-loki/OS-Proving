int
struct msm_dsi *	msm_dsi
struct drm_device *	dev
struct drm_encoder *	encoder
