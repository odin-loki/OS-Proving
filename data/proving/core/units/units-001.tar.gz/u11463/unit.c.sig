int
struct gsi *	gsi
