int
int	charset
int	length
