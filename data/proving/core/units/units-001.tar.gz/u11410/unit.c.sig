acpi_status
u64	operand
u32	count
u64 *	out_result
