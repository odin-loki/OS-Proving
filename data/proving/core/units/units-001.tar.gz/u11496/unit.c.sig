s32
struct dm_odm_t *	dm_odm
s32	curr_sig
