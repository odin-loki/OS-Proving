gpa_t
gfn_t	gfn
