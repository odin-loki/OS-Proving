bool
struct b43legacy_dmaring *	ring
dma_addr_t	addr
size_t	buffersize
bool	dma_to_device
