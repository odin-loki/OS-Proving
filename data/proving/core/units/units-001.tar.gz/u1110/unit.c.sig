bool
struct ufs_hw_queue *	q
