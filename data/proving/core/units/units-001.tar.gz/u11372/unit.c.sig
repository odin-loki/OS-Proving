int
struct btrfs_delayed_node *	node
struct btrfs_ref_tracker *	tracker
