int
struct dma_desc *	p
int	rx_coe
