acpi_status
u64	in_dividend
u32	divisor
u64 *	out_quotient
u32 *	out_remainder
