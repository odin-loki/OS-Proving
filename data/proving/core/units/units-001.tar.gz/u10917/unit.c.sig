int
struct fimc_is *	is
unsigned long	bit
unsigned int	state
unsigned int	timeout
