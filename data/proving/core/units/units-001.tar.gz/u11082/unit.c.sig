__s32
const struct hid_field *	field
__u16	code
