unsigned int
unsigned int	offset
i915_reg_t	_start
i915_reg_t	_next
i915_reg_t	_end
