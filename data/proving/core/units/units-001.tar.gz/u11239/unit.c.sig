int
struct usb_device *	dev
struct ezusb_fx_type	fx
const char *	firmware_path
