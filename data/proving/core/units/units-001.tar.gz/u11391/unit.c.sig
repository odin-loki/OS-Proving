int
struct adf_accel_dev *	accel_dev
