bool
u64	val
u64	fixed0
u64	fixed1
