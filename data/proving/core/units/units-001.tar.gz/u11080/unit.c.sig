unsigned int
struct amdgpu_device *	adev
unsigned int	width
unsigned int	cpp
bool	tiled
