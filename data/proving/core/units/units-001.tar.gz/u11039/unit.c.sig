int
unsigned int	bitwidth
