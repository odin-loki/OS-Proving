unsigned int
int	cpu
