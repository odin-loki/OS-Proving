int
struct ipack_bus_device *	bus
