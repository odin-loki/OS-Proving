int
const struct intel_dsi *	intel_dsi
