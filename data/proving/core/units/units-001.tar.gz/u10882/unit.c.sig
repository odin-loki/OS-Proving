int
struct cgroup *	cgrp
struct bpf_prog *	prog
struct bpf_prog *	replace_prog
struct bpf_cgroup_link *	link
enum bpf_attach_type	type
u32	flags
u32	id_or_fd
u64	revision
