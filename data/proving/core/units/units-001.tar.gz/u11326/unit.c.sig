unsigned int
struct tmio_mmc_host *	host
