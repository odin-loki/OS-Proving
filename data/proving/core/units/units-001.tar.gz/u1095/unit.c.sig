int
int	ecw
