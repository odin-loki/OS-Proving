bool
u16	asid
