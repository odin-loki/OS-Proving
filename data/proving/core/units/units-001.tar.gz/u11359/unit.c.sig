int
sector_t	s1
int	l1
sector_t	s2
int	l2
