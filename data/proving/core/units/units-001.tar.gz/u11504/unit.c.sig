u64
u64	xmit_wait_val
u16	link_width
u16	link_speed
