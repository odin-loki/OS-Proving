int
struct sk_buff *	skb
int	offset
