bool
const struct vdso_time_data *	vd
const struct vdso_clock *	vc
clockid_t	clk
struct __kernel_timespec *	ts
