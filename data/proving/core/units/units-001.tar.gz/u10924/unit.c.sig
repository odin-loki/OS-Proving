int
struct inode *	inode
loff_t	offset
loff_t	len
int	mode
