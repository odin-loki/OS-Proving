int
const struct modsig *	modsig
enum hash_algo *	algo
const u8 **	digest
u32 *	digest_size
