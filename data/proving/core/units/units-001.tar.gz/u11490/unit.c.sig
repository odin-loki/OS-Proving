int
struct bnx2fc_cmd *	aborted_io_req
