int
struct proc *	p
int	resource
uint64_t	amount
