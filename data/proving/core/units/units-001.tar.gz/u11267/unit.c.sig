int
struct ip_vs_stats *	s
