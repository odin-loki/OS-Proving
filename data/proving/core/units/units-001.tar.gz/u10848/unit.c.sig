bool
struct nlattr **	attrs
