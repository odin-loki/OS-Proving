int
struct hinic_pf_to_mgmt *	pf_to_mgmt
struct hinic_hwif *	hwif
