int
struct v4l2_subdev *	sd
u16	reg
u32	val
int *	err
