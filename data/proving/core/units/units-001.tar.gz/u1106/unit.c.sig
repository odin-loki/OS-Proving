s64
const ktime_t	kt
