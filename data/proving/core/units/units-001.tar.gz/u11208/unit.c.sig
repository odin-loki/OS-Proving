int
struct eth_dev *	dev
struct gether *	link
unsigned	n
