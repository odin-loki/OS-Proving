int
struct beiscsi_endpoint *	beiscsi_ep
