int
struct amd_cpudata *	cpudata
