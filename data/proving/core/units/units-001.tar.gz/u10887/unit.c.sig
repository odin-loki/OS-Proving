int
enum chip_type	chip
