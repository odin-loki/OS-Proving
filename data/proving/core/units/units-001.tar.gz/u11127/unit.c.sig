u32
u32	index
u32	count
u32	max
