ssize_t
u32 *	dst
struct mcu_msg_destroy_channel *	msg
