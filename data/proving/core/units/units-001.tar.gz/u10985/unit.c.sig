int
u8	link_bw
