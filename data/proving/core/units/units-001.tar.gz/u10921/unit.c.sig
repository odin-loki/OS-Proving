u32
u32	port_id
