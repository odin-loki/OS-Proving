int
struct w5100_priv *	priv
