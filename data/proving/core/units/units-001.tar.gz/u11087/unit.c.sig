int
struct amdgpu_device *	adev
unsigned int	type
uint64_t	size_in_page
