void
int	len
int *	firstPtr
int *	lastPtr
int *	rangeLenPtr
