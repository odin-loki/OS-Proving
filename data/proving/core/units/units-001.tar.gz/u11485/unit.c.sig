bool
u64	track_val
u64	var_val
