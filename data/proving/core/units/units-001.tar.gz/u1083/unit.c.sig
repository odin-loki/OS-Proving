int
struct sym_hcb *	np
