int
struct bnx2fc_rport *	tgt
struct fc_frame *	fp
