int
struct siw_cep *	cep
int	num
