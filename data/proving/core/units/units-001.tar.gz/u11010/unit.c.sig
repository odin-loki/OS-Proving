int
struct iio_dev *	indio_dev
unsigned long	channel_map
