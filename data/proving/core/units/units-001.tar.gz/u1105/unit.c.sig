U32
U32	hashLog
ZSTD_strategy	strat
