int
int	cdclk
