int
struct ice_hw *	hw
struct list_head *	v_list
