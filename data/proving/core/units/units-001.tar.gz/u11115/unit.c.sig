bool
struct bnx2x *	bp
u32	sig
int *	par_num
bool	print
