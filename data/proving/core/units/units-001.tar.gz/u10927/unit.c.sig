int
char *	str
unsigned int	val
