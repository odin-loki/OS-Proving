uint8_t
struct x86emu *	emu
uint8_t	d
uint8_t	s
