int
struct snd_pcm_substream *	plug
struct snd_pcm_plugin_format *	src_format
struct snd_pcm_plugin_format *	dst_format
struct snd_pcm_plugin **	r_plugin
