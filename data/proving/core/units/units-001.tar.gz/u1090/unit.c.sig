void
struct allegro_dev *	dev
struct allegro_buffer *	buffer
