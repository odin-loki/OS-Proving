void
int	i
atomic_t *	v
