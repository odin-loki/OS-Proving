int
struct mthca_dev *	dev
struct mthca_cq *	cq
struct mthca_qp **	cur_qp
int *	freed
struct ib_wc *	entry
