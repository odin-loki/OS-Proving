const __u8 *
struct hid_device *	hdev
__u8 *	rdesc
unsigned int *	rsize
