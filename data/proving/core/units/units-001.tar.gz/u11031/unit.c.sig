enum ena_xdp_errors_t
struct ena_adapter *	adapter
