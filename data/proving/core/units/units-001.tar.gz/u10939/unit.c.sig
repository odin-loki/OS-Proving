int
device_t	bus
device_t	child
struct resource *	r
rman_res_t	start
rman_res_t	end
