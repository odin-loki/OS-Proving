int
struct comedi_device *	dev
unsigned int *	ns
unsigned int	flags
