bool
int	idx
