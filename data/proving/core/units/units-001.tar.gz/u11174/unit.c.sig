unsigned int
struct btree_keys *	b
struct bset *	i
