int
int	usermode
int	prot
int	rsvd
uint64_t	pte
