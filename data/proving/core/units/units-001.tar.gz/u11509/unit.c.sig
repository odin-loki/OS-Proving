int
struct gnttab_vm_area *	area
unsigned	nr_frames
