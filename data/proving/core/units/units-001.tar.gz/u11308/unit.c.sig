s64
s64	ticks
