int
int	argc
?	?
const char *	optstring
