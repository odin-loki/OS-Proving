int
struct sock *	sk
struct sk_buff *	skb
