int
u32	risc
