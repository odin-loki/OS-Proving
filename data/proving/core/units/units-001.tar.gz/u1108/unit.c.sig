void
struct iwx_softc *	sc
struct iwx_rx_ring *	ring
