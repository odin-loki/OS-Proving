int
dev_t	_d
