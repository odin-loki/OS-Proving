int
struct lpfc_vport *	vport
uint16_t	tgt_id
uint64_t	lun_id
lpfc_ctx_cmd	context
