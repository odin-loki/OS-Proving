void
volatile uint64_t *	p
uint64_t	val
