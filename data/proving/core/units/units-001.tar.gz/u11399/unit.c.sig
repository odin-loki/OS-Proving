int
int	shrinker_id
