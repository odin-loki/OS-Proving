int
struct vb2_queue *	vq
unsigned int *	nbuffers
unsigned int *	nplanes
?	?
?	?
