int
struct ufs_hba *	hba
size_t	offset
size_t	len
const char *	prefix
