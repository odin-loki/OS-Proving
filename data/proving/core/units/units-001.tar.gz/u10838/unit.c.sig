u64
size_t	ns
u32	speed_mbps
