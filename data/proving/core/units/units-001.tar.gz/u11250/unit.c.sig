int
int	fs
int	sample_size
int	channels
int	tdm_slots
