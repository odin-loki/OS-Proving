int
vm_offset_t	addr
vm_size_t	size
