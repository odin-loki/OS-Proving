uint32_t
struct x86emu *	emu
uint32_t	d
uint32_t	s
