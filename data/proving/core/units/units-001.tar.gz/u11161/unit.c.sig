int
struct mtd_info *	mtd
int	new_state
