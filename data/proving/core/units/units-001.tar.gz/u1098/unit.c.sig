int
struct ast_device *	ast
