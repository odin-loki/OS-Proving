int
struct cs48l32_codec *	cs48l32_codec
const char *	propname
u32 *	dest
int	n_max
