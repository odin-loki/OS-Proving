int
u32	efuse
int	pmd
