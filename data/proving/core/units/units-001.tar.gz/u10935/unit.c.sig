int
struct snd_soc_component *	component
u32	dmic
bool	enable
