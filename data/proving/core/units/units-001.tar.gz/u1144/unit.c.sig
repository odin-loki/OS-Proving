enum pkt_hash_types
u64	rcd
