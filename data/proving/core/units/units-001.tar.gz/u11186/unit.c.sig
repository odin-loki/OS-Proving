int
unsigned char	cmd
