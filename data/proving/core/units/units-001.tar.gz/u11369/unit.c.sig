bool
const struct vdso_time_data *	vdns
const struct vdso_clock *	vcns
clockid_t	clk
struct __kernel_timespec *	ts
