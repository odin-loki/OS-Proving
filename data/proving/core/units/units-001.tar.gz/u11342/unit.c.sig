double
unsigned long long	total
unsigned long long	count
