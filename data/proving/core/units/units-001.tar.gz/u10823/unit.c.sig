bool
const struct sseu_dev_info *	sseu
int	slice
int	subslice
