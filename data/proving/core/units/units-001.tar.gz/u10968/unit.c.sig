int
struct nand_chip *	chip
const struct nand_subop *	subop
struct loongson_nand_op *	op
