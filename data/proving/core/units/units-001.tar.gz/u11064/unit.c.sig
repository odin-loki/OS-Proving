int
u32	flags
u32	version
