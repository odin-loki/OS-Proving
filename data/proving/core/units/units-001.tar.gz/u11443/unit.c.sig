int
unsigned long	con
