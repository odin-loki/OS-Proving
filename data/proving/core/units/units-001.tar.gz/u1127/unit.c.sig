qsize_t
qsize_t	space
