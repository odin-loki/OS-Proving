int
struct ena_com_dev *	ena_dev
uint32_t	debug_area_size
