int
unsigned int	wait_monitoring
