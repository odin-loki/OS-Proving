size_t
void *	buf
void *	entry_ptr
enum packing_op	op
