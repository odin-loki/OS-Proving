bool
int	error
