int
struct device_node *	np
struct net_device *	dev
