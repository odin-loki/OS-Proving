int
struct mlxsw_core *	mlxsw_core
const struct mlxsw_bus_info *	mlxsw_bus_info
struct mlxsw_thermal **	p_thermal
