int
struct airoha_npu *	npu
