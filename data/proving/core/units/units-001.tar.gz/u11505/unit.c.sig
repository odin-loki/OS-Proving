unsigned long
phys_addr_t	base1
phys_addr_t	size1
phys_addr_t	base2
phys_addr_t	size2
