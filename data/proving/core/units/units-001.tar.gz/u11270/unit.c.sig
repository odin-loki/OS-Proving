unsigned int
struct sdhci_s3c *	ourhost
unsigned int	src
unsigned int	wanted
