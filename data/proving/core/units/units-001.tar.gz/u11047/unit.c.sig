int
struct gve_priv *	priv
struct gve_tx_ring *	tx
void *	data
int	len
void *	frame_p
bool	is_xsk
