unsigned long
u32	vidfreq
