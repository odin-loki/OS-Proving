unsigned int
unsigned int	cc_fec
