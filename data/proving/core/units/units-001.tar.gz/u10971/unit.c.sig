u32
struct platform_device *	pdev
int	wanted
unsigned long	clk
