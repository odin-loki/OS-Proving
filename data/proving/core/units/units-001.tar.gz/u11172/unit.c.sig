int
struct sja1105_private *	priv
enum sja1105_reset_reason	reason
