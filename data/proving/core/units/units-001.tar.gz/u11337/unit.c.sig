int
struct device_node *	np
void *	base
const struct clock_config *	cfg
