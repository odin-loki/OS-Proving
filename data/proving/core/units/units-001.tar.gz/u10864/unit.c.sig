bool
unsigned long	r1_start
unsigned long	r1_end
unsigned long	r2_start
unsigned long	r2_end
