int
char	c
