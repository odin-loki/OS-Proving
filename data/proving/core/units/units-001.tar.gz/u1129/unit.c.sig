u8
int	state
