u16
u8	hi
u8	lo
