int
struct ubi_attach_info *	ai
