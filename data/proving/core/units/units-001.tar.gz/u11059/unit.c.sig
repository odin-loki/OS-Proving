int
struct mvneta_softc *	sc
