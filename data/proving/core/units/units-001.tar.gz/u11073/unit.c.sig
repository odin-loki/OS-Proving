int
struct mlx4_ib_dev *	dev
int	qpn
int	slave
