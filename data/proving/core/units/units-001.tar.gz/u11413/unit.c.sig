int
struct mmu_interval_notifier *	mni
unsigned long	cur_seq
struct kgd_mem *	mem
