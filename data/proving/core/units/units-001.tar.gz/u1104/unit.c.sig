u64
u64	block
unsigned int	bit
