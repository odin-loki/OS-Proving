unsigned int
int	idx
