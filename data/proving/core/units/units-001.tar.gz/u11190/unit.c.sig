uint32_t
const volatile uint32_t *	p
