int
int	x
int	xa
int	xb
int	ya
int	yb
