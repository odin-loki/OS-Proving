int32_t
struct gve_tx_ring *	tx
