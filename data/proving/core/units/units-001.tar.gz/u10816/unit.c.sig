u32
u32	usec
unsigned long	clk_hz
