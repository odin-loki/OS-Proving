int
u32	level
