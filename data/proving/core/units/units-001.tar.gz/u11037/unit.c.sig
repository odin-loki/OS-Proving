int
struct nvkm_gsp *	gsp
struct nvkm_falcon_fw *	fw
u32	if_offset
u32	init_cmd
