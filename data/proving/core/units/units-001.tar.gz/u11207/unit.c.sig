int
int	wakeref_count
