void
unsigned long	limit
