int
struct dma_chan *	dc
