int
struct completion *	x
unsigned int	state
