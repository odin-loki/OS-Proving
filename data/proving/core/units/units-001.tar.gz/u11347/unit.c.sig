int
struct inode *	inode
int	need
int	want
bool	nonblock
int *	got
