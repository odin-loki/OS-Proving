int
u8	comp_status
