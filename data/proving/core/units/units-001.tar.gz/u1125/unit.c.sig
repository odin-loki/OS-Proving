u64
struct ttm_resource_manager *	man
