int
struct task_struct *	cur
struct task_struct *	p
int	target_cpu
int	curr_cpu
