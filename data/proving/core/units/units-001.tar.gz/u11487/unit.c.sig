int
struct hpre_ctx *	ctx
struct hpre_sqe *	sqe
void **	kreq
