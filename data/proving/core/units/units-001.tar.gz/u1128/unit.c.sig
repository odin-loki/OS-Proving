int
struct ite_dev *	dev
u8 *	buf
int	buf_size
