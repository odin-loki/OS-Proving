int
int	divident
int	divisor
