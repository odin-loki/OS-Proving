int
struct key *	l_keyring
struct key *	u_keyring
const struct keyring_index_key *	index_key
