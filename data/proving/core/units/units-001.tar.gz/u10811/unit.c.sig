int
struct xhci_hcd *	xhci
unsigned int	trb_comp_code
