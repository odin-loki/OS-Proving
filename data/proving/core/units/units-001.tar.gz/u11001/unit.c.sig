int
unsigned long	pfn
int	flags
int *	hugetlb
