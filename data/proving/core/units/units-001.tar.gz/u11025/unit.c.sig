int
unsigned int	mhz
