int
volatile uint32_t *	_ptr
uint32_t	_old
uint32_t	_new
