int
struct ahash_request *	req
