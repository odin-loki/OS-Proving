int
struct fb_info *	fbi
u_int	regno
u_int	red
u_int	green
u_int	blue
u_int	transp
int	update_hw_pal
