size_t
size_t	blockSize
unsigned	minMatch
int	useSequenceProducer
