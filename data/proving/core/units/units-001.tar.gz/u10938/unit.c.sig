u64
u64	start_seq
u64	max_seq
size_t	size
bool	syslog
bool	time
