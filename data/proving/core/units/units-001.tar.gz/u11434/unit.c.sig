int
vpdbuf_t *	vpd
