acpi_status
u64	in_dividend
u64	in_divisor
u64 *	out_quotient
u64 *	out_remainder
