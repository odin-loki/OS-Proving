u8
u32	mask
