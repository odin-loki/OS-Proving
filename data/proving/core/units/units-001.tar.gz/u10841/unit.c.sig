int
struct sk_buff *	skb
unsigned int	len
bool	free_on_error
