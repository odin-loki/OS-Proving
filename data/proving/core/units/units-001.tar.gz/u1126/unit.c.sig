int
struct generic_pm_domain *	genpd
struct generic_pm_domain *	parent
unsigned int	pstate
