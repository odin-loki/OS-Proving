bool
unsigned int	flags
