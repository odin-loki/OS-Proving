unsigned long
int	ctrl
