int
unsigned long	start
unsigned long	size
