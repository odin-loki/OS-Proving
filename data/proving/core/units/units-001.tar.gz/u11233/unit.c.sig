u16
unsigned int	mode
