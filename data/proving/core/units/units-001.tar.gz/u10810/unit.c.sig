int
struct b43legacy_dmaring *	ring
