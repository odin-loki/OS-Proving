int
u16	prod
u16	cons
u16	comp
u16	mask
