int
struct lan966x *	lan966x
u8	grp
u32 *	rval
