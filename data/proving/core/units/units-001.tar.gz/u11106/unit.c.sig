int
struct ath12k_ce_pipe *	pipe
struct sk_buff *	skb
dma_addr_t	paddr
