u32
u32	hash
