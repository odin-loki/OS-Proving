int
struct hbg_priv *	priv
