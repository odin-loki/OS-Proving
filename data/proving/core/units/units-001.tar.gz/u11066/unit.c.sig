unsigned long
unsigned long	gma
