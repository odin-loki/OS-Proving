int
uint64_t	base
uint16_t	domain
uint8_t	minbus
uint8_t	maxbus
