unsigned char
unsigned int	a
unsigned int	b
