u32
u64	xstate_bv
bool	compacted
