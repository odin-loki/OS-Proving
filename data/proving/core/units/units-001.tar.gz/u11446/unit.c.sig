int
struct dc_softc *	sc
