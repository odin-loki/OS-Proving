int
u8	hi
u8	lo
