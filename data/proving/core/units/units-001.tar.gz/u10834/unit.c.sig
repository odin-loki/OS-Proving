bool
u16	regdomain
