int
struct komeda_kms_dev *	kms
struct komeda_crtc *	kcrtc
