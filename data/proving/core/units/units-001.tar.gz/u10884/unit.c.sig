int
struct uart_amba_port *	uap
