int
const struct ubifs_info *	c
struct ubifs_nnode *	parent
int	iip
