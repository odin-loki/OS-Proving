u32
struct radeon_device *	rdev
u32	engine_clock
