loff_t
struct file *	file
loff_t	offset
int	whence
