int
struct phylink *	pl
struct phy_device *	phy
phy_interface_t	interface
