int
struct ifaddr *	ifa
int	vhid
