int
const struct ethnl_req_info *	req_base
const struct ethnl_reply_data *	reply_base
