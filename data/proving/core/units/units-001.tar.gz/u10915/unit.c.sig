int
long	retval
