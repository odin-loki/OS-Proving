int
int	req_blkaddr
