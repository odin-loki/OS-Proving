int
struct mt76_dev *	dev
struct mt76_queue *	q
int	idx
int	n_desc
int	bufsize
u32	ring_base
