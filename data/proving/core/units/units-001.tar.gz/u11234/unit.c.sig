int
unsigned long	pfn
