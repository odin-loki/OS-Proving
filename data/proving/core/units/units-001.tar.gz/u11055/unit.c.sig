int
int	unit_expo
