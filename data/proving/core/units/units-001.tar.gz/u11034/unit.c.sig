int
struct keylist *	l
unsigned int	u64s
struct cache_set *	c
