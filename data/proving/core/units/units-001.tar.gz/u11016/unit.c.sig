unsigned int
unsigned int	ssid
