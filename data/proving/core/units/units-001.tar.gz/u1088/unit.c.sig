u8
struct b43legacy_wldev *	dev
int	freq
