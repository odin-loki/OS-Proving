int
struct be_adapter *	adapter
