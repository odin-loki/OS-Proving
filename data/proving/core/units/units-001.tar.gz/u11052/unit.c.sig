bool
size_t	size
size_t	offset
size_t	len
