int
struct d40_chan *	d40c
struct d40_desc *	d40d
