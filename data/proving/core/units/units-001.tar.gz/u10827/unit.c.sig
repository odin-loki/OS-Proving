int
struct regmap *	regmap
unsigned int	reg
unsigned int	bit
