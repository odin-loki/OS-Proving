size_t
u32	tr_count
u32	tr_size
