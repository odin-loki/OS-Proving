void
int	expected
int	got
int	cmp
const char *	desc
