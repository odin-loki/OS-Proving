int
struct psp_context *	psp
const struct psp_fw_bin_desc *	desc
const struct ta_firmware_header_v2_0 *	ta_hdr
