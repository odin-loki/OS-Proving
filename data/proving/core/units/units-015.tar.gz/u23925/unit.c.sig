int
struct tps6586x *	tps6586x
struct tps6586x_platform_data *	pdata
