int
struct zram *	zram
u32	mode
unsigned long	lo
unsigned long	hi
struct zram_pp_ctl *	ctl
