int
u16	raweth_qp1_flags
u16	raweth_qp1_flags2
