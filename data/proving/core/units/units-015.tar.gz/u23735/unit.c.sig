int
u32	src_sz
u32	dst_sz
u32	max_sz
