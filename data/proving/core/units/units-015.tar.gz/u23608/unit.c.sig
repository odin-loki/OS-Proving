int
struct ice_vf *	vf
u16	quanta_size
u16 *	quanta_prof_idx
