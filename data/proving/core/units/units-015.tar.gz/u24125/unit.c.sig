int
struct ili9320 *	lcd
struct ili9320_platdata *	cfg
