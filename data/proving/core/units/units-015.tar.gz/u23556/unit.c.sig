unsigned long
unsigned long	sec
