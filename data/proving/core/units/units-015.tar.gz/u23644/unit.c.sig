int
char *	data
int	data_len
struct ecryptfs_msg_ctx **	msg_ctx
