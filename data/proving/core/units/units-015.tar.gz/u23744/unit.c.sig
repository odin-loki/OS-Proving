int
kcondvar_t *	cvp
kmutex_t *	mp
