ssize_t
struct device *	dev
struct device_attribute *	attr
const char *	buf
size_t	count
