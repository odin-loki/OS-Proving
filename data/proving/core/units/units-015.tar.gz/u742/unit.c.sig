int
struct dss_device *	dss
struct platform_device *	pdev
struct device_node *	port
enum dss_model	dss_model
