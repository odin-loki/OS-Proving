int
struct dm_arg_set *	as
struct dm_verity *	v
unsigned int *	argc
const char *	arg_name
