int
uint32_t	vni
