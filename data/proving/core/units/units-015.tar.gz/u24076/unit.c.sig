unsigned long
unsigned int	amb
