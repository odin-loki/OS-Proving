unsigned int
struct mbq *	q
