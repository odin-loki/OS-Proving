u_int
struct ahd_softc *	ahd
u_int	scbid
u_int	prev
u_int	next
u_int	tid
