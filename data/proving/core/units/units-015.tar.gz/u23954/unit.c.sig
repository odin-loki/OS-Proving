gfn_t
gpa_t	gpa
