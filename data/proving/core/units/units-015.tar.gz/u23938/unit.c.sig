int
int	watchnum
struct dbreg *	d
