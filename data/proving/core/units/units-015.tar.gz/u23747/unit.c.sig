int
unsigned long	base
unsigned long	size
int	replace_reg
