int
struct sh_pfc_chip *	chip
