int
struct simple_util_priv *	priv
struct device_node *	np
struct simple_util_dai *	dai
