int
struct regmap *	map
