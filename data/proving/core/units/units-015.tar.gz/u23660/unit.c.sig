bool
bool	cond
