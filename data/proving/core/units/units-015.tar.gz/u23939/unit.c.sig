unsigned
__le16	dlen
