unsigned int
unsigned int	num_dsp_words
