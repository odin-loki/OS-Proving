int
struct dm_verity *	v
struct dm_verity_io *	io
enum verity_block_type	type
sector_t	block
u8 *	dest
