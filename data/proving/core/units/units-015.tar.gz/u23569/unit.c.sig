int
struct sk_buff *	skb
struct net_bridge_vlan *	vtbegin
struct net_bridge_vlan *	vtend
