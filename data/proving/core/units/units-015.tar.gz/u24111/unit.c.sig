int
struct drm_i915_gem_object *	obj
unsigned int	idx
unsigned int	max
