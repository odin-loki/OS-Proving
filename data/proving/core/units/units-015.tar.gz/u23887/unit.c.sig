int
struct inodetree *	tree
struct inode **	inop
const char *	path
struct dirent ***	dirp
?	?
?	?
