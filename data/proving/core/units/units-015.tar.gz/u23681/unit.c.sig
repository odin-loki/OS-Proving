int
const u32	node
