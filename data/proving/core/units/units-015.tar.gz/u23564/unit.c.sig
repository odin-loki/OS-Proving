bool
u8	old_guc_prio
u8	new_guc_prio
