void
struct ath6kl *	ar
int	count
