unsigned int
struct tegra_dma_channel *	tdc
u32	burst_size
enum dma_slave_buswidth	slave_bw
u32	len
