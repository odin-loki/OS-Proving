void
struct ipc_namespace *	ns
