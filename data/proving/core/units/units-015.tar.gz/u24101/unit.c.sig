unsigned int
unsigned int	obit
