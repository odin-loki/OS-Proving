int
struct aac_dev *	aac
