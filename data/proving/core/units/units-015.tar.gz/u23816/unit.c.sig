int
struct mc5 *	mc5
u32	mask_array_base
u32	data_array_base
u32	write_cmd
int	addr_shift
