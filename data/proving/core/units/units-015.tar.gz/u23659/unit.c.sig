bool
const struct fib_rule_port_range *	range
