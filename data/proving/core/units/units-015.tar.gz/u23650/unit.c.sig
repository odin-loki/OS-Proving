int
void *	cookie
