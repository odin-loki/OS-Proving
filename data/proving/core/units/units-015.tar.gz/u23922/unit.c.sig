int
struct iscsi_node_acl *	acl
u32	random_datain_seq_offsets
