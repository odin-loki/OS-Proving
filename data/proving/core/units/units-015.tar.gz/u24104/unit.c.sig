int
int	mthca_flags
