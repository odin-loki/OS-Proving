int
u8	rc_buffer_block_size
u8	rc_buffer_size
