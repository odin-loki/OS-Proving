unsigned long
unsigned long	parent
unsigned long	n
unsigned long	k
unsigned long	m
unsigned long	p
