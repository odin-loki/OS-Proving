int
struct virtio_net_hdr *	vnet_hdr
size_t	len
