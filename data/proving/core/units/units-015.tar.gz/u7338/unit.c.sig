int
enum typec_port_type	type
