int
const struct path *	path
int *	flags
unsigned char *	uuid
