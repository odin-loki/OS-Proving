int
int	new_id
