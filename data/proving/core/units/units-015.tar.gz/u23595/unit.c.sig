int
struct mc5 *	mc5
