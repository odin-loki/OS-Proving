u_long
const volatile u_long *	addr
