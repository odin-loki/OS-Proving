int
struct ef4_nic *	efx
unsigned	mask
