int
int	isgcmd
