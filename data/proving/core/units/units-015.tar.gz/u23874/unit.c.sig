int
struct efx_channel *	channel
int	quota
