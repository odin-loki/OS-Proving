int
unsigned short	type
