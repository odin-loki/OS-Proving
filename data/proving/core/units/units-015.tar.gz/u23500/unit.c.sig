u32
u32	cycles
u64	clk_freq
