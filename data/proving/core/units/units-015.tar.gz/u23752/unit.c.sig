unsigned long
struct task_struct *	p
u64	clone_flags
unsigned long	stack_size
