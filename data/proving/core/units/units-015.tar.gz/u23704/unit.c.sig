int
struct fbnic_dev *	fbd
