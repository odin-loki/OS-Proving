int
struct ocfs2_caching_info *	ci
u64	off
struct buffer_head **	bh
?	?
