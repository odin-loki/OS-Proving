bool
int	link_rate
