int
struct dwc2_hsotg *	hsotg
struct dwc2_qh *	qh
