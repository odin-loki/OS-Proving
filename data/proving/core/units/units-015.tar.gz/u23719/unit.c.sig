bool
unsigned long	start
unsigned long	end
