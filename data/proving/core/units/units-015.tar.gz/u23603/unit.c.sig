int
u32 *	frD
u32 *	frB
