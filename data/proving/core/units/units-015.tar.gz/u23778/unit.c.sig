int
void *	buf
int	buf_len
