int
struct cpupri *	cp
