int
struct mlx5_ib_dev *	dev
struct mlx5_ib_pf_eq *	eq
