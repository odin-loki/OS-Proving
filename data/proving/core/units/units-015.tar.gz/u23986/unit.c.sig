int16_t
struct ath_hal *	ah
const HAL_CHANNEL_INTERNAL *	c
