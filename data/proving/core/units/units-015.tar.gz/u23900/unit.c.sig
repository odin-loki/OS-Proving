u32
const int	type
u16	itr
