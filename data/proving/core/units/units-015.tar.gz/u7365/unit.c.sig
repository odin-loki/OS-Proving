int
struct hci_uart *	hu
struct sk_buff *	skb
