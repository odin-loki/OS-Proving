int
struct clkdom *	clkdom
struct aw_clk_np_def *	clkdef
