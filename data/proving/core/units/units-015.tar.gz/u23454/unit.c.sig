int
struct crypto_tfm *	tfm
u32	algs_flags
