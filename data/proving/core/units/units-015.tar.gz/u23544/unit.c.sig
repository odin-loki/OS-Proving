int
struct drm_i915_private *	i915
struct drm_gem_object *	obj
resource_size_t	size
