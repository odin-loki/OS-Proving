int
struct bwi_mac *	mac
