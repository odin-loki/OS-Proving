int
struct dtsec_regs *	regs
struct dtsec_cfg *	cfg
phy_interface_t	iface
u16	iface_speed
u64	addr
u32	exception_mask
u8	tbi_addr
