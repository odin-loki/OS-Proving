int
unsigned long	freq
