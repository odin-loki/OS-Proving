int
struct socket *	sock
struct sock *	sk
int	protocol
