int
struct vfio_dma *	dma
dma_addr_t	iova
bool	do_accounting
