int
int	port
int	txq
