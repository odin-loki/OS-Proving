u32
__le16	vid_le
