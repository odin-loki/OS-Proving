bit32
dmRoot_t *	dmRoot
agsaRoot_t *	agRoot
dmMemoryRequirement_t *	memoryAllocated
dmSwConfig_t *	swConfig
bit32	usecsPerTick
