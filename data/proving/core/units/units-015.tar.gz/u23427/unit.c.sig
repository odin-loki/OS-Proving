int
struct device *	dev
struct vm_area_struct *	vma
void *	cpu_addr
dma_addr_t	dma_addr
size_t	size
unsigned long	attrs
