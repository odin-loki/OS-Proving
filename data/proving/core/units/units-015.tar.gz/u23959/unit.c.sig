int
struct intel_dp *	intel_dp
int	max_dprx_rate
int	max_dprx_lanes
