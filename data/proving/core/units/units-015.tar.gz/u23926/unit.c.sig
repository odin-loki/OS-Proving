int
struct ahci_host_priv *	hpriv
