short
unsigned int	num_dests_old
unsigned int	num_dests_reduce
