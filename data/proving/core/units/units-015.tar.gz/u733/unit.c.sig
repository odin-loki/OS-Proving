uint64_t
volatile uint64_t *	p
