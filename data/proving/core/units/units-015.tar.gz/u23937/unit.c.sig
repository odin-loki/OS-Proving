int
struct dwc3 *	dwc
u8	epnum
