int
int	val
int	max
unsigned int	invert
