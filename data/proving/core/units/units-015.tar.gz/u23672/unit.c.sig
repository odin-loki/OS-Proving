bool
int	verdict
