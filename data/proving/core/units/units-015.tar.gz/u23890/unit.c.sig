int
struct tiger_hw *	card
