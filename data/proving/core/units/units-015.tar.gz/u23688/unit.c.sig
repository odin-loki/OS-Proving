int
struct device *	dev
struct apds9160_chip *	data
