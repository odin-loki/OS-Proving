int
efi_guid_t	guid
u32	flags
size_t	size
int *	reset
