int
struct ice_hw *	hw
struct list_head *	em_list
