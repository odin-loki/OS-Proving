int
struct nvme_dev *	dev
int	qid
int	depth
