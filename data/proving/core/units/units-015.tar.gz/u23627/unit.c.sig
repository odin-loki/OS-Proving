int
u16	reg
bool	extended
