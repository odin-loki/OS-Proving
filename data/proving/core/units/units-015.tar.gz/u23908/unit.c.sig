int
struct mlxsw_hwmon_dev *	mlxsw_hwmon_dev
