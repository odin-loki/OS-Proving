unsigned int
struct inode *	inode
unsigned long	index
loff_t	write_end
bool	shmem_huge_force
struct vm_area_struct *	vma
vm_flags_t	vm_flags
