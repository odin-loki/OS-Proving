unsigned char
size_t	a
size_t	b
