int
struct snd_sof_dev *	sdev
u32	id
