int
struct super_block *	sbp
u_long	bsize
