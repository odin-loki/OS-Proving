u32
unsigned long	clk_rate
int	ns
