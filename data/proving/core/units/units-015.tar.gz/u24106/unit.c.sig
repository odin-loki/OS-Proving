int
struct dw_mci *	host
