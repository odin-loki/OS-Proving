hpa_t
kvm_pfn_t	pfn
