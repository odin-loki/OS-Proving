unsigned int
unsigned int	pi
unsigned int	ci
unsigned int	elements_in_queue
