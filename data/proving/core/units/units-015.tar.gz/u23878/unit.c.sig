int
struct inode *	inode
const char *	name
