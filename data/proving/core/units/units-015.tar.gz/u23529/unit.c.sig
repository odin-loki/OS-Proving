bool
struct rvt_qp *	qp
u32	opcode
