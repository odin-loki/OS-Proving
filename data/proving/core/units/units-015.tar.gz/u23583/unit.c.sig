int
struct i915_address_space *	vm
struct i915_gem_ww_ctx *	ww
struct drm_mm_node *	node
u64	size
u64	offset
unsigned long	color
unsigned int	flags
