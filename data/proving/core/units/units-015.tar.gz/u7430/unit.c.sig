int
struct platform_device *	pdev
struct ltq_pinmux_info *	info
