u32
int	cntr_idx
