int
void *	buf
size_t	len
