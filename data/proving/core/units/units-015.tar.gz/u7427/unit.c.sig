int
struct btrfs_raid_bio *	rbio
int	sector_nr
void **	pointers
void **	unmap_array
