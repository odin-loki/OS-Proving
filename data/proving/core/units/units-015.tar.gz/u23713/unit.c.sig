__be32
__be32	status
u32	minor
