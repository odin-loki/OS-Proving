bit32
tiRoot_t *	tiRoot
tiEVTData_t *	agEventData
