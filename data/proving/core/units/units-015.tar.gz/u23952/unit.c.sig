int
struct efc_node *	node
struct list_head *	list
