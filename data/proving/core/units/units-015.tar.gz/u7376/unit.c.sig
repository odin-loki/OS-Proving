unsigned long
unsigned int	flags
