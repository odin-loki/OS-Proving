size_t
struct hwbus_priv *	self
size_t	size
