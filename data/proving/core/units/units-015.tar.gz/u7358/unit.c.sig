unsigned int
unsigned int	reg
int	idx
