int
struct xfs_inode *	dp
struct xfs_buf *	node1_bp
struct xfs_buf *	node2_bp
