_Bool
const atf_list_citer_t	i1
const atf_list_citer_t	i2
