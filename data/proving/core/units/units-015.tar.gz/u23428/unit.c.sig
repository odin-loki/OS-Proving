bool
u8	bitmap
int	prec
