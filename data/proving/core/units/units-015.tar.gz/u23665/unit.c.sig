bool
u32	start
u32	end
