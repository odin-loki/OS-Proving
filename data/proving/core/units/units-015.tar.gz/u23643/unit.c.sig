vm_fault_t
struct kvm_vcpu *	vcpu
struct vm_fault *	vmf
