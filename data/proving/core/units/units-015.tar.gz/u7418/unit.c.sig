int
int	pass_thresh
int	drop_thresh
