int
struct rtsx_softc *	sc
uint8_t	sample_point
