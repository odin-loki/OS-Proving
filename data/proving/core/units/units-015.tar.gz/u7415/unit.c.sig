int
struct iosm_mux *	ipc_mux
struct mux_adb *	ul_adb
u32	type
