int
struct lpfc_hba *	phba
uint32_t	ring_number
struct lpfc_iocbq *	piocb
uint32_t	flag
