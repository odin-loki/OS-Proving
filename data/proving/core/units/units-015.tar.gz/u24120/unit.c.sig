int
struct aml_sfc *	sfc
