int
struct ifnet *	ifp
struct sockaddr **	llsa
struct sockaddr *	sa
