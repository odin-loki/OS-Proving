int
bus_dma_tag_t	tag
struct iwx_dma_info *	dma
bus_size_t	size
bus_size_t	alignment
