int
u32 *	ret_payload
u32	num_args
?	?
