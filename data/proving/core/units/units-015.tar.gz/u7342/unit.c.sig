bool
struct ext4_dir_entry_2 *	de
