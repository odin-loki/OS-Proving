u32
u32	req_kHz
struct mipi_phy_params *	phy
