int
struct module *	mod
unsigned long *	start
unsigned long *	end
