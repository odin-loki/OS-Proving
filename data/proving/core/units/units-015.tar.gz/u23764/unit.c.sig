void
int	eval
int	code
const char *	fmt
?	?
