priority_t
u32	sk_priority
