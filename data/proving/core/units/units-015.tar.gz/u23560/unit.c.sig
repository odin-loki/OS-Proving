phys_addr_t
phys_addr_t	size
phys_addr_t	align
int	nid
