int
struct agp_bridge_data *	bridge
