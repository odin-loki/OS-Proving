bit32
agsaRoot_t *	agRoot
bit32	count
bit32	queueNum
