int
struct mtd_info *	mtd
loff_t	ofs
uint64_t	len
