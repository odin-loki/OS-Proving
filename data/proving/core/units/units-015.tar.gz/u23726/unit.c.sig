int
struct emac_adapter *	adpt
