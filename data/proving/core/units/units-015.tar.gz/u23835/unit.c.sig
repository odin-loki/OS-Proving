int
struct cap_msg_args *	arg
