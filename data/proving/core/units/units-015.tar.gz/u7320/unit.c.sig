int
struct ocs_ecc_ctx *	tctx
unsigned int	curve_id
