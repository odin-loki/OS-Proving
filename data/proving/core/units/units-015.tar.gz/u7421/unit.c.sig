int
struct ddb_ci *	ci
