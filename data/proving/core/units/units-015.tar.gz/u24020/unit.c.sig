int
struct gem_softc *	sc
