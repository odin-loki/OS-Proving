void
unsigned long *	flags
struct other_info *	other_info
