s8
u8	mask
s8	true_val
s8	false_val
