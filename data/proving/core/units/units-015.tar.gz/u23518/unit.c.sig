int
struct dma_desc *	p
