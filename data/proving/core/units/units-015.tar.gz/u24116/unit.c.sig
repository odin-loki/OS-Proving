int
ipf_main_softc_t *	softc
void *	arg
