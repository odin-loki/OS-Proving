bool
unsigned int	nr
