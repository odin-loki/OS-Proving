unsigned int
unsigned long	word
