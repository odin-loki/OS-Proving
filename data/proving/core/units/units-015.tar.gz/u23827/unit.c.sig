int
struct nvkm_fb *	fb
int	l
int	k
int	i
