s32
s32	dividend
u32	divisor
s32 *	remainder
