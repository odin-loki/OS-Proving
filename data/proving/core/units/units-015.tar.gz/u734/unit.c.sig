int
struct dsa_switch *	ds
int	port
const unsigned char *	addr
