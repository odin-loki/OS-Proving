uint32_t
volatile uint32_t *	p
uint32_t	val
