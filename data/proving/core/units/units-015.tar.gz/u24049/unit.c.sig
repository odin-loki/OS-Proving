int
struct rcar_lvds *	lvds
