signed int
struct adapter *	adapter
union recv_frame *	precvframe
