u32
struct stv0900_internal *	intp
u32	mclk
enum fe_stv0900_demod_num	demod
