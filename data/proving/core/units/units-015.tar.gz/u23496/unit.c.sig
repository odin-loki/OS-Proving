u32
int	mtu
u32	speed
