int
enum htt_security_types	sec_type
