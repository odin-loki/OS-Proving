u_int
u_int	mask0
