u32
struct range_node *	rn
