int
int	card_idx
struct snd_pcm_hw_params *	params
int	direction
