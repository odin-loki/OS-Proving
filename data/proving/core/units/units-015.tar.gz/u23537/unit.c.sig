int
u32	chan_width
