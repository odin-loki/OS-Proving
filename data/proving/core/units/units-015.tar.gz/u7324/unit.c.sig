int
struct ipw_priv *	priv
