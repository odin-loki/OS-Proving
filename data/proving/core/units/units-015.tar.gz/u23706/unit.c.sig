int
struct ena_com_admin_queue *	admin_queue
u8	comp_status
