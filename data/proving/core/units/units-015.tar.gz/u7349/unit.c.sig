int
struct xfs_btree_cur *	cur
const struct xfs_alloc_rec_incore *	rec
void *	priv
