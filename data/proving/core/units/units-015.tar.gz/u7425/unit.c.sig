int
u32	dgt_hz
int	sched_bits
int	irq
bool	percpu
