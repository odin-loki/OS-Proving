int
struct og0ve1b *	og0ve1b
