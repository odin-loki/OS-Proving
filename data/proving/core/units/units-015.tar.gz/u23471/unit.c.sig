int
struct nvmet_tcp_queue *	queue
struct msghdr *	msg
char *	cbuf
