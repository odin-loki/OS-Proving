uint64_t
uint64_t	x
uint64_t	size
