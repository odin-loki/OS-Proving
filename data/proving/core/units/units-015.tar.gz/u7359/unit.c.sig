u32
struct amdgpu_device *	adev
int	xcc_id
