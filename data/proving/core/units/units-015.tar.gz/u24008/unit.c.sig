unsigned int
const struct comedi_device *	dev
int	timer
