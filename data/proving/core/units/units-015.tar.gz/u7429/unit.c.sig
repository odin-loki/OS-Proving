int
struct hbg_mac *	mac
