U32
U32	sequence
tableType_t const	tableType
