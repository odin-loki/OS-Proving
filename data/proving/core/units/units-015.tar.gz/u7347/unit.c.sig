int
struct cc_drvdata *	drvdata
struct cc_req_mgr_handle *	req_mgr_h
unsigned int	total_seq_len
