unsigned long
unsigned long	insn
long	value
ppc_cpu_t	dialect
const char **	errmsg
