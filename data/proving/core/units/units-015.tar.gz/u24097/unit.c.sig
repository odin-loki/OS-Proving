int
struct clk_hw *	hw
unsigned long	rate
unsigned long	prate
int	maxdiv
