bool
bool	fshared
