u32
u32	base_clk
u32	clk
