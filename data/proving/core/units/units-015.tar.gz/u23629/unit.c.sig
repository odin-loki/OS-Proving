int
struct bdx_priv *	priv
struct rxd_fifo *	f
int	budget
