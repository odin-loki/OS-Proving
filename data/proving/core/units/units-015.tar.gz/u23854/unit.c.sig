bool
u64	address
u64	size
u64	range_start_address
u64	range_end_address
