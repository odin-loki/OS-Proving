int
struct _fll_div *	fll_div
unsigned int	Fref
unsigned int	Fout
