int
struct snd_ymfpci *	chip
int	secondary
