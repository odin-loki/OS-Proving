bool
struct radeon_fence *	fence
int	dst_ring
