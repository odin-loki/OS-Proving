enum da7218_hpldet_jack_thr
struct snd_soc_component *	component
u32	val
