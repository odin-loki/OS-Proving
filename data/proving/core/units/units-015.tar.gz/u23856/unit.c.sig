u_short
u_char *	addr
int	len
