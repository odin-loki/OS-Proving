unsigned long
unsigned int	cpu
