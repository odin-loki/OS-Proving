unsigned long
unsigned long	rate
u32	m
u32	n
u32	mode
u32	pre_div
