int
struct sdhci_pci_slot *	slot
