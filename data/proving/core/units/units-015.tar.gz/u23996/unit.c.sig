bus_size_t
bus_dma_tag_t	dmat
bus_dmamap_t	map
bus_addr_t	curaddr
bus_size_t	sgsize
bus_dma_segment_t *	segs
int *	segp
