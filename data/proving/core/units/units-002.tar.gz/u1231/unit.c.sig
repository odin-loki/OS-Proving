bool
struct rtw89_dev *	rtwdev
enum rtw89_rf_path	path
u8	kidx
