int
uint32_t	wheel_slot
uint32_t	plus
