size_t
struct ttyoutq *	to
const void *	buf
size_t	nbytes
