int
struct cc_cipher_ctx *	ctx_p
unsigned int	size
