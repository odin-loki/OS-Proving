bool
uptr	addr
