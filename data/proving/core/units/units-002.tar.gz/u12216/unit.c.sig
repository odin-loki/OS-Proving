bool
unsigned int	src
unsigned int	dst
unsigned int	min
unsigned int	max
