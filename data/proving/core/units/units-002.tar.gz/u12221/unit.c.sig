int
struct notifier_block *	nb
unsigned long	val
void *	data
