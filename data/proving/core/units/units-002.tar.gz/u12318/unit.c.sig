int
struct device_node *	node
unsigned	num_chips
