int
pid_t	pid
clockid_t *	clock_id
