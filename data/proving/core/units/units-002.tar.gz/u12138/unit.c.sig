int
struct ubi_device *	ubi
struct ubi_attach_info *	ai
struct ubi_fastmap_layout *	fm
