int
struct hns3_enet_ring *	ring
struct net_device *	netdev
struct sk_buff *	skb
