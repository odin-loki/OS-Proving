bool
u32	bo_flags
