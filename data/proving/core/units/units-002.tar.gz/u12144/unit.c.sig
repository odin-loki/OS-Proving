unsigned short
unsigned short *	s
int	n
