int
struct g_provider *	pp
int	r
int	w
int	e
