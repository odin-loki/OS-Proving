int
struct rio_mport *	port
u16	destid
u8	hopcount
int	wait_ms
