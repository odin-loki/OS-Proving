int
struct ftrace_ops *	ops
unsigned long	addr
bool	free_filters
