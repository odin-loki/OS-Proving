bool
struct hl_device *	hdev
u64	addr
