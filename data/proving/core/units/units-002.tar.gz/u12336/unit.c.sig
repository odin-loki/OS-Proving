int
struct pnp_dev *	pdev
const struct pnp_device_id *	dev_id
