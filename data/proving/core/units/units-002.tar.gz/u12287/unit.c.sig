int
struct clkdom *	clkdom
struct ti_clk_clkctrl_def *	clkdef
