int
struct nand_chip *	chip
