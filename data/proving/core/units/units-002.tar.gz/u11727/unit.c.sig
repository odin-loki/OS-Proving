bool
const struct nf_queue_entry *	entry
bool *	is_unconfirmed
