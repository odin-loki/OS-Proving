int
u32 *	pifutex
struct futex_hash_bucket *	hb1
struct futex_hash_bucket *	hb2
union futex_key *	key1
union futex_key *	key2
struct futex_pi_state **	ps
struct task_struct **	exiting
int	set_waiters
