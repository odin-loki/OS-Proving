int
unsigned long	vaddr
unsigned long	pfn
pgprot_t	prot
