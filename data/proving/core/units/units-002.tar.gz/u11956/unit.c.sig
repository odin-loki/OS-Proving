bool
u32	version
u32	major
u32	minor
