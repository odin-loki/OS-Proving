int
void *	reg
u32	mask
u32	ms
