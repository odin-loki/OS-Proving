int
struct mlxsw_sp *	mlxsw_sp
void *	region_priv
void *	entry_priv
struct mlxsw_sp_acl_rule_info *	rulei
