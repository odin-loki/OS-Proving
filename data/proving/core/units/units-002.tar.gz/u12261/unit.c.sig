int
int	field
int	line
int	is_pal
