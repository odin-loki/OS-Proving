u8
u32	data
u8	init
u8	poly
