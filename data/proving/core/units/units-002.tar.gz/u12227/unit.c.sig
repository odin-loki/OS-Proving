u32
u32	csr6
int	rxfifosz
