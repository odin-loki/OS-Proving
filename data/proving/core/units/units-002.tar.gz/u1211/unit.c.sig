unsigned long
vm_flags_t	vm_flags
