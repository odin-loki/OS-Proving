int
struct xhci_softc *	sc
