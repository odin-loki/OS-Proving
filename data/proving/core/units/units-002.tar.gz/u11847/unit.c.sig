int
struct cnic_dev *	dev
struct cnic_dma *	dma
int	pages
int	use_pg_tbl
