int
struct thread *	td
pid_t	pid
void *	addr
void *	data
