dma32_t
dma32_t	a
u32	b
