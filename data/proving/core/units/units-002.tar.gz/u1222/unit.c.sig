bool
enum pageblock_bits	pb_bit
