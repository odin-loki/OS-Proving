int
struct csio_scsim *	scm
struct csio_hw *	hw
int	buf_size
int	num_buf
