u8
const struct amdgpu_ras_eeprom_control *	control
