void
struct mlx5e_ptp_metadata_fifo *	fifo
