long
key_serial_t	id
key_serial_t	ringid
