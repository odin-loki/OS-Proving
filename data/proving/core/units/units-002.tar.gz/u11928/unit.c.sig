int
struct super_block *	sb
int	is_dir
int	xattr_credits
