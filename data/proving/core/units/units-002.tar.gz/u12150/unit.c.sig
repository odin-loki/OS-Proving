int
const struct drm_display_mode *	mode
int	channel
