int
__u8	duplex
