int
struct octeon_device *	oct
