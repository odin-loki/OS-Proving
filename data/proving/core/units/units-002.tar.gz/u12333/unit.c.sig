u8
struct rtw89_dev *	rtwdev
enum rtw89_phy_idx	phy
enum rtw89_rf_path	path
u8	txagc
s8	gain_offset
