int
struct socket *	so
int	proto
struct thread *	td
