unsigned int
unsigned int	input
unsigned int	output
