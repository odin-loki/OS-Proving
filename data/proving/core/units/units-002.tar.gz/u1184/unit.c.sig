int
struct fb_videomode *	mode
int	margins
int	rb
