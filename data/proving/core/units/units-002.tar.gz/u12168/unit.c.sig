int
unsigned long	rate
unsigned long	parent_rate
