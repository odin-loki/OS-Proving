unsigned int
struct comedi_subdevice *	s
unsigned int	num_bytes
