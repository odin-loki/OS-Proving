sbintime_t
struct pcpu_state *	state
int	idle
