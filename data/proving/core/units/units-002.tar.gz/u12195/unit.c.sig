bool
int	a
int	b
int	x
int	y
