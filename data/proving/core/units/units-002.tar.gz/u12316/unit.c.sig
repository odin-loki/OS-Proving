int
const struct tls_crypto_info *	crypto_info
const struct tls_crypto_info *	alt_crypto_info
