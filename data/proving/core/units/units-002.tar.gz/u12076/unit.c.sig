int
struct i915_power_domains *	power_domains
