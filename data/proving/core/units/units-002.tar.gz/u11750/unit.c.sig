int
uint32_t	phase_map
int	start_bit
