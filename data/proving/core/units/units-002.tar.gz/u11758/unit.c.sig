bool
struct skcipher_request *	areq
