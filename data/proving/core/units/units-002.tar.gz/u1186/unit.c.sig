int
struct amdgpu_device *	adev
uint32_t	flags
