int
int	reg
int	div
