unsigned long
u64	deltatsc
u64	hpet1
u64	hpet2
