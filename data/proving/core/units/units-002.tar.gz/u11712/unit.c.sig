_Bool
uint32_t	msr
