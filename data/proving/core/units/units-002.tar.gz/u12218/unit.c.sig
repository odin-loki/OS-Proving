int
struct mei_device *	dev
unsigned char *	buf
unsigned long	len
