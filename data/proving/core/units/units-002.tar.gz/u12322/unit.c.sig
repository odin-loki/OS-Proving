int
struct rcar_pwm_chip *	rp
int	div
u64	duty_ns
u64	period_ns
