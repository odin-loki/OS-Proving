int
struct ubi_device *	ubi
struct ubi_volume *	vol
int	lnum
int *	pnum
