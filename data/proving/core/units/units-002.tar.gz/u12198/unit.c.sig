unsigned int
unsigned int	sectors
unsigned int	lbs
