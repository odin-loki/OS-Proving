uint32_t
struct radeon_device *	rdev
uint32_t	req_clock
int *	fb_div
int *	post_div
