int
struct inpcb *	inp
