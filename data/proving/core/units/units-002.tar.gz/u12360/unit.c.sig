ssize_t
const void *	kern_spec_filter
u16	kern_filter_size
u16	ib_real_filter_sz
