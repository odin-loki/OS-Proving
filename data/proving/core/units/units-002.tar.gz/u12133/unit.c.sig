int
struct bxe_softc *	sc
