int
struct crypto_template *	tmpl
struct aead_instance *	inst
