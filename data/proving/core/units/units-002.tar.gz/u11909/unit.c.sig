int
ipf_main_softc_t *	softc
minor_t	unit
int	flags
