int
const struct net_device *	dev
u16	vid
struct bridge_vlan_info *	p_vinfo
