int
struct ixgbe_softc *	sc
