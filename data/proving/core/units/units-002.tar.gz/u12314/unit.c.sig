int
keyboard_t *	kbd
void *	buf
size_t	len
