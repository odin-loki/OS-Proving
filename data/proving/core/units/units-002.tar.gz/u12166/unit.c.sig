int
struct nandsim *	ns
