acpi_status
u32	start_ticks
u32	end_ticks
u32 *	time_elapsed
