int
struct device *	dev
u64 *	nname
u64 *	pname
const char *	buf
