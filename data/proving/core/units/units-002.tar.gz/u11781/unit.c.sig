int
unsigned long	nr_shared
unsigned long	nr_status
