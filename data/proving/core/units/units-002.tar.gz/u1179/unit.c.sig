int
struct sdebug_dev_info *	devip
int	nbr_partitions
int	part_0_size
int	part_1_size
