int
struct ntfs_sb_info *	sbi
