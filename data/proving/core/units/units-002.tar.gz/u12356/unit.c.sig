int
struct hinic_rxq *	rxq
int	budget
