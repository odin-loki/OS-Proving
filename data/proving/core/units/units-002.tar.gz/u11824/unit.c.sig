u64
u64	gen
