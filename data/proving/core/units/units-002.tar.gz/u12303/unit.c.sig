int
int	nid
unsigned long	max_pages
