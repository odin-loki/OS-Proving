u8
u8 *	bins
int	num_bins
