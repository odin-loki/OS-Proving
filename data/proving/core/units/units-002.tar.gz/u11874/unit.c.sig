void
struct qce_device *	qce
u32 *	major
u32 *	minor
u32 *	step
