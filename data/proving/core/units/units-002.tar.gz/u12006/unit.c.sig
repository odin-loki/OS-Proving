enum virtchnl_status_code
int	ice_err
