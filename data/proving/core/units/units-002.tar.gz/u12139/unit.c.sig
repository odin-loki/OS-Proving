int
struct g_raid_tr_object *	tr
