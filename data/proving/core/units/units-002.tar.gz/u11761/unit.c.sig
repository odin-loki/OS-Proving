u32
u64	ns
u32	clk_mhz
