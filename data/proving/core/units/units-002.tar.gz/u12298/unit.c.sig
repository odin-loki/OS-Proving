int
const struct nvkm_vmm_func *	func
struct nvkm_mmu *	mmu
u32	pd_header
bool	managed
u64	addr
u64	size
void *	argv
u32	argc
struct lock_class_key *	key
const char *	name
struct nvkm_vmm **	pvmm
