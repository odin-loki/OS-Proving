int
struct i2c_client *	client
enum si5351_variant	variant
