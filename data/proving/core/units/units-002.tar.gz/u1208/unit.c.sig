unsigned int
unsigned int	num_vecs
