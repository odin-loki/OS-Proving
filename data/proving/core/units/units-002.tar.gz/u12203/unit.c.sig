long
s16	temp
u8	resolution
