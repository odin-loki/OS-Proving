s64
int	msb
int	delta
int	sign
