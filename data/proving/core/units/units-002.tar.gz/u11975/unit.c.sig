void
struct radeon_fence **	fence
