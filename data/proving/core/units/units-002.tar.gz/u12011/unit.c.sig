int
struct nvme_dev *	dev
int	nr_io_queues
int	entry_size
