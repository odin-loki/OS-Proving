int
struct fdc_data *	fdc
const char *	s
