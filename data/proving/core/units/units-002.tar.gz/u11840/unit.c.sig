u32
u32	index
u32	n_rx_rings
