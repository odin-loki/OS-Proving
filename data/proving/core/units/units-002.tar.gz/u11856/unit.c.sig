s32
const s32	val
s32	n
