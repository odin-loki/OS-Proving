int
int	gain
