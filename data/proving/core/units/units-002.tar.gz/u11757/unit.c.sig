int
unsigned int	flags
unsigned int	ns
