int
struct dvb_adapter *	adap
struct dvb_net *	dvbnet
struct dmx_demux *	dmx
