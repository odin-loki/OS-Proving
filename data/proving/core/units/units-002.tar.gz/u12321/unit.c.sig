int
struct jsm_board *	brd
