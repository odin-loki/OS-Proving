unsigned long
unsigned long	word
