void __attribute__((__noreturn__))
struct ghcb *	ghcb
unsigned int	set
unsigned int	reason
u64	exit_info_2
