int
struct parser_exec_state *	s
struct mi_display_flip_command_info *	info
