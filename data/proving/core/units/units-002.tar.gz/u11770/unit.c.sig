long
struct clk *	clk
unsigned long	rate
