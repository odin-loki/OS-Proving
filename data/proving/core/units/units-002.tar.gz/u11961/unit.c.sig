int
struct file *	filp
int	cmd
struct file_lock *	fl
