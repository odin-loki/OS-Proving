int
const struct omap_prcm_init_data *	data
