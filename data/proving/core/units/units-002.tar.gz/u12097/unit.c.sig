int
const void *	zIn
int	nByte
int	nChar
