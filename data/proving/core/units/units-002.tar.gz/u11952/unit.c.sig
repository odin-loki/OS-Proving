enum mlxsw_reg_rauht_op
bool	adding
