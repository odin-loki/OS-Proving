int
unsigned	depth
