int
struct device *	dev
int	num_consumers
struct regulator_bulk_data *	consumers
enum regulator_get_type	get_type
