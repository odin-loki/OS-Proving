int
vortex_t *	vortex
