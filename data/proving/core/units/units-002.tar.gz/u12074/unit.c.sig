int
struct fdma *	fdma
int	dcb
int	db
u64 *	dataptr
