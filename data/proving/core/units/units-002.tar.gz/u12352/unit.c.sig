bool
u32	config
