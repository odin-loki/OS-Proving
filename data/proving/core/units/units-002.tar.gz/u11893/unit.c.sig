int
struct rvt_qp *	qp
struct rvt_ack_entry *	e
struct hfi1_packet *	packet
struct ib_other_headers *	ohdr
u32	bth0
u32	psn
u64	vaddr
u32	len
