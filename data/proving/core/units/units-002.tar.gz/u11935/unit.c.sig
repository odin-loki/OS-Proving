int
struct fm10k_q_vector *	q_vector
struct fm10k_ring *	rx_ring
int	budget
