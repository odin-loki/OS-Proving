bool
const struct hal_rx_u_sig_info *	usig_info
