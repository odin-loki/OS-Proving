__wsum
__sum16	n
