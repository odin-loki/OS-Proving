int
struct k3_ringacc *	ringacc
