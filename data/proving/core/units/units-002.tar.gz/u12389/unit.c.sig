int
int	argc
char **	argv
unsigned int *	threshold_mb
unsigned int *	pattern_seed
