int
struct btrfs_fs_info *	fs_info
u64	parent
u32	num_refs
u64	bytenr
u64	num_bytes
