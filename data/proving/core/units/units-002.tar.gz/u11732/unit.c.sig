int
struct ata_queued_cmd *	qc
