int
unsigned int	status
