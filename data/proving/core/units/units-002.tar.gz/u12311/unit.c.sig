bool
u32	level
