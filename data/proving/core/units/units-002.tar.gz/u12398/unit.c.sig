int
struct inode *	inode
int	index
const char *	name
void *	buffer
size_t	buffer_size
struct folio *	dfolio
