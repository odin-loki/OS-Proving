unsigned int
struct rt711_sdca_priv *	rt711
