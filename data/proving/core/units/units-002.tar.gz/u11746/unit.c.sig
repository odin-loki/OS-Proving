int
struct ice_hw *	hw
enum ice_block	blk
u8	ptg
u16	vsig
u8	cdid
u16	flags
?	?
?	?
?	?
?	?
