int
const u8 *	buf
u8	len
