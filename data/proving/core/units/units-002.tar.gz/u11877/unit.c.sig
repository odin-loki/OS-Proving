long long
long long	u
word_type	b
