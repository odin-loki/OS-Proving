int
struct pmcraid_instance *	pinstance
