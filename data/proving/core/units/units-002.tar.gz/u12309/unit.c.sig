int
struct snd_trident *	trident
int	pcm_spdif_device
