int
struct tegra_dc *	dc
