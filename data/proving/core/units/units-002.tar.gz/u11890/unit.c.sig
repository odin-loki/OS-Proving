int
int	disk_index
int	num_disks
int	disk_shift
