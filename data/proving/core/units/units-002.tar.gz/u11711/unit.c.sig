unsigned short
u8	a
u8	b
