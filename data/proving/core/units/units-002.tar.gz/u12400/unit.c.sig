int
int	min1
int	max1
int	min2
int	max2
