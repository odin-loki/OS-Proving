int
int	pages
