int
struct bhnd_nvram_io *	io
size_t	size
