int
struct ubifs_info *	c
int	lnum
int	free
int	pad
