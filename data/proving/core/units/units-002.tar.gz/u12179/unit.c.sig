int
struct datapath *	dp
struct sk_buff *	skb
const struct sw_flow_key *	key
const struct dp_upcall_info *	upcall_info
uint32_t	cutlen
