unsigned int
const u64	config
