enum mandoclevel
