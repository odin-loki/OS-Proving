int
struct rmlock *	rm
struct rm_priotracker *	tracker
int	trylock
const char *	file
int	line
