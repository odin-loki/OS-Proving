int
int	ctr
int	n
