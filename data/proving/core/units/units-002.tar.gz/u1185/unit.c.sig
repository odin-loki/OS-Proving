u64
u64	wr
u64	rd
u64	len
