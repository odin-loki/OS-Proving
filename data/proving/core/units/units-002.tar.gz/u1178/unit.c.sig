u32
u32	key
