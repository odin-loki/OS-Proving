int
struct ahc_softc *	ahc
