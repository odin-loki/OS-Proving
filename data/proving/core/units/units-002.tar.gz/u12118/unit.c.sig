int
struct file *	dst
__u64	offset
__u32	count
struct nfs_commitres *	res
