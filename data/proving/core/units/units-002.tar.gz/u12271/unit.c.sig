u32
u32	ring_size
u32	max_size
