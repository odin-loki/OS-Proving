int
struct mt7615_dev *	dev
u32	addr
