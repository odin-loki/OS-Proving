int
struct radeon_device *	rdev
u32	engine_clock
u32	memory_clock
LPRV7XX_SMC_MCLK_VALUE	mclk
