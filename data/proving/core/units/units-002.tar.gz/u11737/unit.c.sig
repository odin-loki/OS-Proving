u_int16_t
struct mbuf *	m
bpf_u_int32	k
int *	err
