int
int	dataram1
int	sectors
int	count
