unsigned long
gfp_t	gfp
int	preferred_nid
nodemask_t *	nodemask
int	nr_pages
struct page **	page_array
