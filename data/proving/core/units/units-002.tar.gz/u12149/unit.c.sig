int
struct iomap_swapfile_info *	isi
const char *	str
