int
arch_spinlock_t	lock
