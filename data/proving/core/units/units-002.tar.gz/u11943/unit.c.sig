int
struct inode *	inode
?	?
