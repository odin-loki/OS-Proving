unsigned int
u32	reg
