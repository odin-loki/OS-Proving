u32
u16	period
u16	ref
u16	delay
u16	delay_m
