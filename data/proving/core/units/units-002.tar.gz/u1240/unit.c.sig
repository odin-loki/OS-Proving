u32
u32	ba_window_size
u8	tid
