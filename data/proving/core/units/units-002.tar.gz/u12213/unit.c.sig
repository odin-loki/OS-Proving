int
struct qm_portal *	portal
const struct qm_portal_config *	config
enum qm_dqrr_dmode	dmode
enum qm_dqrr_pmode	pmode
enum qm_dqrr_cmode	cmode
u8	max_fill
