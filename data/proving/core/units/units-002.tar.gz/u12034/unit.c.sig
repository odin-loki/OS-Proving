bool
struct elevator_type *	e
