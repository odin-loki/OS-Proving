int
unsigned int	iop_base
ushort	data_reg
