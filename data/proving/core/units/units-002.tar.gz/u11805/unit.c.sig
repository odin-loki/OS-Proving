u32
u32	dx
u32	direction
