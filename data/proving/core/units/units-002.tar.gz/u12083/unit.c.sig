int
struct mlx4_dev *	dev
u32 *	idx
u8	usage
