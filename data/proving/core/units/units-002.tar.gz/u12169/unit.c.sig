unsigned int
int	color
