bool
unsigned int	len
