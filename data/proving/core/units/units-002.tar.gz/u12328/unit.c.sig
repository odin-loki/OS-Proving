enum cookie_mac_state
struct cookie_checker *	checker
struct sk_buff *	skb
bool	check_cookie
