int
struct snd_efw *	efw
