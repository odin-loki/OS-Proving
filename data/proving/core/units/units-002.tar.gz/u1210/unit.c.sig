int
struct device *	dev
int	N
int	dir
