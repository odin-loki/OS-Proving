int
struct radeon_i2c_chan *	chan
const char *	name
