int
struct admv8818_state *	st
u64	freq
