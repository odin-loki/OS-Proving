u64
const struct yfs_xdr_u64	x
