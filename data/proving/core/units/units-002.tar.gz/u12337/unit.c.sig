int
struct bq2515x_device *	bq2515x
int	val
