int
struct ntfs_inode *	ni
u32	data_size
enum ATTR_TYPE	type
const __le16 *	name
u8	name_len
struct ATTRIB **	new_attr
struct mft_inode **	mi
struct ATTR_LIST_ENTRY **	le
