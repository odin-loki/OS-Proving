int
struct nilfs_bmap *	bmap
const char *	fname
int	err
