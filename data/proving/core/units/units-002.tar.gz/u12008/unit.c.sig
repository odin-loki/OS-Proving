long
key_serial_t	key_id
int	watch_fd
int	watch_id
