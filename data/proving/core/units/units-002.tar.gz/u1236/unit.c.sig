int
struct vmw_private *	dev_priv
uint32_t	stream_id
