bool
u64	val0
u64	val1
u64	min
u64	max
