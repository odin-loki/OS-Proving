int
int	xres
int	bpp
