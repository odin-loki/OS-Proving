u8
const struct recovery_journal *	journal
sequence_number_t	sequence
