uint64_t
device_t	dev
uint64_t	child_features
