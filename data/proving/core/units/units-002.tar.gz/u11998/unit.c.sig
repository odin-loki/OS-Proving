void
struct gb_loopback_stats *	stats
u64	val
u32	count
