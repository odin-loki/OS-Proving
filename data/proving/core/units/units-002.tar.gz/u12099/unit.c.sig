uint32_t
uint32_t *	target
uint32_t	mask
uint32_t	delta
