unsigned int
unsigned int	win
