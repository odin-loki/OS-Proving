int
struct reset_controller_dev *	rcdev
unsigned long	id
bool	assert
