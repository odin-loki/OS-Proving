int
struct gdma_dev *	gd
bool	resuming
