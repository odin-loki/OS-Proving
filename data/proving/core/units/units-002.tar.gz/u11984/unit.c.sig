unsigned int
int	prot_caps
