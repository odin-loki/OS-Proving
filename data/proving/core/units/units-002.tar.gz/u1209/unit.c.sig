int
struct crypto_instance *	inst
struct crypto_alg *	alg
