u32
struct radeon_device *	rdev
struct radeon_ring *	ring
