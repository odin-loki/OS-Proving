int
const struct dm_block_validator *	v
struct dm_block *	b
size_t	size_of_block
