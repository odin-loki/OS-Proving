int
struct iio_sw_trigger *	swt
