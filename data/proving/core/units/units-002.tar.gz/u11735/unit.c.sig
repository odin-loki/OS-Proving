int
struct ab8500_gpadc *	gpadc
enum ab8500_gpadc_channel	ch
int	ad_value
