int
struct pt_regs *	regs
unsigned char *	instr
unsigned char	opcode
int *	prefetch
