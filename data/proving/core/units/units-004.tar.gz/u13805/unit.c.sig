void
unsigned	n
