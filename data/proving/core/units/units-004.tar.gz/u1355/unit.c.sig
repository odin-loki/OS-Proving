bool
u32	new
u32	old
