enum mlx5_traffic_types
enum fs_udp_type	i
