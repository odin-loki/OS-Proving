int
char *	bcc_ptr
int	blob_len
struct cifs_ses *	ses
