bool
struct bpf_insn *	insn
