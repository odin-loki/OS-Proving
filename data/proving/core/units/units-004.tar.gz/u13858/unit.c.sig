bool
u32	bit_posn
const char *	field_name
const char *	clock_name
