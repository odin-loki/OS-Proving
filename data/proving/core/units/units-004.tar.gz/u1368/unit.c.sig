bool
int	gre_hdr_len
