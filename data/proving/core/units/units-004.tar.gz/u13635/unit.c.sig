u32
struct qed_hwfn *	p_hwfn
struct qed_ptt *	p_ptt
enum BAR_ID	bar_id
