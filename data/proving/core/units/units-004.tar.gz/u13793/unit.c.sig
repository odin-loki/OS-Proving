bool
u16	center_freq
