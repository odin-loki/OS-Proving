int
int	wstatus
const char *	what
