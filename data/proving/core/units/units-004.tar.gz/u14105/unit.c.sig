s8
struct rtw_dev *	rtwdev
u16	rate
