int
struct regnode *	regnode
