u64
u64	kflags
int	ubit
int	kbit
