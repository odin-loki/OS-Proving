int
struct aead_alg *	algs
int	count
struct simd_aead_alg **	simd_algs
