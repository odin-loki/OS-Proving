long
long	val
long	min
long	max
