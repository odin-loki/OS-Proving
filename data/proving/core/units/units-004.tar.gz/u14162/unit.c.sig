int
const u8 *	addr
