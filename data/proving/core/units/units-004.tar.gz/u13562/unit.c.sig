int
struct aa_profile *	profile
struct aa_perms *	perms
u32	request
struct apparmor_audit_data *	ad
?	?
