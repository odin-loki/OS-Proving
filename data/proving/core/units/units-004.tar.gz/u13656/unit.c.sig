int
struct range_node *	range
struct bus_node *	bus_cur
u8	type
