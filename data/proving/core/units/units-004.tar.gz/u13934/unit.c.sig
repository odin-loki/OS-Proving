long long
unsigned long	setpoint
unsigned long	dirty
unsigned long	limit
