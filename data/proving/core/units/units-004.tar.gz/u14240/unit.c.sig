int
u32	mode
