int
struct file *	file
const char *	op
