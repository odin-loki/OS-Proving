int
struct event_command *	cmd_ops
struct trace_event_file *	file
char *	glob
char *	cmd
char *	param_and_filter
