int
struct file *	file
loff_t	pos
decompress_fn *	decompressor
