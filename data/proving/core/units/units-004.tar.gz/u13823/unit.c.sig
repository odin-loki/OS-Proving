int
struct gb_connection *	connection
