int
int	raw_val
