int
struct apm_queue *	q
