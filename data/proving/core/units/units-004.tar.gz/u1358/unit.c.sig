int
u8	mgmt_class
