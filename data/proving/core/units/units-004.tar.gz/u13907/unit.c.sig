unsigned long
unsigned long	val
unsigned long	data
const struct word_at_a_time *	c
