int
const void *	arg
