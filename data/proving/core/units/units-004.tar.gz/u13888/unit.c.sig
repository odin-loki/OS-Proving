int
struct usb_device *	udev
struct usb_host_endpoint *	host_ep
