int
struct esp_cmd_entry *	ent
struct esp_lun_data *	lp
