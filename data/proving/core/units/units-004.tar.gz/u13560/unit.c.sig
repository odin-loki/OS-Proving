bool
enum atomisp_input_format	format
