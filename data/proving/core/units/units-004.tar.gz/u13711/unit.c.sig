int
int	devcmd_status
