int
struct mutex *	mutex
unsigned	nonblock
