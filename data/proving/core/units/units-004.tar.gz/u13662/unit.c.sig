int
u32	result
