enum pvrdma_mtu
enum ib_mtu	mtu
