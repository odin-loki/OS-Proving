int
struct ocfs2_super *	osb
unsigned int	needed
