int
u32 *	rel_index
u32	devlink_index
u32	obj_index
devlink_rel_notify_cb_t *	notify_cb
devlink_rel_cleanup_cb_t *	cleanup_cb
struct devlink *	devlink
