int
u8	val
int	micbias
