int
int	sku
int	freq
