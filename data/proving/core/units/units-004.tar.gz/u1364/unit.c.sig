unsigned int
int	rate
u32 *	dds
