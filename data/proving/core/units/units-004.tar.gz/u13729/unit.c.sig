int
struct notifier_block *	this
unsigned long	ev
void *	ptr
