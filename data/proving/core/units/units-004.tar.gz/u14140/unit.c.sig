int
struct cpu_rmap *	rmap
int	irq
