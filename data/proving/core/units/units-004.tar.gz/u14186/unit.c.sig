int
struct device_node *	np
struct pinctrl_dev *	pctldev
unsigned long **	configs
unsigned int *	nconfigs
