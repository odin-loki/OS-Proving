bool
struct cdns2_endpoint *	pep
struct cdns2_request *	preq
