int
struct wm8994 *	wm8994
