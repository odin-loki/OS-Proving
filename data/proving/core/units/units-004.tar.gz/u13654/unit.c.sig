int
struct v4l2_subdev *	sd
const struct adv7511_cfg_read_infoframe *	cri
u8 *	buffer
