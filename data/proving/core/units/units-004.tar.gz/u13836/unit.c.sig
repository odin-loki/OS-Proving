unsigned int
struct snd_motu *	motu
