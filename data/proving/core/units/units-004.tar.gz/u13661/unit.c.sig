int
unsigned int	a
int	adir
unsigned int	b
int	bdir
