int
struct musb_hdrc_platform_data *	data
unsigned int	ps_refclk
unsigned int	waitpin
unsigned int	async
unsigned int	sync
unsigned int	dmachan
