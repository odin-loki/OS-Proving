uint32_t
uint32_t	u
uint32_t	v
