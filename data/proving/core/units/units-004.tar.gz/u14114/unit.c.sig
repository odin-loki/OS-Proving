bool
unsigned long	vmemmap_size
