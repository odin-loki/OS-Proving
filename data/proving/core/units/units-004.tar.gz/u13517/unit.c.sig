bool
u16	idx
