u16
u16	auth_key_len
u16	enc_key_len
bool	is_hash
