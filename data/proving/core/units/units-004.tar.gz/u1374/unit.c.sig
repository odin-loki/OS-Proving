int
int	level
