int
int	cmd
