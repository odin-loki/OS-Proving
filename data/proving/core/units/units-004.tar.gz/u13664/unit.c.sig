unsigned int
unsigned int	width
