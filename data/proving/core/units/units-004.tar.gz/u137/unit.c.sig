bool
uint32_t	link_speed
