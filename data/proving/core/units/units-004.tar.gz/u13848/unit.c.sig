int
int	status
int	dir_out
