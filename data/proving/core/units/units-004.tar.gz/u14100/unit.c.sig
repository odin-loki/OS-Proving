int
struct fsi_priv *	fsi
struct device *	dev
