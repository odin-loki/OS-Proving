unsigned int
unsigned int	rotation
unsigned int	supported_rotations
