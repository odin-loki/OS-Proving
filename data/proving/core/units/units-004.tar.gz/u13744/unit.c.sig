int
node_p	node
