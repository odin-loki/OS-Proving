uint64_t
const volatile uint64_t *	p
