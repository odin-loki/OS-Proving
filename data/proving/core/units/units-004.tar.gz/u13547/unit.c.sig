bool
u8	lec
