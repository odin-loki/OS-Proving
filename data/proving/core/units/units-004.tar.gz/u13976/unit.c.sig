int
fr_info_t *	fin
ap_session_t *	aps
nat_t *nat	__unused
