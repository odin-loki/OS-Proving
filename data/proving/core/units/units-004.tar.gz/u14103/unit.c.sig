u64
u32	txq_num
u32	rxq_num
u32	fcoe_cntx_num
u32	fcoe_filt_num
