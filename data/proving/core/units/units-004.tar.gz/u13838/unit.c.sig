int
struct irq_domain *	domain
const struct irq_domain_ops *	vpe_ops
const struct irq_domain_ops *	sgi_ops
