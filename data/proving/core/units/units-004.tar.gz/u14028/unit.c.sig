int
ASC_DVC_VAR *	asc_dvc
