int
struct sock *	sk
struct sockaddr *	addrs
int	addrcnt
