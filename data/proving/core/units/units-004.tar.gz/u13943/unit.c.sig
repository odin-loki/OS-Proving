a_sle16
s16	val
