int
struct rfcomm_session *	s
int	cr
struct sk_buff *	skb
