int
unsigned char *	ptr
