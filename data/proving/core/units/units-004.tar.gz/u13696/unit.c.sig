u32
struct iwl_priv *	priv
u16	tsf_bits
