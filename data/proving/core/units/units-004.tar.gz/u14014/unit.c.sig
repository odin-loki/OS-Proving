bool
u16	lower
u16	value
u16	upper
u16	modulus
