u16
u8	c8
enum c8_to_c12_mode	mode
