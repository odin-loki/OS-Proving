int
struct btusb_data *	data
void *	buffer
int	count
