int
struct stv *	state
u16	reg
u8	mask
u8	val
