int
struct hci_dev *	hdev
