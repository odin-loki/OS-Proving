int
struct gbe_priv *	priv
u32	slave_num
