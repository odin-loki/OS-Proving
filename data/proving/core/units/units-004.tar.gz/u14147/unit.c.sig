sector_t
struct mddev *	mddev
sector_t	sectors
int	raid_disks
