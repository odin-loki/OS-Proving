int
struct camss_video *	vid
enum vb2_buffer_state	state
