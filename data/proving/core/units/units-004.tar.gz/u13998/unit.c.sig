int
struct scsi_device *	sdev
activate_complete	fn
void *	data
