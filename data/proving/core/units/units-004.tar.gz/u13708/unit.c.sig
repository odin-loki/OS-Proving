bit32
agsaRoot_t *	agRoot
agsaEchoRsp_t *	pIomb
