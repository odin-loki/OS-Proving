int
struct genl_info *	info
