int
vortex_t *	vortex
int	wtdma
