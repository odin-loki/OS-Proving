int
int	sz
const char *	fmt
u_char *	p
int	ofs
