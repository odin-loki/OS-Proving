int
int	sym
