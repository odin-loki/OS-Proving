unsigned long
struct snd_timer *	timer
