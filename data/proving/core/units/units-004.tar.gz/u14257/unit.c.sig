u16
u32	avg
u32	val
