u64
u64	ctl_opt
u32	msr
