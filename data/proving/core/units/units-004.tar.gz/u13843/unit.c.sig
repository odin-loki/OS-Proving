u32
struct ice_hw *	hw
u32	max
