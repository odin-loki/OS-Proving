u32
struct pnfs_layout_segment *	lseg
u32	mirror_idx
u32	dss_id
