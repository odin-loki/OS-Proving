int
unsigned int	hash_slots
unsigned int	flags
