u8
u8 *	msgbuf
u32	len
