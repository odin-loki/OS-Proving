int
struct net *	net
enum nf_log_type	t
