bool
const struct drm_rect *	a
const struct drm_rect *	b
