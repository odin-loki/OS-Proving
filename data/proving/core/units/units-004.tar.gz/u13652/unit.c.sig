u64
u64	abs
u64	save_ts
