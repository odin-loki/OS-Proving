increment_t
int	x
