_Bool
unsigned long *	bw_imc
unsigned long *	bw_resc
