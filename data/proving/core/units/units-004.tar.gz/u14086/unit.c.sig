int
struct lm63_data *	data
int	nr
