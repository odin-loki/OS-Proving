xfbno_t
xfs_daddr_t	daddr
