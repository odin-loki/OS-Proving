int
struct dwc2_hsotg *	hsotg
