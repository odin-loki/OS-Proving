int
unsigned long	base
unsigned long	size
unsigned int	type
