bool
__be16	proto
