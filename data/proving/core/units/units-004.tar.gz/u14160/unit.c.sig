int
struct ocs_hcu_dev *	hcu_dev
enum ocs_hcu_algo	algo
const u8 *	key
size_t	key_len
const struct ocs_hcu_dma_list *	dma_list
u8 *	dgst
size_t	dgst_len
