int
enum dma_data_direction	dir
bool	coherent
unsigned long	attrs
