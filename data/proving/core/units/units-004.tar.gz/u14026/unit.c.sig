INTERVAL
double	a
double	b
INTERVAL	v
