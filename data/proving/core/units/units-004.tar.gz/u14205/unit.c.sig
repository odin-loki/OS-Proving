int
struct sk_buff *	skb
u16	msg_type
