u8
u64	cookie
