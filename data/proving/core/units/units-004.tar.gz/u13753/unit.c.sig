int
struct t7xx_pci_dev *	t7xx_dev
