bool
unsigned long	src
unsigned long	dst
unsigned long	len
