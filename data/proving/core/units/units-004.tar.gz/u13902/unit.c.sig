long
volatile long *	p
long	v
