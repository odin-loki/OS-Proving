unsigned char
const unsigned char	qp
int	scale
