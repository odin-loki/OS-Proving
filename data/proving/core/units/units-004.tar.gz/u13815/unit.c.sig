u8
unsigned int	reg
