int
unsigned long	addr
unsigned long	end
int	depth
struct mm_walk *	walk
