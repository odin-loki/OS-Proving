unsigned int
struct cros_ec_sensors_core_state *	st
unsigned int	idx
