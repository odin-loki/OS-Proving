int
struct tegra_pmc *	pmc
