enum lan969x_dsm_cal_dev
int	speed
