int
struct lagg_port *	lp
int	rundelport
