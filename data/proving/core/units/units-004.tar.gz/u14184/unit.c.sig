unsigned int
ao_flag_names_t const *	fnt
char const *	txt
