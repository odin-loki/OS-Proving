u8
u32	data
u8	crc
