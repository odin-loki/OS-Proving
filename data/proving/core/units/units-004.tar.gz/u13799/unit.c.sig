int
enum mlx5_ptys_rate	rate
