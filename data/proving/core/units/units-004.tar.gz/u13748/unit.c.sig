u32
struct xfrm_iptfs_data *	xtfs
struct list_head *	list
