int
volatile uint16_t *	_ptr
uint16_t	_old
uint16_t	_new
