int
struct ps_device *	ps_dev
struct hid_report *	report
u8 *	data
int	size
