ssize_t
struct tty_struct *	tty
struct file *	file
const u8 *	buf
size_t	nr
