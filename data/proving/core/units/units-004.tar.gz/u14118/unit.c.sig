uint64_t
struct pcg_state_setseq_128*	rng
