u32
u64	vmx_basic
