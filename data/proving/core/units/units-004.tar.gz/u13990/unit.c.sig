int
u8	val_h
u8	val_l
