int
struct ena_com_dev *	ena_dev
uint32_t	coalesce_usecs
uint32_t	intr_delay_resolution
uint32_t *	intr_moder_interval
