int
struct nic *	nic
