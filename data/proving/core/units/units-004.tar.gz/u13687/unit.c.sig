u32
u32	minuend
u32	subtrahend
