int
struct neighbour *	neigh
