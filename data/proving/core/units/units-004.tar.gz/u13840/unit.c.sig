unsigned int
int	layout
