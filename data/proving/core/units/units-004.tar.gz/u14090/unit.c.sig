int
u32	apicid
unsigned long	start_eip
unsigned int	cpu
