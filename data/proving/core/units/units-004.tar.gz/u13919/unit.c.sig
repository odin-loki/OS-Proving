int
struct hdsp *	hdsp
int	load_on_demand
