int
const cap_rights_t *	havep
const cap_rights_t *	needp
