int
u32	slave_read
