u8
__be16	mpa_rr_bits
