int32_t
sli4_t *	sli4
