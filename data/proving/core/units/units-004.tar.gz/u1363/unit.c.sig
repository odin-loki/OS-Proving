int
struct platform_device *	pdev
struct dbx500_regulator_info *	regulator_info
int	num_regulators
