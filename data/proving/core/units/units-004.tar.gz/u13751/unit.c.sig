int
struct w83627hf_sio_data *	sio
