int
struct tegra_xusb_padctl *	padctl
