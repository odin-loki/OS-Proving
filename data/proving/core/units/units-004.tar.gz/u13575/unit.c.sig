unsigned int
struct regulator_dev *	rdev
int	input_uV
int	output_uV
int	load_uA
