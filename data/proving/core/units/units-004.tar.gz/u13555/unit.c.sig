int
struct d40_chan *	d40c
struct stedma40_chan_cfg *	conf
