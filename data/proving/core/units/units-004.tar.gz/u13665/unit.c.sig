int
enum toshiba_iio_accel_chan	chan
