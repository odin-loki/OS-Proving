int
sqlite3_file *	pJfd
void *	zBuf
int	iAmt
sqlite_int64	iOfst
