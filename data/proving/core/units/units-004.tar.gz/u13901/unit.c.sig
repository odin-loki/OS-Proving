s64
s64	credits
s64	slope
