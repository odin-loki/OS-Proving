int
struct user_sdma_request *	req
struct hfi1_pkt_header *	hdr
u32	lrhlen
u32	datalen
