int
struct snd_card *	card
struct pardevice *	pardev
struct mts64 **	rchip
