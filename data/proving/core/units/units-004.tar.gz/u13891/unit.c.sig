u64
u32	hi_sw
u32	hi
u32	lo
u32	cycle_time_ns
