int
unsigned int	mA
