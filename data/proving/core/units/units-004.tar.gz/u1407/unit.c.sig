int
int	flags
int	rm
int	control_w
