int
struct drbg_state *	drbg
unsigned char *	buf
unsigned int	buflen
struct drbg_string *	addtl
