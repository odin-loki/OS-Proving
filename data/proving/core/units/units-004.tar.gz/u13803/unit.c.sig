int
struct adf_accel_dev *	accel_dev
struct rl_sla *	sla
bool	is_update
