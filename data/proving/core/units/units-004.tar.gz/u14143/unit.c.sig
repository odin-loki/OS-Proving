int
struct pci_dev *	sis630_dev
