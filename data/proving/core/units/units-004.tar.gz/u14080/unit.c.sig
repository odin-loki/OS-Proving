int
struct uart_port *	port
char *	options
bool	probe
