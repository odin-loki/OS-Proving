int
struct access_coordinate *	perf
int *	adist
