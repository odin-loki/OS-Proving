int
struct bpf_verifier_log *	vlog
const struct bpf_prog *	prog
