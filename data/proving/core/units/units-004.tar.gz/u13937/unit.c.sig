bool
u8	opcode
