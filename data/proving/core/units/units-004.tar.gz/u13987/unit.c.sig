int
void *	addr
int	entries
struct dir_context *	ctx
