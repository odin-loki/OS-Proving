int
struct ma_state *	mas
unsigned long	min
unsigned long	max
unsigned long	size
