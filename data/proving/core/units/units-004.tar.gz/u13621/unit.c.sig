unsigned int
__le16	dlen
