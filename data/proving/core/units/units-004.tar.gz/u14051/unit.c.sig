u64
struct ufs_sb_private_info *	uspi
u64	b
