int
struct rds_ib_device *	rds_ibdev
__be32	ipaddr
