int
struct isp_video *	video
struct isp_buffer *	buffer
