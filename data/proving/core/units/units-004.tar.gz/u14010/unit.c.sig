bool
uint32_t	caps
