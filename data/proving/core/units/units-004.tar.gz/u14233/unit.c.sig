int
int	pointer
