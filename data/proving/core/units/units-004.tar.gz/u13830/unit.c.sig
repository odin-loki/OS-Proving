size_t
u8 *	eir
size_t	eir_len
