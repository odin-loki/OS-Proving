int
struct adapter *	padapter
