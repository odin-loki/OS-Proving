int
struct sg2044_spifmc *	spifmc
unsigned int	speed_hz
