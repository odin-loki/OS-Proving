bool
unsigned int	tcode
