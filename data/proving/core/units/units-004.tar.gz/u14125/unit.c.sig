int
struct cfcnfg *	cnfg
struct cflayer *	phy_layer
