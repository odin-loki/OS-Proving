u8
enum lp8788_int_id	id
