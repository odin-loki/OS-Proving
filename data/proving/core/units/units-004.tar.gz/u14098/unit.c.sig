unsigned long
unsigned int	byte_num
unsigned int	bit
