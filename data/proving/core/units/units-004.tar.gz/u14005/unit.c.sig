u64
const struct screen_info *	si
unsigned int	type
