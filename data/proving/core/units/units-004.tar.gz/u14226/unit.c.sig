int
int *	enter_fd
int *	exit_fd
int *	beauty_fd
