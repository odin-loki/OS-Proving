int
struct max8925_chip *	chip
struct max8925_platform_data *	pdata
