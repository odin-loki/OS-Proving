int
unchar *	sense
unchar *	status
