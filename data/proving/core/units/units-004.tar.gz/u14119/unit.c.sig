bool
int	bitrate
