int
unsigned char *	edid
