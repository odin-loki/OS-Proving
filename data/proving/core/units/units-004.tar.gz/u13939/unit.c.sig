int
struct gctl_req *	req
struct g_geom *	gp
bool	force
