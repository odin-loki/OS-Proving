u64
u64	a
u64	mul
u64	div
