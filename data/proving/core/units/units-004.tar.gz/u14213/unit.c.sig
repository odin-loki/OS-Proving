bool
struct nvkm_sw *	sw
int	chid
int	subc
u32	mthd
u32	data
