enum scale_mode
int	src
int	dst
