u8
enum spi_nor_protocol	proto
