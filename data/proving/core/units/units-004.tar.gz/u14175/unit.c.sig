int
increment_t	x
