u8
struct vc_data *	c
u8	color
enum vc_intensity	intensity
bool	blink
bool	underline
bool	reverse
bool	italic
