int
struct semaphore *	sem
long	state
long	timeout
