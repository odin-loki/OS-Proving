int
struct mlx5e_rq *	rq
u16	ix
int	wqe_bulk
