int
ipf_ftp_softc_t *	softf
ftpside_t *	ftps
char *	buf
size_t	len
