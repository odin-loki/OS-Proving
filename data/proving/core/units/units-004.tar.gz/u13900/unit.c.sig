int
struct device *	dev
unsigned int	id
