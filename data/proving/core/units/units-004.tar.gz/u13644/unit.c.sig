uint
uint	x
uint	n
