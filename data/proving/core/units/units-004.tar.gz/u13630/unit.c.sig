bool
u8	byte
