u8
int	val
int	inv
