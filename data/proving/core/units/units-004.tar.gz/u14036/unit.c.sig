int
struct queue_entry *	entry
