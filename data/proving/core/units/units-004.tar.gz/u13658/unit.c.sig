__u64
__u64	ring_cookie
