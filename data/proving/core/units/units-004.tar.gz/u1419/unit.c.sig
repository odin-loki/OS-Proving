u64
const struct psched_ratecfg *	r
unsigned int	len
