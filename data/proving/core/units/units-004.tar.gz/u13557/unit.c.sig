bool
u32	prob
