int
struct datapath *	dp
