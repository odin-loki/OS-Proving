void
struct fprop_global *	p
struct fprop_local_percpu *	pl
unsigned long *	numerator
unsigned long *	denominator
