int
struct chromeos_laptop *	cros_laptop
const struct chromeos_laptop *	src
