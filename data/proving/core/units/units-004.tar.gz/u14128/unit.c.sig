int
const struct resctrl_val_param *	param
int	domain_id
