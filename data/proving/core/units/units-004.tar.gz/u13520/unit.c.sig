int
size_t	mask
int	a
int	b
