int
struct seq_file *	s
struct list_head *	lh
