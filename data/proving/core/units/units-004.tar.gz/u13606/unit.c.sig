int
ips_ha_t *	ha
