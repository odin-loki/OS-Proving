int
struct mlx5_core_dev *	dev
u32	rqn
u8 *	state
