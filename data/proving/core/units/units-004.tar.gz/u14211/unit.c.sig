struct btrtl_device_info *
struct hci_dev *	hdev
const char *	postfix
