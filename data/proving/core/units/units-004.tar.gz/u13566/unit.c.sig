int
struct ubifs_info *	c
int *	main_lebs
int *	big_lpt
