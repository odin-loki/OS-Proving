ctl_action
uint64_t	lba1
uint64_t	len1
uint64_t	lba2
uint64_t	len2
bool	seq
