int
int	layout
