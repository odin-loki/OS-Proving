int
int	tmp
int	mask
