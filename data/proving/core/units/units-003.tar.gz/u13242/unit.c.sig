int
struct ath_softc *	sc
int	size
