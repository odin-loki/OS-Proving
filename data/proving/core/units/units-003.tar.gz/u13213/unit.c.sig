bool
int	lckd
int	pckd
unsigned long	lck
unsigned long	pck
void *	data
