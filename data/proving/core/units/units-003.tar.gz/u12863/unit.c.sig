unsigned int
unsigned int	size
unsigned int	min_order
unsigned int	max_order
unsigned int	fract_leftover
