int
struct xrs700x *	priv
