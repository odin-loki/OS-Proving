int
struct bhnd_pcie2hb_softc *	sc
