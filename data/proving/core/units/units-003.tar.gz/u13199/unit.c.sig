unsigned long
struct clk *	clk
