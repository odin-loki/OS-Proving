u32
u16	num_popped
u16	id
u32	arm
