int
int	qp_cap_flags
