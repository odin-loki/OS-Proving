int
struct ag71xx *	ag
