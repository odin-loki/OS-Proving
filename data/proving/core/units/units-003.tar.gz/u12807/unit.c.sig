int
struct inomap *	imap
int	agno
bool	dir
struct inode *	ip
