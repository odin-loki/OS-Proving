int
struct xlocale_ctype *	l
_RuneLocale *	rl
