int
unsigned long	idx
bool	guest
