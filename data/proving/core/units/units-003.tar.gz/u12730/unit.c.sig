int
struct padata_shell *	ps
int	offlining_cpu
