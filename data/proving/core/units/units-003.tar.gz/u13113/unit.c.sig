int
struct rt2661_softc *	sc
