u_int
int	af
int	proto
int	size
