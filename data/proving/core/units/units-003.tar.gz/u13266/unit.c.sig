bool
unsigned int	namelen
