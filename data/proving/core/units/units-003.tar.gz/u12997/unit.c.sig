u_int
struct timecounter *	tc
