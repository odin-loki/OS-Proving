bool
struct gendisk *	disk
unsigned int	zno
unsigned int	offset_in_zone
