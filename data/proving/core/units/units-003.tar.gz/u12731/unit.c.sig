int
struct ceph_connection *	con
const u8 *	session_key
int	session_key_len
const u8 *	con_secret
int	con_secret_len
