enum usb_device_speed
u32	reg
