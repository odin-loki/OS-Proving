int
struct bam_device *	bdev
