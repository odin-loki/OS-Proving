void
struct saa7146_dev *	dev
int	source
int	sync
u32*	hps_ctrl
