int
const struct net_device *	dev
u16	msti
unsigned long *	vids
