unsigned int
unsigned int	divider
unsigned int	rollovers
