bool
u32	id
