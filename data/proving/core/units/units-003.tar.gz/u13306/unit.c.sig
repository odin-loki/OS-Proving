int
unsigned int	vid
