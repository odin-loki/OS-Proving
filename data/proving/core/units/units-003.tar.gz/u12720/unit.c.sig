int
const u32	reset
const enum zynqmp_pm_reset_action	assert_flag
