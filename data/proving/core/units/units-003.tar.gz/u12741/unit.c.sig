int
struct flow_cls_offload *	cls
u16 *	vlan
