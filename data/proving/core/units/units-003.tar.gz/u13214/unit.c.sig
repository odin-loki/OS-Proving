void
struct usb_memory *	usbm
int *	count
