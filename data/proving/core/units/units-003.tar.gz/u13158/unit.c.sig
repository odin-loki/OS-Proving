bool
u64	block
u32	n_block
