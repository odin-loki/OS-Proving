u16
u16	sn1
u16	sn2
