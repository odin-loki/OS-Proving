int
int	expr
int	llen
