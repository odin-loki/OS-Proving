u16
struct ti_sci_resource *	res
