int
struct vmctx *	ctx
int	apicid
