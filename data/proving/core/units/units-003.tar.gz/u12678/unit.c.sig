int
unsigned int	pacsize
