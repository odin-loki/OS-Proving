int
struct mapping_ctx *	ctx
u32	id
