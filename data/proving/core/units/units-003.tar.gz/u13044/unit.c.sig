int
int	val
int	lo
int	hi
