bool
struct pfn_batch *	batch
unsigned long	pfn
u32	nr
