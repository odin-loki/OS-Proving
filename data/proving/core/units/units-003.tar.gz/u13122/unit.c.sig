int
struct ulist *	ulist
u64	val
void *	aux
void **	old_aux
gfp_t	gfp_mask
