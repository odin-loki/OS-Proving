void
struct vcpu_vmx *	vmx
