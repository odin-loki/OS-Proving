int
struct tipc_msg *	_hdr
struct msghdr *	m
int	dlen
int	mss
struct sk_buff_head *	txq
