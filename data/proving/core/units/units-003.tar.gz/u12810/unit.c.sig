int
struct hnae3_handle *	handle
u16	vector_num
struct hnae3_vector_info *	vector_info
