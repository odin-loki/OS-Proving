int
u32	map_flags
