int
u16	reg
