ssize_t
struct regmap *	regmap
const u8 *	buf
size_t	size
unsigned int	offset
