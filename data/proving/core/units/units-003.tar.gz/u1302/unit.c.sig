int
struct pqi_ctrl_info *	ctrl_info
struct pqi_host_memory_descriptor *	host_memory_descriptor
u32	total_required_size
u32	min_required_size
