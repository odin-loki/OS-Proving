unsigned char
unsigned char	mask
unsigned char	a
unsigned char	b
