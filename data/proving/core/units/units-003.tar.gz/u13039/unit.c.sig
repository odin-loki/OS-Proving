int
struct usb_composite_dev *	c
unsigned	n
