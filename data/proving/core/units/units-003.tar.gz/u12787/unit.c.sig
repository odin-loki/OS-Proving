int
RMPCONN *	rconn
int	doread
