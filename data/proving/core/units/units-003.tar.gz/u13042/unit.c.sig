int
struct phy *	_phy
