void
struct sci_timer *	tmr
?	?
