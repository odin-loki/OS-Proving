int
struct realtek_priv *	priv
