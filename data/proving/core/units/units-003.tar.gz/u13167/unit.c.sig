int
struct hpre_ctx *	ctx
u8	type
