u64
struct xgene_pcie *	port
u32	addr
u32	flags
u64	size
