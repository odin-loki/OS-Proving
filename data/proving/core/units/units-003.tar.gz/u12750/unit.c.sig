ssize_t
struct file *	file
const char *	ubuf
size_t	len
loff_t *	offp
