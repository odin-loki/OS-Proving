int
struct serdes_ctrl *	ctrl
u8	idx
struct phy **	phy
