unsigned short
unsigned char *	s
int	n
