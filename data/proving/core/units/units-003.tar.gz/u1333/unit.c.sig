int
struct comedi_device *	dev
int	loops
