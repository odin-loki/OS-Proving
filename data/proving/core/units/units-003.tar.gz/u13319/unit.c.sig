int
unsigned int	in
int	minimum
int	maximum
