uint16_t
uint16_t	sum
uint16_t	a
