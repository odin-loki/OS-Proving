long
volatile void *	ptr
long	addend
