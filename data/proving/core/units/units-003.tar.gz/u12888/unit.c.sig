uint32_t
const be_id_t	s_id
