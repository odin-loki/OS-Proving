int
struct amd64_pvt *	pvt
