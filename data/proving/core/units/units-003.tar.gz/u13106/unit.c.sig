int
const char *	buf
const struct kernel_param *	kp
