int
struct rpc_rqst *	rqstp
struct xdr_stream *	xdr
void *	data
