ssize_t
struct file *	file
const char *	buf
size_t	count
loff_t *	ppos
