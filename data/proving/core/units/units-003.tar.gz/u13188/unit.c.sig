int
struct ttm_device *	bdev
u32	mem_type
u32	size
