int
struct kvm *	kvm
struct kvm_dirty_ring *	ring
int *	nr_entries_reset
