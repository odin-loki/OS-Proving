bool
struct xfs_mount *	mp
unsigned int	mask
