int
struct cdns3_device *	priv_dev
int	size
int	is_in
