ssize_t
struct file *	file
const char *	user_buf
size_t	size
loff_t *	pos
