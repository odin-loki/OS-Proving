bool
const u32	address
