unsigned int
unsigned int	len
