unsigned short
struct oxu_hcd *	oxu
unsigned	frame
unsigned	uframe
