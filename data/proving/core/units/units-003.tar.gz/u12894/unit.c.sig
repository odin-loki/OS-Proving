u32
u32	var
u32	mask
u8	shift
