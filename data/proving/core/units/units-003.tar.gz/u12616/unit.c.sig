int
xfs_fsblock_t	x
