int
struct r5conf *	conf
int	num
