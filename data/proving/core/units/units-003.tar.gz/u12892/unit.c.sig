int
unsigned int	srcprefs
