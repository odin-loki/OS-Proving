int
unsigned int *	nanosec
unsigned int	flags
int	base
