int
struct sp2 *	s
