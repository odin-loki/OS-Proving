int
uint16_t	ch_id
