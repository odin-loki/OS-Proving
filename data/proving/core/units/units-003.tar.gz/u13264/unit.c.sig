int
const Elf64_Ehdr *	hdr
const Elf64_Shdr *	sechdrs
const char *	secstrings
const struct module *	mod
