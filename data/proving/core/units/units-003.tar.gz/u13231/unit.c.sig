int
int	mode
