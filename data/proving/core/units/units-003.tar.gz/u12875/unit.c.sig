int
int	attr_type
