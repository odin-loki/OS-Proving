int
int *	fd
char *	devname
