int
struct inode *	inode
struct file *	fd
