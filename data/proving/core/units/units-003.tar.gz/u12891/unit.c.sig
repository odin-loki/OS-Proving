int
struct nvkm_devinit *	devinit
u32	type
u32	freq
