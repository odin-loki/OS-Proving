int
struct rme96 *	rme96
