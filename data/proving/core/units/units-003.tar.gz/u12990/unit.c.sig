int
unsigned long	ip
