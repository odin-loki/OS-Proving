int
const struct inode *	dir
const char *	name
int	len
struct dx_hash_info *	hinfo
