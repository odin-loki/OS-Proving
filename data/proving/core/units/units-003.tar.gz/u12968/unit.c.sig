u32
struct ieee80211_hw *	hw
