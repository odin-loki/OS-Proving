int
struct device *	dev
const struct w5100_ops *	ops
int	sizeof_ops_priv
const void *	mac_addr
int	irq
int	link_gpio
