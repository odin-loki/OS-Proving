int
device_t	bus
device_t	child
