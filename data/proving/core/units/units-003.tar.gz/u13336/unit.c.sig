int
struct cyttsp5 *	ts
