u_int
u_int	a
u_int	b
