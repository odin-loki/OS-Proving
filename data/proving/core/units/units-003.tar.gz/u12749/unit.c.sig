int
int	speed
