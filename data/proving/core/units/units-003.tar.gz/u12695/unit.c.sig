unsigned int
unsigned long	bmap
