int
u64	pmiaddr
int	idx
int	shft
