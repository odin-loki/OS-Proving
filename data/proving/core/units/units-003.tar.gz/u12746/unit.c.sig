int
struct bm_portal *	portal
enum bm_rcr_pmode	pmode
enum bm_rcr_cmode	cmode
