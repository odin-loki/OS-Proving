u32
u32	width
u32	height
u32	num_vpp_pipes
