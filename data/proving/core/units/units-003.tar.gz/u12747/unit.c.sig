s32
struct e1000_hw *	hw
