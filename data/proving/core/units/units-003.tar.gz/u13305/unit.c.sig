int
struct lanai_dev *	lanai
