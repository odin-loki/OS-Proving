bool
unsigned int	seals
