int
FuncDef *	p
int	nArg
u8	enc
