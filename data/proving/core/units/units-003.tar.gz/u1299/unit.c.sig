boolean_t
const ib_net16_t	pkey
