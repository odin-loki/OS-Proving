int
struct snd_m3 *	chip
