unsigned int
struct bunzip_data *	bd
char	bits_wanted
