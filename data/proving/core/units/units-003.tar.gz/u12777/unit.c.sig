int
sqlite3_int64	iJD
