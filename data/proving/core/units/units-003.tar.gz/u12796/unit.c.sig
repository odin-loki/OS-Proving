void
u32	tlen
struct hfi1_opcode_stats *	stats
