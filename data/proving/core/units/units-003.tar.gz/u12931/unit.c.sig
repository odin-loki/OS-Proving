int
struct llcc_slice_desc *	desc
