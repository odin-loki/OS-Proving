void
struct shadow_queue *	queue
