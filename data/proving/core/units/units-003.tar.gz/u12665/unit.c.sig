int
device_t	dev
device_t	child
int	count
int *	irqs
