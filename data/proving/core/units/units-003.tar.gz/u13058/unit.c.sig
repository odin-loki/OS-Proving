bool
unsigned	d1
unsigned	d2
unsigned	margin
