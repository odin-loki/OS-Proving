int
struct bt3c_info *	info
const unsigned char *	firmware
int	count
