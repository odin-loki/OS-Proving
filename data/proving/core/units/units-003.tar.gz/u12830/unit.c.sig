bool
struct rtw89_dev *	rtwdev
u8	path
u8	ktype
