size_t
size_t	h
int	bits
