int
struct irq_domain *	domain
struct msi_desc *	desc
int	allocated
