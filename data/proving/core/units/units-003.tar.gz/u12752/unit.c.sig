unsigned int
struct dpmaif_ctrl *	dpmaif_ctrl
unsigned int	q_num
