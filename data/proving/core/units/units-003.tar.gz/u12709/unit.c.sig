u32
struct sdhci_host *	host
u32	intmask
