int
long	num
