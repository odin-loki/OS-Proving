u8
unsigned long	caps
unsigned long	flag
