int
int	microamp
