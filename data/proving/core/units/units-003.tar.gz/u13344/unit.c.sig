void
unsigned int	segment_shift
