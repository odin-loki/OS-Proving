int
video_adapter_t *	adp
