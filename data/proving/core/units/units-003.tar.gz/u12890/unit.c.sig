int
struct ssusb_mtk *	ssusb
