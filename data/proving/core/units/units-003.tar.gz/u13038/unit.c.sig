key_serial_t
struct key *	keyring
const char *	hostnqn
const char *	subnqn
