int
struct resource *	res
struct pci_dev *	dev
int	resno
resource_size_t	size
