u16
u16	pmtu
u8	is_ipv6
u8	tcp_ts_en
u8	vlan_en
