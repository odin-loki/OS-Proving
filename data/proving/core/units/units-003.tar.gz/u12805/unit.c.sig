int
struct inode *	inode
struct ufs2_inode *	ufs2_inode
