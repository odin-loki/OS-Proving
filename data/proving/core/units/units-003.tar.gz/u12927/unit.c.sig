int
efi_status_t	status
