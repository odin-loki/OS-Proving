int
char *	s
