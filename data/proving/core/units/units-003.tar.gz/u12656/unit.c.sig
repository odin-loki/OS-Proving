int
unsigned int	reg
