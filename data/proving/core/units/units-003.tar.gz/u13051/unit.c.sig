void
struct clk_rpm *	r
unsigned long	rate
unsigned long *	active
unsigned long *	sleep
