int
uint32_t	rpc_status
