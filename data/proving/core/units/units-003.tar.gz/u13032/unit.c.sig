int
struct snd_ice1712 *	ice
