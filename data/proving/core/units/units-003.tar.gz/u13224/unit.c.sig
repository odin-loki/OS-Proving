unsigned char
struct snd_cs4231 *	chip
int	format
int	channels
