int
struct mlx5_tun_entropy *	tun_entropy
int	reformat_type
