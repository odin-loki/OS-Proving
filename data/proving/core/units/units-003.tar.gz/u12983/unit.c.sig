u32
struct atyfb_par *	par
u32	vxres
u32	bpp
