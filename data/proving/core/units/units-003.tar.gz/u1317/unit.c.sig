int
struct clknode *	clk
device_t	dev
