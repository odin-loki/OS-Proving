bool
struct vhost_virtqueue *	vq
struct vhost_work *	work
