void
struct mm_struct *	mm
unsigned long	mask
unsigned long	bits
