int
struct lp55xx_chip *	chip
