unsigned long
struct zone *	zone
unsigned long	pfn
unsigned long	end_pfn
