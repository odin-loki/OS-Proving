resource_size_t
resource_size_t	addr
resource_size_t	size
unsigned long	flags
