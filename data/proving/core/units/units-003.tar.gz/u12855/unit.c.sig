int
struct crypto_sig *	tfm
const void *	key
unsigned int	keylen
