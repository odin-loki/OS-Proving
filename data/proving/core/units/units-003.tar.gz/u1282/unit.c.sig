int
int	cpu
