int
struct dentry *	dentry
