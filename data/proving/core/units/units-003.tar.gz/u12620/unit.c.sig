int32_t
ocs_hw_t *	hw
int32_t	status
uint8_t *	mqe
void *	arg
