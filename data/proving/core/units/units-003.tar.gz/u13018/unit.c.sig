ssize_t
struct file *	filp
char *	buf
size_t	siz
loff_t *	ppos
