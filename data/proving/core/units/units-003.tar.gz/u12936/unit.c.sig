int
struct rzg2l_du_crtc *	rcrtc
