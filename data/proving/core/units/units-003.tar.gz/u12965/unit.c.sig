bool
u32	cap
