int
struct ixl_pf_qmgr *	qmgr
u16	num_queues
