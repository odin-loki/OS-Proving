enum skb_drop_reason
struct sk_buff *	skb
__be32	daddr
__be32	saddr
dscp_t	dscp
struct net_device *	dev
struct in_device *	in_dev
u32 *	itag
