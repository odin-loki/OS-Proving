acpi_status
const char *	name
u32	debug_level
u32	debug_layer
u32	flags
