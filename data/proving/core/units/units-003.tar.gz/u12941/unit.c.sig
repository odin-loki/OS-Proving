s32
a_sle32	val
