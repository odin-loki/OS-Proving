int
struct clk_hw *	hw
struct clk_rate_request *	req
