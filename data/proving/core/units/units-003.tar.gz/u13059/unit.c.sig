u32
u8	epnum
u16	offset
