u64
struct printk_ringbuffer *	rb
