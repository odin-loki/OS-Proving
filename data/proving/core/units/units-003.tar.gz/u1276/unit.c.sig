int
adapter_t *	adapter
