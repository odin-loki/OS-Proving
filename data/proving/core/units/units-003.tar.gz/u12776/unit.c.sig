int
struct xfs_buftarg *	btp
size_t	logical_sectorsize
const char *	descr
