unsigned int
fw_port_cap32_t	caps
