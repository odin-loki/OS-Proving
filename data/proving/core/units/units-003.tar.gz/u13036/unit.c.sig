int
unsigned int	x
