int
struct drm_device *	dev
const struct drm_format_info *	info
const struct drm_mode_fb_cmd2 *	mode_cmd
struct drm_afbc_framebuffer *	afbc_fb
