bool
const char *	str
u32	flags
