u16
const struct skl_ddb_entry *	entry
