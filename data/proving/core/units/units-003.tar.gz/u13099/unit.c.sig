int
struct alvium_dev *	alvium
