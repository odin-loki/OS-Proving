bool
struct myrs_hba *	cs
unsigned char	status
unsigned char	parm0
unsigned char	parm1
