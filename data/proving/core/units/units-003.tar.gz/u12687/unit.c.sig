int
int	ticks
