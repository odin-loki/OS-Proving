int
int	integral
int	fractional
