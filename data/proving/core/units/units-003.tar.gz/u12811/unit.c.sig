bool
struct vdpasim *	vdpasim
u64	start_sector
u64	num_sectors
u64	max_sectors
