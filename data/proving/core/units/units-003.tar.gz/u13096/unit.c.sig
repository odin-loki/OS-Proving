u32
struct pci_dev *	pdev
u32	scale
u32	val
