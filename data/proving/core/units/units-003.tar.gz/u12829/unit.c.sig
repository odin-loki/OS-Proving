u16
u16	ac_freq
