int
struct w1_master *	dev_master
int	tout_ms
