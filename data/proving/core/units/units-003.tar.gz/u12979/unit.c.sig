int
struct dm_arg_set *	as
struct dm_snapshot *	s
struct dm_target *	ti
