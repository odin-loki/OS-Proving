flag
float64	a
float64	b
