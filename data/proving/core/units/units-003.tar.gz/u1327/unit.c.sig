u64
struct amdgpu_device *	adev
s64	us
