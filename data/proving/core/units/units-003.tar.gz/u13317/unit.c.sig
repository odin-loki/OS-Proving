u64
struct msdc_host *	host
u64	ns
u64	clks
