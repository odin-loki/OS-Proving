unsigned
unsigned char	val
