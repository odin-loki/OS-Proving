u64
u64	control
u64	param1
u64	param2
