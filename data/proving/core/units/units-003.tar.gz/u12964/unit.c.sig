bool
const struct range *	r1
const struct range *	r2
