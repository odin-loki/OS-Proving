int
u16	mcs_map
int	nss
