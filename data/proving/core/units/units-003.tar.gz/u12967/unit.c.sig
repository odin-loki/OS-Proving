int
struct bcm_qspi *	qspi
