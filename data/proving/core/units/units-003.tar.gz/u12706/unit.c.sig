int
struct gspca_dev *	gspca_dev
