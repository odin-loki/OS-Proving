int
__u16	log_addr_mask
