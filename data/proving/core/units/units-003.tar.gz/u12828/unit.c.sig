int
struct snd_soc_card *	card
struct snd_soc_component *	comp
