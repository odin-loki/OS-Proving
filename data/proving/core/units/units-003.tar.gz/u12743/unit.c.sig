int
struct qed_dev *	cdev
bool	pci_enabled
