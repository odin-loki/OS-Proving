int
const char *	inval
char *	outval
