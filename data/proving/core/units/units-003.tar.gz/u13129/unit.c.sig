int
struct tg3_napi *	tnapi
int	budget
