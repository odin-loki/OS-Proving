int
struct w83781d_data *	data
u16	reg
