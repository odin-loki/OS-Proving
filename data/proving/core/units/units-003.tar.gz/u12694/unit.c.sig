u64
struct super_block *	sb
struct ufs_cg_private_info *	ucpi
u64	goal
unsigned	count
