int
unsigned int	mcdi_err
