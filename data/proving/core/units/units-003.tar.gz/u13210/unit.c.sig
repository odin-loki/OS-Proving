int
struct gdma_context *	gc
gdma_obj_handle_t	dma_region_handle
