u8
u64	num
int	shift
