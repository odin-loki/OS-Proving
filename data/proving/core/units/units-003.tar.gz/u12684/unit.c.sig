unsigned int
unsigned char	hdr
