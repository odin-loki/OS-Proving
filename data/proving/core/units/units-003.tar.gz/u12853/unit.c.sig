int
struct nicvf *	nic
struct cmp_queue *	cq
struct cqe_rx_t *	cqe_rx
