int
struct xfs_scrub *	sc
bool	temp_local
bool	ip_local
