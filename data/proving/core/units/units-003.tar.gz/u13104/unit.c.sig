int
struct mvpp2 *	priv
unsigned short	proto
unsigned int	ri
unsigned int	ri_mask
