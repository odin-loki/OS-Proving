int
int	bsize
