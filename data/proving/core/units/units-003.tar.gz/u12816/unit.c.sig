int
const u8 *	ies1
u16	ies1_len
const u8 *	ies2
u16	ies2_len
u8 **	merged_ies
u16 *	merged_len
