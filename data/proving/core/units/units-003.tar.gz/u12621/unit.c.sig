int
struct emu_sc_info *	sc
