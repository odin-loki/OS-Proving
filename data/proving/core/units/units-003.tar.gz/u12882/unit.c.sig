int
u8	ch0
u8	ch1
