int
struct rapl_pmus **	rapl_pmus_ptr
int	rapl_pmu_scope
const struct attribute_group **	rapl_attr_groups
const struct attribute_group **	rapl_attr_update
