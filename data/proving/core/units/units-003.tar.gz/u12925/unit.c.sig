unsigned int
unsigned int	bcn_interval
