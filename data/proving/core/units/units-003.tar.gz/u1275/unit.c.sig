int
struct ipu_di *	di
struct videomode *	mode
