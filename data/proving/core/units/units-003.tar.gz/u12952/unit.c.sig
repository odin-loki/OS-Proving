bool
u8	sk
u8	asc
u8	ascq
