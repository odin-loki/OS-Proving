unsigned int
unsigned int	burst_size
