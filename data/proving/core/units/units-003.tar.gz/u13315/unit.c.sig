int
struct si2165_state *	state
u32	dvb_rate
