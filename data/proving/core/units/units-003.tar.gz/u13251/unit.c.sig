u32
const unsigned char *	in
unsigned int	len
