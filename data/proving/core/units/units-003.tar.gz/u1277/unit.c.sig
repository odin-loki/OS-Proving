unsigned
struct platform_device *	dsidev
unsigned	ns
