int
vm_fault_t	vm_fault
int	foll_flags
