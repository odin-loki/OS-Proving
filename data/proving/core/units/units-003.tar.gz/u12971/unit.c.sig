unsigned int
unsigned int	ns
unsigned int	flags
