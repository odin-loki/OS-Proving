enum scsi_disposition
struct scsi_device *	sdev
struct scsi_sense_hdr *	sense_hdr
