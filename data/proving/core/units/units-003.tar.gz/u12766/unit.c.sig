int
u32	node_id
u32	type
u32	value
