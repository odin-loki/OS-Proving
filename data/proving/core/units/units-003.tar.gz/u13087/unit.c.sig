int
struct shash_desc *	desc
u8 *	out
