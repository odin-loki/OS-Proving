int
struct crypto_shash *	hmac_tfm
const u8 *	ikm
unsigned int	ikmlen
const u8 *	salt
unsigned int	saltlen
u8 *	prk
