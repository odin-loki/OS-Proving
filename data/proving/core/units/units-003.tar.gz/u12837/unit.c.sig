int
u16	frame1
u16	frame2
