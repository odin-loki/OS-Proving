bool
struct hisi_sas_complete_v3_hdr *	complete_hdr
