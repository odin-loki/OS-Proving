u32
unsigned int	i
