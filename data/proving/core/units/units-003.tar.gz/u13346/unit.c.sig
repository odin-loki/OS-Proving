int
struct mtk_eint *	eint
