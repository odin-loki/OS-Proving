word_type
unsigned long long	a
unsigned long long	b
