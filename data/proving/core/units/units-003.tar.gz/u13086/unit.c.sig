int
struct device *	dev
struct device_node *	node
struct mtk_mdp_comp *	comp
enum mtk_mdp_comp_type	comp_type
