unsigned long
unsigned long	old
u_int	div
u_int	mult
