int
struct virtnet_info *	vi
struct receive_queue *	rq
gfp_t	gfp
