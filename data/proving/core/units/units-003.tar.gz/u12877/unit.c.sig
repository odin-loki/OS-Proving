int
struct cx23885_dev *	dev
struct sram_channel *	ch
unsigned int	bpl
u32	risc
