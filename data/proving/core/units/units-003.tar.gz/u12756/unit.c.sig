int
struct sk_buff *	skb
struct vlan_head *	key_vh
bool	untag_vlan
