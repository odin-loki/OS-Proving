int
struct riprt *	rrt
struct ifc *	ifcp
