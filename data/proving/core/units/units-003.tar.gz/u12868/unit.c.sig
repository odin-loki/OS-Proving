u8
long	temp
