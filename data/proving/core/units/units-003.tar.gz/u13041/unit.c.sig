int
int	duration
