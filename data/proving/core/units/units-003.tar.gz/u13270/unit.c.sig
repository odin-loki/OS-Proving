int
struct smb_share *	ssp
