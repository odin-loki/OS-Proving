enum xp_retval
unsigned long	dst_gpa
const unsigned long	src_gpa
size_t	len
