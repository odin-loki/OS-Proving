int
int	command_status
