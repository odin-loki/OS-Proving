enum mandocerr
