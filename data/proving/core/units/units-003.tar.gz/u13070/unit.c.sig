unsigned long
struct clk_hw *	hw
unsigned long	parent_rate
