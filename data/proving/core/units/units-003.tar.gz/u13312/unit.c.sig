int
enum ib_mtu	mtu
