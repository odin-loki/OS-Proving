__le32
u32	tx_flags
