unsigned char
unsigned	val
