int
struct spi_nor *	nor
