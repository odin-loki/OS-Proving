int
struct cros_ec_sensorhub *	sensorhub
