int
struct rpcrdma_xprt *	r_xprt
struct rpcrdma_req *	req
struct rpc_rqst *	rqst
enum rpcrdma_chunktype	wtype
