u32
struct ath10k *	ar
unsigned int	ce_id
