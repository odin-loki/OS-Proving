s32
const char *	buf
size_t	count
size_t *	consumed
size_t *	want
