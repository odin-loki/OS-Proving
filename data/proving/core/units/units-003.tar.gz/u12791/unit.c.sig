int
struct dbitmap *	dmap
