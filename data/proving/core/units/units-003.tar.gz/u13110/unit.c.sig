int
struct wmi_device *	wdev
const void *	ctx
