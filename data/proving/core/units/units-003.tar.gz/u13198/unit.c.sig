int
struct timespec *	a
struct timespec *	b
