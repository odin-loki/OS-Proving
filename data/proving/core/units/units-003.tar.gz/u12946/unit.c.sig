u32
struct intel_guc_log *	log
