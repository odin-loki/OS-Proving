int
struct bpf_test *	self
void *	arg
int	dbits
int	sbits
int	block1
int	block2
?	?
