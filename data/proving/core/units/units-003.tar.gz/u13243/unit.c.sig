u32
u32	seed
