int
struct fman_mac *	dtsec
