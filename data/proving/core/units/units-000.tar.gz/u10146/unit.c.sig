u32
enum nl80211_txrate_gi	gi
