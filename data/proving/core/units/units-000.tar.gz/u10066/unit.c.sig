bool
struct gsi_trans_info *	trans_info
u32	tre_count
