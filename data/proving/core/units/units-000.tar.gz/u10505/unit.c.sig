int
void *	vsc
uint16_t	txqid
bool	clear
