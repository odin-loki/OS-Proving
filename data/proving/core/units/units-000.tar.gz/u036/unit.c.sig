int
struct pvr_device *	pvr_dev
