int
struct usbhs_priv *	priv
