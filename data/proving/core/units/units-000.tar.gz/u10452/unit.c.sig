u32
u32	cycles
unsigned long	clk_hz
