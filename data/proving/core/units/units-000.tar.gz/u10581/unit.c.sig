u16
u8	funct3
u32	uimm
u8	rs2
u8	op
