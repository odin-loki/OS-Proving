unsigned int
u8	status
