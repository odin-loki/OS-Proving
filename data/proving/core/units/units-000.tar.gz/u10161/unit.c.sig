u64
u16	ltr
