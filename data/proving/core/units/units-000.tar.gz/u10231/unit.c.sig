u32
u16	divider
