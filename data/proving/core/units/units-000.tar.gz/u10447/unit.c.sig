int
int	nr_entry
