unsigned long
uint64_t	mask
