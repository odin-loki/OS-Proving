int
struct coreboot_device *	dev
