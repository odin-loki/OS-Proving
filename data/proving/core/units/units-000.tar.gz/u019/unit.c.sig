uint8_t
int	fd
