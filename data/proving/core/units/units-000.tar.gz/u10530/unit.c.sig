u8
u8	ep_addr
