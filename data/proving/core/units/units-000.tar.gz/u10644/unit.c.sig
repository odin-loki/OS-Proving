void
u64	pkey_reg
