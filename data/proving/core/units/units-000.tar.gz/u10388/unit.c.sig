u32
__be32 *	buffer
const u8	n_elem
