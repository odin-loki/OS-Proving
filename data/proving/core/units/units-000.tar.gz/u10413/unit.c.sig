int
struct cmdif *	cif
u32	addr
u32	data
u32	mask
