u8
u8	req_rate
u8	cur_rate
