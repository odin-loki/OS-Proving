unsigned int
const nodemask_t *	maskp
