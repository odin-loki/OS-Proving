int
struct sdw_slave *	slave
