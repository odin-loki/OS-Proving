int
struct device *	dev
const char *	name
enum lm75_type	kind
int	irq
struct regmap *	regmap
