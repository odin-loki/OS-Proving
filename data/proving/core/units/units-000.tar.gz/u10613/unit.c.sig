int
struct acpi_resource *	ares
void *	data
