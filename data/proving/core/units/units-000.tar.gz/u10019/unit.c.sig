u32
u8	bs
