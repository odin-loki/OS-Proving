size_t
size_t	b_total
unsigned int	channels
unsigned int	b_sample
