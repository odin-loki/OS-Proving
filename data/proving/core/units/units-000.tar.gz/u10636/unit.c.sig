u8
u8	agc
u8	sq
