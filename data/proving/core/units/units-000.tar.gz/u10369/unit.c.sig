u_int
volatile u_int *	p
u_int	v
