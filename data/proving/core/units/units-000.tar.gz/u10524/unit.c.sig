void *
struct iwl_trans *	trans
size_t *	len
