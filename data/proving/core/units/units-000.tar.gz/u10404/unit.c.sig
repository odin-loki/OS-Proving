unsigned int
u32	counts
