int
const char *	buf
const char *	file
const char *	func
int	line
