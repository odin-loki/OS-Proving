unsigned int
unsigned int	blocklen
bool	leaf
