int
struct llcc_drv_data *	drv
u32	bank
int	err_type
