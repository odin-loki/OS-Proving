int
struct ahc_softc *	ahc
int	target
char	channel
int	lun
u_int	tag
role_t	role
uint32_t	status
ahc_search_action	action
