int
int	ns
