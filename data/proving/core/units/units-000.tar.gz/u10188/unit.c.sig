int
int	mtu
