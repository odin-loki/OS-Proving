int
struct snd_soc_component *	component
struct snd_compr_stream *	stream
