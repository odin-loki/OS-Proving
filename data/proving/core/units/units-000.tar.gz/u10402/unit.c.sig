unsigned int
enum atomisp_input_format	fmt_type
