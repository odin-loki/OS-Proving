int
const char *	s
