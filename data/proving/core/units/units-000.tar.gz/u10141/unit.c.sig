int
struct s_smc *	smc
const u_char *	mac_addr
