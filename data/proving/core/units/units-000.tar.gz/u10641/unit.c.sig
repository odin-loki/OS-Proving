bool
u32	reg
