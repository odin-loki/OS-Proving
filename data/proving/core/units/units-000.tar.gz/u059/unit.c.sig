s64
ktime_t	reltime
