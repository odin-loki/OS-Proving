int
const struct intel_crtc_state *	crtc_state
bool	dsc
