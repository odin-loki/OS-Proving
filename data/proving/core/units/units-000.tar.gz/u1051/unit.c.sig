int
struct vm_area_struct *	vma
unsigned long	addr
