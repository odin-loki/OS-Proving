int
const struct nlmsghdr *	nlh
bool	strict_check
struct neigh_dump_filter *	filter
struct netlink_ext_ack *	extack
