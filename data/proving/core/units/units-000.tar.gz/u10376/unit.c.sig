int
int	num_blocks
