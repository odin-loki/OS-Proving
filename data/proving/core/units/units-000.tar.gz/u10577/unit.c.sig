int
struct hwbm_pool *	hwbm_pool
void *	buf
