unsigned long
struct ov8865_sensor *	sensor
const struct ov8865_mode *	mode
