int
void *	ip
enum bpf_text_poke_type	t
void *	addr1
void *	addr2
