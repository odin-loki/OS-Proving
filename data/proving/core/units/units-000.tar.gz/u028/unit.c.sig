int
struct img_ir_priv *	priv
