int
uint64_t	expr
int	llen
uint64_t	val
