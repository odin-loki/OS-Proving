int
u8	hfunc
