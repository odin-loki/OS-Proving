int
struct snd_usb_audio *	chip
int	direction
