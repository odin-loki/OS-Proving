int
struct rtw_dev *	rtwdev
u8	fifo_sel
u32	addr
u32	size
u32 *	buffer
