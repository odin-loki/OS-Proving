u32
u8	log_sz
u8	log_stride
