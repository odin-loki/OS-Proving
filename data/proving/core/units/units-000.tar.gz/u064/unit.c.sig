bool
uint64_t	addr
