int
u16	key1
u16	key2
