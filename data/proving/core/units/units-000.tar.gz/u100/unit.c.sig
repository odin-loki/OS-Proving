int
unsigned int	cpu
