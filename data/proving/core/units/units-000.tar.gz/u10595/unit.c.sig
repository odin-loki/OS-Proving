int
u8	omap2xxx_pwrst
