unsigned int
u16	reg
unsigned int	divreg
