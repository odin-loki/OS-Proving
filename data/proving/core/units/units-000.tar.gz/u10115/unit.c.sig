bool
u32	adv_flags
