int
struct rproc_vdev *	rvdev
struct fw_rsc_vdev *	rsc
int	i
