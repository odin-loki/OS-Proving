int
struct scsi_qla_host *	a
