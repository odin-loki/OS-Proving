bool_t
AUTH *	auth
void *	header
size_t	headerlen
XDR*	xdrs
xdrproc_t	xdr_args
void *	args_ptr
