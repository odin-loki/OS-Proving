s32
struct ixgbe_hw *	hw
u32	adv_reg
u32	lp_reg
u32	adv_sym
u32	adv_asm
u32	lp_sym
u32	lp_asm
