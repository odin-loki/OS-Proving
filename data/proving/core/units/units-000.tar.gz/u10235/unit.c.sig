u16
u16	value
