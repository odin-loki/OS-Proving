int
__be16	status
u8	badfcs_enc
__be16	checksum
