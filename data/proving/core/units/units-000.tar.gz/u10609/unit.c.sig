bool
int	cpu
