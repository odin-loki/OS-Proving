bool
kvm_pfn_t	pfn
