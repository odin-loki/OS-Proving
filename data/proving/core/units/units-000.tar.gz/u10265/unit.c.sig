bool
unsigned int	mask
