uint16_t
struct pcg_state_32*	rng
