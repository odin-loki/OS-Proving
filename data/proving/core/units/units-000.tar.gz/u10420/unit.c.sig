int
struct fc_rport *	rport
