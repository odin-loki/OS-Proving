int
struct nouveau_bo *	nvbo
bool	interruptible
bool	no_wait_gpu
