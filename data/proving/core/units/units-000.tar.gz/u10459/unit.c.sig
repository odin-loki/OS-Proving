int
struct aiptek *	aiptek
