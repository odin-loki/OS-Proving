int
struct spi_transfer *	xfer
struct spi_device *	spi
