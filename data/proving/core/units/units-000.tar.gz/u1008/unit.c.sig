int
char *	p
