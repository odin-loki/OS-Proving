int
struct fun_dev *	fdev
