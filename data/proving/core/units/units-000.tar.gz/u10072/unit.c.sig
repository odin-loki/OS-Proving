uint32_t
struct ffec_softc *	sc
uint32_t	curidx
