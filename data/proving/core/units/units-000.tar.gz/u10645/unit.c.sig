u64
struct kvm_vcpu *	vcpu
