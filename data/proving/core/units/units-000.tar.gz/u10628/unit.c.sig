unsigned int
struct mpu3050 *	mpu3050
