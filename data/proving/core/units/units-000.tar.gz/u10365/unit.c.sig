u32
u32	width
u32	height
u32	min_buf_count
bool	split_mode_enabled
u32	num_vpp_pipes
