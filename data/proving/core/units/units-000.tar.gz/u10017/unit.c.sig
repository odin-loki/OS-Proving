bool
enum rc_proto	proto
u32	scancode
