int
struct cgx *	cgx
