unsigned int
unsigned int	divider
