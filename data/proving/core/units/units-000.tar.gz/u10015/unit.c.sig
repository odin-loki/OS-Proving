int
struct iwl_trans *	trans
struct iwl_txq *	txq
int	slots_num
bool	cmd_queue
