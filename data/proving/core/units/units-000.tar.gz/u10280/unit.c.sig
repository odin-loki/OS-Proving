int
struct ksmbd_work *	work
struct ksmbd_file *	fp
struct smb2_file_alloc_info *	file_alloc_info
