bool
struct cros_ec_device *	ec_dev
