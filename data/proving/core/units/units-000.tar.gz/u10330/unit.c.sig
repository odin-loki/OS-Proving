int
struct nvif_chan *	chan
u32	gpfifo_nr
u32	push_nr
