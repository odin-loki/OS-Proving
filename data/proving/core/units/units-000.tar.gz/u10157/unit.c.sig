int
struct fw_card *	card
int	node_id
int	generation
