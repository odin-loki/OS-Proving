int
long	mask
