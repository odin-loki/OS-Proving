int
struct mlx5_fs_bulk *	bulk
