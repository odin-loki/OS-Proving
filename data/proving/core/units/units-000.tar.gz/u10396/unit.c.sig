int
char *	str
