int
struct mtk_btcvsd_snd *	bt
enum bt_sco_packet_len	packet_type
unsigned int	packet_length
unsigned int	packet_num
unsigned int	blk_size
unsigned int	control
