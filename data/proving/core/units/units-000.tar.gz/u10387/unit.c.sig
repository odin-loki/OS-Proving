int
struct device *	scrub_dev
const struct attribute_group **	attr_groups
u8	instance
