u64
struct intel_rc6 *	rc6
