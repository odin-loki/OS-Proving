int
struct sk_buff *	msg
int	attrtype
u64	val
