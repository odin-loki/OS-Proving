int
struct amdgpu_ring *	ring
long	timeout
