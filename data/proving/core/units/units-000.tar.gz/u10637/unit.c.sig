int
struct sock *	sk
int	urgent
int	mib
