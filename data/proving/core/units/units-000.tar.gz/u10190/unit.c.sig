int
int	nd
int *	y
