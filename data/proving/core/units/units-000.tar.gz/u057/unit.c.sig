int
struct rman *	rm
rman_res_t *	start
rman_res_t *	end
