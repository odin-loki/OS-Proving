u32
struct nand_chip *	chip
unsigned int	ecc_stat
