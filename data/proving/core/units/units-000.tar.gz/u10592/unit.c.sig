bool
unsigned long	start
unsigned long	size
unsigned long	range_start
unsigned long	range_end
