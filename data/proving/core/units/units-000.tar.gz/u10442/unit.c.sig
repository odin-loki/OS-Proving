long
unsigned long	rate
