long
unsigned long	parent_rate
u32	ndiv
u32	fdiv
u32	pdiv
