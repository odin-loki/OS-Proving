int
int	logical_extents
int	physical_extents
unsigned	unit
int	exponent
