__u16
int	phy_id
