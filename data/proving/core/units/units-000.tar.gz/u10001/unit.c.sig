int
struct pci_dev *	pdev
const struct pci_device_id *	id
