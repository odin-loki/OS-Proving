int
int	pba
