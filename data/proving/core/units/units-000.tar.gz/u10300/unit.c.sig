void
u64	size
