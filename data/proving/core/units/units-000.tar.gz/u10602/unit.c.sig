int
struct ath12k_base *	ab
struct ath12k_buffer_addr *	buf_addr_info
enum hal_wbm_rel_bm_act	action
