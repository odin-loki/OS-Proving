unsigned long
unsigned long	parent_ip
struct ftrace_regs *	fregs
