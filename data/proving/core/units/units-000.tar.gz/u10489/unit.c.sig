int
device_t	dev
u_char	speed
u_char	addr
u_char *	oldaddr
