int
struct radio_isa_card *	isa
