int
struct sk_buff *	skb
u32	info
