int
struct mlx5_hv_vhca *	hv_vhca
