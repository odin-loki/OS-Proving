bool
u8	test_type
u8	min_code
u8	max_code
u8	type
u8	code
