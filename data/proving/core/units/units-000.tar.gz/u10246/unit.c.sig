int
int	link_status
