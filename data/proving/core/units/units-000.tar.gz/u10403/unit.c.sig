u32
u32	cycle
unsigned int	addend
