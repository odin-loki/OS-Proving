u8
u32	num_reg_rules
const struct wmi_regulatory_ext_rule *	rule
