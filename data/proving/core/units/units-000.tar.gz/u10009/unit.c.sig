u64
u32	major
u32	minor
