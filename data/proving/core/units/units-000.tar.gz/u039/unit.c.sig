u_quad_t
u_quad_t	a
u_quad_t	b
