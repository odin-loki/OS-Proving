bool
struct fib_rule_port_range *	a
struct fib_rule_port_range *	b
