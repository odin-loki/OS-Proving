int
u8	rfr_severity
