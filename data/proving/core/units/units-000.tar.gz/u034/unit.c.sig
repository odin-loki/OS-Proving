int
unsigned short	device
u8	chiprev
