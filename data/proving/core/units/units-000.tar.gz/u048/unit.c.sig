int
struct ds1307 *	ds1307
u8	mask
u8	value
