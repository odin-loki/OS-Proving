int
struct bdx_priv *	priv
