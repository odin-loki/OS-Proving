int
struct amdgpu_bo *	bo
uint32_t	domain
struct dma_fence *	fence
