int64_t
int64_t	dividend
int64_t	divisor
