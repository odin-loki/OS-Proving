int
enum cache_type	type
