struct st_buffer *
int	max_sg
