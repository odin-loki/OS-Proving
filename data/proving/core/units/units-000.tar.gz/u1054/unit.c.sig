int
struct rcar_du_plane *	plane
struct rcar_du_plane_state *	state
unsigned int	free
