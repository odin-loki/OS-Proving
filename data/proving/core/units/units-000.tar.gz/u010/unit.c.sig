int
struct batadv_priv *	bat_priv
struct sk_buff *	skb
