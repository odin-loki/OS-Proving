int
struct regulator_dev *	rdev
int	lim_uA
int	severity
bool	enable
