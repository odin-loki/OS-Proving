s64
s64	dividend
s64	divisor
