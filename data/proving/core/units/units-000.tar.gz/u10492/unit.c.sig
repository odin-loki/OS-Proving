int
unsigned char *	buf
int	len
