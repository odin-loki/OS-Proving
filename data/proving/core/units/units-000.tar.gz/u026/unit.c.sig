unsigned char
unsigned int	seed
size_t	i
