unsigned int
int	degrees
unsigned int	width
