u_int
XDR *	xdrs
