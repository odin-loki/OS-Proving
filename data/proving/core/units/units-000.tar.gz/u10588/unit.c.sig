unsigned int
char	val
