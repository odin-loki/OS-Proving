int
struct ntfs_sb_info *	sbi
const struct runs_tree *	run
u64	vbo
struct NTFS_RECORD_HEADER *	rhdr
u32	bytes
struct ntfs_buffers *	nb
