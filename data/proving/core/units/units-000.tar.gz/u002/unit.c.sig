int
struct radeon_device *	rdev
uint32_t *	data
