int
struct nozomi *	dc
