int
int	lcb_crc
