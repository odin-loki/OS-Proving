int
struct wcd939x_sdw_priv *	wcd
struct snd_soc_dai *	dai
void *	stream
int	direction
