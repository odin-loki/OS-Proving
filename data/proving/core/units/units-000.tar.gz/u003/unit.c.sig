u64
u64	eaddr
int	mc
