int
struct earlycon_device *	device
const char *	opt
