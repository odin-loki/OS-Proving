uint32_t
struct sbc_encode *	sbc
uint32_t	numbits
