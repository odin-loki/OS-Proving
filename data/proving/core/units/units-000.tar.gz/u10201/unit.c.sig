int
int	power
