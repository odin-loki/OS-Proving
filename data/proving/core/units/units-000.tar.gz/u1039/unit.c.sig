quad_t
quad_t	a
