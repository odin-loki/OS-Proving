u16
u32	divider
unsigned int	us
