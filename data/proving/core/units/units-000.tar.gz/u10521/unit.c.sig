int
unsigned int *	num
unsigned int *	denom
