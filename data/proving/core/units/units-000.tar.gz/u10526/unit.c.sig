bool
const struct adapter *	adapter
const struct sge_fl *	fl
