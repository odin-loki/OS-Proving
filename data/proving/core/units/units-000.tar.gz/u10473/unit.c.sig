int
u64	val
