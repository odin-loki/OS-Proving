int
u8	chip_main_rev
