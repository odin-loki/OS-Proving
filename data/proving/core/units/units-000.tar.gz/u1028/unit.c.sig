int
enum scsi_devinfo_key	key
