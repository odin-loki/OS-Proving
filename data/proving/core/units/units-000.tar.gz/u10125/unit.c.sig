u64
u64	period
u64	runtime
