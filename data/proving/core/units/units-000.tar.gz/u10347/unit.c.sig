u32
u32	attr
