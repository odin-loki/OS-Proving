bool
unsigned long	addr
unsigned long	len
