bool
struct rnd_state *	rng
