int
struct ace_private *	ap
u32	csm
u32	prd
