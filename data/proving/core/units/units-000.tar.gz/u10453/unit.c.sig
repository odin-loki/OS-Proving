u16
struct ef4_rx_queue *	rx_queue
const ef4_qword_t *	event
