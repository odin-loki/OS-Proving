unsigned int
int	role
