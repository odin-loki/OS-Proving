bool
u32	seq1
u32	seq2
