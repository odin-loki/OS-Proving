u32
u32	mask
u32	val
