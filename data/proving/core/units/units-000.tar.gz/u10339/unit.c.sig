acpi_status
u64	multiplicand
u32	multiplier
u64 *	out_product
