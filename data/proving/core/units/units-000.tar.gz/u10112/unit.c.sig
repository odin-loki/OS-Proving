bool
phys_addr_t	phys
size_t	size
