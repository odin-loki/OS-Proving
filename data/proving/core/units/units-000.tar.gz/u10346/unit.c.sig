int
struct ahd_softc *	ahd
