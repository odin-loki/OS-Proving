u_int
vm_offset_t	va
