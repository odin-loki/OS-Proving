int
void *	p
