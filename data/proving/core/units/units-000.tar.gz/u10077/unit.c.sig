int
struct device_node *	np
enum imx_gpt_type	type
