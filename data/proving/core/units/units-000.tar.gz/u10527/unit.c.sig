db_addr_t
db_addr_t	loc
bool	extended
