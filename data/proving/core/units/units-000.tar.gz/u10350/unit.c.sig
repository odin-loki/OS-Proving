u32
struct gspca_dev *	gspca_dev
u32	expo
