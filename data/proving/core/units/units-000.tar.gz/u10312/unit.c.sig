int
struct i2c_client *	client
u16	reg
u8 *	val
u16	len
