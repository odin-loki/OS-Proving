void
struct drbd_device *	device
union drbd_dev_state	state
unsigned long *	rs_total
unsigned long *	bits_left
unsigned int *	per_mil_done
