int
struct device *	dev
const u32 *	id_in
