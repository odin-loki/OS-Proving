int
struct net_device *	netdev
struct nfp_net_tls_resync_req *	req
void *	pkt
unsigned int	pkt_len
