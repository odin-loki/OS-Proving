bool
int	cmd
