bool
unsigned int	order
