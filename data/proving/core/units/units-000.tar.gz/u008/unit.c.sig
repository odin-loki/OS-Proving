bool
enum bfs_result	res
