int
struct afs_addr_preference_list **	_preflist
int	index
