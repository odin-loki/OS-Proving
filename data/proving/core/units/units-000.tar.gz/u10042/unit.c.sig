unsigned int
u32	rdo
