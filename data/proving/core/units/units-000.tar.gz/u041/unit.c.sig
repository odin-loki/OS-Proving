int
struct mt792x_phy *	phy
bool	set_default
