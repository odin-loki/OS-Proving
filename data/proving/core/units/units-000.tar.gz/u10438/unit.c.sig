int
struct mlx4_ib_dev *	dev
int	slave
int	port
int	do_init
