int
char *	params
struct p9_rdma_opts *	opts
