int
unsigned int	queue
struct port *	port
int	is_tx
