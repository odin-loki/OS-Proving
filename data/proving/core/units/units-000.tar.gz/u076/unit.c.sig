int
struct mdio_device *	mdiodev
