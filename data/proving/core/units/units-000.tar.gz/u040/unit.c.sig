u32
struct usbnet *	dev
u32	new_tx
