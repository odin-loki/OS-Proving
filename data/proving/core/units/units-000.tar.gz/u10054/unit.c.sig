int
int	pkey
unsigned long	rights
unsigned long	flags
