int
struct ste_softc *	sc
