int
struct vmw_plane_state *	vps
