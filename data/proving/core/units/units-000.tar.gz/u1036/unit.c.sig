int
struct sdw_intel *	sdw
unsigned int	pdi_num
