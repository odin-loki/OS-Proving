void
struct mtk_jpeg_stream *	stream
long	len
