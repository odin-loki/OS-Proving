int
struct mtk_eint *	eint
struct mtk_eint_pin *	eint_pin
