bool
unsigned short	vid
