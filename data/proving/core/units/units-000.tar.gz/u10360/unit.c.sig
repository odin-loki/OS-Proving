uint32_t
uint8_t	opcode
uint8_t	groupid
uint8_t	version
