bool
s32	a
