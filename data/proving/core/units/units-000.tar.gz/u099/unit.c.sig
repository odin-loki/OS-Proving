int
struct qed_hwfn *	p_hwfn
