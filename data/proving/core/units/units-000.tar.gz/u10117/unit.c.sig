int
unsigned long	nr
void *	ufdset
unsigned long *	fdset
