unsigned int
struct dw_i2s_dev *	dev
struct snd_pcm_runtime *	runtime
unsigned int	tx_ptr
bool *	period_elapsed
