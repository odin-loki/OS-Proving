fw_port_cap32_t
enum cc_fec	cc_fec
