unsigned int
struct pci_dev *	dev
