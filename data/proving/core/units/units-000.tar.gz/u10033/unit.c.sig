void
struct nix_hw *	nix_hw
