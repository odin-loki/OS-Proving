int
unsigned int	req_entries
