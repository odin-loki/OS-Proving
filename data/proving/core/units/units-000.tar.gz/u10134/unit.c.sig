int
struct nau8825 *	nau8825
long	timeout
