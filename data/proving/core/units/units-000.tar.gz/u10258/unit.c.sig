int
u32	field
u32	op
char *	rulestr
void **	lsmrule
gfp_t	gfp
