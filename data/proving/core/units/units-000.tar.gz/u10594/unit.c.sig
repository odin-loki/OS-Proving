int
const struct echoaudio *	chip
