bool
u32	ch_address
