enum timer_app_event
const char *	s
