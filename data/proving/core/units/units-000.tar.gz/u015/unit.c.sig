uint16_t
struct tcp_bbr *	bbr
uint16_t	gain
