int
int	minor
