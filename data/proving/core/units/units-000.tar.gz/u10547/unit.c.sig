int
struct trace_array *	tr
