u8
struct ath11k *	ar
u8	max_nss
