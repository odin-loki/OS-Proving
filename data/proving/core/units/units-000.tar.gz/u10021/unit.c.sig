int
struct ib_device *	dev
u32	port
u32	qp_num
u32	counter_id
