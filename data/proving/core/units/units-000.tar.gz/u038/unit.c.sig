boolean_t
vm_reserv_t	rv
vm_pindex_t	pindex
