int
unsigned long	clk
unsigned char *	param
