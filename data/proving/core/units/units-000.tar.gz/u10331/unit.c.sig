int
int	r1
int	r2
