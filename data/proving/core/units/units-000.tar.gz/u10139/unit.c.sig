int
char *	blk
int	size
