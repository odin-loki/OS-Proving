int
struct ia_css_binary *	binary
