int
char *	val
unsigned long	nr_pages
unsigned long *	lo
unsigned long *	hi
