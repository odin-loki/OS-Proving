int
bus_size_t	o
