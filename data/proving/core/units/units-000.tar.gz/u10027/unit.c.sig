int
?	?
int	nla_count
