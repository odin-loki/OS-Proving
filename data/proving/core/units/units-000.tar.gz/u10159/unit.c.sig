bool
u32	access_flags
