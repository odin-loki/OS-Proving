int
struct mlx4_dev *	dev
int	slave
int	port
