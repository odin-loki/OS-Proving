ssize_t
struct nullb_device *	dev
const char *	page
size_t	count
enum blk_zone_cond	cond
