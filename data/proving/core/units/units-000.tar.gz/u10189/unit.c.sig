u32
u32	flags
