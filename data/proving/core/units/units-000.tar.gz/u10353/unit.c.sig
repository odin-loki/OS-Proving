int
struct c4iw_srq *	srq
struct c4iw_dev_ucontext *	uctx
struct c4iw_wr_wait *	wr_waitp
