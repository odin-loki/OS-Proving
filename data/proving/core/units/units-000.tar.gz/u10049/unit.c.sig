int
struct adapter *	sc
struct sge_fl *	fl
int	n
