int
struct gb_gpio_controller *	ggc
