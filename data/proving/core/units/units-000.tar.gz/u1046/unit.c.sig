int
struct usbip_usb_device *	udev
int	i
struct usbip_usb_interface *	uinf
