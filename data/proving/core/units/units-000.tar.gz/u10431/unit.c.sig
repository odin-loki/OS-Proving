int
struct comedi_device *	dev
struct comedi_subdevice *	s
struct comedi_insn *	insn
unsigned long	context
