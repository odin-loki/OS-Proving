int
int	num_chan
