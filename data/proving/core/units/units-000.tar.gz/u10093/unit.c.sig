int
RING_IDX	idx
