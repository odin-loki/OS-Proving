int
struct xhci_hcd *	xhci
unsigned int	slot_id
unsigned int	ep_index
enum xhci_ep_reset_type	reset_type
