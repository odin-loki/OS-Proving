u8
u16	val
