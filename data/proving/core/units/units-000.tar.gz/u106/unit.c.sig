int
struct snd_soc_component *	component
u16	ana_pwr_reg
u32	source
