int
char *	buf
bool	logErr
