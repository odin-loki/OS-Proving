int
__u64	b
int	n
