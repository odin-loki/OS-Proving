int
struct xe_gt *	gt
