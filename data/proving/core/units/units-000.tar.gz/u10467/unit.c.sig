int
char *	to
struct stat *	to_sb
char *	from
int	ign
