unsigned int
unsigned int	inodes
