int
struct net *	net
struct socket *	sock
int	protocol
int	kern
