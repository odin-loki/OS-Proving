int
int	capacity
