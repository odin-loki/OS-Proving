int
struct device *	dev
struct regmap *	regmap
enum hmc5843_ids	id
const char *	name
