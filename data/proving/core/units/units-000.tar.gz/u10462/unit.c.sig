int
struct dss_device *	dss
struct platform_device *	pdev
struct device_node *	port
