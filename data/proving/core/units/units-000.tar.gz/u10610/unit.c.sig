bool
int	flags
