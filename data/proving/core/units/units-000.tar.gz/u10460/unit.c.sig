unsigned int
int	port
int	reg
