int
struct drm_gem_object **	bos
int	bo_count
struct drm_sched_job *	job
