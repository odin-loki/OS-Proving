u64
u64	vm_flags
