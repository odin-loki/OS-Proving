int
struct inode *	inode
struct inode *	dir
