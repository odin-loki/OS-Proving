int
struct ntfs_inode *	ni
