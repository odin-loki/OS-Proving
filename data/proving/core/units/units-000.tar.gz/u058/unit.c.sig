int
struct insn *	insn
