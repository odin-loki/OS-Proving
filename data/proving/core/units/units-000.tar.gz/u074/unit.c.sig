bool
kvm_pfn_t	start
kvm_pfn_t	end
