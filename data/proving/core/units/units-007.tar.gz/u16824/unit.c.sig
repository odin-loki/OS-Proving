int
struct smbdirect_socket *	sc
