unsigned int
struct p54_common *	priv
