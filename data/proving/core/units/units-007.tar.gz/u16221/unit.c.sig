int
struct intel_memory_region *	mr
struct list_head *	objects
