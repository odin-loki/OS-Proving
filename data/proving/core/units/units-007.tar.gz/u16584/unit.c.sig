int
struct comedi_device *	dev
unsigned int	num_samples
