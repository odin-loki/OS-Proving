int
struct ice_hw *	hw
u16	vsi_handle
