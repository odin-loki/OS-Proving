long
struct bpf_map *	map
void *	value
