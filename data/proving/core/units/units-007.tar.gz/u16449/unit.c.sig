U64
U64	srcSizeHint
size_t	dictSize
ZSTD_CParamMode_e	mode
