int
struct nvmem_device *	nvmem
