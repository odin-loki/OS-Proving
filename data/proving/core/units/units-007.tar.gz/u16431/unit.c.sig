u32
u64	bytes
enum rtw89_tfc_interval	interval
