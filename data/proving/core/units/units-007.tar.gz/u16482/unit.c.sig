u16
struct b43_wldev *	dev
u16	lna
u16	pga
u16	trsw_rx
