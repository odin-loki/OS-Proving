bool
int	ring_num
