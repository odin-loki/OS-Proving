u8
u32	mkey
