u32
struct bnx2x *	bp
