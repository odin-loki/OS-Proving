int
struct scsi_cmnd *	SCpnt
