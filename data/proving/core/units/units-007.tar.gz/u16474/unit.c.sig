int
int	delay
