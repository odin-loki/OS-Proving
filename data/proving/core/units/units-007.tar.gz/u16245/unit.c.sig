enum drbd_role
enum drbd_role	role1
enum drbd_role	role2
