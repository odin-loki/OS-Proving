int
struct i2c_client *	i2c_client
struct cs35l34_platform_data *	pdata
