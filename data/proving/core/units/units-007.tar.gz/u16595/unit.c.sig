unsigned int
int	level
