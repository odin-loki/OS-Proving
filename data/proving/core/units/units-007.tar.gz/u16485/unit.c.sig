int
struct ttm_resource_manager *	man
u64	start
u64	size
