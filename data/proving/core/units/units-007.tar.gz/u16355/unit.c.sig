int
keyboard_t *	kbd
int	lock
