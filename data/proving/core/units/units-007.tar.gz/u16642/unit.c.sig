int
int	rate
