float64
flag	zSign
int16	zExp
bits64	zSig
