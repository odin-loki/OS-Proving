int
struct cdns_nand_ctrl *	cdns_ctrl
