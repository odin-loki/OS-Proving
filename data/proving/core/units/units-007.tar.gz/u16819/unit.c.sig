int
struct mlx5_ib_dev *	dev
bool	is_user
u64	req_ucaps
