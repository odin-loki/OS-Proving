u32
u32	domain
u32	desired
u32	fallback
