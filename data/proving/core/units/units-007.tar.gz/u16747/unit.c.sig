int
struct smb_share *	ssp
struct smb_cred *	scred
