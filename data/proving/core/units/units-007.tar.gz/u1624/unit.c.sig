dma_addr_t
dma_addr_t	addr
dma_addr_t	beg
int	ring_count
