int
struct wx_q_vector *	q_vector
struct wx_ring *	rx_ring
int	budget
