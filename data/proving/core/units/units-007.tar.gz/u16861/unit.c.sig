bool
u64	a
u64	b
