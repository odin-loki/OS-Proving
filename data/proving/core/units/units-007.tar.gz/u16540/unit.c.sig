int
const int	direction
const int	value
