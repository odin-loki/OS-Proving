__sum16
__sum16	csum
__be16	addend
