int
struct hostapd_data *	hapd
struct sta_info *	sta
