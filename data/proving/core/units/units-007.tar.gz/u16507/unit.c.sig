int
int	locked
unsigned long	owner
unsigned long	self
