ssize_t
struct tty_struct *	tty
const u8 *	buf
size_t	count
