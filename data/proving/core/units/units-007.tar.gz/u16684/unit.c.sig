int
struct nouveau_job *	job
struct drm_nouveau_sync *	sync
struct dma_fence **	fence
