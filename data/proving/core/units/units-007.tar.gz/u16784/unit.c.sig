int
struct phy *	phy
