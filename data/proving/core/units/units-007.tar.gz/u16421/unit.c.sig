int
struct hpi_hw_obj *	phw
int	state
int	timeout_us
