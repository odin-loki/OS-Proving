int
struct tb *	tb
struct tb_xdomain *	xd
int	transmit_path
int	transmit_ring
int	receive_path
int	receive_ring
