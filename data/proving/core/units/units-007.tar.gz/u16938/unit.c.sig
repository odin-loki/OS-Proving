bool
u64	addr
