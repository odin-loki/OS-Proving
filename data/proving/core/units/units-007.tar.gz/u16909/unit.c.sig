int
struct file *	file
