size_t
uint32_t	items
