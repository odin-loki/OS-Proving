int
int	wrote
