int
struct net_device *	ndev
int	int_status
int	err_status
