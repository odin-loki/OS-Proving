int
int	fd
char *	str
int	cnt
int *	rem
int *	isempt
int	sz
char *	name
