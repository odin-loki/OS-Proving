int
char *	arg
