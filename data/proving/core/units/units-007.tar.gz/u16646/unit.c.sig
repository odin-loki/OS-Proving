bool
long	val
