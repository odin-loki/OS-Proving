int
struct cc_cipher_ctx *	ctx_p
u32	size
