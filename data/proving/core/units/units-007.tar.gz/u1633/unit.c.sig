int
struct scd4x_state *	state
enum scd4x_cmd	cmd
void *	response
int	response_sz
