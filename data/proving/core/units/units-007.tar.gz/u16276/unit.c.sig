u8
u16	dur
