int
struct pcmtst *	pcmtst
