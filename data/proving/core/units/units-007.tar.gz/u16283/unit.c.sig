bool
unsigned int	feature
