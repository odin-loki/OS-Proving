int
struct hns_roce_dev *	hr_dev
