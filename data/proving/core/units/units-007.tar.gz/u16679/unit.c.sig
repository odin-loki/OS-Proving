unsigned int
u16	snb_gmch_ctl
