size_t
struct tty_port *	port
const u8 *	chars
const u8 *	flags
bool	mutable_flags
size_t	size
