bool
const u8 *	sbuf8
unsigned int	spitch
int	x
int	y
