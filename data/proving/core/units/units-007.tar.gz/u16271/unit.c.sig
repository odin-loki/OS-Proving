unsigned int
unsigned char *	hpte_slot_array
int	index
