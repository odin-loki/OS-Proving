bool
struct amdgpu_device *	adev
u8 *	bios
u32	length_bytes
