int
struct device *	dev
struct device_node *	node
struct simple_util_dai *	simple_dai
struct snd_soc_dai_link_component *	dlc
