int
struct ad3552r_desc *	dac
