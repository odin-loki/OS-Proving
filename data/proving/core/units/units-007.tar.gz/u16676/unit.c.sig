int
struct lola *	chip
