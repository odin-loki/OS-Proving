unsigned int
struct mlx5_core_dev *	dev
struct mlx5_uars_page *	up
struct mlx5_sq_bfreg *	bfreg
