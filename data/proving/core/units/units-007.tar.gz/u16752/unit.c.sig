int
struct pci_dev *	dev
int	resource
