bool
u8	caps
u8	mask
