int
struct snd_pcm_substream *	substream
struct snd_pcm_hw_params *	hw_params
