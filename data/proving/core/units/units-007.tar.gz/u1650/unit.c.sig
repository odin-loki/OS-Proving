int
struct pfn_batch *	batch
size_t	max_pages
