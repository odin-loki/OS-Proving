int
struct rproc *	rproc
const struct firmware *	fw
