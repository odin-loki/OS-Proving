int
struct hci_dev *	hdev
bool	enable
