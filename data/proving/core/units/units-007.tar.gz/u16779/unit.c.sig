int
struct d40_chan *	d40c
