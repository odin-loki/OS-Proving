long
s8	hb
u8	lb
