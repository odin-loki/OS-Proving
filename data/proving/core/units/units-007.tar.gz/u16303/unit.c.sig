enum i40e_status_code
struct i40e_hw *	hw
struct i40e_filter_control_settings *	settings
