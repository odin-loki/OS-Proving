long
struct keyctl_dh_params *	params
char *	buffer
size_t	buflen
struct keyctl_kdf_params *	kdf
