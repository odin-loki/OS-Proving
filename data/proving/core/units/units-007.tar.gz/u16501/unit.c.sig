int
struct irq_data *	idata
unsigned int	type
