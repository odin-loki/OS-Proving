u64
u32	revision
u16	size
u8	memtype
