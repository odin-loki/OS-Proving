bool
u64	val
