int
struct sprd_mcdt_chan *	chan
enum sprd_mcdt_dma_chan	dma_chan
u32	water_mark
