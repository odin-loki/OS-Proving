int
vortex_t *	vortex
int	dma
int	nr_ch
int	dir
int	type
int	subdev
