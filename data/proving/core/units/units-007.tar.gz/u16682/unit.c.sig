int
struct xdr_stream *	xdr
unsigned int	savep
uint32_t	attrlen
