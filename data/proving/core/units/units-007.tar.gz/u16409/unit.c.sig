int
struct backing_dev_info *	bdi
unsigned int	max_ratio
