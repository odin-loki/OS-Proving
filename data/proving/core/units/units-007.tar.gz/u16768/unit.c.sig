s32
u32	pad1
s32	sad1
u32	pad2
s32	sad2
