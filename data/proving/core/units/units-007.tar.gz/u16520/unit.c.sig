int
int	status
