int
struct regulator_dev *	dev
unsigned	selector
