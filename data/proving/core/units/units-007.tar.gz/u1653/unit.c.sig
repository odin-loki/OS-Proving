u8
u8	mask
