u64
__le64	hwaddr
