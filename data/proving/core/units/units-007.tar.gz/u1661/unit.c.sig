int
const char *	val
const struct kernel_param *	kp
