int
int	asroot
int	injail
struct test *	test
