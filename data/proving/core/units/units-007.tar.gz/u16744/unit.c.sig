int
int	reg
