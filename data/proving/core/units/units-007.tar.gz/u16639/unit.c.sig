bool
int	flow_mode
