int
struct bttv *	btv
