unsigned int
unsigned int	flags
