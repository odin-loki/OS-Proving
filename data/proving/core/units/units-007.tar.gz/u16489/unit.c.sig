int
unsigned char	id
?	?
?	?
int	n
int	max_pads
