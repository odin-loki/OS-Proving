bool
unsigned long	s
