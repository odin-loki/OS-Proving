u32
struct mlx4_zone_allocator *	zones
u32	obj
u32	count
