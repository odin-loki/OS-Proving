unsigned int
struct bcmgenet_rx_ring *	ring
unsigned int	budget
