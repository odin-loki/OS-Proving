comp2_t
u64	value
