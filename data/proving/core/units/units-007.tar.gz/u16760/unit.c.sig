unsigned int
long long	value
unsigned int	integer_bits
unsigned int	fractional_bits
unsigned int	min_clamp
