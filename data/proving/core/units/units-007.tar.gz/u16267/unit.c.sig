int
unsigned int	len
