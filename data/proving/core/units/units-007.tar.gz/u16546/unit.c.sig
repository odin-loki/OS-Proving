enum pt_error_code
int	status
