int
struct regmap *	infracfg
u32	mask
bool	reg_update
