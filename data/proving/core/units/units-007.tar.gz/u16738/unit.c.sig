int
uint64_t	mask
