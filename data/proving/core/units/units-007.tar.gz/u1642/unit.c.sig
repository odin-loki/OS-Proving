bool
struct sof_mtrace_core_data *	core_data
