int
struct thinkpad_id_data *	tp
