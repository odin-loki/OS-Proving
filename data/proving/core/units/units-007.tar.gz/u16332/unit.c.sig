int
struct amdgpu_device *	adev
uint8_t	instance
uint16_t	hw_id
