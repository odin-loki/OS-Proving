int
struct sunkbd *	sunkbd
