int
struct cx25821_dev *	dev
int	chan_num
u32	status
