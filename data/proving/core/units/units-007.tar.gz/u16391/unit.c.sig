bool
unsigned int	thoff
