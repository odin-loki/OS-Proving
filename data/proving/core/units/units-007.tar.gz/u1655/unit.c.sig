int
int	vbat_lower
int	vbat_upper
int	level_lower
int	level_upper
int	bat_voltage
