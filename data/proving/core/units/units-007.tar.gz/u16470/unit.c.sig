int
struct rvu *	rvu
u16	pcifunc
int	blkaddr
int	lf
int	slot
