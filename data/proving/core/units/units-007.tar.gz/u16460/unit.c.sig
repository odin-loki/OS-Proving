unsigned int
unsigned int	min
unsigned int	max
unsigned int	step
unsigned int	val
