int
struct scsi_qla_host *	vha
void *	iocb
int	mcmd
