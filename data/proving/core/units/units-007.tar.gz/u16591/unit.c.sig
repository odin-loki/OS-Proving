u32
u16	imm12_1
u8	rs2
u8	rs1
u8	funct3
u8	opcode
