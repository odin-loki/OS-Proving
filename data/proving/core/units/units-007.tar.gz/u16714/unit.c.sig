int
struct ad4170_state *	st
unsigned int	setup_num
