u16
struct b43_wldev *	dev
