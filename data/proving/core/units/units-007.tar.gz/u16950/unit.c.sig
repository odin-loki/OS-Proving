u64
u64	ra_mask
u64	ra_mask_bak
