int
int	errcode
const char *	zFunc
const char *	zPath
int	iLine
