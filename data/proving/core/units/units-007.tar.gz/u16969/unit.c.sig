unsigned long
unsigned long	rate
unsigned long	parent_rate
