u32
u32	hw_id
u32	mask
enum tsens_ver	ver
