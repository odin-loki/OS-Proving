u8
u64	address
struct acpi_generic_address *	reg
u8	max_bit_width
