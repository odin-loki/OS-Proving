bool
pt2_entry_t	pte2
