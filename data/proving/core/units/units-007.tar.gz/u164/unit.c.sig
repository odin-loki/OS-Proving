int
struct gem_softc *	sc
bus_addr_t	r
uint32_t	clr
uint32_t	set
