unsigned int
const struct sseu_dev_info *	sseu
int	groupsize
int	groupnum
