int
struct jfs_log *	log
int	hard_sync
