u8
struct cdns_pcie *	pcie
u8	fn
u8	vfn
