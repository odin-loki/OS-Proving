bool
blk_opf_t	op
