unsigned int
u32	pdo
