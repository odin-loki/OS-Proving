int
struct snd_sof_dev *	sdev
