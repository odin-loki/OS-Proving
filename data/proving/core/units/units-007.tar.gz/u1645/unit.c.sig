unsigned int
unsigned int	maxsegs
