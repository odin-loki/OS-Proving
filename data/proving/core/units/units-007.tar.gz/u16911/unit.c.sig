int
void *	buf_dst
const void *	buf_src
u32	elem_len
u32	elem_size
