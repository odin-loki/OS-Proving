bool __must_check
__force const void *	ptr
