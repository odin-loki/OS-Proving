unsigned long
int	setting
