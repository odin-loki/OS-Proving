int
struct btrfs_inode *	inode
loff_t	start
loff_t	end
