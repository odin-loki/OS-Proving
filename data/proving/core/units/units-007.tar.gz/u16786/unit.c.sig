int
struct sock *	sk
int	val
