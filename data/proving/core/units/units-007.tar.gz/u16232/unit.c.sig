int
struct iwl_trans *	trans
u32	addr
u32	bits
u32	mask
int	timeout
