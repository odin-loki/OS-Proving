bool
u64	n
