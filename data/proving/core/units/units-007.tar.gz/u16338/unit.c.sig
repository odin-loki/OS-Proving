int
struct nf_hook_entries **	pp
const struct nf_hook_ops *	reg
