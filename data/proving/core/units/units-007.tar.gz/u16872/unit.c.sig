u32
const struct hv_ring_buffer_info *	rbi
