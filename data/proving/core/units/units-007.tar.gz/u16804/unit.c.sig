int
u32	drc
int	dev_idx
