int
struct intel_vgpu *	vgpu
u64	resolution
