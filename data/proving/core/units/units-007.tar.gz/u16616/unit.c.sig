size_t
struct n_tty_data *	ldata
