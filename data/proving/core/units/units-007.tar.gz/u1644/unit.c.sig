acpi_status
u32	flags
