int
struct sja1105_private *	priv
int	port
struct netlink_ext_ack *	extack
unsigned long	cookie
struct sja1105_key *	key
u32	index
s32	prio
u64	base_time
u64	cycle_time
u64	cycle_time_ext
u32	num_entries
struct action_gate_entry *	entries
