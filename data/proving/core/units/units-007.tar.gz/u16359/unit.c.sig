uint32_t
struct bstp_port *	bp
