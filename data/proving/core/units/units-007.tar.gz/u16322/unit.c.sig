int
struct icom_adapter *	icom_adapter
