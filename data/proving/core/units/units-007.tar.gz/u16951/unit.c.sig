int
int	len16
