unsigned long
unsigned long	pfn
