bool
s64	num
