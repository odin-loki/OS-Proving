unsigned long
struct bcm2835_clock *	clock
unsigned long	parent_rate
u32	div
