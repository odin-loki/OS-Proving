int
struct resource_node *	res
