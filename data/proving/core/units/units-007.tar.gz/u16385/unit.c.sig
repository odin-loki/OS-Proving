int
struct bnx2x *	bp
u16	pretend_func_val
