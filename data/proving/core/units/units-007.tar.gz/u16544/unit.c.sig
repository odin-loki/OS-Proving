u8
struct iwl_priv *	priv
u8	time
u16	compensation
