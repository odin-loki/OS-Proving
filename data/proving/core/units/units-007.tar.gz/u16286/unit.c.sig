int
const char *	buf
unsigned long *	val
