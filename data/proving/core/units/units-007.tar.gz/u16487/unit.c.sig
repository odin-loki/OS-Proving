u8
enum spacemit_pin_io_type	type
u32	mA
