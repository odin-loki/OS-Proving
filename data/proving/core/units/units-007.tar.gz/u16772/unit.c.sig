int
struct qedf_ioreq *	orig_io_req
u32	offset
u8	r_ctl
