int
struct axp288_fg_info *	info
int	reg
