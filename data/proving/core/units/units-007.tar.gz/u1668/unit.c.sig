int
struct libie_fwlog *	fwlog
struct libie_fwlog_api *	api
