u32
u32	hfreq
u32	xres
