int
struct zstd_data *	data
int	level
