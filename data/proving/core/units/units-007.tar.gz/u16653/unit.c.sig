int
struct mfi_softc *	sc
uint32_t	opcode
