unsigned int
struct efx_nic *	efx
