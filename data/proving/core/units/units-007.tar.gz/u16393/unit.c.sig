enum sci_status
struct isci_host *	ihost
u32	coalesce_number
u32	coalesce_timeout
