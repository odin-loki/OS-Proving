int
vm_paddr_t	start
vm_paddr_t	end
vm_memattr_t	memattr
