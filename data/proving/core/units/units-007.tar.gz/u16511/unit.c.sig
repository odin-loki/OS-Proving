bool
unsigned int	bit
