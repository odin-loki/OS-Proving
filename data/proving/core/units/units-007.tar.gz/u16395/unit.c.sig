int
struct igb_adapter *	adapter
