int
struct shash_desc *	desc
const u8 *	src
unsigned int	len
