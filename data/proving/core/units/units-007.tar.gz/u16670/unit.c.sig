int
struct idpf_adapter *	adapter
