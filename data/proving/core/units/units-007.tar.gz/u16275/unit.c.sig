int
struct hda_codec *	codec
int	port
