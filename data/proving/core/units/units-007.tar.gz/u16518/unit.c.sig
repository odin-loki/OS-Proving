s16
struct dib0090_state *	state
u16	wbd
