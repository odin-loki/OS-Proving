int
struct rvu *	rvu
