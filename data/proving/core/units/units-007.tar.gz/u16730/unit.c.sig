int
struct ipu6_device *	isp
const void *	cpd_file
unsigned long	cpd_file_size
