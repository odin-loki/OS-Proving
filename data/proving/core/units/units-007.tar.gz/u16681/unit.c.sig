s32
struct ptp_clock_info *	ptp
