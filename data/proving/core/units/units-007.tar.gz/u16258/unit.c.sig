void
u64 *	phy_type_low
u64 *	phy_type_high
u16	link_speeds_bitmap
