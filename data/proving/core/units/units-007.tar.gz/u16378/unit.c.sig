size_t
struct fs_context *	fc
const char *	name
size_t	size
