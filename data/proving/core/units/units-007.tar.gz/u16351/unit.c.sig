int
struct sock *	sk
struct msghdr *	msg
unsigned char *	record_type
