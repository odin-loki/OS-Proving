u16
struct bnge_dev *	bd
u16	rx_rings
