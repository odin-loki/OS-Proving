int
int	step
