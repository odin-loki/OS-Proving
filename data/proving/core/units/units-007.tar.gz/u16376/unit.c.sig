bool
u8	start
u8	end
