int
struct atm_vcc*	vcc
