unsigned int
unsigned int	width
unsigned int	height
