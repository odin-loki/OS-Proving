unsigned int
unsigned int	map_size
