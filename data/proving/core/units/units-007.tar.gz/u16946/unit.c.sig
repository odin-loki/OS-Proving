int
unsigned int	host
