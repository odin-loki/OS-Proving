u16
struct ath_hw *	ah
u16	power_limit
u8	antenna_reduction
