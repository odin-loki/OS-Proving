s32
struct v4l2_flash *	v4l2_flash
enum led_brightness	brightness
