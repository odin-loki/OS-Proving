int
struct vtballoon_softc *	sc
