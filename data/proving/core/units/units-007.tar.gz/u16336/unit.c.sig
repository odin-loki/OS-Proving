int
struct usb_serial_port *	port
void *	dest
size_t	size
