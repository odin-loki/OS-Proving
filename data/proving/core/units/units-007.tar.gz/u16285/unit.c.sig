int
u16	flags
