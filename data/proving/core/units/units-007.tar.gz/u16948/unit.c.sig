int
struct xe_vm *	vm
struct xe_svm_range *	range
struct drm_gpusvm_ctx *	ctx
