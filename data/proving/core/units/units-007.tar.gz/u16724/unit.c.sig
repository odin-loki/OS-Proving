int
struct most_interface *	most_iface
int	ch_idx
struct most_channel_config *	ccfg
