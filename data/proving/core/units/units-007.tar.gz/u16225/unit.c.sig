quad_t
quad_t	a
qshift_t	shift
