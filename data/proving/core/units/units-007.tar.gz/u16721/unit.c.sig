int
unsigned long	len
int	offset
