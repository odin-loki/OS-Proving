bool
unsigned int	chunk_sectors
unsigned int	boundary_sectors
