int
struct drm_dp_tunnel *	tunnel
struct drm_dp_tunnel_regs *	regs
unsigned int	flags
