int
struct m66592 *	m66592
u16	pipenum
