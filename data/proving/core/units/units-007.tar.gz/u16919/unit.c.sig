bool
unsigned int	reg
