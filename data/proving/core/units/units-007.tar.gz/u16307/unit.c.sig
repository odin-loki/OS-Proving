int
struct sc_info *	sc
