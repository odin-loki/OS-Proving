enum iavf_status
struct iavf_hw *	hw
struct iavf_dma_mem *	mem
enum iavf_memory_type	type
u64	size
u32	alignment
