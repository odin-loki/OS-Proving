int
YYSTACKDATA *	data
