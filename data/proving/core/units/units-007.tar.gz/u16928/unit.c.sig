int
struct usb_device *	udev
struct usb_hub *	hub
int	port1
u16 *	portchange
u16 *	portstatus
