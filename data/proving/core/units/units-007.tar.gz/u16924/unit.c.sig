int
struct pci_dev *	pci
struct cx25821_riscmem *	risc
unsigned int	size
