u32
struct lpfc_hba *	phba
struct lpfc_rx_info_monitor *	rx_monitor
char *	buf
u32	buf_len
u32	max_read_entries
