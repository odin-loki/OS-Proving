u8
u32	ip_version
