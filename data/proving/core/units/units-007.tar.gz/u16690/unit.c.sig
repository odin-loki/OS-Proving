void
u32	idx
u32 *	closid
u32 *	rmid
