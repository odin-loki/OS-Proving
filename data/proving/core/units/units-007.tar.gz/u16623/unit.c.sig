bool
unsigned long	addr
int	offset
unsigned int	expected
