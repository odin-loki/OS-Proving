enum mlxsw_reg_sfd_op
bool	adding
