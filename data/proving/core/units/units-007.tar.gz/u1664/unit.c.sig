void
int *	limit
int	val
