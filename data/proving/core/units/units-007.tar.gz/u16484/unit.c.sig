unsigned int
struct rnd_state *	rnd
