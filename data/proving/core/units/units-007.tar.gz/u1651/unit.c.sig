int
const struct device_node *	np
const char *	list_name
