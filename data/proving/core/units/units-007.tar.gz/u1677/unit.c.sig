u16
u16	link_width
