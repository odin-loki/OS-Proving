int
struct clkdom *	clkdom
struct aw_clk_frac_def *	clkdef
