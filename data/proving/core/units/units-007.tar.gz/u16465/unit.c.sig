int
struct psmouse *	psmouse
unsigned char *	param
int	command
