int
struct enic *	enic
struct ethtool_coalesce *	ec
