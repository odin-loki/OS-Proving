bool
u64	delta
