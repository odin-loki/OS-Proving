bool
int	cur
int	req
