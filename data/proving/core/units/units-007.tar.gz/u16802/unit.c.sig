int
struct irq_desc *	desc
int	irq
int	node
unsigned int	flags
const struct cpumask *	affinity
struct module *	owner
