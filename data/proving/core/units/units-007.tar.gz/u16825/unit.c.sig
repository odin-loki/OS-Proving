int
uint32_t	ocr
