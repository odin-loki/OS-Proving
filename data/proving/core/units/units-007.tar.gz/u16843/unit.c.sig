int
struct snd_pcm_substream *	substream
int	type
struct device *	data
size_t	size
