u16
struct mlx5_core_dev *	dev
u32	controller
u16	sw_id
