int
struct nmreq_header *	hdr
