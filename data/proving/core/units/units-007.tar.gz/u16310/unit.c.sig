int
struct vx_core *	_chip
