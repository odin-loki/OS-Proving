long
struct file *	file
int	mode
loff_t	offset
loff_t	len
