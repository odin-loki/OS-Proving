int
unsigned int	vc_num
