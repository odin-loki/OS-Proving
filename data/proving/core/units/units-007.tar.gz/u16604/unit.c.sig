int
struct usbatm_data *	usbatm
struct atm_dev *	atm_dev
