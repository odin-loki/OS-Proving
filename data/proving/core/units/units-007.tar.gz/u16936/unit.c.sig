int
HTAB *	hashp
BUFHEAD *	bufp
int	ndx
