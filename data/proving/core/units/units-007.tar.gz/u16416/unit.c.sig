int
struct altera_tse_private *	priv
int	limit
