u16
u8	index
u16	val
