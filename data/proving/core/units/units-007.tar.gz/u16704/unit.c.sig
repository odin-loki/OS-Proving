int
struct tcpcb *	tp
void **	ptr
