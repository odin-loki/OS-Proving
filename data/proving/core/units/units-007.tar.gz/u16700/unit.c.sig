int
struct intel_vgpu_ppgtt_spt *	spt
u64	pa
void *	p_data
int	bytes
