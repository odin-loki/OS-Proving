int
struct ms5611_state *	st
s32 *	temp
s32 *	pressure
