int
struct ecryptfs_daemon *	daemon
char *	data
size_t	data_size
u32	seq
