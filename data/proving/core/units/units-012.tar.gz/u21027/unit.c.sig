int
u8	duty
