bool
u64	superset
u64	subset
u64	mask
