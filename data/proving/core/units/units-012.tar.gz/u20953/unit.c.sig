int
unsigned short	hi
unsigned short	lo
