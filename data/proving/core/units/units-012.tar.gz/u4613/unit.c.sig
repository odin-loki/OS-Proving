_Bool
u8	type
