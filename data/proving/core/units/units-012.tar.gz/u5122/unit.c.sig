void
void **	pages
int	src_cnt
ssize_t	len
