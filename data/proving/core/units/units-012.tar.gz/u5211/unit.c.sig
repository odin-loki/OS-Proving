int
struct mlx5_irq *	irq
struct notifier_block *	nb
