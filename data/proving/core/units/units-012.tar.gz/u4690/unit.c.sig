int
const int *	source_rates
int	source_len
const int *	sink_rates
int	sink_len
int *	common_rates
