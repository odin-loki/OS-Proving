int
struct r8a66597 *	r8a66597
u16	pipenum
