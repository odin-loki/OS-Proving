int
struct bq2415x_device *	bq
u8	reg
u8	mask
u8	shift
