int
struct snd_mpu401 *	mpu
