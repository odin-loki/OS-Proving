unsigned int
unsigned long	addr
