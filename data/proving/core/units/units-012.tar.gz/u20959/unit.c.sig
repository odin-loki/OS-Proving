int
struct vmbus_channel *	chan
void *	data
int	data_len
uint32_t	advance
