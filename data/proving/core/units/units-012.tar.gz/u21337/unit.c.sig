int
struct drm_i915_gem_object *	obj
const struct tile *	tile
unsigned long	end_time
