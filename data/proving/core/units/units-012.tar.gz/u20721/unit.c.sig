int
int	y1
int	y0
int	x1
int	x0
