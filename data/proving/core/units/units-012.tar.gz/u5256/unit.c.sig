u8
struct radeon_device *	rdev
u32	sclk
u32	min_sclk_in_sr
