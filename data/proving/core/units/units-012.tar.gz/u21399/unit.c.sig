int
void *	ioaddr
unsigned int	mii_data
