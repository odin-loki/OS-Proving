int
struct vdpa_device *	vdev
u64	features
