unsigned int
unsigned int	mask
