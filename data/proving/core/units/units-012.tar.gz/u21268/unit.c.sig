bool
u16	langid
