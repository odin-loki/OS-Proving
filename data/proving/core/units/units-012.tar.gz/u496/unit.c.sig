bool
u32	chain_index
bool	ingress
