int
int	max_burst_len
int	quirks
