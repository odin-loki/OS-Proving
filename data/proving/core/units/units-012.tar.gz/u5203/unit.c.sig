enum vmpressure_levels
unsigned long	scanned
unsigned long	reclaimed
