int
struct ksz_device *	dev
int	port
