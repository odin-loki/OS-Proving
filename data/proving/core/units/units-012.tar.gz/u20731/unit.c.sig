int
struct mb_cache *	cache
gfp_t	mask
u32	key
u64	value
bool	reusable
