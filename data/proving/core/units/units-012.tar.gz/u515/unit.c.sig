u32
swreg	reg
