unsigned int
unsigned int	rate
unsigned int *	real_rate
