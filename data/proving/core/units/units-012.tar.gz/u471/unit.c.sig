int
adapter_t *	adapter
struct scsi_cmnd *	cmd
int	channel
