__u8
struct msgtemplate *	msg
