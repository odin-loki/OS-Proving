pending_ring_idx_t
struct xenvif_queue *	queue
