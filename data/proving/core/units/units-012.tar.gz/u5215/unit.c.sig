int
struct inode *	inode
struct ext4_inode *	raw
struct ext4_inode_info *	ei
