int
unsigned long	kbuffer
int	pagecount
bool	enc
