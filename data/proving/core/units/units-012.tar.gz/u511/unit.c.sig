void
struct nouveau_channel *	chan
int	data
