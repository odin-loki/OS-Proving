struct uacce_device *
struct device *	parent
struct uacce_interface *	interface
