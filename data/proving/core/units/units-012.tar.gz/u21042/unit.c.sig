int
struct qm_portal *	portal
