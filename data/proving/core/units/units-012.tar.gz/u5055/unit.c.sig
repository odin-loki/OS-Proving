u16
u16	hw_status_bits
