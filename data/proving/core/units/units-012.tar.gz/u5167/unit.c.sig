int
struct ieee80211_vht_cap *	cap
enum ieee80211_vht_chanwidth	bw
int	mcs
bool	ext_nss_bw_capable
unsigned int	max_vht_nss
