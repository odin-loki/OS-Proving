void
u64 *	avg
u64	sample
