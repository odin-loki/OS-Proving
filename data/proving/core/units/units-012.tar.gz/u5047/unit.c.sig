int
u16	syndrome
