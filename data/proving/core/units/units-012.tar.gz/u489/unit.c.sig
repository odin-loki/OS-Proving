unsigned int
struct comedi_async *	async
