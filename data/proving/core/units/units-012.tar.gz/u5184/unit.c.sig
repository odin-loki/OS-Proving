int
struct bnx2x *	bp
struct bnx2x_sriov *	iov
