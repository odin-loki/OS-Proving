unsigned char
unsigned char	seq
