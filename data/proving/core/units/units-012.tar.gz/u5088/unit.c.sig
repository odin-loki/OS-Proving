u_short
u_short	a
int	blink
