int
struct smmu_softc *	sc
struct smmu_domain *	domain
