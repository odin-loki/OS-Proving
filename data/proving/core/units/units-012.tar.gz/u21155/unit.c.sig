int
struct rxts *	rxts
