int
struct hdac_bus *	bus
unsigned int	status
?	?
