uint8_t
struct bucket *	b
