int
kcondvar_t *	cvp
kmutex_t *	mp
hrtime_t	tim
hrtime_t	res
int	flag
