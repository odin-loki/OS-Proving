int
struct snd_ac97 *	ac97
int	reg
int	shadow_reg
int	rate
