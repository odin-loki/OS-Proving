u64
u32	flags
u32	ro_flags
