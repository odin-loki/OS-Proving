bool
u32	insn_buf
