int
struct ptp_clock_info *	info
const struct timespec64 *	ts
