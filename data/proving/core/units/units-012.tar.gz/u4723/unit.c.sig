unsigned int
struct comedi_device *	dev
struct comedi_subdevice *	s
unsigned int	maxbytes
unsigned int	ns
