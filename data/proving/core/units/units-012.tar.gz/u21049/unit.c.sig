uint16_t
struct pcg_state_16*	rng
uint16_t	bound
