int
struct mf6ctable *	mfct
int	fibnum
struct mif6ctl *	mifcp
