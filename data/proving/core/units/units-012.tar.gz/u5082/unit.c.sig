unsigned int
enum uclamp_id	clamp_id
