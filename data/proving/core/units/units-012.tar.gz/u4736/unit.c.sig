int
struct hfi1_filedata *	fd
struct tid_user_buf *	tbuf
struct tid_group *	grp
u16	count
u32 *	tidlist
unsigned int *	tididx
unsigned int *	pmapped
