bool
const struct sock *	sk
int	family
int	type
int	code
