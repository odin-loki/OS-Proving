bool
char **	line
u32 *	offs
u32 *	val
int	short_fmt_len
int	long_fmt_len
