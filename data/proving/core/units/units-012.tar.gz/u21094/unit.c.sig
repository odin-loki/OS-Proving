int
struct qxl_device *	qdev
struct qxl_bo *	surf
bool	stall
