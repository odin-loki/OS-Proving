int
int	cid
