int
struct mpt_softc *	mpt
target_id_t	tgt
lun_id_t	lun
int	sleep_ok
