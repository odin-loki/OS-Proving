bool
const struct element *	element
const void *	data
size_t	datalen
