u_int32_t
struct sc_info *	sc
int	dir
