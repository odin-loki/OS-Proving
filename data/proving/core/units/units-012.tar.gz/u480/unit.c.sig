bool
int	resno
