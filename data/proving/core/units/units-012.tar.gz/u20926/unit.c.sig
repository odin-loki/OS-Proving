int
struct shash_desc *	desc
const u8 *	data
unsigned int	len
