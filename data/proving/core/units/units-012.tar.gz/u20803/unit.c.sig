bit32
tiRoot_t *	tiRoot
