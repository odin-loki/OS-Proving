int
int	mem_type
int	mode
int	mapping
