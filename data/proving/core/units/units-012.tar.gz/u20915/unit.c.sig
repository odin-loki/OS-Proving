int
int	sd
struct sockaddr *	sa
size_t	salen
int	flags
