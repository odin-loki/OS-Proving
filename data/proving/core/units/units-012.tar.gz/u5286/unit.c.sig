int
struct rbdr *	rbdr
int	mflags
