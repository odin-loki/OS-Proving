bool
const u8 *	data
u8	len
bool	from_ap
