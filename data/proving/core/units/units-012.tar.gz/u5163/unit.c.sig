int
struct mlx4_ib_dev *	dev
struct mlx4_ib_cq_buf *	buf
int	nent
