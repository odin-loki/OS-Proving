int
struct smscore_device_t *	coredev
