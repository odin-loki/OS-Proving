int
struct xe_gt *	gt
unsigned int	vfid
