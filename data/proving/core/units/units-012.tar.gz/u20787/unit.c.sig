int
struct dvb_usb_device *	d
