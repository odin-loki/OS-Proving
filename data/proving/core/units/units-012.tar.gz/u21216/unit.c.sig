int
adapter_t *	adap
