unsigned int
u64	roc
unsigned int	freq_div
