int
struct path_selector *	ps
unsigned int	argc
char **	argv
