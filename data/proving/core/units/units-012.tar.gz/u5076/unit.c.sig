unsigned long
int	scale_bits
unsigned long	dvco_rate
