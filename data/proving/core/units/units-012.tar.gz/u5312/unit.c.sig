void
struct echoaudio *	chip
