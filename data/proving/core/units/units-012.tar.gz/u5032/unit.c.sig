uint32_t
uint32_t	pll_type
uint32_t	n
uint32_t	m
