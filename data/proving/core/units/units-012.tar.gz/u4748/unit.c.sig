bool
u64	counter
u64	match
u8	op
