int
struct dm_cache_metadata *	cmd
struct dm_block **	sblock
