bool
int	cpu
u64	phys_id
