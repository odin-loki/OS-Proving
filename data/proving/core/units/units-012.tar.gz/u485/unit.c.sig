u32
int	x86_feature
