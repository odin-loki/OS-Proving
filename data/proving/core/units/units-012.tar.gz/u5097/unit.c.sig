int
struct amdgpu_device *	adev
u32	dws
