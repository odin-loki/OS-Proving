s64
struct amdgpu_device *	adev
u64	bytes
