bool
unsigned int	ofs
