bool
int	ret
u32	flags
