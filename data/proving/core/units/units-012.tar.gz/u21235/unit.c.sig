u32
u32	khz
s32	ppm
