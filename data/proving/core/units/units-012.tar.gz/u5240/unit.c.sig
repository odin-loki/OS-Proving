u32
u16	max_bw
