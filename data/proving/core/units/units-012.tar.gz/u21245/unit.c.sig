int
struct ntfs_inode *	ni
struct ATTRIB *	bitmap
struct ntfs_index *	indx
size_t	from
?	?
size_t *	ret
