int
char*	buf
int	max
double	value
int	prec
