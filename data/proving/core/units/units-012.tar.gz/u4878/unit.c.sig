int
struct nvkm_fifo *	fifo
int	nr
