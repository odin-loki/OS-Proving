int
struct ttm_object_file *	tfile
unsigned long	key
