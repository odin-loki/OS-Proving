int
wint_t	c
locale_t	locale
