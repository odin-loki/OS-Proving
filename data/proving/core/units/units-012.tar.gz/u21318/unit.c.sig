int
struct nvkm_volt *	base
u32	uv
