int
uint64_t *	frames
unsigned long	nr_gframes
unsigned long	max_nr_gframes
grant_status_t **	__shared
