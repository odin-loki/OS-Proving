int
struct bpf_test *	self
u8	op
bool	alu32
