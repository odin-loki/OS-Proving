int
struct snd_soc_component *	c
