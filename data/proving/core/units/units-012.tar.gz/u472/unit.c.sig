int
Jim_Interp *	interp
Jim_Obj *	filenameObj
Jim_Obj *	modeObj
