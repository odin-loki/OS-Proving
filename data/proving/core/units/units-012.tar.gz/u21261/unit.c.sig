int
unsigned int	fll_in
unsigned int	fs
struct nau8825_fll *	fll_param
