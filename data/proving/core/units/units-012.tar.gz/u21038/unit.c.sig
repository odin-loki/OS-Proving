int
struct pci_dev *	__dev
struct msix_entry *	entries
int	nvec
struct irq_affinity_desc *	masks
