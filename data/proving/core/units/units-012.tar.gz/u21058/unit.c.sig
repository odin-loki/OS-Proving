int
struct cxl_dev_state *	cxlds
