unsigned int
unsigned int	syt
unsigned int	cycle
unsigned int	transfer_delay
