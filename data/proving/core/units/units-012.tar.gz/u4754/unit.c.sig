int
struct ntsync_wait_state *	state
struct thread *	td
