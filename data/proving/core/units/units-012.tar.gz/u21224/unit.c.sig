u32
int	entry
