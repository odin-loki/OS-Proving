int
struct aa_profile *	profile
