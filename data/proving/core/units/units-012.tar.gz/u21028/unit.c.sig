quad_t
u_int	u
u_int	v
