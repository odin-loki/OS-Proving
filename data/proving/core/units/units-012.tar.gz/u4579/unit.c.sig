int
struct amd_page_map *	page_map
