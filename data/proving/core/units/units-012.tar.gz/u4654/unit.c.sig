int
struct intel_uc_fw *	guc_fw
struct intel_uncore *	uncore
