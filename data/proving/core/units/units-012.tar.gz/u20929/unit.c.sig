u16
u16	op1
u16	op2
