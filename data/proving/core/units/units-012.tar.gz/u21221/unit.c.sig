u32
struct ccp_cmd_queue *	cmd_q
unsigned int	count
