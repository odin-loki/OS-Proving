u32
u32	pos
size_t	limit
