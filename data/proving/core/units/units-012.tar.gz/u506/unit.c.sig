int
struct meson_msr_id *	clk_msr_id
unsigned int *	precision
