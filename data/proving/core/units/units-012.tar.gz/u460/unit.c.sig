u16
u16	next_packet_ptr
u16	start
u16	end
