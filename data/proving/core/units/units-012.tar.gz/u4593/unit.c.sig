int
struct ivpu_device *	vdev
u8	active_percent
