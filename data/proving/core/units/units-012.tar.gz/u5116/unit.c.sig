int
int	nid
unsigned long	unit_pages
