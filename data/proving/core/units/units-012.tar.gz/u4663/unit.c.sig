int
struct qlcnic_adapter *	adapter
struct cmd_desc_type0 *	cmd_desc_arr
int	nr_desc
