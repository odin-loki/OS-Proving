u8
struct adapter *	adapter
unsigned char	network_type
