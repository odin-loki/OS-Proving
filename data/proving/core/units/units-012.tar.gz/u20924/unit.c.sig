u8
unsigned	val
