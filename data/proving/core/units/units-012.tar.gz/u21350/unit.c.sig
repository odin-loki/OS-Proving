int
const sigset_t *	set
int *	sig
