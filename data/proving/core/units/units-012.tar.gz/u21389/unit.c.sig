int
struct b44 *	bp
gfp_t	gfp
