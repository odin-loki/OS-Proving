bool
signed long	timeout
