int
struct exynos_asv *	asv
