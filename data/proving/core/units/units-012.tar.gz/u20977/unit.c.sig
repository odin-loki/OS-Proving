int
int	use_dsgl
