u32
struct stv0367_state *	state
u32	adc_hz
