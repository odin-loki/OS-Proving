size_t
struct vhost_virtqueue *	vq
unsigned int	num
