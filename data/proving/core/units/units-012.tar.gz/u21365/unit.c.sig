int
struct fm10k_intfc *	interface
