int
size_t	span
