int
__fs32	ptr
