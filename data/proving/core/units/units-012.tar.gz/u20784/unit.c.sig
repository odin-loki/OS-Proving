int
void *	mem
int	size
void *	arg
int	flags
