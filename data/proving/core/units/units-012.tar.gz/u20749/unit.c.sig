int
struct pci_epf *	epf
u16	nums
