int
struct i2c_adapter *	i2c_adap
u8	i2c_addr
