int
const char *	f
const char *	fl
const char *	fs
const char *	fu
int	i
int	cyclelen
int	deadlock
