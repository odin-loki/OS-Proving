s32
loff_t	offset
