int
struct aac_dev *	dev
int	bled
u8	reset_type
