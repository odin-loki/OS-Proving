__le16
unsigned	len
