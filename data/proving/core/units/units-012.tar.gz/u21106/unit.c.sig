int
struct fsm *	fp
