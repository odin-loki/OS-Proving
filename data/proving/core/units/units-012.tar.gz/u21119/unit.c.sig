int
struct dm_cache_policy_type *	type
