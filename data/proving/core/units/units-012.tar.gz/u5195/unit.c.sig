u32
struct cxgbit_sock *	csk
u32 *	nparamsp
u32 *	flowclenp
