int
struct hid_device *	hdev
struct hid_input *	hi
struct mt_application *	app
