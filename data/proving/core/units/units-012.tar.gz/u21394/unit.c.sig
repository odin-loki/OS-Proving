ssize_t
u32	type
void *	priv
struct file *	filp
char *	ubuf
size_t	count
loff_t *	ppos
