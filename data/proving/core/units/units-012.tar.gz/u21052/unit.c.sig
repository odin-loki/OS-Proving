bool
u16	value
