int
u64	off
u64	len
