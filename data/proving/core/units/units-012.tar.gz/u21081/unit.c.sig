int
struct hda_beep *	beep
int	hz
