int
struct semaphore *	sem
long	timeout
