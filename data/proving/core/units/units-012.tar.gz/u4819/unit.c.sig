int
struct domain_device *	dev
struct scsi_cmnd *	cmd
