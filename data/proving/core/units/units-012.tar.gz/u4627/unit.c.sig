bool
int	sqi
