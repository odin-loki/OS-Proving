bool
const struct RESTART_HDR *	rhdr
