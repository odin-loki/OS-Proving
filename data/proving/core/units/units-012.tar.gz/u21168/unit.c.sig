int
struct mwifiex_adapter *	adapter
const void *	firmware
u32	firmware_len
