u16
struct intel_display *	display
u32	link_clock
u32	lane_count
u32	mode_clock
u32	mode_hdisplay
int	num_joined_pipes
enum intel_output_format	output_format
u32	pipe_bpp
u32	timeslots
