int
struct ieee80211_hw *	hw
int	index
int	limit
