int
struct mlx4_dev *	dev
u32	pd
enum mlx4_mw_type	type
struct mlx4_mw *	mw
