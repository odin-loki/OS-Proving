int
struct stv0367_state *	state
