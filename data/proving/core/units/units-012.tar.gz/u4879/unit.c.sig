int
struct pps_device *	pps
struct pps_bind_args *	bind_args
