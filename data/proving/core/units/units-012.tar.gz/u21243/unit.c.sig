int
const struct ia_css_stream_config *	config
unsigned int	bin_in
unsigned int *	start_column
