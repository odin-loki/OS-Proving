int
unsigned int	base_voltage
unsigned int	scale_factor
unsigned int	range
unsigned int	value
u8	cell_count
