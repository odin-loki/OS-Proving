int
struct sun4i_hdmi *	hdmi
