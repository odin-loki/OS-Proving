int
struct rpc_auth *	auth
