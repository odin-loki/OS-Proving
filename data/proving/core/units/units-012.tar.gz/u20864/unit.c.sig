int
int	sock
int	fd
