mpi_limb_t
mpi_ptr_t	prodp
mpi_ptr_t	up
mpi_ptr_t	vp
mpi_size_t	size
