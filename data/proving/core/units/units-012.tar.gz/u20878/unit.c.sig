int
struct flex_spi_softc *	sc
uint32_t	offset
uint32_t	mask
uint32_t	delay_us
uint32_t	iterations
bool	positive
