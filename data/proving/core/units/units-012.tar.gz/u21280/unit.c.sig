int
volatile uint32_t *	base
uint32_t	oldval
uint32_t *	oldvalp
uint32_t	newval
