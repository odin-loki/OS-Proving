bool
unsigned long	verf
