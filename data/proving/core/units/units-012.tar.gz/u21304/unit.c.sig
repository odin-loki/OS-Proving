int
if_ctx_t	ctx
caddr_t *	va
uint64_t *	pa
int	nrxqs
int	nrxqsets
