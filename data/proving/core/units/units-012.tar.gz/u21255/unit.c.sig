unsigned
u8	bcd
