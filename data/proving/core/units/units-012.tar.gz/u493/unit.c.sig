int
struct regmap *const	map
const unsigned int	base
