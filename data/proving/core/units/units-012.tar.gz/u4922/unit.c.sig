u16
u16	ptr
