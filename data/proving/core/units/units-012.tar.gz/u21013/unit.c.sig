int
ipf_main_softc_t *	softc
caddr_t	data
ipfobj_t *	objp
int **	arrayptr
