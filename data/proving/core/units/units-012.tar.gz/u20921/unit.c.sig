u64
u64	mair
bool	coherent
