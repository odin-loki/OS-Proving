int
u32	reg
u32	bit
