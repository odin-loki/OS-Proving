int
char *	buf
int	cnt
