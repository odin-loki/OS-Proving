int
enum qlink_cmd_result	qcode
