int
int	cpu
int	ri
struct pmc *	pm
const struct pmc_op_pmcallocate *	a
