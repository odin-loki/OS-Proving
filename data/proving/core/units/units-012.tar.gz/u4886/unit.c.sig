int
struct simple_util_priv *	priv
struct device_node *	cpu
struct device_node *	codec
struct link_info *	li
char *	prefix
char *	name
