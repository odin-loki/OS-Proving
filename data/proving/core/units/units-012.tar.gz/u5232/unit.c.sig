int
void *	opaque
struct fbnic_tlv_msg **	results
