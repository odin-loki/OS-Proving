int
struct imx_ic_priv *	ic_priv
