int
uint16_t	event_idx
uint16_t	new_idx
uint16_t	old
