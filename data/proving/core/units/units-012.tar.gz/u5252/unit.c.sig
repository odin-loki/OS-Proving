int
struct ath12k_base *	ab
int	ce_id
