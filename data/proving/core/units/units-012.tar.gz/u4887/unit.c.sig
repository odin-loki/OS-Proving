int
ns_dev *	card
vc_map *	vc
scq_info *	scq
ns_scqe *	tbd
struct sk_buff *	skb
bool	may_sleep
