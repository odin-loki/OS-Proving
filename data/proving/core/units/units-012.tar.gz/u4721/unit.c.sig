bool
int	refcnt
