dma64_t
dma64_t	a
u64	b
