int
int	ulp_type
