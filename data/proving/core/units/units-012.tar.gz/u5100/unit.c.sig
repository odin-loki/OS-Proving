long
const void *	ptr
