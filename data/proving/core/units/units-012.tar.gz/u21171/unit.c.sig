int
int	bank
int	instr
int	key
