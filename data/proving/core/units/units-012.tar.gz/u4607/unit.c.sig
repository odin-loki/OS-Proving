u_int
device_t	dev
const char *	what
u_int	v
u_int	min
u_int	max
