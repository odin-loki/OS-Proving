int
struct usb_composite_dev *	cdev
