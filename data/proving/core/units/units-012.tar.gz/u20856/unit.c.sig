u64
int	size
