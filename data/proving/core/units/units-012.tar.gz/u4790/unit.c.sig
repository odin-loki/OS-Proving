int
struct garmin_data *	garmin_data_p
