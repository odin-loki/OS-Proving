bool
enum resctrl_event_id	eventid
