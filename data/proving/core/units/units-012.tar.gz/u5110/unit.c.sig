int
unsigned int	filter
