u32
u32	supported_cap
u32	ethtool_cap
