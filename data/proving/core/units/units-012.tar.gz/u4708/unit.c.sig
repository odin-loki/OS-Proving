int
struct snd_soc_component *	comp
