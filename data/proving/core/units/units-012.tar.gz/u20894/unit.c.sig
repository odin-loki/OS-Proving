int
scsi_changer *	ch
unsigned int	type
unsigned int	unit
