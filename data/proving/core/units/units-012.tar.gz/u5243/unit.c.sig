int
const union qm_mr_entry *	e
