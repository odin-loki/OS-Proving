bool
struct ck_array *	array
unsigned int	mode
struct ck_malloc *	allocator
unsigned int	length
