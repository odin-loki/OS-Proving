size_t
size_t	box
size_t	len
u8	quirks
