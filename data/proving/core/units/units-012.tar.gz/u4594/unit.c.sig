int
device_t	bus
uint32_t	pin
