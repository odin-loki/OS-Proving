size_t
unsigned int	nr_bits
