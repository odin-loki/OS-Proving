uint64_t
uint8_t	b0
uint8_t	b1
uint8_t	b2
uint8_t	b3
uint8_t	b4
uint8_t	b5
