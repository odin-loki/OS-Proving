bool
enum ieee_attrs_app	type
