bool
scsi_qla_host_t *	vha
uint16_t	reg
