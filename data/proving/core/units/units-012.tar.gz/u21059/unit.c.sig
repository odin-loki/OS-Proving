u64
u16	opcode
u64	integer0
u64	integer1
