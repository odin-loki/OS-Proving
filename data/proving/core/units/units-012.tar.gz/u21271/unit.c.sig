int
struct ssusb_mtk *	ssusb
struct device_node *	parent_dn
