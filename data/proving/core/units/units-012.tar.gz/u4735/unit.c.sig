int
u32	gamma_mode
