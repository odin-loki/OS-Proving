bool
unsigned int	h
unsigned int	i
unsigned int	t
