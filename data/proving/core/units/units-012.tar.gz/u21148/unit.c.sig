int
struct sock_fprog *	dst
sockptr_t	src
int	len
