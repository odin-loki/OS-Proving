bool
unsigned int	rate
