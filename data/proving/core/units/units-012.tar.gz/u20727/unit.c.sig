u64
u64	delta
u32	mul_frac
int	shift
