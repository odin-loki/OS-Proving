u32
u32	function
