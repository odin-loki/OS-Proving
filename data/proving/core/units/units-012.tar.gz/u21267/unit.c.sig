int
enum mlx5_ptys_width	width
