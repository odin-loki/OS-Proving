u32
acpi_adr_space_type	space_id
acpi_physical_address	address
acpi_size	length
u8	warn
