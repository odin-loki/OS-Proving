bool
dm_block_t	n
