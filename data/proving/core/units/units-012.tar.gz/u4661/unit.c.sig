int
unsigned	i
bool	dct_width
