int
struct ovpn_pktid_xmit *	pid
u32 *	pktid
