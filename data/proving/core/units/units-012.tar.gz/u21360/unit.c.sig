unsigned int
unsigned int	i
unsigned int	j
