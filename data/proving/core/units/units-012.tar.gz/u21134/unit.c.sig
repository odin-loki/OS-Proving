u16
int	cap
