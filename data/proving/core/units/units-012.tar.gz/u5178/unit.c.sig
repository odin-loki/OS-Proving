int
kuid_t	uid
struct audit_names *	name
struct audit_field *	f
struct audit_context *	ctx
