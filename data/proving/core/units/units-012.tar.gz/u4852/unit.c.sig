int
struct bnad *	bnad
enum bnad_intr_source	src
u32	txrx_id
struct bna_intr_info *	intr_info
