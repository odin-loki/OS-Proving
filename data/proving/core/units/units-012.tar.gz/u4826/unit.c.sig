int
struct gve_tx_ring *	tx
