int
s64 *	to
const struct uverbs_attr_bundle *	attrs_bundle
size_t	idx
s64	lower_bound
u64	upper_bound
s64 *	def_val
