unsigned long
u32	latch
unsigned long	ms
int	loopmin
