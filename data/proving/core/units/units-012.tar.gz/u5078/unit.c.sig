int
int	x86_len
