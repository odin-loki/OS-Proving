int
struct irq_domain *	d
struct device_node *	node
const u32 *	intspec
unsigned int	intsize
unsigned long *	out_hwirq
unsigned int *	out_type
