int
struct dma_chan *	chan
