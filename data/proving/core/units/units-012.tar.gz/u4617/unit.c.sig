int
struct qedr_dev *	dev
struct mr_info *	info
size_t	page_list_len
bool	two_layered
