int
struct lpass_data *	drvdata
int	dir
unsigned int	dai_id
