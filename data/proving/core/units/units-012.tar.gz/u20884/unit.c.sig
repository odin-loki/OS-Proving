int
char	ch
