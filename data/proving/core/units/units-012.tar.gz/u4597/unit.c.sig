s8
u8	candidates
