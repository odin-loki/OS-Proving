int
struct vmxnet3_tx_queue *	tq
struct vmxnet3_adapter *	adapter
