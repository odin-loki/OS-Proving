bool
struct intel_dp *	intel_dp
int	link_rate
u8	lane_count
