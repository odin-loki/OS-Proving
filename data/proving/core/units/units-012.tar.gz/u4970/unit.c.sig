int
struct genl_info *	info
?	?
enum nl80211_attrs	attr
struct cfg80211_bitrate_mask *	mask
struct net_device *	dev
bool	default_all_enabled
unsigned int	link_id
