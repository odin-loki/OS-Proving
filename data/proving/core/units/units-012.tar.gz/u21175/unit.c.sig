int
u32	mtr
