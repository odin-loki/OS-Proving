int
struct arm_smmu_vmaster *	vmaster
u64 *	evt
