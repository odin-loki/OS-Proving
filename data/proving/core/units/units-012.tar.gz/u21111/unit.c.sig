int
struct pcm_channel *	c
int	vc
int	left
int	right
int	center
