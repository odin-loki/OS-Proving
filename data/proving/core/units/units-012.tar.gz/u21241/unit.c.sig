enum nl80211_he_ru_alloc
u16	rua
