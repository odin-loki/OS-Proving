bool
u32	cdw10
