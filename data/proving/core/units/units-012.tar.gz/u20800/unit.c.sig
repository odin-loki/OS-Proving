u16
long	rpm
