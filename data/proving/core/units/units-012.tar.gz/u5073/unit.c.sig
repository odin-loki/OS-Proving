bool
u8	train_set_lane
