u64
u16	count
u16	divider
