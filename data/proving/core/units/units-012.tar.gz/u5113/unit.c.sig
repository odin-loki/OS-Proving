bool
struct arm_smmu_ctx_desc_cfg *	cd_table
