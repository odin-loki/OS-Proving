u32
u8	num_of_bits
?	?
