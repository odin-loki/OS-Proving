int
u32	access_result
umode_t	umode
