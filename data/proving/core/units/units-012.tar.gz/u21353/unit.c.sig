int
struct gfs2_inode *	ip
bool	initialized
