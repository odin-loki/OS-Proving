int
struct mtk_eth *	eth
