u8
u8	ssc_depth
u8	div
