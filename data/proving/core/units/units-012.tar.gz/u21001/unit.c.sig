void
struct snd_seq_queue *	q
