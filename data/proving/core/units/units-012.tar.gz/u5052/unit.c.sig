int
struct mlx5_core_dev *	mdev
int	numa_node
u32	pdn
struct mlx5_aso *	sq
