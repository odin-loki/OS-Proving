int
char *	s
u8	len
unsigned int	base
u16 *	val
