unsigned int
unsigned int	s0
unsigned int	s1
unsigned int	s2
