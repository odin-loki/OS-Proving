void *
unsigned long	offset
