int
struct hdsp *	hdsp
