int
struct smmu_softc *	sc
