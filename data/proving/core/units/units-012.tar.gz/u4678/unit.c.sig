void
z_streamp	strm
unsigned	out
