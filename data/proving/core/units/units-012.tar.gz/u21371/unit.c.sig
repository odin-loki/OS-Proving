u8
const struct pci_dev *	dev
u8	pin
