int
struct cxl_memdev_state *	mds
u16	cmd
