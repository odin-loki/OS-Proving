unsigned int
ushort	bus_type
