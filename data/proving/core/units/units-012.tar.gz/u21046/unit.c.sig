u32
u32	power_in_watts
u32	scaling_factor
