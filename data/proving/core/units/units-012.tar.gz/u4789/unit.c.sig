bool
unsigned int	bs
