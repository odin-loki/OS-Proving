bool
enum lru_list	lru
