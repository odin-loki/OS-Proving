bool
u8	maj
u8	min
