u32
struct spl2sw_common *	comm
