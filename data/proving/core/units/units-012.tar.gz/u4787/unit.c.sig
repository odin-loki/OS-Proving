int
struct hfi1_ibport *	ibp
u16	pkey
u8	sc5
struct rvt_qp *	qp
u16	slid
struct opa_smp *	smp
