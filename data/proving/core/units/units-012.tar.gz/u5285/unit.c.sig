int
u8	nl_client
