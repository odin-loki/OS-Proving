int
struct mvs_info *	mvi
