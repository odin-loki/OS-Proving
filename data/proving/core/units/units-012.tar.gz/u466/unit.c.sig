int
struct bnx2 *	bp
u32	start
u32	size
