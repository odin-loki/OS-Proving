int
struct fuse_copy_state *	cs
struct fuse_args *	args
unsigned	nbytes
