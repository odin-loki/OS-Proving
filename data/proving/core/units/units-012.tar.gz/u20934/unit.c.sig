dma64_t
u64	addr
