bool
int	f
int	g
