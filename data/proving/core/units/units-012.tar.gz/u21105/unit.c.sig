int
gfp_t	gfp_mask
gfp_t *	gfp_cc_mask
