int
struct fw_device *	fwdev
int	offset
int	recur
