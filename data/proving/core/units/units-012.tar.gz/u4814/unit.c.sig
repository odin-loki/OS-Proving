int
const u16	mcs_value
