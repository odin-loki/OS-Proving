u64
struct intel_vgpu *	vgpu
int	bar
