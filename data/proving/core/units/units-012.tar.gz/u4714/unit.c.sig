int
__u64	x
