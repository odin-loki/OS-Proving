int
dma_cookie_t	cookie
