int_fast64_t
const char *const	codep
