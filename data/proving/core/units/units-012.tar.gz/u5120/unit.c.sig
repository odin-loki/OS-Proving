int
device_t	dev
uint32_t	aperture
