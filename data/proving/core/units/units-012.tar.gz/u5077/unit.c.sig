int
struct hostapd_data *	hapd
struct hostapd_bss_config *	conf
