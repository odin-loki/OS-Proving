int
int	sg_nents
