bool
u64	link_options
