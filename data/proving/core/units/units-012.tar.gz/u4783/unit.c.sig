int
struct fpu *	fpu
int	trap_nr
