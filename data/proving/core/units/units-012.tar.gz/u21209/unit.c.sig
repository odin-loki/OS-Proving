int
struct devlink *	devlink
unsigned int	sb_index
u32	size
u16	ingress_pools_count
u16	egress_pools_count
u16	ingress_tc_count
u16	egress_tc_count
