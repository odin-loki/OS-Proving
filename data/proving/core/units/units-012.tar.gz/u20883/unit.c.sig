int
const char *	op
int	err
const char *	driver
const char *	vec_name
const struct testvec_config *	cfg
