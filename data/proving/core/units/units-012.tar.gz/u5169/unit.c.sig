size_t
struct binder_alloc *	alloc
struct binder_buffer *	buffer
