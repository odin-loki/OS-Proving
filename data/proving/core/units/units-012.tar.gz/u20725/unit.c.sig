int
struct usb_hub *	hub
int	port1
u16 *	status
u16 *	change
