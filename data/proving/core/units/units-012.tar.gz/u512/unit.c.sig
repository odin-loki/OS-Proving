unsigned int
unsigned int	tgt_free
