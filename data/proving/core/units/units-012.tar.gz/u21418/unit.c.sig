int
struct fbnic_net *	fbn
struct fbnic_q_triad *	qt
unsigned int	rxq_idx
