int
const ktime_t	cmp1
const ktime_t	cmp2
