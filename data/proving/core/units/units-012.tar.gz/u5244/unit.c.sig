int
struct cs48l32_codec *	cs48l32_codec
int	id
