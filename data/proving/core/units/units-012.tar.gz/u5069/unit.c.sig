int
struct sg_table *	sgt
struct ceph_msg *	msg
u8 *	front_pad
u8 *	middle_pad
u8 *	data_pad
void *	epilogue
struct page **	pages
int	dpos
bool	add_tag
