int
struct ath6kl_device *	dev
bool	enable_rx
