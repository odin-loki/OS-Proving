int
struct timerlat_params *	params
