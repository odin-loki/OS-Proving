int
struct ad74413r_state *	st
u8 *	buf
