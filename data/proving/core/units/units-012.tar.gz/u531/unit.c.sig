u32
u32	source_val
u32	source_min
u32	source_max
u32	target_min
u32	target_max
