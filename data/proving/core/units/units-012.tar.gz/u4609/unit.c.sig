int
struct cnic_dev *	dev
struct kcq_info *	info
bool	use_pg_tbl
