int
u16	tpc_dec_event_type
