int
u32	clk_id
u32	data
