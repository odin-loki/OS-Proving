enum flow_control
int	rx
int	tx
