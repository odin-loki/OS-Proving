u_long
u_long	n
