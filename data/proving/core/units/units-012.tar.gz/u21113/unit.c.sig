enum fc_sof
enum fc_class	class
