int
int	s_flags
