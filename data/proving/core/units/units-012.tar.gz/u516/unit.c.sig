int
struct adapter *	adap
