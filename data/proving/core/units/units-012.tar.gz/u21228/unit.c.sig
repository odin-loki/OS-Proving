sector_t
sector_t	dev_size
