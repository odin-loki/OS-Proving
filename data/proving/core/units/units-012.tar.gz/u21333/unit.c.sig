int
struct simple_util_priv *	priv
const char *	func
int	ret
