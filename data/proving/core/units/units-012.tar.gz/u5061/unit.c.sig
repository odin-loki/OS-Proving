int
struct snd_gus_card *	gus
int	device
