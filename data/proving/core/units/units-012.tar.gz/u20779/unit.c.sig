double
time_t	time1
time_t	time0
