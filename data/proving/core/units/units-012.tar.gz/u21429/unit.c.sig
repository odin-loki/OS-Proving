int
int	qdly
int	maxqdly
struct chd *	chd_data
