uint32_t
uint64_t	state
