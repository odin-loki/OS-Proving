u32
enum hv_gpadl_type	type
u32	size
