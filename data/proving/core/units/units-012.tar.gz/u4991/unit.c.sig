int
struct brcms_phy *	pi
u32	f_kHz
u16	max_val
u8	iqmode
u8	dac_test_mode
bool	modify_bbmult
