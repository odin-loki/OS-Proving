bool
u64	phy_type_low
u64	phy_type_high
u64	media_mask_low
u64	media_mask_high
