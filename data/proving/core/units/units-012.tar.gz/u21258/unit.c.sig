int
struct sound_queue *	sq
int	num
int	size
