int
const struct nvkm_gr_func *	func
struct nvkm_device *	device
enum nvkm_subdev_type	type
int	inst
struct nvkm_gr **	pgr
