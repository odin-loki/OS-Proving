int
void *	arg
void **	store
int	count
int	domain
int	flags
