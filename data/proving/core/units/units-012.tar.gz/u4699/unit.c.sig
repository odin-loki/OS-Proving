int
__be32	status
