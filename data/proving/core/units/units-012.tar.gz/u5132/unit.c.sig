int
u32	mask
u8	start
u8	end
