int
s16	hw_val
