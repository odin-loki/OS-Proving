unsigned char
struct uart_8250_port *	up
tcflag_t	c_cflag
