bool
int	subclass
