int
struct device_node *	np
phy_interface_t *	interface
