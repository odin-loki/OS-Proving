bool
bool	func_ret
bool	expect_failure
int	memcmp_result
