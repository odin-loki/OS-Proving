int
struct platform_device *	dev
