int
struct hyp *	hyp
uint64_t	msg
uint64_t	addr
