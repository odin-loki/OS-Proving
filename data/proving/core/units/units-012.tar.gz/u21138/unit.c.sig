u8
int	n
int	nent
