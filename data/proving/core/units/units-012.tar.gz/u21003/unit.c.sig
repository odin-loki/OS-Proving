uint8_t
unsigned short	addr
unsigned int	reg
unsigned int	val
