U32
struct agtiapi_softc *	pCard
int	tgtCount
int	tid
