u32
u32	percent
