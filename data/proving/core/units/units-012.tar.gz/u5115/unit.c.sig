int
struct nvkm_ram *	ram
