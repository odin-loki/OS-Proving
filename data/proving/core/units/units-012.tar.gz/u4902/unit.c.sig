int
int	max_active
unsigned int	flags
const char *	name
