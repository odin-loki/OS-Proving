int
struct cxl_cper_prot_err_work_data *	wd
