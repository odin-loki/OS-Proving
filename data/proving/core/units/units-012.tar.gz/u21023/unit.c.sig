int
struct platform_device *	pdev
struct k3_ringacc *	ringacc
