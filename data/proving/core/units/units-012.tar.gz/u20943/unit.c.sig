int
struct tegra210_xusb_fuse_calibration *	fuse
