int
struct dentry *	dentry
unsigned long *	start
unsigned long *	end
