int
struct hwbm_pool *	bm_pool
unsigned int	buf_num
