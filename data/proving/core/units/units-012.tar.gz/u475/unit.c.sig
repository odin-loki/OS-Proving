int
struct ena_adapter *	adapter
int	first_index
int	count
