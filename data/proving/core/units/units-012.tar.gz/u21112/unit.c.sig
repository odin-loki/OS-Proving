bool
struct nfp_ccm *	ccm
