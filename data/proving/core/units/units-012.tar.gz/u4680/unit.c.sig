unsigned int
unsigned int	value
unsigned int	shift_from
unsigned int	shift_to
unsigned int	mask
