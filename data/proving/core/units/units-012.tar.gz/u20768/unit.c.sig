int
sqlite3_file *	id
int	eFileLock
int	handleNFSUnlock
