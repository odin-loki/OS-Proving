bool
struct ccu_common *	common
unsigned long	parent
unsigned long	n
unsigned long	m
