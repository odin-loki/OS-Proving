int
struct otg_switch_mtk *	otg_sx
