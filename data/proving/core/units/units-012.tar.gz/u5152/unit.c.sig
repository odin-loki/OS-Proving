unsigned int
struct coda_ctx *	ctx
u32	sizeimage
u32	width
u32	height
