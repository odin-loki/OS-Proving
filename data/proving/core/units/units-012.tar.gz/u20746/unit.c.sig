unsigned int
unsigned int	d
int	n
