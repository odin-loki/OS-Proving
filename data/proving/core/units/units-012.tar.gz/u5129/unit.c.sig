int
struct coda_ctx *	ctx
const u8 *	buf
u32	size
