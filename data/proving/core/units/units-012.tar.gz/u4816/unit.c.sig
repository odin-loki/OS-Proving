int
struct ubifs_info *	c
int	lnum
int	len
