uint32_t
const u_char *	ucs
