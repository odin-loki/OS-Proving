bool
sector_t	from
sector_t	size
sector_t	from2
sector_t	size2
