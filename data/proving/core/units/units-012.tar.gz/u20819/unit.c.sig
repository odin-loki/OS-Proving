bool
struct sbitmap_word *	map
unsigned int	depth
unsigned int	alloc_hint
bool	wrap
