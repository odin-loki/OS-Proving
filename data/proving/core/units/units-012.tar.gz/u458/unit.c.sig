unsigned
struct ath_softc *	sc
int	length
int	rix
int	short_retries
int	long_retries
int	is_ht40
