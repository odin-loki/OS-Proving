int
struct ida *	ida
unsigned int	min
unsigned int	max
gfp_t	gfp
