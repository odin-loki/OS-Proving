int
compat_sigset_t *	compat
const sigset_t *	set
unsigned int	size
