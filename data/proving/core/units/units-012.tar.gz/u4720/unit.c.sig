unsigned int
unsigned int	uflags
