uint32_t
uint32_t	floor
uint32_t	ceil
