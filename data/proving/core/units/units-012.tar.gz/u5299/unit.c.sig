int
pmap_t	pmap
pt_entry_t	pte
bool	is_pde
