int
int	ramp_delay
