bool
long	cpu
