resource_size_t
u64	val
