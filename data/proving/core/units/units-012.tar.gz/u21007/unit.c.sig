int
struct lio *	lio
int	start_stop
