void
struct intel_llc *	llc
unsigned int	gpu_freq
const struct ia_constants *	consts
unsigned int *	out_ia_freq
unsigned int *	out_ring_freq
