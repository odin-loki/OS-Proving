int
Jim_Interp *	interp
int	istry
int	argc
Jim_Obj *const *	argv
