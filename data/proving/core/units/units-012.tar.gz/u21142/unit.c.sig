u64
u64	y
u64	ism
