int
struct xsk_queue *	q
u64	addr
