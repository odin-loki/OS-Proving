int
struct nand_chip *	chip
unsigned int	max_chips
