bool
bool	early
