int
struct mtk_eint *	eint
unsigned long	eint_num
unsigned int	debounce
