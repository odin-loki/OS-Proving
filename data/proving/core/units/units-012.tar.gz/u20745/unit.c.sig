bool
struct sock *	sk
struct sk_buff *	skb
enum skb_drop_reason *	reason
