int
vm_offset_t	ks
?	?
int	npages
int	req_class
int	domain
