void
struct sshp_buf *	buf
u8 *	ptr
size_t	cap
