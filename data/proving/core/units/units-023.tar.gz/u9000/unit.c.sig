int
struct rvt_qp *	qp
struct ib_qp_attr *	attr
int	attr_mask
struct ib_udata *	udata
