int
int	hhook_type
int	hhook_id
void *	udata
void *	ctx_data
void *	hdata
struct osd *	hosd
