int
int	val
int	size
