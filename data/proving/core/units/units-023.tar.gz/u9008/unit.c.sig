int
struct vmw_cmdbuf_res_manager *	man
struct vmw_resource *	ctx
u32	user_key
struct list_head *	list
