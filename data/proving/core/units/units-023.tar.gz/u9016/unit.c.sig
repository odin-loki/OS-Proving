int
struct exynos_drm_crtc *	crtc
