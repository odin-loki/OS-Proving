u8
u64	recovery_count
