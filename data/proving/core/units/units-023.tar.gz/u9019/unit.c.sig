bool
unsigned long	user_bufs
