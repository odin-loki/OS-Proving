int
struct crypto_sig *	tfm
const char *	alg
const struct sig_testvec *	vecs
unsigned int	tcount
