size_t
size_t	max_offset
