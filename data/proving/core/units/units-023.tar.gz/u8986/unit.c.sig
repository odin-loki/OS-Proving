int
struct mthca_dev *	dev
u8	port_num
