bool
enum lp8727_die_temp	temp
