unsigned long
unsigned long	new
unsigned long	old
