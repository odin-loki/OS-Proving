int
struct mlx5e_channel *	c
struct mlx5e_params *	params
struct xsk_buff_pool *	pool
struct mlx5e_xsk_param *	xsk
struct mlx5e_rq *	rq
