unsigned long
u64	spec_ctrl
