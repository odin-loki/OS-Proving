int
struct hid_device *	hdev
const struct hid_device_id *	id
