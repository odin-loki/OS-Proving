int
struct i2c_adapter *	i2c
int	no_of_demods
u8	default_addr
u8	first_addr
