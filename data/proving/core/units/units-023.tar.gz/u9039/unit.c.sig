int
struct trace_event_call *	call
const char *	type
const char *	name
int	offset
int	size
int	is_signed
int	filter_type
