int
const char *	region_uuid
