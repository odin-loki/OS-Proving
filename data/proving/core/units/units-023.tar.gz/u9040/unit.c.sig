int
struct efx_nic *	efx
unsigned int	cmd
size_t	inlen
