int
int	type
const char *	type_string
