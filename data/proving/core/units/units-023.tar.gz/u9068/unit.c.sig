unsigned int
struct fb_var_screeninfo *	var
