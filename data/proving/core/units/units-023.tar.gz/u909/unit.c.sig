int
int	j
