int
ARCHD *	arcn
int	fd
