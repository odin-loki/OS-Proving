int
size_t const	loadedDictSize
