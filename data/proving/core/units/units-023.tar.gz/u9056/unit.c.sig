unsigned
unsigned int	rate
