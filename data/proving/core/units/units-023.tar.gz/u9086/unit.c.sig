int
struct kvm *	kvm
