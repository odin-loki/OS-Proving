bool
u32	exception_code
