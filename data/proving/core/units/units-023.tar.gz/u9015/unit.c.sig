int
struct omap_overlay_manager *	mgr
struct platform_device *	pdev
