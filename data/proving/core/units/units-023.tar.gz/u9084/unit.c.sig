int
struct qlcnic_adapter *	p_dev
u32	addr
int	duration
u32	mask
u32	status
