int
struct mt7996_dev *	dev
enum mt76_band_id	band
