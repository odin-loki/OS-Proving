bool
u32	freq
