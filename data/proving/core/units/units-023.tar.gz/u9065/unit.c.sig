int
void *	a
char	b
int	c
u64	d
