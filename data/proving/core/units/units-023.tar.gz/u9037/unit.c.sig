int
struct snd_sof_dev *	sdev
enum snd_sof_fw_blk_type	blk_type
u32	offset
void *	src
size_t	size
