struct gve_tx_pending_packet_dqo *
struct gve_tx_ring *	tx
