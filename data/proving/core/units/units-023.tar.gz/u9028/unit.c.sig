int
struct nfp_net_rx_ring *	rx_ring
int	budget
