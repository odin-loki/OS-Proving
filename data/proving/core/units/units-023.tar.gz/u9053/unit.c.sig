dma32_t
u32	addr
