unsigned int
unsigned int	fifo_size
unsigned int	queue_count
