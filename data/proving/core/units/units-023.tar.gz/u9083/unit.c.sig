int
void *	arg
if_rxd_info_t	ri
