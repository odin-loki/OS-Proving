int
struct acpi_device *	adev
int	index
bool *	wake_capable
