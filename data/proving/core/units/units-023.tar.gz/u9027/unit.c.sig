s64
const ktime_t	kt
s64	div
