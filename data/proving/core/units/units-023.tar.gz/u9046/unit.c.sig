int
struct fw_card *	card
int	address
int	clear_bits
int	set_bits
