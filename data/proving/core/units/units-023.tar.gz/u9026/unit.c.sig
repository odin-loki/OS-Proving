int
ZSTD_window_t	w
