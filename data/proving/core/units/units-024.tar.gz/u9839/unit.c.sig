int
int	trans_id
phys_addr_t	base
struct fwnode_handle *	fw_node
