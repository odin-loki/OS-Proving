int
struct ir_raw_handler *	ir_raw_handler
