unsigned
struct sbitmap *	sb
unsigned int	depth
