int
struct platform_device *	pdev
struct pm860x_chip *	chip
int *	res_x
