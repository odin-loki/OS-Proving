int
struct kvm_vcpu *	vcpu
unsigned long	num
const unsigned long *	args
unsigned long *	hret
