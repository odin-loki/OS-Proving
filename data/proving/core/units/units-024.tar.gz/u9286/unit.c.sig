void
u64 *	rate
