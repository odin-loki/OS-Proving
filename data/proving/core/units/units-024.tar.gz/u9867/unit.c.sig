unsigned int
unsigned long	hmm_pfn
unsigned long	hmm_pfn_index
unsigned long	npages
