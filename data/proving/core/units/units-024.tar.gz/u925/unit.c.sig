int
const struct vdpa_mgmt_dev *	mdev
struct sk_buff *	msg
u32	portid
u32	seq
int	flags
