bool
struct rcu_sync *	rsp
