int
unsigned long *	addr
unsigned long	mask_to_clear
