int
const char **	bp
const char *	end
unsigned char **	labelp
unsigned char **	dst
unsigned const char *	eom
