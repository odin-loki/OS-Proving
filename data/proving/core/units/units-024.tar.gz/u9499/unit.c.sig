int
struct hns3_nic_priv *	priv
