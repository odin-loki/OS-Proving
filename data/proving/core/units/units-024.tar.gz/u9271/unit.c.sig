int
struct net_device *	ndev
int	sset
