u32
u32	pend
u32	rx_mask
