int
const int	bpw
