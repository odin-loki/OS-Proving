size_t
struct tty_struct *	tty
const u8 *	cp
const u8 *	fp
size_t	count
bool	flow
