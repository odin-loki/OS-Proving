int
struct atmel_tc *	tc
int	divisor_idx
