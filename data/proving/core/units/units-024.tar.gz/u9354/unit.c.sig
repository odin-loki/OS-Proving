int
struct s2io_nic *	nic
