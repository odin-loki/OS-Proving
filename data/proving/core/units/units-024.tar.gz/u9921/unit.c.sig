int
struct acpi_table_bert *	bert_tab
