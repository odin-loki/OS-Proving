int
hcb_p	np
struct ccb_scsiio *	csio
ccb_p	cp
