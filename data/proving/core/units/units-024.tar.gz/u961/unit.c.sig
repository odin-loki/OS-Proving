u32
struct cxgbi_ppm *	ppm
u32	tag
