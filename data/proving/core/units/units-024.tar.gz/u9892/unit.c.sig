int
struct crypto_shash *	tfm
const u8 *	raw_key
unsigned int	keylen
