int
struct gnttab_unmap_grant_ref *	unmap_ops
struct gnttab_unmap_grant_ref *	kunmap_ops
struct page **	pages
unsigned int	count
