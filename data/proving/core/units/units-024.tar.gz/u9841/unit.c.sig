uint16_t
uint8_t	fbin
HAL_BOOL	is2GHz
