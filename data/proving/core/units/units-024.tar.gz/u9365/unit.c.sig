u32
u32	timing
int	bpp
int	is64
