u32
int	debug_value
int	default_msg_enable_bits
