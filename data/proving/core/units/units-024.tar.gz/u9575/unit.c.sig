int
struct xfs_trans **	tpp
struct xfs_inode *	ip
uint32_t	flags
xfs_fileoff_t	startoff
xfs_fileoff_t	endoff
