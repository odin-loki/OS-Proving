int
struct xae_softc *	sc
uint32_t	n
