int
u32	mtu
