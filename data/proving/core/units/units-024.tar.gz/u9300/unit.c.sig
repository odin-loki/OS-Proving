int
ips_ha_t *	ha
dma_addr_t	busaddr
ips_scb_t *	scb
int	indx
unsigned int	e_len
