int
const struct drm_memory_stats *	stats
