int
struct smb347_charger *	smb
