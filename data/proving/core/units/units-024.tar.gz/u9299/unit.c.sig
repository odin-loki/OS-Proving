int
struct ipu6_device *	isp
const void *	moduledata
u32	moduledata_size
