int
struct dummy *	dum
struct dummy_ep *	ep
