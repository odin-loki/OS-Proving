int
struct vc_data *	vc
