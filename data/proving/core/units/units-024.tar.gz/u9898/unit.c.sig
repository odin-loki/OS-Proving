int
struct device *	dev
struct hte_ts_desc *	desc
int	index
