unsigned long
unsigned long	tramp
