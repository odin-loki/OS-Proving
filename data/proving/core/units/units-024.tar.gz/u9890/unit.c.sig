int
kobj_t	obj
void *	data
