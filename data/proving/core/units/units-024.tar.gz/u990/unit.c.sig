bool
size_t	j
u32	count
u32	cap
