unsigned short
u64	flags
