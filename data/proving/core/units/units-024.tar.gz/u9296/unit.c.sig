acpi_status
struct acpi_rw_lock *	lock
