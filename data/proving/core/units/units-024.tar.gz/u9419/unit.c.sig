int
struct qman_portal *	p
unsigned int	limit
