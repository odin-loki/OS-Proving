int
struct amd_uncore *	uncore
unsigned int	cpu
