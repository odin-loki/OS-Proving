int
int	min_sge
int	spec
