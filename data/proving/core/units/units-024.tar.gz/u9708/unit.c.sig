unsigned int
struct ib_device *	device
u32	port_num
unsigned int	maxpages
