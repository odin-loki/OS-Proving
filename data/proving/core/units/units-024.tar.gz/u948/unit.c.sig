int
struct qed_hwfn *	p_hwfn
struct qed_qm_common_rt_init_params *	p_params
