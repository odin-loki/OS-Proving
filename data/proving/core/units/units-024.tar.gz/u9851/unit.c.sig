int
struct nlattr **	tb
struct fib6_rule *	rule6
struct netlink_ext_ack *	extack
