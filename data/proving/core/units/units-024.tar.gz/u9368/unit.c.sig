u64
u64	ptp_clock_freq
