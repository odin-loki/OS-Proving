unsigned char
int	a
int	b
u8	enable_order_hint
u8	order_hint_bits
