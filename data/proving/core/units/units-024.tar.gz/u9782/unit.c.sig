int
struct napi_struct *	napi
struct niu *	np
struct rx_ring_info *	rp
int	budget
