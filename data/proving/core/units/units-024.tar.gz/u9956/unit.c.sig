bool
unsigned long	error_code
