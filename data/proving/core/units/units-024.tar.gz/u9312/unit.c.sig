int
struct ef4_nic *	efx
int	mmd
int	test
