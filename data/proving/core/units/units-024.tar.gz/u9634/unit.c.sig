int
struct nvkm_object *	object
enum nvkm_suspend_state	suspend
