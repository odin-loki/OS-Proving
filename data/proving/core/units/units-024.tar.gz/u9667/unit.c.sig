int
void *	ctx
const uint8_t *	key
int	len
