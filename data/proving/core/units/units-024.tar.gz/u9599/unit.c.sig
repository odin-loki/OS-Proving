uint32_t
struct amdgpu_device *	adev
struct amdgpu_bo *	db_bo
uint32_t	doorbell_index
uint32_t	db_size
