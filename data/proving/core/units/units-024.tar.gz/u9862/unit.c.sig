int
const void *	ptr
