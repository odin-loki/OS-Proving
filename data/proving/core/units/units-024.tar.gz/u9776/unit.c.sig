int
struct mii_bus *	bus
int	phy_id
int	devad
int	regnum
u16	value
