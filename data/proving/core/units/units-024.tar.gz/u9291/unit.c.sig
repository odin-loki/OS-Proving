int
struct kvm *	kvm
struct kvm_dirty_ring *	ring
int	index
u32	size
