int
unsigned char	c
