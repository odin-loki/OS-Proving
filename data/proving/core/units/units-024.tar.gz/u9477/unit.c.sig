int
int	argc
char *const *	argv
int *	british
int *	stop_list
int *	optind
