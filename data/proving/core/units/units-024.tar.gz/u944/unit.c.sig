int
const struct ubifs_info *	c
const struct ubifs_dent_node *	dent
const struct fscrypt_name *	nm
