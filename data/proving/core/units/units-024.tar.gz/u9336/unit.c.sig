void
struct sdei_crosscall_args *	arg
int	err
