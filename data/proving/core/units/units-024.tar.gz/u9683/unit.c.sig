int
struct stv *	state
u32	master_clock
