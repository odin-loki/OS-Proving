int
struct bond_net *	bn
