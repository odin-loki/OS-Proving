int
struct icc_node *	node
const int	dst_id
