void
volatile atomic_flag *	__object
memory_order	__order
