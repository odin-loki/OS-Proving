u32
const struct sunxi_pinctrl_desc *	desc
u16	irq
