int
struct klp_object *	obj
