int
struct scsi_device *	sdev
struct gendisk *	disk
sector_t	capacity
int *	geom
