int
struct ib_header *	hdr
u64	rhf
