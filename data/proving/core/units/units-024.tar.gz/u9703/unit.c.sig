int
struct backing_dev_info *	bdi
unsigned int	min_ratio
