u8
struct lm93_data *	data
long	hyst
int	nr
int	mode
