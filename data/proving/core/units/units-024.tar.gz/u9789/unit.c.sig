int
struct mbuf *	m
int	offset
