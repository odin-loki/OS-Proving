bool
bool	l3mdev_accept
int	bound_dev_if
int	dif
int	sdif
