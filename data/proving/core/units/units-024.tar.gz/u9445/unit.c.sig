int
struct sctp_tcb *	stcb
struct sctp_ifa *	ifa
uint16_t	type
