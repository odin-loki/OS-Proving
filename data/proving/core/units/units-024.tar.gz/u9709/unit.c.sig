int
struct sock *	sk
int	imp
