int
struct qed_hwfn *	p_hwfn
struct qed_ptt *	p_ptt
struct qed_qm_pf_rt_init_params *	p_params
