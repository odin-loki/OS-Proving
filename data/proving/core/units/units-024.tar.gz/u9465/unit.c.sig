int
u8	stride_log2
int	spec
bool	expdb
