int
lba_t	imgsz
