int
struct omap_sr_class_data *	class_data
