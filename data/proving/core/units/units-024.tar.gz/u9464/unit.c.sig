u32
enum vmw_cursor_update_type	update_type
u32	w
u32	h
