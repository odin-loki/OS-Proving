int
ipf_ftp_softc_t *	softf
ftpinfo_t *	ftp
int	side
char *	buf
size_t	len
