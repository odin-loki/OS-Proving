int
struct qed_hwfn *	p_hwfn
int	num_rx_bufs
int	buff_size
u8	ll2_handle
