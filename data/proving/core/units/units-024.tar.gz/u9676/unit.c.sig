int
struct xfs_mount *	mp
struct xfs_trans *	tp
struct list_head *	buffer_list
int	icount
xfs_agnumber_t	agno
xfs_agblock_t	agbno
xfs_agblock_t	length
unsigned int	gen
