enum _ecore_status_t
struct ecore_hwfn OSAL_UNUSED *	p_hwfn
