int
struct comedi_device *	dev
unsigned long	context
