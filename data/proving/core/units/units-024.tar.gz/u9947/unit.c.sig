uint32
uint32	limit
uint32	mask
