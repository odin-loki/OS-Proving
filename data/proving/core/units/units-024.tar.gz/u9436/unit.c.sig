int
struct vlan_group *	vg
__be16	vlan_proto
u16	vlan_id
