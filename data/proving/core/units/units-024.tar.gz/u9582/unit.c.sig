int64_t
uint64_t	val
