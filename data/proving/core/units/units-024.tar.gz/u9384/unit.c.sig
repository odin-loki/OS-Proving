bool
unsigned char	rtm_protocol
