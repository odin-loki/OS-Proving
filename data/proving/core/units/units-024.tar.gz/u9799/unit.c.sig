int
unsigned int	p_len
