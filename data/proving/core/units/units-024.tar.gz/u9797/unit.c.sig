int
phys_addr_t	cln
int	overlap
