int
struct nicvf *	nic
int	qidx
uint64_t	reg
int	bit_pos
int	bits
int	val
