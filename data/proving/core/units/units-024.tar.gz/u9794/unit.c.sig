int
const char *	buffer
size_t	count
