int
struct btrfs_trans_handle *	trans
struct btrfs_inode *	inode
