int
const struct ubifs_info *	c
void *	buf
int	type
int	len
int	lnum
int	offs
