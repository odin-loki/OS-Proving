s16
u16	linear
