void
struct xhci_hcd *	xhci
struct xhci_virt_device *	virt_dev
bool	drop_control_ep
