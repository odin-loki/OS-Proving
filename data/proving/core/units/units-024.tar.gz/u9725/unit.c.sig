__u32
__u32	mask
