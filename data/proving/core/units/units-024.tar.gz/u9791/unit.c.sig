int
struct cam_periph *	periph
