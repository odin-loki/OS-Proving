bool
U32	ioc_status
U32	ioc_config
