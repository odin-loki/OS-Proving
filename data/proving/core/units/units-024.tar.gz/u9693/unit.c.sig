int
u16	chspec
