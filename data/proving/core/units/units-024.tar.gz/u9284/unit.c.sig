u32
bool	ipv4
bool	tcp
bool	gre
