int
u8	support
enum mask_type	typ
