int
struct rhashtable *	ht
struct test_obj *	obj
const struct rhashtable_params	params
