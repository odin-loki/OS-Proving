int
teken_char_t	ucs
