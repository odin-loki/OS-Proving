int
qla_host_t *	ha
