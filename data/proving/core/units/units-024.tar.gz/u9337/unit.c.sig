u32
u8	nfp_pcie
enum nfp_flower_cmsg_port_vnic_type	type
u8	vnic
u8	q
