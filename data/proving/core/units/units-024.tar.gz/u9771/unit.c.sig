uint32_t
uint32_t	idx
uint32_t	inc
uint32_t	sz
