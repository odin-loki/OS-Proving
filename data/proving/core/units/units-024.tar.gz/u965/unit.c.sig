int
struct mt76_dev *	dev
struct mt76_queue *	q
bool	allow_direct
