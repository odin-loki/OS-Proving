u32
u32	mode_clock
