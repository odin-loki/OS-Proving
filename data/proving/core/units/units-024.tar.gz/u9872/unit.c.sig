int
struct usbtest_dev *	tdev
u8 *	buf
