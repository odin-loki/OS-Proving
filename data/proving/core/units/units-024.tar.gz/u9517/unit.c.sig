socklen_t
int	type
int	segments
