int
int	access
bool	sqd_notify
bool	sq_is_cmb
bool	rq_is_cmb
bool	sq_spec
bool	rq_spec
bool	privileged
bool	remote_privileged
