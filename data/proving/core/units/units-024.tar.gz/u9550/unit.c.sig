enum nfp_repr_type
struct nfp_app *	app
u32	port_id
u8 *	port
