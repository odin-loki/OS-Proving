u16
u16	max
u16	min
