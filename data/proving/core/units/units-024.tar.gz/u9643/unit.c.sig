int
struct kvm_vcpu *	vcpu1
struct kvm_vcpu *	vcpu2
