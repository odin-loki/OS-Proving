int
enum numa_faults_stats	s
int	nid
int	priv
