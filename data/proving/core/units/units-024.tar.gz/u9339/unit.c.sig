int
struct usb_device *	hdev
struct usb_hub_status *	data
