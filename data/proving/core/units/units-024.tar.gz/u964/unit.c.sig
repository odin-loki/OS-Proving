uint64_t
uint64_t	src
unsigned long	lam
