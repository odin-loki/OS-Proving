unsigned long
struct muram_info *	muram
unsigned long	vaddr
