int
struct raid5_percpu *	percpu
int	num
int	cnt
