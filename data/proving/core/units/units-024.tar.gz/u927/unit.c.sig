int
struct qedi_cmd *	cmd
u64	addr
int	sg_len
int	bd_index
