int
struct vge_softc *	sc
int	count
