unsigned int
struct memory_bitmap *	bm
