int
int	idx
int	bus
bool	level
