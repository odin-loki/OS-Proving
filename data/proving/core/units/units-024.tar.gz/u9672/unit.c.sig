int
struct pidfh *	pfh
int	freeit
