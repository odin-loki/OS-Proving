unsigned long
struct pfn_batch *	batch
void *	data
unsigned long	offset
unsigned long	length
unsigned int	flags
