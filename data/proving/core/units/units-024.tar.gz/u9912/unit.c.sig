int
const char *	buf
unsigned long	len
