int
struct airoha_ppe *	ppe
u32	ib1
