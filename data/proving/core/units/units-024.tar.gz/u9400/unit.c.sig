umode_t
u32	wire
bool	is_dir
