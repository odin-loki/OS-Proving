int
struct client *	client
union ioctl_arg *	arg
