bool
long	count
long	tlimit
bool	jlimit_check
unsigned long	jlimit
