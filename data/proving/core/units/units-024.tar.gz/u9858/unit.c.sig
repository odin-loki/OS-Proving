int
struct ftgmac100 *	priv
bool	ignore_alloc_err
