uint32_t
device_t	dev
uint32_t	unit
uint32_t	hz
