int
struct erdma_ucontext *	ctx
struct erdma_cq *	cq
struct erdma_ureq_create_cq *	ureq
