bool
u32	burst
u32	threshold
enum dma_slave_buswidth	width
