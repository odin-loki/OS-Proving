int
unsigned char *	p
unsigned char *	lim
