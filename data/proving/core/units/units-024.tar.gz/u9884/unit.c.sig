int
struct gfs2_sbd *	sdp
struct gfs2_trans *	tr
int *	max_revokes
