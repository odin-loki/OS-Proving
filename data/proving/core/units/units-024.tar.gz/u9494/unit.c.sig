u8
u32	reg
int	dimm_order
