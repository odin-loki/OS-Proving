long
u16	reg
