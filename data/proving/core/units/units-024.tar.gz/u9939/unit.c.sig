bool
u8	data
s8 *	high
s8 *	low
