int
struct otx2_cptlf_info *	lf
