bool
u64	offset
size_t	length
