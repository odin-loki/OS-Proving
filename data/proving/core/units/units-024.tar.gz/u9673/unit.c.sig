int
struct pci_dev *	pdev
unsigned int	base
