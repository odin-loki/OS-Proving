int
FILE *	input
int	output_fd
