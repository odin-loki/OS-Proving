int
u16	status
