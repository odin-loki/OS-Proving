int
struct ahash_request *	req
int	blen
char *	out
int	secs
