int
struct pcmcia_device *	dev
char *	filename
