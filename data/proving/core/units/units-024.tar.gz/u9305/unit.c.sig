u32
u32	ta_handle
