int
const char *	arg
int	hi
