int
struct hns_roce_dev *	hr_dev
struct hns_roce_qp *	hr_qp
