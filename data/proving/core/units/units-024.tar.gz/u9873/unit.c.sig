void
u64	bytes
struct ip_set_counter *	counter
