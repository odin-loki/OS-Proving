unsigned int
unsigned char	format
unsigned int	size
