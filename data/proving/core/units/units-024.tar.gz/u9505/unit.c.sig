boolean_t
const uint8_t	class_code
