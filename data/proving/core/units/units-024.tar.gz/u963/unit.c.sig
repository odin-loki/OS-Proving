int
struct mtk_dp *	mtk_dp
bool	is_read
