int
struct psmouse *	psmouse
