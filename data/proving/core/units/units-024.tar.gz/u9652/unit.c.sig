int
struct gfar_priv_rx_q *	rx_queue
int	rx_work_limit
