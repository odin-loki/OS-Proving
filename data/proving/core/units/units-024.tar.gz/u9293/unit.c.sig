bool
uint64_t	status
