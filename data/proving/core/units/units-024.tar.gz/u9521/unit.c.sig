int
struct audio_client *	ac
uint32_t	stream_id
uint32_t	len
uint32_t	msw_ts
uint32_t	lsw_ts
uint32_t	wflags
