int
struct bhnd_erom_io *	eio
bhnd_addr_t	addr
bhnd_size_t	size
