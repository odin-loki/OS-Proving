int
struct nitrox_device *	ndev
