int
struct otx2_nic *	pfvf
u16	count
