u16
u32	phys_size
u16	width
u8	bytespp
