int
struct rtwn_softc *	sc
const struct ieee80211_node *	ni
int	tid
