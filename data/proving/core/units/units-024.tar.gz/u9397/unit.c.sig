int
struct csio_hw *	hw
enum csio_evt	type
void *	evt_msg
uint16_t	len
bool	msg_sg
