int
int	pool
const __u8 *	key
int	key_size
