u32
u8	dwrr_mtu
