u16
u8	div
int	rpm
