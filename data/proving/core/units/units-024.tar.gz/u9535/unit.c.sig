int
unsigned int	user
unsigned int	file
unsigned int	device
