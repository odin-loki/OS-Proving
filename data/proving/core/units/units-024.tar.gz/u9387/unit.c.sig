int
enum radeon_family	family
