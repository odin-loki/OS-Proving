int
struct usb_device *	udev
struct usb_device_descriptor *	buf
int	size
bool	first_time
