int
struct simple_util_priv *	priv
struct device_node *	node
struct snd_soc_dai_link_component *	dlc
int *	is_single_link
