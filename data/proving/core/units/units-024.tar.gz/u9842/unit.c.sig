int
struct device *	dev
int	irq
const char *	name
struct regmap *	regmap
