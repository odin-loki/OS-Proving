u8
enum mdp_stream_type	type
