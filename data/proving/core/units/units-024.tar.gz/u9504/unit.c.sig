int
struct net *	net
unsigned int	bit
