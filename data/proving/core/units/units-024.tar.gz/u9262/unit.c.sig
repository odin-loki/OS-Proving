long
long *	value
long	n
