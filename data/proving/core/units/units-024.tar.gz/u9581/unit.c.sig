int
struct nfs4_slot_table *	tbl
unsigned int	max_reqs
const char *	queue
