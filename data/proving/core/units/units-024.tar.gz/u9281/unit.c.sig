int
struct drm_device *	ddev
struct lsdc_display_pipe *	dispipe
unsigned int	index
