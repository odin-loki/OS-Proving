quad_t
u_long	u
u_long	v
