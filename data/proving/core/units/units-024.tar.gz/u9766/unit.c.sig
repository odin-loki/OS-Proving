int
struct xfs_scrub *	sc
const struct xfs_rmap_irec *	rec
