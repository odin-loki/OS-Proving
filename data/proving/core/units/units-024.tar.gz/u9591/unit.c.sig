int
struct nand_device *	nand
struct nand_page_io_req *	req
