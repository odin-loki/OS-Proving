int
struct xfrm_state *	x
