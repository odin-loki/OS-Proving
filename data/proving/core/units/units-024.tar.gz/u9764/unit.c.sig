int
struct kmem_cache *	s
struct slab *	slab
u8 *	object
const char *	what
u8 *	start
unsigned int	value
unsigned int	bytes
bool	slab_obj_print
