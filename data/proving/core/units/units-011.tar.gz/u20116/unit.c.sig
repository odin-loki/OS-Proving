int
struct aesni_session *	ses
struct cryptop *	crp
