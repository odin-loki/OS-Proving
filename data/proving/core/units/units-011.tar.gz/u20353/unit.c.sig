unsigned
ReInput *	p
