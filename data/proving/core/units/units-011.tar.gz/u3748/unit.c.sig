int
struct dev_cgroup *	devcgroup
int	filetype
char *	buffer
