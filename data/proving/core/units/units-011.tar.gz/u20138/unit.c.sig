u32
u16	red
u16	green
u16	blue
