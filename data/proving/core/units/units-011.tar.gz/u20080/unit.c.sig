int
struct net *	net
struct socket *	sock
int	kern
