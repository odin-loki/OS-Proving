int
struct vcpu *	vcpu
uint64_t	paddr
struct mem_range **	mr_paramp
