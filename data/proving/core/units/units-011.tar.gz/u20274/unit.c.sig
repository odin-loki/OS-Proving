int
struct usb_gadget *	_gadget
