int
struct nvkm_ltc *	ltc
