int
struct dsa_switch *	ds
int	port
