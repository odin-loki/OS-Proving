int
struct sdw_slave *	slave
struct sdw_slave_runtime *	s_rt
const struct sdw_port_config *	port_config
bool	is_bpt_stream
