u16
u16	wm
u16	fifo_size
