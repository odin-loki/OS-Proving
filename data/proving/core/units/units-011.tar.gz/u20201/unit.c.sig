uint8_t
struct pcg_state_8*	rng
uint8_t	bound
