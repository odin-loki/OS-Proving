phys_addr_t
unsigned long	d
dma_addr_t	va
dma_addr_t	mask
