ssize_t
struct kiocb *	iocb
struct iov_iter *	iter
ssize_t	direct_written
ssize_t	buffered_written
