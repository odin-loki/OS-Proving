int
int	queue_type
