bool_t
XDR *	xdrs
const char *	bp
u_int	len
