long
key_serial_t	id
const struct iovec *	_payload_iov
unsigned	ioc
key_serial_t	ringid
