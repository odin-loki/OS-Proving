int
struct iop_softc *	sc
