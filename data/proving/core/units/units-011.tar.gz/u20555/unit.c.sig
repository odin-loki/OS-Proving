int
struct bq24190_dev_info *	bdi
