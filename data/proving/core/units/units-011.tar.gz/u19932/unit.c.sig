int
struct gus_pcm_private *	pcmp
int	voice
unsigned int	pos
unsigned int	len
