int
struct nvkm_clk *	clk
int	idx
