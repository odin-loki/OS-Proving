u32
u32	win
