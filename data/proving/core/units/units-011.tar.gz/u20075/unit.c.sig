int
struct adapter *	adap
int	mbox
const void *	cmd
int	size
void *	rpl
bool	sleep_ok
int	timeout
