__wsum
__be32	saddr
__be32	daddr
__u32	len
__u8	proto
__wsum	sum
