int
struct power_supply *	psy
