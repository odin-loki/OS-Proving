size_t
loff_t	end_pos
unsigned	block_bits
unsigned	blocks_truncated
