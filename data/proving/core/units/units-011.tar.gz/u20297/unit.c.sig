u32
struct ipa *	ipa
const struct reg *	reg
u32	microseconds
