int
int	rc
