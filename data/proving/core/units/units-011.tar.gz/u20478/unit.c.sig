int
int	disks
int *	tests
