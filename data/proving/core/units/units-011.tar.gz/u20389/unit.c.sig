int
struct sis7019 *	sis
