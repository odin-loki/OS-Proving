u8
u16	byte_count
