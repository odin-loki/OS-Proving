ssize_t
struct file *	filp
const char *	ubuf
size_t	usize
loff_t *	off
