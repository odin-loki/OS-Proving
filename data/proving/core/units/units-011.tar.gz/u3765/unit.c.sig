int
struct fib_rule *	rule
struct sk_buff *	skb
struct fib_rule_hdr *	frh
struct nlattr **	tb
struct netlink_ext_ack *	extack
