enum ice_ddp_state
struct ice_ddp_send_ctx *	ctx
struct ice_pkg_hdr *	pkg_hdr
u32	idx
u32	start
u32	count
