int
struct hci_dev *	hdev
u32	dump_size
