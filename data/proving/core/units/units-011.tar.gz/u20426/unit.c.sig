bool
uint32_t	mem_type
