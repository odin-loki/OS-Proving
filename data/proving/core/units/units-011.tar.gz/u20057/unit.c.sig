int
struct pstore_record *	record
