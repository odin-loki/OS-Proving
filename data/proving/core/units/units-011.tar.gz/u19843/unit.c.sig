bool
ptrdiff_t	val
