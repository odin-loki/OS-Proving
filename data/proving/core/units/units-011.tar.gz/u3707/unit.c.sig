u64
u64	cost
u32	hw_inuse
