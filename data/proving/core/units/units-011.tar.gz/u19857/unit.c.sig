int
struct writer *	wr
uint8_t	byte
