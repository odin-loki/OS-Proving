int
struct aac_softc *	sc
