int
struct bm_rcr_entry *	e
