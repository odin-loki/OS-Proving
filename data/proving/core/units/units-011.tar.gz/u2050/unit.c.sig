u8
struct radeon_device *	rdev
u32	memory_clock
bool	strobe_mode
