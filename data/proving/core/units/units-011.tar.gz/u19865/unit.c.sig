time64_t
s64	time_in_100ns
