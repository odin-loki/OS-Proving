vm_offset_t
vm_offset_t	va
