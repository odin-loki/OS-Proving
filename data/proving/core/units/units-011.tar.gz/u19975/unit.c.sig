int
struct usb_serial *	serial
struct usb_serial_endpoints *	epds
