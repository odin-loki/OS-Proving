int
struct imx_sc_ipc *	ipc
u16	resource
u8 *	pt
