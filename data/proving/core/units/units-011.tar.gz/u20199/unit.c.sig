int
struct ada4250_state *	st
