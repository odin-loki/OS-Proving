int
int	clockid
int	abs
