bool
u16	width
u16	height
