int
struct ieee80211_hw *	hw
unsigned int	prio
unsigned int	entries
