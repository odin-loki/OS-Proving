int
u32	prec_index
