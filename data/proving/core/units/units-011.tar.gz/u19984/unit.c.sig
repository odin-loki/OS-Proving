int
struct drm_mm * const	mm
struct drm_mm_node * const	node
u64	size
u64	alignment
unsigned long	color
u64	range_start
u64	range_end
enum drm_mm_insert_mode	mode
