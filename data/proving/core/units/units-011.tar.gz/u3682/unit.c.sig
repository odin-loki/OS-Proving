unsigned long
int	load
