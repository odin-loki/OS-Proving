int
int	order
void *	vaddr
