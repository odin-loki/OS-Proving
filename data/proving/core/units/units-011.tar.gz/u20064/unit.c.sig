unsigned int
u64	status
