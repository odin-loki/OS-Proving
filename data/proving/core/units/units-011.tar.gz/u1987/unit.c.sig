u32
enum br_cfm_ccm_interval	interval
