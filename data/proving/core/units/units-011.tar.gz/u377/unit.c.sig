bool
struct xt_percpu_counter_alloc_state *	state
struct xt_counters *	counter
