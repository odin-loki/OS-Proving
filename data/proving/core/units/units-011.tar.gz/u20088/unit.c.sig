int
struct netxen_adapter *	adapter
struct net_device *	netdev
