enum hist_field_fn
struct hist_field *	divisor
