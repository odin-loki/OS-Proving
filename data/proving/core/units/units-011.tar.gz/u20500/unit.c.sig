int
unsigned int	count
