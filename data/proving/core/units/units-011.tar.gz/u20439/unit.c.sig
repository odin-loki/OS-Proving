u32
struct lpc32xx_udc *	udc
u32	hwep
u32 *	data
u32	bytes
