void
unsigned long	ptr
