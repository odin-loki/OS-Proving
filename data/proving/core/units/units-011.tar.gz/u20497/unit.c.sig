int
struct tn40_priv *	priv
int	budget
