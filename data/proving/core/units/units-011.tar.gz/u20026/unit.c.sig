int
__le16	fc
