int
struct module *	mod
const Elf64_Shdr *	sechdrs
