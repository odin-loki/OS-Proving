int
struct adapter *	sc
int	mtype
uint32_t	off
uint32_t	len
uint32_t *	addr
