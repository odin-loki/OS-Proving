bool
int	api
