unsigned int
int	family
bool	echo
bool	port
