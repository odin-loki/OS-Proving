int
struct wkup_m3_ipc *	m3_ipc
