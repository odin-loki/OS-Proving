u8
int	idx
