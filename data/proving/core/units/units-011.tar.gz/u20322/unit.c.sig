int
int *	sock
uint32_t *	seq_nr
int	proto
