void
u_int	gdiv
