int
u32	val_min
u32 *	val_add
struct netlink_ext_ack *	extack
