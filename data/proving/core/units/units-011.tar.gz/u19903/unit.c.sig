int
struct qmp_usb *	qmp
