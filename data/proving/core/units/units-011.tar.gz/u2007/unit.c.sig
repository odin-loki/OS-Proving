int
unsigned int	freq
