uint32_t
u32	sp_thread_id
uint32_t	stream_id
