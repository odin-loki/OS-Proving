s16
long	val
int	resolution
