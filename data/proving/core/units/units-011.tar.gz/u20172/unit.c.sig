void
long *	value
long	n
