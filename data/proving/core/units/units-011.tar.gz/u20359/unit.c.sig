int
u32	fpga_id
