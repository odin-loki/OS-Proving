int
u32	width
u32	height
