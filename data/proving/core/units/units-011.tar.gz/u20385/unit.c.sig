phys_addr_t
phys_addr_t	start
phys_addr_t	end
phys_addr_t	size
phys_addr_t	align
int	nid
enum memblock_flags	flags
