int
struct usb_hub *	hub
int	port1
