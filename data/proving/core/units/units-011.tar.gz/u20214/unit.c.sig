u64
u64	nom
u32	den
