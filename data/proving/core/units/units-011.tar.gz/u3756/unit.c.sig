int
unsigned int	val
unsigned int	width
