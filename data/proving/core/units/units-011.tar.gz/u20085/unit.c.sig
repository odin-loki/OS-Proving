bool
u64	s1
u64	e1
u64	s2
u64	e2
