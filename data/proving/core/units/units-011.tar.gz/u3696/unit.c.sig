int
const struct rcar_gen3_cpg_pll_config *	config
unsigned int	clk_extalr
u32	mode
