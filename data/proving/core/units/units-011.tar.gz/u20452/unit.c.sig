u32
card_t *	card
u8 *	rambase
u32	ramsize
