u32
u32	usecs
u64	clk_freq
