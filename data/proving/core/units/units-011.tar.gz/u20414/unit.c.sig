int
struct ntb_dev *	ntb
int	pidx
int	idx
dma_addr_t	addr
resource_size_t	size
