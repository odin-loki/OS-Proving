int
struct ath11k_vif *	arvif
u32 *	flags
u32 *	tx_vdev_id
