unsigned long
unsigned long	idx
struct page **	inpages
unsigned long	npages
