int
struct rvu *	rvu
struct nix_hw *	nix_hw
