int
struct bpf_verifier_log *	log
const struct bpf_reg_state *	reg
int	off
int	size
