int
keyInstance *	key
BYTE	direction
int	keyLen
const char *	keyMaterial
