s8
struct rt2x00_dev *	rt2x00dev
unsigned int	channel
s8	txpower
