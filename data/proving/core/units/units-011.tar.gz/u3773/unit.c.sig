int
struct elf64_hdr *	hdr
struct file *	file
