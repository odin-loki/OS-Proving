bool
u16	advertising
u16	supported
