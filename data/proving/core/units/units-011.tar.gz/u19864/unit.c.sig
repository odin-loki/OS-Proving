u32
struct intel_connector *	connector
u32	user_level
u32	user_max
