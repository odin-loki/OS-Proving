int
struct dvb_frontend *	fe
int	f1
int	f2
int	spectrum_from
int	spectrum_to
