int
struct mthca_dev *	dev
struct mthca_cq_buf *	buf
int	nent
