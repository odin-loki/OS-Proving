int
u32	p_flags
struct arch_elf_state *	arch_state
bool	has_interp
bool	is_interp
