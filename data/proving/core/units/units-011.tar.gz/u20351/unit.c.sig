int
struct dpaa2_caam_priv_per_cpu *	ppriv
