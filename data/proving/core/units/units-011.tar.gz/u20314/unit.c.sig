long
unsigned long	addr
size_t	size
bool	is_write
