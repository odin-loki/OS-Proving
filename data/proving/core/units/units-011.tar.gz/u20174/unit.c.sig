int
struct sound_unit *	s
struct sound_unit **	list
const struct file_operations *	fops
int	index
int	low
int	top
