int
const u32	node
const u32	capabilities
const u32	qos
const enum zynqmp_pm_request_ack	ack
