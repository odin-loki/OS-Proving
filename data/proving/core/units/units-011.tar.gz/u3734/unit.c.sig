u64
u64	abs_cost
u32	hw_inuse
