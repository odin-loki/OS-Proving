bool
int	err
