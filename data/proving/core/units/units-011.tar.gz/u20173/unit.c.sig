bool
unsigned int	offset
