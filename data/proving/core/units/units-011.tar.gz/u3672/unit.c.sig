void
const char *	str
