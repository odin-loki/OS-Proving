int
long	val
int	ix
int	reg
