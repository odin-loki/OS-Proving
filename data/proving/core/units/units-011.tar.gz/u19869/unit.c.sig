u8
u8	curr
