bool
u16	status
