unsigned int
unsigned int	pio_mask
unsigned int	mwdma_mask
unsigned int	udma_mask
