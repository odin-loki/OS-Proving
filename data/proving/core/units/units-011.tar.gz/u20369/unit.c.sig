int
struct radeon_device *	rdev
u32	engine_clock
SMU7_Discrete_GraphicsLevel *	sclk
