int
char *	glob
struct event_trigger_data *	data
struct trace_event_file *	file
