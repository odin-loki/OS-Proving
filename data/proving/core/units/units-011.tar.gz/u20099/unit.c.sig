bool
int	rc
