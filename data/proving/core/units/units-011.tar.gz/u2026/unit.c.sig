int
struct ttm_test_devices *	priv
struct ttm_device *	ttm
bool	use_dma_alloc
bool	use_dma32
