int
enum ice_fdir_tunnel_type	ttype
