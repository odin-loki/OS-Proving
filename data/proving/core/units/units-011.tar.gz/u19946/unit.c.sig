int
struct snd_soc_component *	component
struct aif *	aif
bool	playback
