uint8_t
struct ftgpio_softc *	sc
uint8_t	reg
unsigned	group
