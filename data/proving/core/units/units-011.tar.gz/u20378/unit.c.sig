int
struct thread *	td
vm_offset_t	uaddr
size_t	len
struct zbuf **	zbp
