int
struct dmirror_device *	mdevice
int	id
