int
struct wil6210_vif *	vif
int	ring_id
int	size
int	cid
int	tid
