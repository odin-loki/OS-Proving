int
struct nvkm_falcon_qmgr *	qmgr
const char *	name
struct nvkm_falcon_cmdq **	pcmdq
