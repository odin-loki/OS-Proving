u64
u64	base
u32	num
u32	den
