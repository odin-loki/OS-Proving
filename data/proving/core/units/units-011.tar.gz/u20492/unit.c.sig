int
unsigned long	pfn
int	flags
