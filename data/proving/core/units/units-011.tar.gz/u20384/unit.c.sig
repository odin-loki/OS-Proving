int
struct nfp_fl_lag *	lag
