int
atomic_t *	addr
