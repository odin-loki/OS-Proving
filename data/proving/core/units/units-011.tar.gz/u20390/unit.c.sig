u32
struct dm_odm_t *	pDM_Odm
u32	macid
u32	ra_mask
u8	rssi_level
