bool
struct dm_io *	io
struct io_comp_batch *	iob
unsigned int	flags
