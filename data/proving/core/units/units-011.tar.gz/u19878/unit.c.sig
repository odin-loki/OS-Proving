int
struct sdw_slave *	slave
struct sdw_slave_runtime *	s_rt
unsigned int	num_config
