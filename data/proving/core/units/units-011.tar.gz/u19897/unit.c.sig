u64
struct i915_perf *	perf
int	exponent
