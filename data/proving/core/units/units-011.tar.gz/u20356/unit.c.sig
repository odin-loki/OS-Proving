int
struct ocelot *	ocelot
u32	pol_ix
