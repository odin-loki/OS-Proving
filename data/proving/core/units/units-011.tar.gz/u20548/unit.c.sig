int
struct file *	filp
const struct seq_operations *	ops
int	psize
