unsigned char
short int	linear
