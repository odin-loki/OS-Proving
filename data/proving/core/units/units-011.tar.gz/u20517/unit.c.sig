int
int	this_cpu
int	prev_cpu
int	sync
