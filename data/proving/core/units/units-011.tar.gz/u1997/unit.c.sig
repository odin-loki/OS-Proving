int
priv_p	priv
int	fib
