u32
u32	P_Kin
u32	P_Kout
u32	insertExtSynchro
u32	syncSize
