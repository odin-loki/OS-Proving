_Bool
atomic_t *	v
