int
struct dm_block_manager *	bm
struct dm_buffer *	buf
struct buffer_aux *	aux
const struct dm_block_validator *	v
