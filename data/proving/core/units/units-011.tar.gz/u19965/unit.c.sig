bool
unsigned int	obj_type
