int
struct atmel_qspi *	aq
u32	irq_mask
