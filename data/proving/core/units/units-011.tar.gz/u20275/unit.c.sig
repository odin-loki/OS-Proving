bool
struct request *	req
