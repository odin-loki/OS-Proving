int
const struct device_node *	np
const char *	list_name
int	index
struct of_phandle_args *	out_args
