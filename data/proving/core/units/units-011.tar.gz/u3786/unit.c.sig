u64
struct vcpu_svm *	svm
u64	mask
unsigned int	pos
