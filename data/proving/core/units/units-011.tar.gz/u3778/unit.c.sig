u32
u16	reg_flags
