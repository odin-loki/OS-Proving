bool
unsigned long	ip
