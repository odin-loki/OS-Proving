int
struct omap_vout_device *	vout
unsigned int *	count
unsigned int	startindex
