int
struct irq_data *	d
const struct cpumask *	affinity
bool	force
