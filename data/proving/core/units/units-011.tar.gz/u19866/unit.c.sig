int
struct i915_power_domains *	power_domains
const struct i915_power_well_desc_list *	power_well_descs
int	power_well_descs_sz
