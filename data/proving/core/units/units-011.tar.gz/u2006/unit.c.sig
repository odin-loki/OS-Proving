enum typec_orientation
unsigned int	status
