unsigned long
unsigned long	nr
