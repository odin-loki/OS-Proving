int
resource_size_t	addr
