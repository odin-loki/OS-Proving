int
u32	maxburst
