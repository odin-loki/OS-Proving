u8
u8	valid_antenna
u8	ant_type
