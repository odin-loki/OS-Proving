int
struct snd_emu10k1 *	emu
int	pcm_device
int	multi_device
