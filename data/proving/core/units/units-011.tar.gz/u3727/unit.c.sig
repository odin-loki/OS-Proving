int
u64	parent
u64	owner
