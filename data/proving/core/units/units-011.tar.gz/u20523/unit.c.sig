int
struct vme_bridge *	bridge
u32	aspace
unsigned long long	vme_base
unsigned long long	size
