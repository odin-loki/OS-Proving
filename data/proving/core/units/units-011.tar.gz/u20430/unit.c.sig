int
struct ath_hw *	ah
