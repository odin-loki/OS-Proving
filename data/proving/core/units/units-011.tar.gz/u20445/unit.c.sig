int
void *	context
unsigned int	reg
unsigned int	val
