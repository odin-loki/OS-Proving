u16
u16	actual_count
