long
key_serial_t	id
unsigned	timeout
key_serial_t	ringid
