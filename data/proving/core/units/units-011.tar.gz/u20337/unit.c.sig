int
struct lpfc_queue *	q
union lpfc_wqe128 *	wqe
