int
struct thc_device *	dev
struct thc_dma_configuration *	read_config
u8 *	read_ptr
u8 *	write_ptr
