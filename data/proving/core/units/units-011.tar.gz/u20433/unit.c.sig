int
struct sja1105_private *	priv
