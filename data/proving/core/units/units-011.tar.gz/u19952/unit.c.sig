int
int	n
