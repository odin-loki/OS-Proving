int
int	ns
int	dnr
