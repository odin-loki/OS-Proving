int
u64	vmx_misc
