unsigned char
int	pcm_val
