int
struct readahead_control *	ractl
