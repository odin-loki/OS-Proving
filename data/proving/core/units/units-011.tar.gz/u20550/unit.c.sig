int
adapter_t *	adapter
const u8 *	tp_sram
unsigned int	size
