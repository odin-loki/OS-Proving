int
struct task_struct *	tsk
struct mm_struct *	mm
