bool
void *	msg
