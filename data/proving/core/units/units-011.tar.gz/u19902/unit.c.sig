bool
u64	reg
