unsigned int
sector_t	capacity
unsigned	divisor
