u32
u32	d
u32	b1
u32	b0
