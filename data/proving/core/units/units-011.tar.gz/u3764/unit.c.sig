int
struct mlx5_pkt_reformat *	pkt_reformat
u32 *	reformat_id
