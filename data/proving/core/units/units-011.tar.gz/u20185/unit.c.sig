int
const struct sh_css_binary_args *	args
