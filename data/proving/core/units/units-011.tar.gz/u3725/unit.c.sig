int
enum bpf_map_type	map_type
__u32	inner_map_fd
