int
struct radeon_device *	rdev
int	r
