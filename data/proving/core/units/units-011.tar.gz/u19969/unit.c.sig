int
struct mii_bus *	mii
int	addr
int	reg
