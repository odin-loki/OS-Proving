int
struct ptp_clock_info *	ptp_info
s32	phase_ns
