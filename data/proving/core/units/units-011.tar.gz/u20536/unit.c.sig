int
const u_char *	lp
