int
struct rockchip_sfc *	sfc
u8 *	buf
int	len
