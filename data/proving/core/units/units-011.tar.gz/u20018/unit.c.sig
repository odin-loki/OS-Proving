bool
int	status
