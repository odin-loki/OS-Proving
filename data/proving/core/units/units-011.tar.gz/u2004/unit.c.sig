u32
u16	entry
u64	base
u8	type
