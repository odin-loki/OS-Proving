vm_pindex_t
vm_offset_t	va
