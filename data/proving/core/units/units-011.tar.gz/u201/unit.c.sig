int
int	nlocks
int	nthreads
unsigned int	flags
