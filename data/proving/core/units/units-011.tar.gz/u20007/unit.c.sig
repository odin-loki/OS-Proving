u16
u16	subtree_control
u16	this_ss_mask
