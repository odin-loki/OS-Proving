int
struct kretprobe **	rps
int	num
