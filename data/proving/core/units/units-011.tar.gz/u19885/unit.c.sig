long
u16	val
