uint8_t
struct x86emu *	emu
uint8_t	d
