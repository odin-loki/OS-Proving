int
struct srcu_struct *	ssp
bool	is_static
