int
struct drm_connector *	connector
struct dcb_output *	entry
