u32
struct sock *	sk
