void
u64	data
u32 *	lo
u32 *	hi
