int
u32	addr
const void *	txbuf
size_t	len
