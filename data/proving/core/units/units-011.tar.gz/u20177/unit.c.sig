int
struct lm63_data *	data
long	val
