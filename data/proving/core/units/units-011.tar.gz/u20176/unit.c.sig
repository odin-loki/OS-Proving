u64
u64	a
u32	b
