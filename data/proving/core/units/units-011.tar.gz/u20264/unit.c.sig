bool
struct hci_dev *	hdev
u16	opcode
u8	event
struct sk_buff *	skb
