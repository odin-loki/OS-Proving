int
struct fq *	fq
int	flows_cnt
