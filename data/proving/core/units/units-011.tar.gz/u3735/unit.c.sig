unsigned int
u32	device_baudrate
