int
int	level
int	qual
int	disks
int	force
