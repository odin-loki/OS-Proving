int
struct ov5640_dev *	sensor
