u_long
u_long	a
u_long	b
