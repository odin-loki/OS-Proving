u16
u8	data
u16	crc
