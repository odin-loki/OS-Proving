int
size_t	size
int	res
