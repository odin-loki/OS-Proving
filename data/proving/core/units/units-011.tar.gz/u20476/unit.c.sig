bool
__le16	seq_ctrl
