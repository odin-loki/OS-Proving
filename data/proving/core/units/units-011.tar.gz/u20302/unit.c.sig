bool
unsigned long	scause
