unsigned int
unsigned int	div_factor
