__u32
__u32	a
__u32	b
__u32	c
__u32	d
__u32	e
