int
struct udev_device *	sdev
struct usbip_usb_device *	udev
