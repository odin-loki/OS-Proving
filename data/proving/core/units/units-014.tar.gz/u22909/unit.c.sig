u32
u32	ptr
u16	val
