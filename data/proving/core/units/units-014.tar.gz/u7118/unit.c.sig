int
u32	flags
