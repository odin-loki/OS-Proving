u16
struct ice_hw *	hw
enum ice_block	blk
u16	vsig
