bool
int	errno
