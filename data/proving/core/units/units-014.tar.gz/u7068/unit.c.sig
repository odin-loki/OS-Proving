int
struct drm_device *	drm_dev
struct sti_mixer *	mixer
struct drm_plane *	primary
struct drm_plane *	cursor
