int
struct msghdr *	msg
size_t *	rdma_bytes
