int
int	fd
ioctlfunc_t	iocfunc
char *	string
