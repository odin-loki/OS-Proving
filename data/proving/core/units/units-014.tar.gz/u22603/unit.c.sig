unsigned int
unsigned int	pixel_rate
unsigned int	cpp
unsigned int	latency
