int
struct fc_lport *	lport
struct fcoe_ctlr *	fip
const struct libfc_function_template *	tt
int	init_fcp
