u32
u32	ignored
u32	rmid
