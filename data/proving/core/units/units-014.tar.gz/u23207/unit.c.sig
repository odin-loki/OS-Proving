int
unsigned int	clk_mult
