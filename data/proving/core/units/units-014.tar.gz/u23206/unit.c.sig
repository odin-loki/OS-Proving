bool
u32	user_key
SVGA3dShaderType	shader_type
