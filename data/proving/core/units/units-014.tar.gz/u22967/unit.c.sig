int
struct ocelot_fdma *	fdma
