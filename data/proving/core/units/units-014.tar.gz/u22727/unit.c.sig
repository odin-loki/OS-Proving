int
struct lpi2c_imx_struct *	lpi2c_imx
bool	atomic
