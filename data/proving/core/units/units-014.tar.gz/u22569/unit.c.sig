int
struct gsserrmap__head *	head
