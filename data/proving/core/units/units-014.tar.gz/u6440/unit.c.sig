long
const struct key *	key
char *	buffer
size_t	buflen
