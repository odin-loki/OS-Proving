int
struct rio_mport *	mport
