int
struct nand_device *	nand
unsigned char *	buf
unsigned char *	read_ecc
unsigned char *	calc_ecc
