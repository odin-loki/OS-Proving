int
struct ntfs_index *	indx
struct ntfs_inode *	ni
size_t	bit
