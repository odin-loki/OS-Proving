u32
u64	xfeatures_en
bool	compacted
