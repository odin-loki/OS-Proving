int
u8	pxvid
