unsigned int
unsigned int	mtu
