u16
u16	phys_addr
u8	input
