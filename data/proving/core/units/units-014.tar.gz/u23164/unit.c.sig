bool
struct gve_tx_ring *	tx
int	needed_descs
