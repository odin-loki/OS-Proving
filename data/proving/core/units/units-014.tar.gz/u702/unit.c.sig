int
struct bpf_sockopt_kern *	ctx
int	max_optlen
struct bpf_sockopt_buf *	buf
