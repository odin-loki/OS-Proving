long
unsigned long	last_checked
unsigned long	timeout
