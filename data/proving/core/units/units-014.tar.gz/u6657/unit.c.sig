int
unsigned long *	bitmap
int	len
int	bitmap_size
int	first
