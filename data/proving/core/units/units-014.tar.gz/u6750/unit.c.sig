int
struct tpm_space *	space
unsigned int	buf_size
