int
unsigned long	from
unsigned long	to
int	abort
bool	fused
int *	offset
