unsigned
struct ufs_sb_private_info *	uspi
struct ufs_buffer_head *	ubh
unsigned	begin
unsigned	size
unsigned char *	table
unsigned char	mask
