u32
const struct igc_adapter *	adapter
unsigned long	preemptible_tcs
