u16
u8	funct6
u8	rd
u8	funct2
u8	rs2
u8	op
