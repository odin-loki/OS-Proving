unsigned int
u32	spi
