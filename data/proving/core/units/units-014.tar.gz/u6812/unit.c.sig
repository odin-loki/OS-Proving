u8
u16	input
u16	output
