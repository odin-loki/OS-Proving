int
enum scan_result	r
