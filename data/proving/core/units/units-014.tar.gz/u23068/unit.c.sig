int
enum mbox_cmd	cmd
u32	retval
