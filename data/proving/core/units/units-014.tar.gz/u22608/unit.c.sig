u_int
fr_info_t *	fin
int	hlen
u_int	sum
