int
struct task_struct *	child
u64	clone_flags
