int
resource_size_t	base
unsigned long	size
