int
int	qp_per_entry
