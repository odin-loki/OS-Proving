int
struct qxl_device *	qdev
