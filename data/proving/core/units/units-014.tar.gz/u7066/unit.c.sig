u32
u32	link_fec
