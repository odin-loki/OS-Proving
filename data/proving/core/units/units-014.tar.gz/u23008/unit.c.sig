u64
struct bio *	bio
struct ioc_gq *	iocg
bool	is_merge
