u32
enum bfa_port_speed	pport_speed
