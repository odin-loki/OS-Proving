u64
struct safexcel_ahash_req *	req
