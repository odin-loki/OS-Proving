int
struct pci_dev *	dev
const struct pci_device_id *	id
