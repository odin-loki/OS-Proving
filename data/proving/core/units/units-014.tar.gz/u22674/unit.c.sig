bool
const struct drm_rect *	r
