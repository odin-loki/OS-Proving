int
struct bhnd_nvram_io *	io
size_t	offset
const void **	ptr
size_t	nbytes
size_t *	navail
