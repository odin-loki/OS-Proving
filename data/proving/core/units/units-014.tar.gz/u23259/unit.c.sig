u32
const u8 *	buf
u32	vrls_length
