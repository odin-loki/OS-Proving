bool
unsigned int	clx
