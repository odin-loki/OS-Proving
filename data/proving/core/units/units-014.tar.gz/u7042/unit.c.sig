int
struct nvkm_vmm *	vmm
