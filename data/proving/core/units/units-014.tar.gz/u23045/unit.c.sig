int
struct dvb_adapter *	dvb_adapter
struct dvb_ca_en50221 *	pubca
int	flags
int	slot_count
