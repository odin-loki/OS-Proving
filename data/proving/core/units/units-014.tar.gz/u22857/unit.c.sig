int
struct acpi_device *	adev
struct ipu_sensor *	sensor
