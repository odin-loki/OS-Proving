int
int	mfd
