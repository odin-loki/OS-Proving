pci_ers_result_t
struct pci_dev *	pdev
pci_channel_state_t	error
