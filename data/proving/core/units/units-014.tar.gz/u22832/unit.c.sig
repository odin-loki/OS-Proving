unsigned int
unsigned int	src_idx
