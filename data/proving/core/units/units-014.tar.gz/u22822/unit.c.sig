u32
int	slots
