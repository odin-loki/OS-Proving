unsigned long
unsigned long	start_pfn
unsigned long	end_pfn
struct zone *	zone
