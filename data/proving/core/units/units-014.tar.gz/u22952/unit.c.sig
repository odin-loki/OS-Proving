int
struct lbuf *	bp
int	flag
