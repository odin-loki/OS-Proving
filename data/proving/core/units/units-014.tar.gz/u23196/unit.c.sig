u16
u16	avg
u16	val
