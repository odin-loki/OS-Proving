int
struct snd_card *	card
