u16
u16	word
s16	fixed
