int
const gdc_ID_t	ID
