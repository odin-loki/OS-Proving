bool
struct obj_cgroup *	objcg
unsigned int	nr_bytes
struct pglist_data *	pgdat
enum node_stat_item	idx
