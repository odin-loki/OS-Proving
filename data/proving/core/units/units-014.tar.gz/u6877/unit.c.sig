int
unsigned int	offset
unsigned int	length
