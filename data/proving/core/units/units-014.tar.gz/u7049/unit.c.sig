int
u32	sectorsize
u32	nodesize
