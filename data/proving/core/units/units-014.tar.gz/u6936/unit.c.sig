size_t
struct ttyoutq *	to
void *	buf
size_t	len
