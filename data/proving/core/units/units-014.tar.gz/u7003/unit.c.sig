int
int	lev
