enum fs_udp_type
enum mlx5_traffic_types	i
