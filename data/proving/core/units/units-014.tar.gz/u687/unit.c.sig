bool
struct hfi1_ibdev *	ibd
