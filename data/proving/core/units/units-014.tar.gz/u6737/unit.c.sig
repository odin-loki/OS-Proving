int
struct siba_bhndb_softc *	sc
