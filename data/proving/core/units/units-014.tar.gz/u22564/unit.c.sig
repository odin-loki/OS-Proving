sector_t
unsigned long	index
