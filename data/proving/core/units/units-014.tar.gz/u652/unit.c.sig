_Bool
enum num_t	t
___u64	x
