int
struct map_info *	map
struct flchip *	chip
loff_t	adr
size_t	len
