unsigned long
unsigned long	pclk
const struct omap_video_timings *	mgr_timings
u16	width
u16	height
u16	out_width
u16	out_height
enum omap_color_mode	color_mode
