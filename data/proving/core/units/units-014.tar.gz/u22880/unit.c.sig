unsigned long
unsigned long	prev
unsigned long	curr
