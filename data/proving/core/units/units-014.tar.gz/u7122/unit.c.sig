int
struct r8152 *	tp
int	budget
