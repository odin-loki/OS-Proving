u32
struct ieee80211_hw *	hw
enum wireless_mode	wirelessmode
u32	ratr_bitmap
