int
struct fsl_asrc *	easrc
u64 *	infilter
u64 *	outfilter
int	shift
