int
struct ip_fw_chain *	ch
uint32_t	eaction_id
uint32_t	kidx
