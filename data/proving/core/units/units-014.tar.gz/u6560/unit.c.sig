int
struct dsi_data *	dsi
