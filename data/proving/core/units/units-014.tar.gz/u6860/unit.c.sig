int
unsigned int	channel
