u32
u32	max_bits
