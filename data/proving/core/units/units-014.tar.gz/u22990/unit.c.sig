int
struct inode *	inode
struct inode *	dir
const struct qstr *	qstr
struct folio *	ifolio
