int
int	verdict
