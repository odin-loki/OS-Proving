int
struct hfi1_devdata *	dd
u8	port
