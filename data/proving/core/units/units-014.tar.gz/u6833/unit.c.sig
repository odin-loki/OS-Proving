u16
struct il_priv *	il
enum nl80211_band	band
u8	n_probes
