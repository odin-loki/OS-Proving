int
char *	cmdline
unsigned long long	system_ram
unsigned long long *	crash_size
unsigned long long *	crash_base
unsigned long long *	low_size
unsigned long long *	cma_size
bool *	high
