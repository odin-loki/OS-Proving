u32
unsigned	indx
unsigned	threshold
