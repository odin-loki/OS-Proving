int
struct shm_channel *	sc
u32	msg_type
u32	msg_version
bool	reset_vf
