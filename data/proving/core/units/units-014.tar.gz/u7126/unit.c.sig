u32
void *	rom_start
