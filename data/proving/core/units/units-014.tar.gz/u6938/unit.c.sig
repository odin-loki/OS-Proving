unsigned int
sector_t	block
unsigned int	num_locks
