u16
unsigned long	rate
unsigned long	parent_rate
