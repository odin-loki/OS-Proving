int
struct icc_node *	node
const struct icc_provider *	provider
const char *	name
