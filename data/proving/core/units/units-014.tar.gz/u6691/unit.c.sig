u_int
u_int	chan
u_int	flags
