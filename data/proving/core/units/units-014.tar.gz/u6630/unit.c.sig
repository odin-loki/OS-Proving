int
struct fluke_priv *	e_priv
struct gpib_board *	board
int	handshake_mode
