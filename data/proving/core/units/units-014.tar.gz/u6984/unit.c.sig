bool
int	temp
