s64
u64	diff
