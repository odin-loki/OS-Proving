int
int	index
int	ring_count
