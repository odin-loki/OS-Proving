int
const struct device *	dev
enum rpmh_state	state
const struct tcs_cmd *	cmd
u32	n
