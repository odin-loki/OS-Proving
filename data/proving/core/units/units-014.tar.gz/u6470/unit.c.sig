int
struct mlx_softc *	sc
int	error
int	param1
int	param2
