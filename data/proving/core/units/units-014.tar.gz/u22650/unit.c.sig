int
scanopt_t *	svoid
