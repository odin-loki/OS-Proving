u8
u8	bits
