u32
u32	alg_digest_size
enum hash_alg	alg
enum hash_type	htype
