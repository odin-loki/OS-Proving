u64
struct ieee80211_link_data *	link
u16	capab
bool	erp_valid
u8	erp
