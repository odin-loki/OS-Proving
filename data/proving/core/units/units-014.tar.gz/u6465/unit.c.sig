bool
struct thread *	td
uintptr_t	v
bool	fp
