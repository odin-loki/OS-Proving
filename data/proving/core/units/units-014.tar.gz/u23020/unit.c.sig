void
u64	amount
