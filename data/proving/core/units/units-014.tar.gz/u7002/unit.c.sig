int
char *	buffer
struct timespec64 *	time
bool *	compressed
