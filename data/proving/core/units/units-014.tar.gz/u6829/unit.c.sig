int
struct nlmsghdr *	nh
size_t	req_sz
const char *	peer
int	ns
