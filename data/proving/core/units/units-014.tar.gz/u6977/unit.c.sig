int
struct hbg_priv *	priv
struct hbg_ring *	ring
?	?
enum hbg_dir	dir
