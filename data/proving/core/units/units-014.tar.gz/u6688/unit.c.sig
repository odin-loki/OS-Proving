int
struct ixgbe_hw *	hw
struct ixgbe_dcb_config *	dcb_config
int	max_frame
u8	direction
