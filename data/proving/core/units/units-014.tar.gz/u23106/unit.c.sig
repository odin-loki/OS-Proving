bool
struct xfs_group *	xg
unsigned int	mask
