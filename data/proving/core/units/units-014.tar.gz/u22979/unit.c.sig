int
struct net_device *	dev
enum hsr_version *	ver
