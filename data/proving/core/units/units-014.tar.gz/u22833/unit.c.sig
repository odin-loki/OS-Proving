int
struct filter *	chain
int	max_len
