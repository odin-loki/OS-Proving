uint32_t
atom_exec_context *	ctx
uint8_t	attr
int *	ptr
uint32_t *	saved
int	print
