int
scr_stat *	scp
void **	softc
