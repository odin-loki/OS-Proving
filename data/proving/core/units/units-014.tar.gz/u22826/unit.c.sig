unsigned long
u32	ratio
u32	rate_in
bool	lf_ratio
