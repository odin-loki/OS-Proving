int
struct hv_device *	hdev
struct completion *	comp
