int
struct acpi_device *	adev
const struct acpi_device_id *	id
