int
u32	Clk
