int
struct watchdog_device *	wdd
unsigned int	t
