unsigned int
enum nsim_dev_port_type	type
unsigned int	port_index
