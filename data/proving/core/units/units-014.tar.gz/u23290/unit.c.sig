u32
u32	len
enum dma_slave_buswidth	dw
u32	chan_max_burst
u32	bus_max_burst
