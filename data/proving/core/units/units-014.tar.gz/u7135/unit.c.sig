bool
struct mlx5e_xdpsq *	sq
unsigned int	budget
