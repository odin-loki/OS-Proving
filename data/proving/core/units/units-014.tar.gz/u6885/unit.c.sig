u64
u64	ino
int	xinobits
int	fsid
const char *	name
int	namelen
bool	warn
