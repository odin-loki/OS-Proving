u8
s8	power
