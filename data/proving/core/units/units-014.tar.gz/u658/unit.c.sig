int
const char *	str
int *	val
int	min
int	max
