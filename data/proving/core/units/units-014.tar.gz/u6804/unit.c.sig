bool
u16	rqid
