int
struct ethtool_rx_flow_spec *	fsp
struct npc_install_flow_req *	req
u32	flow_type
