int
struct intel_vgpu *	vgpu
int	port_num
int	type
unsigned int	resolution
