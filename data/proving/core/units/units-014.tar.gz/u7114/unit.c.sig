int
struct iwl_mld *	mld
struct ieee80211_vif *	vif
struct ieee80211_sta *	sta
u32	old_sta_mask
u32	new_sta_mask
