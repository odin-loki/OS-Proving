int
unsigned	test
unsigned	mask
