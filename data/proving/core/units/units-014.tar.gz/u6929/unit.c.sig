unsigned int
unsigned int	val
unsigned int	max_exp
unsigned int	max_mantissa
