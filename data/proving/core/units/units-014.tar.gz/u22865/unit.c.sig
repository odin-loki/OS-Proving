int
unsigned char	code
