bool
umode_t	mode
