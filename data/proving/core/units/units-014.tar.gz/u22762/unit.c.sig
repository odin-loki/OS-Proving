int
int	index
bool	eventsel
