int
struct dumperinfo *	di
