u32
u8	bus
u8	dev
u8	func
u16	reg
