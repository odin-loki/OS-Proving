long
struct ieee80211_hw *	hw
enum wireless_mode	wirelessmode
u8	txpwridx
