int
struct ath_hal *	ah
int	i
