int
int	mtu
int	bufsize
