unsigned int
struct nand_device *	nand
const struct nand_pos *	pos
