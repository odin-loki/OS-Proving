int
struct sw_flow_actions **	sfa
int	attrtype
void *	data
int	len
bool	log
