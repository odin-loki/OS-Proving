int
struct acpi_device *	adev
void *	not_used
