int
u16	wIndex
