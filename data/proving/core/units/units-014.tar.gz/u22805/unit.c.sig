int
uint32_t *	bs
unsigned int	bit
