u32
struct mlx5_eq *	eq
u32	cc
