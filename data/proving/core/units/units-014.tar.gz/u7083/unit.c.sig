u8
u32	chain_bitmap
