ssize_t
struct dentry *	dentry
char *	list
size_t	size
