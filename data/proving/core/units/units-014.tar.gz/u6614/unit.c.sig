long
struct hstate *	src
nodemask_t *	nodes_allowed
unsigned long	nr_to_demote
