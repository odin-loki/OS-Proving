enum ib_mtu
int	mtu
