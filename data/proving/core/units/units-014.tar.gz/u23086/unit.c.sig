int
struct xlgmac_channel *	channel
int	budget
