int
mp_int *	a
mp_int *	b
mp_int *	c
int	digs
