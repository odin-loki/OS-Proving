int
struct dvb_frontend *	fe
unsigned int	rfin
unsigned int	if1
unsigned int	if2
unsigned int	spectrum_from
unsigned int	spectrum_to
unsigned char *	buf
int *	ret_sel
unsigned int	xogc
