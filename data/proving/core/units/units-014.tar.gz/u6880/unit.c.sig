int
int	val
unsigned int	mask
int	min
int	thresh
unsigned int	invert
