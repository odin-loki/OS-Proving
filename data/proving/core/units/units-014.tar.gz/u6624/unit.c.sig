bool
uintptr_t	x
int	flags
bool	fp
