int
struct idt77252_dev *	card
struct sk_buff *	skb
int	queue
