int
struct platform_device *	pdev
struct hdmi_core_data *	core
struct hdmi_wp_data *	wp
