u32
u32	cur
u32	val
