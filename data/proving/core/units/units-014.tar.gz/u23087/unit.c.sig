int
struct devfreq *	df
unsigned long *	freq
