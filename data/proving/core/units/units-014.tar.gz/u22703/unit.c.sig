int
struct efx_nic *	efx
struct efx_channel *	channel
