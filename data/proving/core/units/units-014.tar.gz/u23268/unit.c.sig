u_int32_t
HTAB *	hashp
char *	k
int	len
