__wsum
__wsum	val
