long
void *	window
unsigned long	outcnt
