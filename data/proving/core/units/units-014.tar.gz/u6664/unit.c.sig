u_int32_t
kobj_t	obj
void *	devinfo
