unsigned int
struct smsc911x_data *	pdata
