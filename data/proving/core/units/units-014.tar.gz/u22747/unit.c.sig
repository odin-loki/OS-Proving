u32
u32	cycle_timer
