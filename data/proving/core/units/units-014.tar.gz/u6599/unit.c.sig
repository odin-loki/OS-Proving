bool
struct drm_dp_tunnel_mgr *	mgr
const struct drm_dp_tunnel_regs *	regs
unsigned int	flags
