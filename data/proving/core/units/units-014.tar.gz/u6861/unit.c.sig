u32
enum comm_dir	mode
u32	tdm_num
