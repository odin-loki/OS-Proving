int
struct TCP_Server_Info *	server
