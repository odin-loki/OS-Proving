unsigned int
unsigned int	audio_sample_rate
unsigned int	tmds_clock
unsigned int	n
