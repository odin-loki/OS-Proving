unsigned int
const unsigned int	opcode
