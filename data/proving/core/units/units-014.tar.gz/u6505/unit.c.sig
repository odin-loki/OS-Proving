int
struct pci_dev *	pdev
struct nfp_nsp *	nsp
const char *	key
const char *	default_val
int	max_val
int *	value
