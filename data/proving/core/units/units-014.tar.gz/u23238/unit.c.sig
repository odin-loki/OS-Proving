int
fc_port_t *	fcport
uint16_t	sa_index
uint16_t	handle
