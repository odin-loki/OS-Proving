enum pwm_polarity
struct i2c_client *	client
struct device_node *	fan_np
