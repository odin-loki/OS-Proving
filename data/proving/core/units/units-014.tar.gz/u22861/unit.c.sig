unsigned int
u64	word
