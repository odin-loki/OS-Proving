int
int	posixError
int	sqliteIOErr
