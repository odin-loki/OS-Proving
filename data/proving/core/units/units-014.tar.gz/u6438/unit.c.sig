s32
struct adapter *	padapter
