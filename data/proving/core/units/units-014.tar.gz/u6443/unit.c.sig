long
long	val
long	orig_max
long	new_max
