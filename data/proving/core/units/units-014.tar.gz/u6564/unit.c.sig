uint32_t
unsigned int	region
enum amcc_prefetch_bits	prefetch
