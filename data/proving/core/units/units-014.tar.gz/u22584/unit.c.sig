int
char *	keyname
char *	key
u_int *	keylen
