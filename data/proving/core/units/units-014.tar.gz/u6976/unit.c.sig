int
struct scsi_qla_host *	ha
int	bus
int	target
