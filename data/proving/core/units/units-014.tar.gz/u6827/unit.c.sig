long
int	cpu
