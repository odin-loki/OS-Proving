int
int	w
