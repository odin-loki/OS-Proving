int
struct iwl_trans *	trans
struct sk_buff *	skb
struct iwl_txq *	txq
u8	hdr_len
struct iwl_cmd_meta *	out_meta
struct iwl_device_tx_cmd *	dev_cmd
u16	tb1_len
