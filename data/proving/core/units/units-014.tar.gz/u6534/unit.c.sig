int
struct drm_dp_aux *	aux
struct drm_edp_backlight_info *	bl
u16	driver_pwm_freq_hz
?	?
