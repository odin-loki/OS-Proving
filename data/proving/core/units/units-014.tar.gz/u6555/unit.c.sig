int
struct ufs_hba *	hba
struct ufshcd_lrb *	lrbp
