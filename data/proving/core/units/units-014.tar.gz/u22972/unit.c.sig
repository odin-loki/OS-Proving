void
struct btrfs_inode *	inode
const u64	add_bytes
const u64	del_bytes
