int
struct domain_device *	parent
struct ex_phy *	phy
struct domain_device *	child
int	phy_id
