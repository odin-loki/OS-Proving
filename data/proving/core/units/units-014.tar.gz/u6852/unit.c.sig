int
struct imx_timer *	imxtm
