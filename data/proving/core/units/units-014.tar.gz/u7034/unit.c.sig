int
int	period_size
int	sample_size
