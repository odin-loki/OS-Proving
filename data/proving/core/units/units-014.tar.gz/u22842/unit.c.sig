int
u8 *	buf
