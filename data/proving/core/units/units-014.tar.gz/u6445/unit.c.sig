u32
u32	data
u32	shift
