int
struct ipv6_opt_hdr *	opt
unsigned int	offset
