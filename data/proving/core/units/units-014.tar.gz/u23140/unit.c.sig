int
uint32_t	inv_w
unsigned int	maxlen
