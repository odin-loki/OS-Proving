int
struct rand_data *	ec
unsigned char *	data
unsigned int	len
