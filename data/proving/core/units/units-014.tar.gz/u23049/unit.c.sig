int
const struct option *	opt
const char *	str
int	unset
