int
int	soc_type
