word_type
long long	a
long long	b
