int
struct ath5k_hw *	ah
struct ath5k_led *	led
const char *	name
const char *	trigger
