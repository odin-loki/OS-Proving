bool
int	mask
