loff_t
int	bits
