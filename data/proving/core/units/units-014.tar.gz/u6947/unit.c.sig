int
struct pn533 *	priv
u32	protocols
struct device *	parent
