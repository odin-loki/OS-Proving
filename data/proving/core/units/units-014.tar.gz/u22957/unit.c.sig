int
struct tty_struct *	tty
u8	ch
