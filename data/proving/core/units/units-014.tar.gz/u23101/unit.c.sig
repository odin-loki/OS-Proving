long
struct clk *	clk
int	phase
