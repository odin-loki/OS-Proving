int
struct rio_dev *	rdev
