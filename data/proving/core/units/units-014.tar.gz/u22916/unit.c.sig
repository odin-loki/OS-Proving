int
struct sk_buff *	skb
int	nhs
int	type
unsigned int	data_len
