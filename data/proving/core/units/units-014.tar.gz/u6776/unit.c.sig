int
struct gpio_chip *	chip
unsigned	offset
