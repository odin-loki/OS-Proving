int
struct mipid02_dev *	bridge
