int
struct adapter *	adapter
int	attempts
int	delay
