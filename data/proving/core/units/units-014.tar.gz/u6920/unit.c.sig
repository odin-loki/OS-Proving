int
void *	addr
size_t	size
gfp_t	gfp_mask
