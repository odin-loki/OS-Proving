int
struct sk_buff *	skb
int	type
