u32
struct cx231xx *	dev
struct cx231xx_dmaqueue *	dma_q
u8	sav_eav
u8 *	p_buffer
u32	buffer_size
