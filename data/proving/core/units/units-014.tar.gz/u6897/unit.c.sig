int
struct scsi_qla_host *	ha
