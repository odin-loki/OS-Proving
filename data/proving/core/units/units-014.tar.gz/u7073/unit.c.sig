int
struct sw_flow_actions **	sfa
int	attrtype
bool	log
