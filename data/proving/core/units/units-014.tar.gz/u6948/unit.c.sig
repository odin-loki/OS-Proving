int
struct _scanopt_t *	s
int	is_short
int	err
