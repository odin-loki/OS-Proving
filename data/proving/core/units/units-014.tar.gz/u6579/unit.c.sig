u32
unsigned long	ringbytes
