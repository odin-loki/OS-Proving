u32
u32	refClock
u32	coreClock
u32 *	FOut
u32 *	ROut
u32 *	POut
