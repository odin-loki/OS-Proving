int
struct mlx5_core_dev *	dev
enum mlx5_sw_icm_type	type
u64	length
u16	uid
phys_addr_t	addr
u32	obj_id
