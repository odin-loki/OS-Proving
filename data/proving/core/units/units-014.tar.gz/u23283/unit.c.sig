u_int
u_char *	p
