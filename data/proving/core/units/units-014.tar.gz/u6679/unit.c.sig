uint8_t
void *	bios
int	ptr
