u64
u32	opcode
u32	obj_id
