int
void *	blk
