u8
int	num
