int
int	pg_sz
