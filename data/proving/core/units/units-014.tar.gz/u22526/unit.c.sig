int
struct tpg_data *	tpg
unsigned	max_w
