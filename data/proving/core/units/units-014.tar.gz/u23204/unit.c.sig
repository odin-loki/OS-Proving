int
struct snd_ad1843 *	ad1843
