bool
u32	center
enum nl80211_chan_width	width
