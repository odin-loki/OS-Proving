unsigned long
u32	regval
unsigned long	parent_rate
