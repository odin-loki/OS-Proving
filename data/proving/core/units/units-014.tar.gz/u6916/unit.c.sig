int
struct i915_address_space *	vm
struct i915_sw_fence *	sw_fence
u64	offset
u64	size
bool	intr
gfp_t	gfp
