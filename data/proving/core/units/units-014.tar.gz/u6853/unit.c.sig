int
struct file *	file
loff_t	start
loff_t	end
int	datasync
