void
struct lola *	chip
