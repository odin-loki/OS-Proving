int
int	ipwrate
