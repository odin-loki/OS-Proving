int
struct vmw_sw_context *	sw_context
struct vmw_resource *	res
u32	dirty
u32	flags
