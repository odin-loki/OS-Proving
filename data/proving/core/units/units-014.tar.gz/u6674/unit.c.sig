int
struct cec_adapter *	adap
u8	logical_addr
