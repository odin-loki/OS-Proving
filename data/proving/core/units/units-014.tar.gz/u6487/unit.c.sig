int
int	ioapic
int	pin
