int
struct drm_gem_object *	obj
