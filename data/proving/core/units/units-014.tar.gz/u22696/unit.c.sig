u32
u32	major
u32	minor
