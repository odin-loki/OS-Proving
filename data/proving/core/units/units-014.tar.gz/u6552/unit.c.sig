int
struct key *	key
const char *	sig
int	siglen
const char *	h
int	hlen
