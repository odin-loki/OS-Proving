u32
u32	rate_in
u32	rate_out
bool	lf_ratio
