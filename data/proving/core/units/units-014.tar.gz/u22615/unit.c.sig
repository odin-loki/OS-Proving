int
struct iovec *	dst
void *	src
size_t	transferred
unsigned	count
bool	is_compat
