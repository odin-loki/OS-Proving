s32
struct igc_hw *	hw
