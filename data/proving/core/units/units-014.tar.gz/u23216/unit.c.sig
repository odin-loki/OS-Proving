enum ice_fec_mode
u8	caps
u8	fec_options
