uint32_t
struct pcg_state_setseq_64*	rng
uint32_t	bound
