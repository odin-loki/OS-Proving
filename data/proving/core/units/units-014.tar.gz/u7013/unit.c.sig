u64
u64	t1
u64	t2
