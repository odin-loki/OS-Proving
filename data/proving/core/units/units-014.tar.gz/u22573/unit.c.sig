int
struct hdlcd_drm_private *	hdlcd
