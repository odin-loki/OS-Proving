int
struct device *	dev
bool	ign_usage_count
