int
struct aq_nic_s *	aq_nic
const enum atl_ring_type	ring_type
