int
struct sock *	sk
int	flags
