unsigned long
struct clk_hw *	hw
unsigned long	prate
int	index
