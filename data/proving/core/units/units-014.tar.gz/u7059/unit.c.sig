int
struct saa7146_dev *	dev
int	in_x
int	out_x
int	flip_lr
u32*	hps_ctrl
u32*	hps_v_gain
u32*	hps_h_prescale
u32*	hps_h_scale
