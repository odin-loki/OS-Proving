u32
int	dcore_id
int	hmmu_id
