int
atomic_t *	addr
int	newval
