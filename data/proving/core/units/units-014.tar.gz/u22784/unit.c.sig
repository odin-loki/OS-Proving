unsigned char
struct spk_synth *	in_synth
