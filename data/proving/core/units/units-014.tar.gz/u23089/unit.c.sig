int
int	loops
