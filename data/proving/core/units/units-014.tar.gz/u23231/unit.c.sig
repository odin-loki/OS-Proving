int
struct mipi_dsi_device *	dsi
