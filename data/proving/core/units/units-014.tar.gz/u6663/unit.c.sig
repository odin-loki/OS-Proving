int
struct sja1105_private *	priv
int	port
struct netlink_ext_ack *	extack
unsigned long	cookie
struct sja1105_key *	key
unsigned long	destports
bool	append
