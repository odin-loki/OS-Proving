int
struct echoaudio *	chip
