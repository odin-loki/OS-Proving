int
struct ahash_request *	req
int	ret
