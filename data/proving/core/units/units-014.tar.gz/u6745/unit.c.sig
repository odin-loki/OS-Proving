int
struct core_reloc_test_case *	test
