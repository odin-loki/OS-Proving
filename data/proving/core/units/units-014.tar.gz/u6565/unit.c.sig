int
struct usbphy_softc *	sc
