int
struct fsl_sata_channel *	ch
bus_size_t	off
unsigned int	mask
unsigned int	val
int	t
