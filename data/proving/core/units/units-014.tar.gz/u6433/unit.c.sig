int
struct altera_pcie *	pcie
