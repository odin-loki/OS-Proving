int
struct amd64_pvt *	pvt
u8	umc
unsigned int	cs_mode
int	csrow_nr
