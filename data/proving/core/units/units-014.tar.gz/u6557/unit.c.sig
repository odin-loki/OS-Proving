u32
u32	real_pay_size
u8	curr_frag
