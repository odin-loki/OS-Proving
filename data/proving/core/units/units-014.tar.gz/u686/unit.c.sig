int
unsigned char	x
