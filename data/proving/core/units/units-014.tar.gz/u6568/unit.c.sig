int
u8	fc
