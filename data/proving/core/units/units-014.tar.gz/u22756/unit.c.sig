int
Jim_Interp *	interp
Jim_Obj *	objPtr
