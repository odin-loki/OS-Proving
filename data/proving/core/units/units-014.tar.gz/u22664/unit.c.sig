int
struct c8sectpfei *	fei
struct channel_info *	tsin
