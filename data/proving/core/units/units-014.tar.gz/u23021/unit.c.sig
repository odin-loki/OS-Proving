int
int	val
int	width
