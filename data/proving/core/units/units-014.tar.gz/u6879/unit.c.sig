int
struct inode *	inode
int	write
