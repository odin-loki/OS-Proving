bool
u32	mdiv
u32	pdiv
u32	pll_con
