_Bool
const void *	ptr
