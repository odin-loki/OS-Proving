u64
u32	a
u32	b
