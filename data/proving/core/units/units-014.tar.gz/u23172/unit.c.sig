xfs_dir2_db_t
struct xfs_da_geometry *	geo
xfs_dablk_t	da
