int
int	reg
unsigned int	nr
