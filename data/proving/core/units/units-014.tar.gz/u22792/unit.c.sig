void
u32	packet_id
u8 *	queue_generation
u8 *	queue_id
u8 *	item_generation
u8 *	item_id
