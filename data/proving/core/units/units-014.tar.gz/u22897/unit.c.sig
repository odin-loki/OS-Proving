unsigned int
unsigned int	block_num
