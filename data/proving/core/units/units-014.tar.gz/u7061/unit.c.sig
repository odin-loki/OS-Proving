int
struct vmw_cmdbuf_res_manager *	man
u32	user_key
struct list_head *	list
