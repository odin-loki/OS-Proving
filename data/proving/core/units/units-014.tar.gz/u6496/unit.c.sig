enum can_state
u16	err
