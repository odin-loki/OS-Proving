size_t
size_t	mask
size_t	a
size_t	b
