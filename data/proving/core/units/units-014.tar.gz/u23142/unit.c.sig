int
struct x86_emulate_ctxt *	ctxt
int	vec
u32	error
bool	valid
