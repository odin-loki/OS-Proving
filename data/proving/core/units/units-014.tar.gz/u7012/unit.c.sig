int
struct spmi_controller *	ctrl
u8	opc
u8	sid
