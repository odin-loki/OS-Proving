u64
struct perf_event *	event
u64	now
