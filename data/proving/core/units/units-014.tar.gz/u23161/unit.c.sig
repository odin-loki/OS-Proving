unsigned long
u64	log
