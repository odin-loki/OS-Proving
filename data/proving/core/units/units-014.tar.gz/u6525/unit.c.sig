__always_inline unsigned long long
