int
struct cxgbi_ppm *	ppm
u32	sw_tag
u32 *	final_tag
