int
uint8_t *	lba
