unsigned int
struct pci_dev *	dev
u32	aercc
