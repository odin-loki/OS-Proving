int
struct tee_context **	ctx
