unsigned short
unsigned int	sum
