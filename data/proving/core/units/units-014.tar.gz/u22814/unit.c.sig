int
struct snd_emux **	remu
