int
struct stm32_gpio_bank *	bank
int	pin
u32	mode
u32	alt
