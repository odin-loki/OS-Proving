int
const char *	dir_path
struct dirent *	evt_dir
