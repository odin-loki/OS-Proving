uint16_t
int	chan
