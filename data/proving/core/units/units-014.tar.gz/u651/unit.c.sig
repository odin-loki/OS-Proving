int
struct amdgpu_device *	adev
int	i
bool	restore
