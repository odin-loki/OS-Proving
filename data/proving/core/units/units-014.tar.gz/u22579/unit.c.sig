int
struct ixgbe_hw *	hw
