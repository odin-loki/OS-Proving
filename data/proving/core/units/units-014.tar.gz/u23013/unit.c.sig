u32
u8	max_fill
u8	wn
u8	est
u8	rpm
u8	dcm
u8	epm
int	sd
int	sp
int	se
int	dp
int	de
int	ep
