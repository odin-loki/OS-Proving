int
struct lola *	chip
unsigned int *	val
unsigned int *	extval
