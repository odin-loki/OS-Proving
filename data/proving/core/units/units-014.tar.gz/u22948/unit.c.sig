int
struct rndis_params *	params
u8 *	buf
