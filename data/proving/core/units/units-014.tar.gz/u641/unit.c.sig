intel_wakeref_t
struct intel_gt *	gt
