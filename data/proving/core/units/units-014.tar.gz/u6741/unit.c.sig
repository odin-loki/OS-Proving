__wsum
__wsum	csum
__wsum	addend
