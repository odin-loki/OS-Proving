int
struct jbd2_inode *	jinode
