bool
u32	action
