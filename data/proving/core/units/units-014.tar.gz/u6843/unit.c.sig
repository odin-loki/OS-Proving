int
struct service_processor *	sp
unsigned long	reader
