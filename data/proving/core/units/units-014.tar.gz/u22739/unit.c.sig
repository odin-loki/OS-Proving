int
struct ps_device *	dev
