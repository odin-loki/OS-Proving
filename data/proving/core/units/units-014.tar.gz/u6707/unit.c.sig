int
struct jpeg_stream *	stream
