int
unsigned int	byte
