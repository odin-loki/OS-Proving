bool
struct dirty_throttle_control *	dtc
