int
struct dpaa_priv *	priv
