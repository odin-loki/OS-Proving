bool
uint16_t	error
