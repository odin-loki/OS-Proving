int
struct list_head *	dev_resv_regions
struct list_head *	group_resv_regions
