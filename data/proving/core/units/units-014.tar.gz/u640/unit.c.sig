u32
u16	flag
