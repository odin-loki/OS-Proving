int
struct wpa_supplicant *	wpa_s
struct wpa_ssid *	ssid
