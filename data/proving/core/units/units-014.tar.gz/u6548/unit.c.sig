u8
unsigned long	cqn
