int
struct lan966x *	lan966x
