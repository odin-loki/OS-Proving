unsigned long
unsigned int	old_hmask
