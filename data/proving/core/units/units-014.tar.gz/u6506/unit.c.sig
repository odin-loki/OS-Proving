u32
bool	rw
u8	func
u8	raw
u32	address
u8	writedata
