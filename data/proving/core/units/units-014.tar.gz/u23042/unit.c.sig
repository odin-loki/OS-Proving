int
unsigned long	pclk
unsigned long	lclk
const struct omap_video_timings *	mgr_timings
u16	width
u16	height
u16	out_width
u16	out_height
enum omap_color_mode	color_mode
bool *	five_taps
int *	x_predecim
int *	y_predecim
int *	decim_x
int *	decim_y
u16	pos_x
unsigned long *	core_clk
bool	mem_to_mem
