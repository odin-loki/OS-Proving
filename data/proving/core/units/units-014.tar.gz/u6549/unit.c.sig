int
unsigned long	mclk
unsigned long	rate
unsigned long	i2sdiv_max
