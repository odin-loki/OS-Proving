int
struct usbtest_dev *	tdev
int	len
