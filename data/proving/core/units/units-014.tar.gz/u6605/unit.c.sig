ssize_t
struct mtd_info *	mtd
bool	is_user
