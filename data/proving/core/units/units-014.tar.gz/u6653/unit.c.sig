int
struct stm32_lptim_trigger *	priv
