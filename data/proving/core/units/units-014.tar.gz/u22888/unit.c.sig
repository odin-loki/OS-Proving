int
int	x
int	b
int	bmask
