bool
u32	sh_psize
size_t	buf_size
