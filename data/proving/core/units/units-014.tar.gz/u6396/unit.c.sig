uint16_t
struct x86emu *	emu
uint16_t	d
uint16_t	fill
uint8_t	s
