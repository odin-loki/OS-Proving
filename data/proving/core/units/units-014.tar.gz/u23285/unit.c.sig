int
struct adapter *	adap
struct sge_qset *	qs
int	budget
