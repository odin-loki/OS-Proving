int
struct bxe_softc *	sc
struct dmae_cmd *	dmae
