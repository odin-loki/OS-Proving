uint16_t
uint16_t	target
uint16_t	srcLeft
uint16_t	srcRight
uint16_t	targetLeft
uint16_t	targetRight
