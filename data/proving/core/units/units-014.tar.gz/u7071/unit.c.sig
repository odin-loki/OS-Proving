int
struct ieee80211_scan_state *	ss
struct ieee80211vap *	vap
