u16
u8	vfe_id
