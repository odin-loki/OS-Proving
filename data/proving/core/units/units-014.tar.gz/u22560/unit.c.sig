int
u32	base
u32	lim
