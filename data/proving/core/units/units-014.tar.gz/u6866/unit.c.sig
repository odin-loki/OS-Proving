int
uint32_t	cap
