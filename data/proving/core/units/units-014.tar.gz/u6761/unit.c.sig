efx_rc_t
caddr_t	data
size_t	size
boolean_t	wantpid
