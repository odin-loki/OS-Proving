int
radix_softc_t *	softr
ipf_rdx_head_t **	headp
