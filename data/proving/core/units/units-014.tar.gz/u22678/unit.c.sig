int
struct adi *	adi
int	count
