int
struct m_can_classdev *	cdev
u32	mram_max_size
