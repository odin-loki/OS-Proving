int
struct btrfs_root *	root
int	num_bytes
bool	enforce
bool	noflush
