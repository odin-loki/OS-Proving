u8
enum vpfe_ccdc_data_size	sz
