int
struct qm_portal *	portal
enum qm_mr_pmode	pmode
enum qm_mr_cmode	cmode
