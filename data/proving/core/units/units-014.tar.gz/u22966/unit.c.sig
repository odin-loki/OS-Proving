int
struct dquot *	dquot
