int
unsigned	vcpu_size
unsigned	vcpu_align
struct module *	module
