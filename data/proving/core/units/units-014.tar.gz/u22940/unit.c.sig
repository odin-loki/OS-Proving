int
struct cdev *	dev
char *	buf
int	maxretries
