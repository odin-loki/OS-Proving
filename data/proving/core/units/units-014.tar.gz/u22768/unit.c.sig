int
uint32_t	flash_size
