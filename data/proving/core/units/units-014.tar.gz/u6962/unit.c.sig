int
struct pci_dev *	dev
unsigned int	reg
