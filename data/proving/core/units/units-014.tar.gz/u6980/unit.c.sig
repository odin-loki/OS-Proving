__le32
__le32	daccess
