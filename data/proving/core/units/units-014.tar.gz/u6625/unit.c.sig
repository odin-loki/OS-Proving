u32
const u64	stripe_unit
const u32	dss_count
const loff_t	offset
