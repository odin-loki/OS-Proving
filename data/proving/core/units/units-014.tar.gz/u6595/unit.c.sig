bool
u32	val
u32	expected_val
