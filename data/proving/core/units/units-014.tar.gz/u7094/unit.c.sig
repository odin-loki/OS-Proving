int
struct clocksource *	cs
u32	scale
u32	freq
