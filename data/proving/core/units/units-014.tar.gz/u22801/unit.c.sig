bool
u64	basetime
u64	old_basetime
enum tk_offsets	tko
enum tk_offsets	old_tko
s32	clockid
s32	old_clockid
