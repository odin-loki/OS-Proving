unsigned long
u64	deltatsc
u64	pm1
u64	pm2
