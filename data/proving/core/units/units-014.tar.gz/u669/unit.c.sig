int
struct hdac_device *	hdev
