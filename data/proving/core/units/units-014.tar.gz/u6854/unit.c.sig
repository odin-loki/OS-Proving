int
struct pci_dev *	pci_dev
const struct pci_device_id *	pci_id
