int
struct max77705_charger_data *	chg
int	float_voltage
