bool
const void *	base
size_t	size
unsigned char	align
