u32
bool	is_ud_or_gsi
u32	max_send_sge
