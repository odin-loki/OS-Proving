u32
u32	val1
u32	val2
