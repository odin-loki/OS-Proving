int
uint32_t	buffer_size
uint32_t	wr_idx
uint32_t	rd_idx
