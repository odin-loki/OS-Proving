int
struct ieee80211_hw *	dev
unsigned int	prio
unsigned int	entries
