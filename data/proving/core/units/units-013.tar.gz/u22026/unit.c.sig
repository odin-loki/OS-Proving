bool
__le64	addr
