unsigned long
long	numeric
unsigned long	bits_len
