u8
struct rtw89_dev *	rtwdev
const struct rtw89_chan *	chan
enum rtw89_bandwidth	dbw
