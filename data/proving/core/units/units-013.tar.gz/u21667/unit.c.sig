int
int	amt
