int
struct hl_mem_mgr *	mmg
u64	handle
