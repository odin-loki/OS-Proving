int
struct if_sdio_card *	card
u8 *	buffer
unsigned	size
