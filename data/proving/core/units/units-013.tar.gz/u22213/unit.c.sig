int
unsigned int	fifosize
unsigned int	len
