int
struct gpib_board *	board
