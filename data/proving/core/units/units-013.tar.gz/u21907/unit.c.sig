void
volatile u_long *	addr
u_long	val
