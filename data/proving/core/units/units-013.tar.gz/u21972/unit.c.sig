int
enum pds_core_status_code	code
