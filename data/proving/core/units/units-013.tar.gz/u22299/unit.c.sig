int
volatile uint64_t *	_ptr
uint64_t *	_old
uint64_t	_new
