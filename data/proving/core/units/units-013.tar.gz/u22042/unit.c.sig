int
struct power_supply *	psy
const char *	name_template
struct led_trigger **	tp
int *	err
