int
unsigned int	max
