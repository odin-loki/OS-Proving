size_t
size_t	sz
void *	arg
