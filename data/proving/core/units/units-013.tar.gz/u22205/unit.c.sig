int
struct p54s_priv *	priv
u16	reg
u32	bits
