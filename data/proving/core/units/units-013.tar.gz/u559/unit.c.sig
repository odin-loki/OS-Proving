int
qla_host_t *	ha
uint32_t	reg
uint32_t	bit
uint32_t	err_bit
