bool
enum req_op	op
