dm_block_t
dm_block_t	b
uint32_t	n
