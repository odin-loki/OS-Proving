int
const char *	name
