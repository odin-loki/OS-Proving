int
u8	status
