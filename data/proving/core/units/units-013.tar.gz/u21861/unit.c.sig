int
struct vfio_pci_core_device *	vdev
unsigned int	vector
bool	msix
