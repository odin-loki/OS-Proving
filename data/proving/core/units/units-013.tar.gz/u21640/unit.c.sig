int
struct mt76_dev *	mdev
int	err
bool	enable
