int
struct rpmsg_device *	rpdev
