int
struct Qdisc *	sch
struct qfq_class *	cl
u32	weight
u32	lmax
