int
struct pqi_ctrl_info *	ctrl_info
