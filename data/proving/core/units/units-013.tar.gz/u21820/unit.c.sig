u32
struct mlx4_zone_allocator *	zones
u32	uid
int	count
int	align
u32	skip_mask
u32 *	puid
