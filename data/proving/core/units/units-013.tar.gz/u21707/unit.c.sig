int32_t
struct rte_lpm_tbl_entry *	tbl8
uint32_t	number_tbl8s
