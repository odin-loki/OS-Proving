int
u32	flags
u16	regval
u8	resolution
