bool
struct brcms_phy *	pi
