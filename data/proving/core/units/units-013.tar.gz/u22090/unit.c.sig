int
struct wcd_mbhc *	mbhc
struct wcd_mbhc_config *	mbhc_cfg
struct snd_soc_jack *	jack
