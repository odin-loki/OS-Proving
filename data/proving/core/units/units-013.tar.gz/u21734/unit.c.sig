fxp_t
fxp_t	a
fxp_t	b
