int
struct snd_bt87x *	chip
int	device
char *	name
