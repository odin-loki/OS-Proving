int
struct nitrox_kcrypt_request *	nkreq
struct scatterlist *	src
char *	iv
int	ivsize
int	buflen
