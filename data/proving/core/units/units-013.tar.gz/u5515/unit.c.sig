int
int	disk
int	raid_disks
