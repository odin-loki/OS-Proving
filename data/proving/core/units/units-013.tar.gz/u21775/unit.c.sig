unsigned int
unsigned int	base
size_t	len
