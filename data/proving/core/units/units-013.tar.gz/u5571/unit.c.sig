int
mtx_t *	mtx
int	type
