int
int	nd
