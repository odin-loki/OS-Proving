int
struct dwc3 *	dwc
const char *	propname
u8 *	eps
u8	num
