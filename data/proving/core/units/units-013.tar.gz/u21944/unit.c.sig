int
int	chan
