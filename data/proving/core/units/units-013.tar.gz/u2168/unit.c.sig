enum cable_selections
int	phy
unsigned char	selection_byte
