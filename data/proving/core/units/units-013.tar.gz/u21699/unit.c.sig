int
snd_wavefront_t *	dev
