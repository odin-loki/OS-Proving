int
unsigned int	id
unsigned int	max
