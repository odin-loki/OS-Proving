int
struct iwl_mvm *	mvm
bool	clear
u8	cmd_ver
