u8
struct nfc_llcp_local *	local
