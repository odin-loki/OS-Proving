int
struct ath5k_hw *	ah
int	mode
struct ath5k_chan_pcal_info *	chinfo
