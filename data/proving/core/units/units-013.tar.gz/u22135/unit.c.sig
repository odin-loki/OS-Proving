int
void *	address
size_t	size
int	how
