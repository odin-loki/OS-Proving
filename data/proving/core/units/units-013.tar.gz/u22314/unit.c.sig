unsigned int
struct __kfifo *	fifo
struct scatterlist *	sgl
int	nents
unsigned int	len
size_t	recsize
dma_addr_t	dma
