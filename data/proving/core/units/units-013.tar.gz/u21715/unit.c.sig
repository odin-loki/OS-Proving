int
struct netns_ipvs *	ipvs
