int
u_char *	buffer
int	len
