int
struct ocfs2_super *	osb
struct ocfs2_lock_res *	lockres
int	ex
int	local
