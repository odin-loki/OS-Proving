int
struct ocfs2_journal *	journal
int	full
