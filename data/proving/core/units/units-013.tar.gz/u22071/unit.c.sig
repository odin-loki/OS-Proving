int
const void *	addr
