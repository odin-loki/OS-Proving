unsigned long
phys_addr_t	start
phys_addr_t	end
