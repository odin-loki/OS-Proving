bool
struct pt_regs *	regs
unsigned long *	target
u32 *	type
