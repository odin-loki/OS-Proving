long
const char *	name_one
const char *	name_eval
const char *	name_two
unsigned long long	one
?	?
unsigned long long	two
_Bool	skip
