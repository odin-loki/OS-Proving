bool
unsigned long	addr
