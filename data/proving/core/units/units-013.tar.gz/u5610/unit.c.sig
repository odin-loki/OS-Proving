uint64_t
uint64_t	mask
uint64_t	a
uint64_t	b
