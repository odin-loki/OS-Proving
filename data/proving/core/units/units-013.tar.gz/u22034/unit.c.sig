u32
u32	ptr
