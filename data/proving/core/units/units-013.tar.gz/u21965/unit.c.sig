int
unsigned long	freq
int	irq
