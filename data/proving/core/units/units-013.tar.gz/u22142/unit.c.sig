int
struct mtkswitch_softc *	sc
