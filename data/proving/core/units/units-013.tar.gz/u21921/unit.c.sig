uint32
uint32	limit
