int
fr_info_t *	fin
