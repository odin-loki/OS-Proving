int32_t
ocs_xport_t *	xport
