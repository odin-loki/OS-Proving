int
struct sparx5 *	sparx5
u32	speed
