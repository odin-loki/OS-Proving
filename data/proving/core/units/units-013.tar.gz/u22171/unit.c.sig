u16
u16	gray_code
