int
int	idle_minutes
