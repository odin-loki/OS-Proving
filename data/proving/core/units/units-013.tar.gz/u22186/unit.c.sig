int
struct ptp_clock_info *	ptp
s64	delta
