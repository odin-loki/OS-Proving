int
struct dvb_frontend *	fe
u32	sample_freq_hz
u32	bw
