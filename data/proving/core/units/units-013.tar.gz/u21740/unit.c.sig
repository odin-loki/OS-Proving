u8
unsigned long	rate
unsigned long	req_rate
