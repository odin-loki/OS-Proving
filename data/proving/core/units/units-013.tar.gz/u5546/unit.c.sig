int
struct nvkm_subdev *	subdev
enum nvkm_suspend_state	suspend
