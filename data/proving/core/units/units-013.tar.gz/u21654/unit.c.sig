int
struct kmem_cache *	s
gfp_t	flags
size_t	size
void **	p
