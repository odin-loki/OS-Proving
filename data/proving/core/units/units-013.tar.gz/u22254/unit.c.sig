bool
u64	blocknr
u64	other
u32	blocksize
