int
struct vmci_queue *	queue
size_t	add
uint64_t	queue_size
