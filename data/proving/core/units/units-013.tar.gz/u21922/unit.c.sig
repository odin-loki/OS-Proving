int32_t
ocs_hw_t *	hw
hw_eq_t *	eq
uint32_t	max_isr_time_msec
