bool
struct folio *	folio
