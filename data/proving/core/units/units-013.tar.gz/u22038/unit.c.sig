int
struct version_number	expected_version
struct version_number	actual_version
const char *	component_name
