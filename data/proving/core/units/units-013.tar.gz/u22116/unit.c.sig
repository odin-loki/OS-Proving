int
int	pixel_clock
int	bpp_x16
int	bw_overhead
