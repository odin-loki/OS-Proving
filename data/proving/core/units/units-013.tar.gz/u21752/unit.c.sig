int
struct amdgpu_device *	adev
uint32_t	lo_addr
uint32_t	lo_val
uint32_t	hi_addr
uint32_t	hi_val
