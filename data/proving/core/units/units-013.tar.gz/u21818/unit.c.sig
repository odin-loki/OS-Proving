unsigned int
struct __kfifo *	fifo
