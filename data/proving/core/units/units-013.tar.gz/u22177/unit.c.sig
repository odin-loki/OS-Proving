bool
struct ufs_hba *	hba
