int
struct hda_codec *	codec
hda_nid_t	nid
int	num_pins
const hda_nid_t *	pins
