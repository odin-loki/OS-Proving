int
int	log2_num
