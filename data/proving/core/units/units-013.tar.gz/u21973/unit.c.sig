int
struct icc_node *	node
u32	tag
u32	avg_bw
u32	peak_bw
u32 *	agg_avg
u32 *	agg_peak
