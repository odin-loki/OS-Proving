unsigned int
int	win
