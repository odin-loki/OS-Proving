int
struct mbo *	mbo
