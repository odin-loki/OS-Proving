int
struct sk_buff *	skb
enum nft_registers	dreg
u32	modulus
enum nft_ng_types	type
u32	offset
