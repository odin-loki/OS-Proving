int
struct iopf_group *	group
