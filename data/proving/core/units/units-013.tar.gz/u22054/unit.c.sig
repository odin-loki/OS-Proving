int
struct ccr_softc *	sc
struct ccr_session *	s
struct cryptop *	crp
const struct cpl_fw6_pld *	cpl
int	error
