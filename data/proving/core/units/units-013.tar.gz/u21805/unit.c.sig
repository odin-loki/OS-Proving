u64
enum chip_type	chip
const struct sk_buff *	skb
