u_int
u_int	bus_width
