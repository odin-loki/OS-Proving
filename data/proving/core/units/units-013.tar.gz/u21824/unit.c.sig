int
struct be_eq_obj *	eqo
