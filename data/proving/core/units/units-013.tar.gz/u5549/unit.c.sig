int
struct pci_host_bridge *	bridge
struct pci_dev *	pdev
