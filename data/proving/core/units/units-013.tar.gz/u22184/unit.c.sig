int
u8	reg
int	mode
