int
int	pool
int	size
int	elements
