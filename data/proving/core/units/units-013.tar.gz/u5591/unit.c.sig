int
struct otx2_mbox *	mbox
int	devid
u16	pcifunc
u16	id
