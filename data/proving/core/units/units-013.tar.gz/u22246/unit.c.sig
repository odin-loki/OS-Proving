int
struct hl_device *	hdev
u32	q_idx
struct hl_hw_sob **	hw_sob
u32	count
bool	encaps_sig
