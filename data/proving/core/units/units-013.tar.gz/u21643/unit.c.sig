int
struct dvb_frontend *	fe
u16 *	snr
