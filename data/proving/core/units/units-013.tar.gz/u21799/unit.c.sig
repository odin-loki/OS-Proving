unsigned int
unsigned int	chnl
