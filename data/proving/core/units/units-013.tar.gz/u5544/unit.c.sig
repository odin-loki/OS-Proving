enum acc_err_result
struct hisi_qm *	qm
