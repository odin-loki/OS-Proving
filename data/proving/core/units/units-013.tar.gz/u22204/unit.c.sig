int
struct xfs_scrub *	sc
