int
struct mtk_hsdma_device *	hsdma
