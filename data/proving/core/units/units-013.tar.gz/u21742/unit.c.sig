int
struct cdnsp_device *	pdev
struct cdnsp_ring *	ep_ring
u32	ep_state
unsigned
         int	num_trbs
gfp_t	mem_flags
