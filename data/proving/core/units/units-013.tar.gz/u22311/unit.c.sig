int
struct tpda_drvdata *	drvdata
struct coresight_device *	csdev
