int
u32	dcmd
