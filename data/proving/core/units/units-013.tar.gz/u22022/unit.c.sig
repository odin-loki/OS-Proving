int
struct intel8x0m *	chip
unsigned int	codec
