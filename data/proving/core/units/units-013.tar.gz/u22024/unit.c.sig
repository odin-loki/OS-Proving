unsigned int
unsigned int	total_cnt
unsigned int	rd_idx
unsigned int	wr_idx
enum dpmaif_rdwr	rd_wr
