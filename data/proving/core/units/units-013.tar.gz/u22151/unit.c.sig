unsigned int
int	error1
int	error2
