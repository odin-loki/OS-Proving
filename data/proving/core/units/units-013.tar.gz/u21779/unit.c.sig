bool
struct comedi_device *	dev
unsigned int	reg
