u32
u32	buf_len
u32	max_burst
u32	threshold
enum dma_slave_buswidth	width
