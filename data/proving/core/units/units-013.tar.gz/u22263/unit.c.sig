int
u32	flags
size_t	argsz
u32	supported_ops
size_t	minsz
