u64
u64	a
u32	mul
u32	div
