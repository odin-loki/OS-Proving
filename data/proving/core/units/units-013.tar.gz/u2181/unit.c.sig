int
enum i2c_status	status
