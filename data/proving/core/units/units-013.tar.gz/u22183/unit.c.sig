int
struct ef4_nic *	efx
u32	type
