u32
unsigned int	cpb_size
unsigned int	bitrate
