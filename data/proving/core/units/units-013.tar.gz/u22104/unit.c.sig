void
struct xfrm_iptfs_data *	xtfs
u32	shift
