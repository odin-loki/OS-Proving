int
u16	acs_ctrl_req
u16	acs_ctrl_ena
