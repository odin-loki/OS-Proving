int
const struct nfp6000_pcie *	nfp
const struct nfp_bar *	bar
u32 *	bar_config
u64 *	bar_base
int	tgt
int	act
int	tok
u64	offset
size_t	size
int	width
