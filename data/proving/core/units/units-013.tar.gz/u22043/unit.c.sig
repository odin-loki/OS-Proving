int
struct qcom_ess_edma_softc *	sc
int	queue
