bool
int	len
