unsigned int
struct vnic_wq_copy *	wq
