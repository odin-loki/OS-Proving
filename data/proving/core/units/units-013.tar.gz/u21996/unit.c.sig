int
HTAB *	hashp
int	nsegs
