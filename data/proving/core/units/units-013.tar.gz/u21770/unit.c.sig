ib_net32_t
const uint8_t	ver
const uint8_t	tclass
const uint32_t	flow_lbl
