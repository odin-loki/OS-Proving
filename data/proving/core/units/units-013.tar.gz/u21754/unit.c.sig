int
struct cldma_ctrl *	md_ctrl
