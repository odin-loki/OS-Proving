int
struct reserved_mem *	rmem
