int
struct mvpp2_port *	port
phy_interface_t	interface
