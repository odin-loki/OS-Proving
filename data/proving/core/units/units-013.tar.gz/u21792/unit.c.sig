u8
int	ramp
