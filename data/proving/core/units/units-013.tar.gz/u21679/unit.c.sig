int
struct cc_drvdata *	drvdata
