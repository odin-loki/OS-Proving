int
struct ia_css_rmgr_vbuf_pool *	pool
