int
const struct pvscsi_adapter *	adapter
