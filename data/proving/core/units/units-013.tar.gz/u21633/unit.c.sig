int
struct b43legacy_dmaring *	ring
struct b43legacy_dmadesc32 *	desc
struct b43legacy_dmadesc_meta *	meta
gfp_t	gfp_flags
