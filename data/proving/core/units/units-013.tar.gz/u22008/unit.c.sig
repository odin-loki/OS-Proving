int
u32 *	location
Elf64_Addr	v
bool	rela
