int
struct inode *	dir
umode_t *	mode
struct ceph_acl_sec_ctx *	as_ctx
