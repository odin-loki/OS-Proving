int
struct em_sti_priv *	p
unsigned int	user
