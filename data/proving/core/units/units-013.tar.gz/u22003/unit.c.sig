u32
const struct uvc_urb *	uvc_urb
