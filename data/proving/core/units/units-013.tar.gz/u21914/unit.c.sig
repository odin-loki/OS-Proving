int
unsigned int	sync_clk
