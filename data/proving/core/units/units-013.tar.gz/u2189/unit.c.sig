int
ffa_fn **	invoke_ffa_fn
