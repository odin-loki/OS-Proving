enum intel_fbc_id
enum pipe	pipe
