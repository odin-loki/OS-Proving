int
struct qcom_scm *	scm
