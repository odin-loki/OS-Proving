void
struct gsi *	gsi
u32	evt_ring_id
u32	index
