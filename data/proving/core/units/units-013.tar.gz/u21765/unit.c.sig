int
struct inode *	inode
int	type
