bool
int	type
