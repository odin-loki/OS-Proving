int
struct dn_sch_inst *	si
