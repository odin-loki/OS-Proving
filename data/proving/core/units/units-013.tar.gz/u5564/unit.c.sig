int
struct vfio_dma *	dma
unsigned long	vaddr
unsigned long *	pfn_base
bool	do_accounting
