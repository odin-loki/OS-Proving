long long
unsigned long long	nsec
