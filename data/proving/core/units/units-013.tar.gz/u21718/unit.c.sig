u16
struct radeon_device *	rdev
const u16	prev_std_vddc
const u16	curr_std_vddc
