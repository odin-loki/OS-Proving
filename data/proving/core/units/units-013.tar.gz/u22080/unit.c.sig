int
int	ioreg
