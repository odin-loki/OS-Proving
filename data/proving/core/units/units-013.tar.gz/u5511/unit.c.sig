int32_t
int32_t	hi
int32_t	lo
