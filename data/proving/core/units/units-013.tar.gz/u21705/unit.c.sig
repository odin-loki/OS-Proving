int
qla_host_t *	ha
bus_dma_segment_t *	segs
int	nsegs
uint32_t	tx_idx
struct mbuf *	mp
uint32_t	txr_idx
uint32_t	iscsi_pdu
