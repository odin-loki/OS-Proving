int
struct pcs_device *	pcs
unsigned int	offset
