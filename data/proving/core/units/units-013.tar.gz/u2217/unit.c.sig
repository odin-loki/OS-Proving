int
const struct ng_parse_type *	type
const u_char *	start
const u_char *	buf
