int
struct autofs_sb_info *	sbi
struct file *	file
const void *	addr
int	bytes
