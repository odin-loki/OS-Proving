int
struct xfsb_bitmap *	bitmap
xfs_fsblock_t	start
xfs_filblks_t	len
