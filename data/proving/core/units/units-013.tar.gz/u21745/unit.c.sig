unsigned int
u8	reg
u8	mode
