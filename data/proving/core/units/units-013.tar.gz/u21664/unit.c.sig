int
const unsigned long *	l1
const unsigned long *	l2
size_t	n
