u32
struct brcms_c_info *	wlc
u32	rspec
bool	use_rspec
u16	mimo_ctlchbw
