u64
unsigned int	pixel_rate
unsigned int	cycles
