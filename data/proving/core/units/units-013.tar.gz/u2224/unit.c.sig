unsigned long
u8	clock
