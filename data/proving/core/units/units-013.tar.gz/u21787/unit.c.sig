int
struct ftrace_ops *	ops
unsigned long	addr
