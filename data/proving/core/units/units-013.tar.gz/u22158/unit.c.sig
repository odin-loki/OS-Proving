u8
u8	slot_num
