int
struct snd_soc_dai *	dai
