unsigned long
unsigned int	psvalue
