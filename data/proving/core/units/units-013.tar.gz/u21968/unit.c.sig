int
const struct ieee80211_scanner *	scan
struct ieee80211vap *	vap
int	flags
u_int	duration
u_int	mindwell
u_int	maxdwell
u_int	nssid
?	?
