int
struct dm_verity *	v
