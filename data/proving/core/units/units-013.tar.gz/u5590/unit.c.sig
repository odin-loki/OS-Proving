int
struct scsi_device *	sdp
