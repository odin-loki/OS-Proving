flag
float32	a
float32	b
