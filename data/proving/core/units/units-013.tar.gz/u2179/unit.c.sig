unsigned int
u16	val
