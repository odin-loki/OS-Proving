int
u_long	addr
