u32
int *	x
int *	y
unsigned int	cpp
unsigned int	pitch
u32	old_offset
u32	new_offset
