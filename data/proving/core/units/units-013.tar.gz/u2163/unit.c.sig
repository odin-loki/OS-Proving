unsigned int
u64	val
u64	total
