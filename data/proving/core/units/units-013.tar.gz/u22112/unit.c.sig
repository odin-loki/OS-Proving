u16
u64	pteflags
