int
struct adf_accel_dev *	accel_dev
struct adf_rl_sla_input_data *	sla_in
bool	is_update
