uint
struct brcms_c_info *	wlc
