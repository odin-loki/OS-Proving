int
struct cudbg_init *	pdbg_init
struct cudbg_buffer *	dbg_buff
struct cudbg_error *	cudbg_err
