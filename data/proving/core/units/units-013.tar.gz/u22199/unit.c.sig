s16
struct brcms_phy *	pi
bool	mode
