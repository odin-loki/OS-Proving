int
size_t	v
