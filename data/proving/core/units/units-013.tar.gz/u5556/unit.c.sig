bool
struct kvm_vcpu *	vcpu
