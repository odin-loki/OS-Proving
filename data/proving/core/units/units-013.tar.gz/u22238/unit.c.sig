u16
struct ath_hw *	ah
u8	ctlmode
