int
u32	user_n_regs
u64	user_regs_ptr
u32	kernel_n_regs
