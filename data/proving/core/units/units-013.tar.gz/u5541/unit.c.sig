int
struct efx_nic *	efx
struct sk_buff *	skb
