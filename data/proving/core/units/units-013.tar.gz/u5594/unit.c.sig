int
struct crypto_aead *	aead
const u8 *	key
unsigned int	keylen
