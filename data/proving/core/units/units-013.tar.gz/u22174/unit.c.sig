s8
struct brcms_phy *	pi
bool	mode
