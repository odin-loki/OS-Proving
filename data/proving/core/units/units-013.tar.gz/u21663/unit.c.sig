int
const struct fb_info *	info
u32	vclk_per
u32	bpp
union aty_pll *	pll
