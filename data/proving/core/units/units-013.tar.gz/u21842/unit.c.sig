int
struct spinand_device *	spinand
