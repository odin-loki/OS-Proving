int
struct mtd_info *	mtd
struct mtd_partition *	parts
int	nr_parts
