bool
u32	val
u32	start
u32	end
