enum tpm2_mso_type
u32	handle
