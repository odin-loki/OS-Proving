int
struct kprobe *	p
