uint32_t
unsigned long	clk_rate_khz
