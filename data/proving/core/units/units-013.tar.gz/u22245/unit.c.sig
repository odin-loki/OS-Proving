int
struct smc_connection *	conn
struct smc_rdma_wr *	wr_rdma_buf
