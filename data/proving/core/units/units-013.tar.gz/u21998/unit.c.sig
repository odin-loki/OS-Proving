int
struct atl1e_adapter *	adapter
