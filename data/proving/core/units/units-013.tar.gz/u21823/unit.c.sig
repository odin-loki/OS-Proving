bool
const u64	csb
