bool
const struct exception_table_entry *	ex
struct pt_regs *	regs
