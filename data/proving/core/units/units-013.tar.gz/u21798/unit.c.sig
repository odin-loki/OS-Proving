u16
MemPage *	pPage
u8 *	pCell
