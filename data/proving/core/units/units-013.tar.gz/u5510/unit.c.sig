u8
int	link_rate
