int
const struct nlattr *	nla
struct fib6_rule *	rule6
struct netlink_ext_ack *	extack
