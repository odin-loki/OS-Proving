int
unsigned int	advise
