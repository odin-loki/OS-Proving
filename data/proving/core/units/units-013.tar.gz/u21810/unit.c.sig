int
struct crypto_acomp_streams *	s
