u64
u64	spte
