int
struct et_softc *	sc
