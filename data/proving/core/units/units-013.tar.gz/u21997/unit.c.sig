int
struct iwm_softc *	sc
enum iwm_ucode_type	type
const uint8_t *	data
size_t	dlen
