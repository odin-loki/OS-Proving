int
struct npe *	npe
u32	instr
u32	ctx
u32	ldur
