int
struct xoff_bitmap *	bitmap
xfs_fileoff_t	off
xfs_filblks_t	len
