int
int	count
