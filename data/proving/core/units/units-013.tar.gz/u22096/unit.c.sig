enum mei_cb_file_ops
u8	req
