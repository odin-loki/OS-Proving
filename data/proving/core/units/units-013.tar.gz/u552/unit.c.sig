int
u16	ddrcsr
