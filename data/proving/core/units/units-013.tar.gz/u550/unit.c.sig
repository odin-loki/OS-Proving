int
device_t	dev
int	target
int	mode
