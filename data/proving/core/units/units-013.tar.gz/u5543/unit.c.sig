int
struct ntfs_inode *	ni
enum ATTR_TYPE	type
const __le16 *	name
u8	name_len
const struct runs_tree *	run
CLST	svcn
CLST	len
__le16	flags
struct ATTRIB **	new_attr
struct mft_inode **	mi
struct ATTR_LIST_ENTRY **	le
