int
void *	rom_start
