int
struct xilinx_dma_chan *	chan
int	size
int	done
