int
struct nicpf *	nic
int	new_frs
int	vf
