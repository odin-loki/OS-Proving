void
struct ice_hw *	hw
u16	num_qs
u16 *	num_nodes
