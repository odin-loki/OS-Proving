bool
const struct drm_rect *	r1
const struct drm_rect *	r2
