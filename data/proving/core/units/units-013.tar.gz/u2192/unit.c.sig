int
struct socket *	sock
struct msghdr *	m
size_t	dlen
