int
struct pci_config_window *	cfg
