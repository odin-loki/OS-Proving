int
struct cdev *	dev
u_long	cmd
caddr_t	data
int	fflag
struct thread *	td
