u16
int	len
