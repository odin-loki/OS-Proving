int
struct rtl8xxxu_priv *	priv
