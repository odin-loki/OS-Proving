int
struct exynos_tmu_data *	data
