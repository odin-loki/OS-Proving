u8
u16	reg
