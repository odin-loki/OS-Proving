int
regex_t *	preg
int	p
int	max
