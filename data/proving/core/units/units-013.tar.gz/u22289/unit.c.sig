gfn_t
u32	gpte
