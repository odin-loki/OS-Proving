bool
u64	start
u64	end
u64	ts
