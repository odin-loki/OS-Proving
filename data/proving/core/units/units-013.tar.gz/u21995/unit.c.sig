unsigned int
struct enic *	enic
unsigned int	cq_index
unsigned int	work_to_do
