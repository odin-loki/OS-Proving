int
const struct drm_rect *	r
