int
struct hl_device *	hdev
u16	event_type
u64	mmu_base
bool	is_pmmu
u64 *	event_mask
