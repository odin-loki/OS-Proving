int
struct mvneta_softc *	sc
int	q
int	count
