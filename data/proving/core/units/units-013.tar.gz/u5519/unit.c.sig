unsigned long
struct rpc_clnt *	clnt
int	error
?	?
const void *	data
