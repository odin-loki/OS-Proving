int
struct virtio_device *	vdev
