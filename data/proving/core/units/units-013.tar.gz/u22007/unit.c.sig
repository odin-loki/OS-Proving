bool
sci_t	sci
