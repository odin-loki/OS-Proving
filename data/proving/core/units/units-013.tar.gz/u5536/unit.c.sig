int
enum ieee8021q_traffic_type	tt
unsigned int	num_queues
