bool
unsigned int	seq
