int
int	temp
