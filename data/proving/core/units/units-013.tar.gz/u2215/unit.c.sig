int
enum intel_output_format	output_format
int	bpp
