u32
struct nvbios_init *	init
u32	reg
