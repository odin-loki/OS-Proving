bool
const struct exception_table_entry *	x
struct pt_regs *	regs
