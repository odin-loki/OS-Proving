u64
u64	user_input
u32	m
u32	n
