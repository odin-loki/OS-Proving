u32
u32	index
u32	length
u32	inc
