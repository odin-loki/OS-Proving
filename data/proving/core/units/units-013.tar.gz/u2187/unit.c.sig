u_int
int	pq
