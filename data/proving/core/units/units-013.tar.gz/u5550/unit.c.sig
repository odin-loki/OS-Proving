int
u64 *	out
const u64	in
