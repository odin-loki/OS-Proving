enum virtchnl_status_code
int	err
