int
struct lpfc_nodelist *	ndlp
