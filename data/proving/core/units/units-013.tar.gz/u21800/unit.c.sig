int
struct sock *	sk
char *	optval
int *	optlen
