int
const char *	buf
const char *	migrate_info
