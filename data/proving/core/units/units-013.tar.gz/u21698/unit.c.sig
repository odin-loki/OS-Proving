int
struct rpc_rqst *	req
struct xdr_stream *	xdr
void *	data
