int
void *	audio_ptr
int	pin_nid
