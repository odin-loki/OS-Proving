int
struct inode *	inode
loff_t	size
