int
struct cros_ec_device *	ec_dev
int	need_len
