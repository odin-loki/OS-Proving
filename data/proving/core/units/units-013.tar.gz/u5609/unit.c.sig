unsigned int
struct request *	rq
