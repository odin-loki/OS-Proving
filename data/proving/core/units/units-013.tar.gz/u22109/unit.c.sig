bool
unsigned long	exit_code
