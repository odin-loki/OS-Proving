int
struct cachefiles_cache *	cache
struct dentry *	dir
char *	filename
