int
u64	info
