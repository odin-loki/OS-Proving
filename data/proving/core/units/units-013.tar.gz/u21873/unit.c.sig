unsigned int
struct dmz_reclaim *	zrc
