int
u8	candidate_dly
