int
struct sdw_intel *	sdw
struct sdw_cdns_pdi *	pdi
unsigned int	num_pdi
unsigned int *	num_ch
