int
void *	nh
int	len
