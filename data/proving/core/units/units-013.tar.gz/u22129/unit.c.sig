int
struct smmu_softc *	sc
int	sid
