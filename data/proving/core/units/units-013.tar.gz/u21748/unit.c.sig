uint16_t
struct pcg_state_16*	rng
