int
unsigned int	mtu
