int
struct i2c_client *	i2c
struct da9121 *	chip
