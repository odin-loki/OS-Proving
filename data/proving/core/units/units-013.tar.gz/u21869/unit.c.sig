int
struct smb347_charger *	smb
bool	writable
bool	irq_toggle
