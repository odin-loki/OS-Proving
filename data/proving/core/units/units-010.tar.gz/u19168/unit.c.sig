int
struct mgb4_vout_dev *	voutdev
int	id
