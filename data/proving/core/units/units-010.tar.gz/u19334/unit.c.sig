struct tegra_bpmp *
struct device *	dev
