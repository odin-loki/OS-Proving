u64
struct em_sti_priv *	p
