int
struct device *	dev
void *	regs
