int
enum ima_hooks	func
const void *	buf
loff_t	buf_len
struct modsig **	modsig
