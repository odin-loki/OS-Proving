u32
unsigned long	cfg_val
unsigned long	clk_hz
