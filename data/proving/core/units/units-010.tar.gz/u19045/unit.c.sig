enum reset_type
enum reset_type	reason
