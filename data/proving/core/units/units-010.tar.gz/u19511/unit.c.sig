int
struct phy *	phy
u8	lane
