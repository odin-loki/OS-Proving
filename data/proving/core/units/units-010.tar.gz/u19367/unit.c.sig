u32
struct cmdq_base *	req
