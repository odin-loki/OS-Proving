int
caddr_t	cp
caddr_t	cplim
struct rt_addrinfo *	rtinfo
