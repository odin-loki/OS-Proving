u64
u64	x
int	which
