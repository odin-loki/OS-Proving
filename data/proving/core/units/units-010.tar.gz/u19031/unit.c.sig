u32
u32	lp_clk_rate
unsigned long	us
