unsigned short
struct SiS_Private *	SiS_Pr
unsigned int	VBFlags
int	VGAEngine
unsigned short	adaptnum
unsigned short	DDCdatatype
bool	checkcr32
unsigned int	VBFlags2
