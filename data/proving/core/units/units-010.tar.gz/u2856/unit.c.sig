int
const u8 *	data
int	bit
