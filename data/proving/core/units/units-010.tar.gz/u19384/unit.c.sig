int
struct smc_sock *	smc
struct msghdr *	msg
int	len
int	flags
