int
struct zs_pool *	pool
