int
unsigned long	vaddr
int	numpages
bool	enc
