int
struct gve_priv *	priv
struct gve_tx_ring *	tx
int	budget
