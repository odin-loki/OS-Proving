bool
int	type
struct trace_pid_list *	pid_list
struct trace_pid_list *	no_pid_list
