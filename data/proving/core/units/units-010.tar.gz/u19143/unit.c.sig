unsigned int
unsigned int	v
int	a
int	b
