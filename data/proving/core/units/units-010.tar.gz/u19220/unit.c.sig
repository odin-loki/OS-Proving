kernel_cap_t
u32	low
u32	high
