uint16_t
struct pcg_state_setseq_32*	rng
uint16_t	bound
