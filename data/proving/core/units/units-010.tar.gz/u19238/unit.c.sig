int
struct rt_addrinfo *	info
uint32_t	fibnum
