u8
int	cdclk
