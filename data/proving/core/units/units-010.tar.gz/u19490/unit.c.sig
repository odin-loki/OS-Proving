int
unsigned long	start_pfn
unsigned long	end_pfn
enum pb_isolate_mode	mode
