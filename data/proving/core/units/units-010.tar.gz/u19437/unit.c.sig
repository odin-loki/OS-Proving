int
struct ci_hdrc *	ci
