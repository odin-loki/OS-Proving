int
unsigned int	target_speed
