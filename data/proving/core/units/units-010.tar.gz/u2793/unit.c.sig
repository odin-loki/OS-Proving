u_int
u_int	cfg
