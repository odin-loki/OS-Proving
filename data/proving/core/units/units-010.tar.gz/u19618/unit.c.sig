int
u_int *	deb
