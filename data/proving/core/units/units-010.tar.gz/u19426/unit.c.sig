int
struct acpi_table_header *	table
