unsigned int
unsigned int	tile_r
unsigned int	sbs_r
