int
struct iosm_mux *	ipc_mux
struct mux_adbh *	adbh
struct mux_adth_dg *	dg
struct sk_buff *	skb
int	if_id
int	nr_of_dg
