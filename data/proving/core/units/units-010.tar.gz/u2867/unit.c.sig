int
struct nvkm_vmm *	vmm
void *	argv
u32	argc
struct nvkm_vmm_map *	map
