int
struct nge_softc *	sc
int	idx
