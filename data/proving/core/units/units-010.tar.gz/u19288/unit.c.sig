bool
struct g2d_data *	g2d
struct g2d_buf_desc *	buf_desc
enum g2d_reg_type	reg_type
unsigned long	size
