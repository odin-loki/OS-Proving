unsigned int
const struct usb_endpoint_descriptor *	epd
enum usb_device_speed	speed
