enum mlxsw_reg_sfmr_op
bool	valid
