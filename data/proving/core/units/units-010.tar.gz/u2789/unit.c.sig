int
struct hinic3_rxq *	rxq
int	budget
