int
u32	clock_id
u32	parent_id
