int
struct s_zstate *	zs
code_int	ocode
