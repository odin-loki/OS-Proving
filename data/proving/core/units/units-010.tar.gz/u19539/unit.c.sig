int
struct nf_log_buf *	m
const struct sk_buff *	skb
u8	proto
int	fragment
unsigned int	offset
unsigned int	logflags
