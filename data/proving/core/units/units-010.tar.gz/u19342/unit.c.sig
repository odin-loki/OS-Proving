ssize_t
u32 *	dst
struct mcu_msg_put_stream_buffer *	msg
