u8
u8	status_read
u8	status_written
