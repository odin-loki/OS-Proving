u16
struct radeon_device *	rdev
u16	voltage
