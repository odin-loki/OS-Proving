int
int *	array
int	arraysize
