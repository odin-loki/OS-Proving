unsigned long
char *	str
