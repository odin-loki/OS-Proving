int
unsigned int *	val
u8	c
