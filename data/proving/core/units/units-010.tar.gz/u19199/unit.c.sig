int
struct sym_quehead *	head
