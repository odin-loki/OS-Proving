bool
u64	uaddr
u64	size
