bool
u8	temp
