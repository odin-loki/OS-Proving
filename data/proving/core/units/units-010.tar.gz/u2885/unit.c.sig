int
struct videocodec *	codec
const struct tvnorm *	norm
struct vfe_settings *	cap
struct vfe_polarity *	pol
