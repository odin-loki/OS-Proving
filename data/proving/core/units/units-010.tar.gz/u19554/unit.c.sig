int
struct exynos_dp_device *	dp
