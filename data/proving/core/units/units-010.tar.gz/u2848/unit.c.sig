int
void *	addr
unsigned int	bit
