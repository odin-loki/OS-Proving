int
u32 *	fifo
u8 *	buf
struct goku_request *	req
unsigned	max
