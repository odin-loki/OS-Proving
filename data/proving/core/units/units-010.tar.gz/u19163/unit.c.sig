uint64_t
uint64_t	ofs
