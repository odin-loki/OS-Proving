int
struct bsg_job *	job
