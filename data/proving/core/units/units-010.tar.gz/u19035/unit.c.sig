void
ocs_hw_t *	hw
hw_cq_t *	cq
