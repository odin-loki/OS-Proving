int
struct aac_dev *	dev
