unsigned int
unsigned int	qid
u32	stride
