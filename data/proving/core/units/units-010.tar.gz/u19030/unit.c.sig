int
struct pl022 *	pl022
struct pl022_config_chip const *	chip_info
