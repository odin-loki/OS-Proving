int
void *	data
int	datalen
void *	ecc
int	ecclen
void *	extraoob
int	extraooblen
int	bitflips_threshold
