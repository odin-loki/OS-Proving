bool
struct xdr_stream *	xdr
struct xdr_buf *	subbuf
unsigned int	nbytes
