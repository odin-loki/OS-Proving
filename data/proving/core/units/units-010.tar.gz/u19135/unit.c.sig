int
u32	error
