u8
u8	chip_chainmask
u8	eeprom_chainmask
