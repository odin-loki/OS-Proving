int
struct firedtv *	fdtv
