int
u8	result
