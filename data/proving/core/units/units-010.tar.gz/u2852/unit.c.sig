int
struct ifnet *	ifp
u_long	cmd
caddr_t	data
