int
u16	seg
struct device *	dev
char *	estr
