unsigned int
unsigned int	flags
int	type
