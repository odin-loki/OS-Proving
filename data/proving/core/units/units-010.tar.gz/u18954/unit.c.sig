int
struct hci_dev *	hdev
bdaddr_t *	bdaddr
u8	bdaddr_type
