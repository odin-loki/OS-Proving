int
struct thin_disk_superblock *	disk_super
struct dm_pool_metadata *	pmd
