bool
const struct fwht_cframe_hdr *	p_hdr
