int
struct snps_hdmirx_dev *	hdmirx_dev
u32	reg
u32	bit_mask
u32	expect_val
bool	is_grf
u32	ms
