u32
u32	srcsize
u32	dstsize
u32	phidef
