int
struct sta_info *	sta
