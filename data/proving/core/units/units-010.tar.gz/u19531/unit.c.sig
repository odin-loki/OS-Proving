u16
const struct mlxsw_sp_fid *	fid
const struct mlxsw_sp_flood_table *	flood_table
