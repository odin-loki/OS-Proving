int
struct erdma_cq *	cq
struct ib_wc *	wc
