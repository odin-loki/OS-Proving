int
struct bnx2x *	bp
struct bnx2x_queue_state_params *	params
