unsigned long
int	nr_pages
