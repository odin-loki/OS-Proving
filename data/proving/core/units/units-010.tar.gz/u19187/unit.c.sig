bool
scsi_qla_host_t *	vha
