int32_t
ocs_hw_t *	hw
