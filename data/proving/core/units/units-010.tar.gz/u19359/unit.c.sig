int
struct tcm_loop_tpg *	tl_tpg
u64	lun
int	task
enum tcm_tmreq_table	tmr
