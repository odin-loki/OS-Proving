int
struct max8925_chip *	chip
int	irq
struct max8925_platform_data *	pdata
