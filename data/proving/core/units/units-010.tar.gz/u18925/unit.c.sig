int
struct pinctrl_dev *	pctldev
struct pinctrl_gpio_range *	range
unsigned int	pin
