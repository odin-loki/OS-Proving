bool
struct adf_rl_sla_input_data *	sla_in
struct rl_sla *	sla_parent
u32	sla_cir
bool	is_update
