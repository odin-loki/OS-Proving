int
struct applespi_data *	applespi
struct touchpad_info_protocol *	rcvd_tp_info
