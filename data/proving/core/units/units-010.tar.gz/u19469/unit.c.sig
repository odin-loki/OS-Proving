int
l_dev_t	_dev
