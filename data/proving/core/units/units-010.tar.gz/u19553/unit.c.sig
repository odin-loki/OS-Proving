int
struct device *	dev
struct regmap *	sysc
