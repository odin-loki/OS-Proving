s32
s16	ambient_new_raw
s16	ambient_old_raw
u16	P_G
u16	P_O
s16	Gb
