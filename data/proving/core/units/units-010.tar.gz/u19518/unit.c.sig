u16
int	speed
int	duplex
