int
struct bdc_ep *	ep
