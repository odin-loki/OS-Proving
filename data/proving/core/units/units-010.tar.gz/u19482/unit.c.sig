bool
int	ts_cap
