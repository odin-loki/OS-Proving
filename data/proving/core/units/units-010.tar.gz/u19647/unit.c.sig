u32
struct ib_device *	ibdev
u32	port_num
