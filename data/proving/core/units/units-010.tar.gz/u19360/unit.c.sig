uLong
z_streamp	strm
uLong	sourceLen
