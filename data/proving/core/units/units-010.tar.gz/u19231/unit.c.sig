int
struct drm_device *	dev
struct drm_fb_helper *	fb_helper
