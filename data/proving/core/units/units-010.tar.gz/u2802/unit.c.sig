int
unsigned int	fsbspeed
