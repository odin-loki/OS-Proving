int
struct nvkm_disp *	disp
int	index
struct nvbios_connE *	info
struct nvkm_conn **	pconn
