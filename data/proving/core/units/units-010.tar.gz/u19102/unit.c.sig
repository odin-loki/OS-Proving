int
struct rpmsg_device *	rpdev
void *	data
int	count
void *	priv
u32	addr
