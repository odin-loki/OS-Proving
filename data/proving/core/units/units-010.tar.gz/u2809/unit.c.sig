enum xgene_ring_owner
u16	id
