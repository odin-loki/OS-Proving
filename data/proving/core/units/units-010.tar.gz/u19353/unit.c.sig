sector_t
struct raid_set *	rs
unsigned long	recovery
enum sync_state	state
sector_t	resync_max_sectors
