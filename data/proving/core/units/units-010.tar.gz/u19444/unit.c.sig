int
unsigned int	n
unsigned int	out_of
