enum drm_plane_type
unsigned int	plane_idx
unsigned int	num_planes
