int
struct i2c_client *	client
unsigned char *	buf
int	len
