int
unsigned long	rate
