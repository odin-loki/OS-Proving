int
struct xfs_scrub *	sc
xfs_rgblock_t	rgbno
xfs_filblks_t	len
