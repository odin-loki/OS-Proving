int
struct ksignal *	ksig
