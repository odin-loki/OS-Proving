u32
u64	n
u32	d
