unsigned __used
unsigned	n
