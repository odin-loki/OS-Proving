int
const char *	param
int	max_entries
unsigned long *	sizes
unsigned long *	paddrs
