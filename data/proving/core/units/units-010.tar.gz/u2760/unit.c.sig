int
struct ubifs_info *	c
int	cnt
