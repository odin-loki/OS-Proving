int
struct device *	dev
struct scatterlist *	sgl
int	nelems
enum dma_data_direction	dir
unsigned long	attrs
