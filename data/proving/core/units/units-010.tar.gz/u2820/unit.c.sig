int
struct nfsd4_session *	ses
int	dec
