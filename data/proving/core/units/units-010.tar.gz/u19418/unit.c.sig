int
struct asus_laptop *	asus
struct asus_led *	led
const char *	name
const char *	method
