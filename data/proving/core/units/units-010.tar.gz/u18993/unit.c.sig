int
struct rq *	rq
struct task_struct *	t
struct mm_struct *	mm
