enum ng_parse_token
const char *	s
int *	startp
int *	lenp
