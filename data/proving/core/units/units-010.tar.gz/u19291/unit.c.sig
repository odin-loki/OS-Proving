int
struct hns_roce_dev *	hr_dev
struct hns_roce_v2_cmq_ring *	csq
