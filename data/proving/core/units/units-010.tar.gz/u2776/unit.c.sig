int
struct cpuidle_driver *	drv
struct cpuidle_device *	dev
