int
struct visl_dev *	dev
