unsigned int
struct pxad_chan *	chan
dma_cookie_t	cookie
