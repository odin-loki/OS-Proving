int
struct g_consumer *	cp
uint32_t	blk
struct apm_ent *	ent
int	tivo_series1
