int
struct vcap_rule_internal *	ri
