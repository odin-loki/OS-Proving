bool
u32	psn
