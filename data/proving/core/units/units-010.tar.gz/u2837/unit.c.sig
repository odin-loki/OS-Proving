s8
struct b43_wldev *	dev
u8	in_rssi
int	ofdm
int	adjust_2053
int	adjust_2050
