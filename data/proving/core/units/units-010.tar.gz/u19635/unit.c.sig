u32
u32	mfs_max
u32	mfs_tc
