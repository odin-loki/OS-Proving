u32
struct gve_priv *	priv
u32	queue_idx
