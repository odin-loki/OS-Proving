int
struct occ *	occ
struct occ_response *	resp
u16	data_length
