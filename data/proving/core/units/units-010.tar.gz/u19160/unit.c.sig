int
struct mlxsw_core *	mlxsw_core
const struct mlxsw_bus_info *	mlxsw_bus_info
struct mlxsw_hwmon **	p_hwmon
