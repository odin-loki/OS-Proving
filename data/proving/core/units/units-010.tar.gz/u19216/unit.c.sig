int
struct iio_dev *	indio_dev
int	val
int	val2
