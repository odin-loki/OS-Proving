int
struct intel_pmc_dev *	pmc
u32	offset
u64 *	data
