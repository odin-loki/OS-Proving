int
struct mt7915_dev *	dev
struct mt7915_phy *	phy2
