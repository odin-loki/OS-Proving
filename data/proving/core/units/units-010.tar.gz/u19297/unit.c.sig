int
struct ceph_osd_req_op *	op
int	cnt
