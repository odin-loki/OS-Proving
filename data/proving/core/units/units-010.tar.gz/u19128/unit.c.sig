int
struct nvkm_therm *	therm
int	line
