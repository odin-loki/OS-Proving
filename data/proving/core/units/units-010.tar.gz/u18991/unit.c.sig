int
struct device *	dev
struct regmap *	regmap
const struct visconti_reset_data *	resets
unsigned int	num_resets
const struct reset_control_ops *	reset_ops
spinlock_t *	lock
