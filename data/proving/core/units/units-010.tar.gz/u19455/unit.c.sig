unsigned
const void*	src
size_t	srcSize
