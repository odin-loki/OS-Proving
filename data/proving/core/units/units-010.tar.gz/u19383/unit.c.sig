int
struct mlx5e_priv *	priv
u32	id
u32 *	ipsec_obj_id
