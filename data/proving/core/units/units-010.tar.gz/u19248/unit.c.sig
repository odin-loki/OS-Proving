int
char **	stringp
u_long *	setp
u_long *	clrp
