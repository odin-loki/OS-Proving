pci_ers_result_t
struct pci_dev *	dev
pci_channel_state_t	state
