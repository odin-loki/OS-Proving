u32
enum media_gobj_type	type
u64	local_id
