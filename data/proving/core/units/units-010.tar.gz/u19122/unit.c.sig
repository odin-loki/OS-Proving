int
scsi_qla_host_t *	vha
uint32_t	addr
