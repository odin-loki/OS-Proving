bool
struct scatterlist *	src
size_t	src_len
const u8 *	ad
const size_t	ad_len
const u64	nonce
?	?
