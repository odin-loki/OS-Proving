int
long	ioaddr
