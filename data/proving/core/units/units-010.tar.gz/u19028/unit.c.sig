int
int	width
