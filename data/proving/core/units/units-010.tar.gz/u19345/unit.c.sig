int
struct lpfc_hba *	phba
uint32_t	size
