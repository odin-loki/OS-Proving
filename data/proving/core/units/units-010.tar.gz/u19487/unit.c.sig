int
struct rnandc *	rnandc
struct nand_chip *	chip
