unsigned int
unsigned int *	nanosec
unsigned int	flags
