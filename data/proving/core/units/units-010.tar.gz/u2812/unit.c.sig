blkcnt_t
u64	size
