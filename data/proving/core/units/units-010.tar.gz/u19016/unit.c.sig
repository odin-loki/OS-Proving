unsigned int
u32	val
