u32
unsigned int	cap
u32	fmt_value
