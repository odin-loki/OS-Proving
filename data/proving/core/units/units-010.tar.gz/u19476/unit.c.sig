u32
struct cdnsp_device *	pdev
int	transferred
int	trb_buff_len
unsigned int	td_total_len
struct cdnsp_request *	preq
bool	more_trbs_coming
bool	zlp
