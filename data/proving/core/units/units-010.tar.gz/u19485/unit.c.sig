int
struct bpf_dynptr *	data_p
struct bpf_dynptr *	sig_p
struct bpf_key *	trusted_keyring
