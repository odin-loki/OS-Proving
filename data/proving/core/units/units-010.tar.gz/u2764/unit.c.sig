int
struct gpio_chip *	gc
unsigned long *	valid_mask
unsigned int	ngpios
