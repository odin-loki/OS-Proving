void
struct drm_rect *	r
int	dw
int	dh
