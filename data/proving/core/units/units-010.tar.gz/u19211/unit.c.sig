void
uint32	seed
