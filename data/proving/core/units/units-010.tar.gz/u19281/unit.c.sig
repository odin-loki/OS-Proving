int
struct pinctrl_dev *	pctldev
unsigned int	pin
unsigned long *	configs
size_t	nconfigs
