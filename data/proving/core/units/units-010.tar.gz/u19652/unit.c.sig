bool
u32	link
