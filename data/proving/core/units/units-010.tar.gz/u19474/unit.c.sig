int
DateTime *	pDate
