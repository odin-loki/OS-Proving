bool
u64	time
u64	limit
int	signo
bool	rt
bool	hard
