int
struct vivid_dev *	dev
