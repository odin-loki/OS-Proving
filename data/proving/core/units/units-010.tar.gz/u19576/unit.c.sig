int
struct scsi_device *	sdev
struct rdac_dh_data *	h
char *	array_name
u8 *	array_id
