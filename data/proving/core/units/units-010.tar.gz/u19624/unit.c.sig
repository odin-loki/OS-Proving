int
struct iscsi_task *	task
uint8_t	opcode
