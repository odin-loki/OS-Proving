u32
u32	ep_ro
struct rnd_state *	state
