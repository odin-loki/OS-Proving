int
const struct btrfs_fs_info *	fs_info
enum btrfs_feature_set	set
u64	change_mask
u64	flags
u64	supported_flags
u64	safe_set
u64	safe_clear
