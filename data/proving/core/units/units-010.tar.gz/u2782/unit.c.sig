int
int	delay
int	rate
