int
struct pci_bus *	bus
struct resource *	res
resource_size_t	size
resource_size_t	align
resource_size_t	min
unsigned long	type_mask
resource_alignf	alignf
void *	alignf_data
