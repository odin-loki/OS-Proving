int
unsigned long	pclk
unsigned long	lclk
enum omap_overlay_caps	caps
const struct omap_video_timings *	mgr_timings
u16	width
u16	height
u16	out_width
u16	out_height
enum omap_color_mode	color_mode
bool *	five_taps
int *	x_predecim
int *	y_predecim
u16	pos_x
enum omap_dss_rotation_type	rotation_type
bool	mem_to_mem
