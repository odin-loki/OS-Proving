int
int	resno
