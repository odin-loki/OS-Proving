int
struct amvdec_session *	sess
