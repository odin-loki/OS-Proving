u16
const struct slope *	slopes
u8	num
s16	val
