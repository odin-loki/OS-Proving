int
const union dlm_packet *	p
uint16_t	msglen
int	nodeid
