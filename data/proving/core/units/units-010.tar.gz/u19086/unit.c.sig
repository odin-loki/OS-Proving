unsigned int
unsigned int	dpi_timing
unsigned int	dpi_bpp
unsigned int	dsi_pkt_overhead
