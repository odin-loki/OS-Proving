u32
u32	value
u32	resolution
