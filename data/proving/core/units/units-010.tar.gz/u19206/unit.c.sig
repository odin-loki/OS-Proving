int
struct ida *	ida
gfp_t	gfp
