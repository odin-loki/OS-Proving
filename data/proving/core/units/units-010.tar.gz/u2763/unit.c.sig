unsigned int
unsigned int	nr_segs
