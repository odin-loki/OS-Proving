int
struct amdgpu_device *	adev
struct ras_badpage **	bps
unsigned int *	count
