int
struct cyapa *	cyapa
