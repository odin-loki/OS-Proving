int
struct kvm *	kvm
u64	pfn
