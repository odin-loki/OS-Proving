int
struct hci_dev *	hdev
u8	pattern
u32	len
