u16
u16	sn
