u8
bool	hr12
int	hour
