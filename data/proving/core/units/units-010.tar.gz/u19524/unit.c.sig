uint64_t
struct pcg_state_setseq_64*	rng
uint64_t	bound
