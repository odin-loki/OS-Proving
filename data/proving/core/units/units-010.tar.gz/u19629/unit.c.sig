int
struct tg3 *	tp
int	kind
bool	silent
