int
struct device *	host
struct cxl_memdev *	cxlmd
