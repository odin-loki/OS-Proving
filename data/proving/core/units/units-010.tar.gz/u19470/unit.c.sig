int
struct open_file *	f
