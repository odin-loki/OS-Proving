gfn_t
u64	spte
