int
struct rtc_device *	rtc
const struct attribute_group **	grps
