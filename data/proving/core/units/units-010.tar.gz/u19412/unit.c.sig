int
struct mt6370_priv *	priv
unsigned int	led_no
unsigned int	ton
unsigned int	toff
