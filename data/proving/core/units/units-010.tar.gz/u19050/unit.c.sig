struct svc_i3c_xfer *
struct svc_i3c_master *	master
unsigned int	ncmds
