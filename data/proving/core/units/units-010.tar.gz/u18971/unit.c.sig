int
const u8 *	z
int	n
u32 *	piOut
