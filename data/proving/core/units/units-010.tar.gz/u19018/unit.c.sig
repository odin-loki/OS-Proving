int
struct i915_ggtt *	ggtt
struct drm_mm_node *	node
u32	size
