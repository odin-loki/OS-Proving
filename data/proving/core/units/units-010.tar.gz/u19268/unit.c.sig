int
struct rockchip_sfc *	sfc
const u8 *	buf
int	len
