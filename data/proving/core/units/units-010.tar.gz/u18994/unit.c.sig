U32
U32	block_descriptor_length
U32	cdb_size
