u_long
u_long	addr
