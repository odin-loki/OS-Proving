int
u16	val
int	wps2
