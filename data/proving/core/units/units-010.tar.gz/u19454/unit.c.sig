uint32_t
uint32_t	rss_hash
