int
int	irq
unsigned long	clock_tick_rate
