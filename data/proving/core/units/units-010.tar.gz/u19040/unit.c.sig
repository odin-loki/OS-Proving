unsigned int
struct virtqueue *	vq
struct vring_desc *	desc
struct vring_desc_extra *	extra
unsigned int	i
dma_addr_t	addr
unsigned int	len
u16	flags
bool	premapped
