int32_t
int	strength
