U32
U32	windowLog
U64	srcSize
U64	dictSize
