int
unsigned int	mask
int	true_val
int	false_val
