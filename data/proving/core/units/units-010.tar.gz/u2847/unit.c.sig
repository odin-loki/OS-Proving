long
void *	buf
unsigned long	len
