long
const u8	reg
const u16	val
