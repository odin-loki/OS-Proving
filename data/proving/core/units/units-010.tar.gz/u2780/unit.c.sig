int
unsigned int	iop_base
uchar	cmd_reg
