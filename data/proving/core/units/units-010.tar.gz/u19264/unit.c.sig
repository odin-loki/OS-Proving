int
struct ocfs2_dinode *	di
struct buffer_head *	bh
u32	blksz
struct ocfs2_blockcheck_stats *	stats
