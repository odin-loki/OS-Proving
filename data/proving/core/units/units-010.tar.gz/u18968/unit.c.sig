int
struct siw_qp *	qp
