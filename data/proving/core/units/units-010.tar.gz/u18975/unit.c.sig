int
struct kretprobe *	rp
