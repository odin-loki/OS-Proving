int
const struct rsp_desc *	r
