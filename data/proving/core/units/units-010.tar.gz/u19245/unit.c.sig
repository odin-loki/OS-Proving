bool
u16	seq1
u16	seq2
