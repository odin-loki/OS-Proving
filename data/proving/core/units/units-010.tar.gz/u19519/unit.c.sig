int_fast32_2s
const char *const	codep
