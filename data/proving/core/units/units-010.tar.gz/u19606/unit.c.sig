int
struct stv *	state
