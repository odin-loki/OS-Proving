bool
u8	syndrome
