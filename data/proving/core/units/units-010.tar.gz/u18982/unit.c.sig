resource_size_t
const struct resource *	r
