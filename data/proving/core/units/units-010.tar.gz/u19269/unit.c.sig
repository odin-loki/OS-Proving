int
struct tda1997x_state *	state
bool	on
