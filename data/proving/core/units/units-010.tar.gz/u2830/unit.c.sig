bool
struct vnic_rq *	vrq
u8	packet_error
u8	fcs_ok
u16	bytes_written
