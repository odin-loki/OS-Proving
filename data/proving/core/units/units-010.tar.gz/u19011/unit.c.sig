int
u8	div
u16	tach
