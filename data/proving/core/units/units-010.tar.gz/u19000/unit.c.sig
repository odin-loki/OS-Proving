uint32_t
int8_t	fec
