int
struct cpuset *	cur
struct cpuset *	trial
