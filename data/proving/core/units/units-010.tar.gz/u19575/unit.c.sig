int
int	ua
bool	cgain
