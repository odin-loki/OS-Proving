int
struct amdgpu_device *	adev
uint32_t	me
uint32_t	pipe
uint32_t	queue
uint32_t	xcc_id
