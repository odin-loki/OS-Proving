u32
struct idtcm_channel *	channel
