bool
struct resource *	a
struct resource *	b
