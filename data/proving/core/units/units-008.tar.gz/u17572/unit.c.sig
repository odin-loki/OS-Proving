bool
int	flags
bool	is_dir
