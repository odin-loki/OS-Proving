u32
u64	dividend
u32	divisor
u64 *	remainder
