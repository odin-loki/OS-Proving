unsigned int
u8	val
