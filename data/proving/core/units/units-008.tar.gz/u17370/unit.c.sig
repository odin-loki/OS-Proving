int
u32	share_access
