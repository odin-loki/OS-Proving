int
struct firewire_comm *	fc
int	sub
struct fw_xfer *	xfer
