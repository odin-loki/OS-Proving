int
int	thismask
int	checkmask
