void
u32 *	xres
u32 *	yres
