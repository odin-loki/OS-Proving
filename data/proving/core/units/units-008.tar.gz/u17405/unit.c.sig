u8
struct il_priv *	il
u8	time
u16	compensation
