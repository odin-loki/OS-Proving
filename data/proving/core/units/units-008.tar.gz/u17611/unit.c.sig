int
struct watchdog_device *	wdd
const char *	buf
