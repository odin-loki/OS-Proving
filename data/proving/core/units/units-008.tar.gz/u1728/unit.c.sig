u32
const struct macvlan_dev *	vlan
