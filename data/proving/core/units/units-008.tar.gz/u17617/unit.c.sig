u8
u32	last_ts_usec
u32	curr_ts_usec
u32	total_airtime_usec
