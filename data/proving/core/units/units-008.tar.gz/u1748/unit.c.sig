unsigned long
struct hpets *	hpets
unsigned long	dis
