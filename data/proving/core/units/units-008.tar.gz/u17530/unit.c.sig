int
struct mtk_ppe *	ppe
u32	ib1
