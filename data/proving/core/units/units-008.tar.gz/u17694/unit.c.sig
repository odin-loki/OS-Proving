bool
unsigned long	err
