bool
struct slgt_info *	info
const u8 *	buf
unsigned int	size
