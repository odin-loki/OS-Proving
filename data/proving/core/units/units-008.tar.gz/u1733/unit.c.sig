int
struct ecryptfs_msg_ctx *	msg_ctx
struct ecryptfs_message **	emsg
