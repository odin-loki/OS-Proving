int
struct net_device *	hsr_dev
struct net_device *	dev
enum hsr_port_type *	type
