unsigned long
unsigned long	nr_pages
unsigned long	highmem
unsigned long	total
