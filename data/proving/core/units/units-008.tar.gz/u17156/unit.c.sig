int
struct radeon_bl_privdata *	pdata
int	level
