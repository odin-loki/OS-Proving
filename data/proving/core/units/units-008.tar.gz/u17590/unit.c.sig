int
struct sdw_master_runtime *	m_rt
const struct sdw_port_config *	port_config
