unsigned int
struct memory_bitmap *	bm
unsigned int	n
