__always_inline u32
u32	t
u32	z
u32	nz
