bool
int	emul_type
