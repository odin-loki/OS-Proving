bool
s64	val
