int
struct mtk_wed_device *	dev
struct mtk_wed_ring *	ring
