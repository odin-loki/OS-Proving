ssize_t
struct ucma_file *	file
const char *	inbuf
int	in_len
int	out_len
