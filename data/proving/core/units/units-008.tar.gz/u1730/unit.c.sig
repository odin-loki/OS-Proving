int
int	year
int	days
