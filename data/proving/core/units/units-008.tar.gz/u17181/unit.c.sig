bool
int	start
int	spare
