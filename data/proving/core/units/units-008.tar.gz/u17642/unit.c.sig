u32
u32	phy_flags
