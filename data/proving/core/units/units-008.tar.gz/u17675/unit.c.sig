int
struct ubifs_info *	c
int	lnum
int	gap_start
int	gap_end
int *	dirt
