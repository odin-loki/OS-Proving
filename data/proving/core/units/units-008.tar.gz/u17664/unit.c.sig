int
struct hns_roce_dev *	hr_dev
struct ib_cq *	cq
struct ib_qp_init_attr *	init_attr
int	i
