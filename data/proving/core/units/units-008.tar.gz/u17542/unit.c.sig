u8
int	vout
u16	limit
bool	over
