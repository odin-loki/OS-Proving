u32
u16	freq
