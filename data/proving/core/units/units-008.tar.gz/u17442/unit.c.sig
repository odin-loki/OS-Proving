void
refcnt_t *	count
unsigned int	v
