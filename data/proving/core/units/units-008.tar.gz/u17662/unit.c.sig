int
struct inode *	dir
struct buffer_head *	bh
void *	buf
int	buf_size
