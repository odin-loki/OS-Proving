unsigned int
const struct nf_loginfo *	li
const struct sk_buff *	skb
unsigned int	copy_len
