int
struct timespec64 *	a
struct timespec64 *	b
