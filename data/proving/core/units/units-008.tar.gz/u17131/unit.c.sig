u32
struct ath_hw *	ah
