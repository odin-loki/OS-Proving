int
struct mbuf *	m
int	how
