u32
struct netdev_private *	np
