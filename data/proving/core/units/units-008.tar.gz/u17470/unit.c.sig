int
struct _citrus_mapper_area *restrict *restrict	rma
const char *restrict	area
