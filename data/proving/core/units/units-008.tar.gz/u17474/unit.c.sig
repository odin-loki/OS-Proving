uint64_t
int	n
