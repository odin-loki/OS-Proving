double
const struct ptime_data *	minuend
const struct
    ptime_data *	subtrahend
