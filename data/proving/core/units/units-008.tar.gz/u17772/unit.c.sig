int
struct hl_device *	hdev
