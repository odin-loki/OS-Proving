int
struct afs_net *	net
struct socket *	socket
