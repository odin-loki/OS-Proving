int
struct octeon_device *	oct
int	q_no
int	num_descs
int	desc_size
void *	app_ctx
