u32
struct tid_user_buf *	tidbuf
unsigned int	npages
