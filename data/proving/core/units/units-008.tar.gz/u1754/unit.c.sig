int
u8	first
u8	second
u8	third
