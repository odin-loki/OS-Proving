int
struct smsdvb_client_t *	client
