unsigned int
const struct sfxge_softc *	sc
enum sfxge_txq_type	type
unsigned int	tso_fw_assisted
