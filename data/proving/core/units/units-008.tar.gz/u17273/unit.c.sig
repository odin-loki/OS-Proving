int
struct hinic_dev *	dev
enum hinic_dbg_type	type
void *	data
struct dentry *	root
struct hinic_debug_priv **	dbg
char **	field
int	nfile
