int
struct mlxfw_dev *	mlxfw_dev
struct netlink_ext_ack *	extack
u8	err
