void
struct ck_spinlock_ticket *	ticket
