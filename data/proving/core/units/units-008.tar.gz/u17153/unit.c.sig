int
const struct intel_crtc_state *	crtc_state
bool	ssc
int	dsc_slice_count
int	bpp_x16
