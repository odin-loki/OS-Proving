int
HTAB *	hashp
