void
volatile int *	p
int	v
