u8
u32	airtime
u32	elapsed
