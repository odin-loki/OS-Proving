int
mp_int *	a
int	size
