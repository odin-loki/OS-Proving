void
struct io_worker *	worker
