int
struct vcap_control *	vctrl
int	from_cid
int	to_cid
