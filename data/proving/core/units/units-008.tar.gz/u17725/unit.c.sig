int
const char *	dev
bus_addr_t	align
bus_addr_t	bndry
bus_addr_t	maxaddr
bus_size_t	maxsz
u_int	nsegs
bus_size_t	maxsegsz
u_int	datarate
u_int	flags
busdma_tag_t *	out_p
