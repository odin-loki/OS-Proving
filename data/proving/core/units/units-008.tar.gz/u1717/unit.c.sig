int
sqlite3_file *	fd
int	ofst
int	n
int	flags
