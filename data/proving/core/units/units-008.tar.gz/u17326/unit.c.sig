int
struct mlx5_rep_uplink_priv *	uplink_priv
