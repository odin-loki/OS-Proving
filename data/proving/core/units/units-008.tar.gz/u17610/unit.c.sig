int
struct smb3_fs_context *	ctx
struct cifs_ses *	ses
