int
struct sec_req *	req
