xfs_lsn_t
xfs_lsn_t	lsn1
xfs_lsn_t	lsn2
