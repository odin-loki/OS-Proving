unsigned long
unsigned long	parent_rate
unsigned long	pre_div_sel
unsigned long	div_sel
unsigned long	post_div_sel
