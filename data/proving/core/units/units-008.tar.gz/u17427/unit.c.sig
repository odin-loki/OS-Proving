int
struct btrfs_device *	device
u64	physical
u64	length
u64 *	bytes
