u8
u8	exp
u32	mantissa
u8	count
