int
struct isotp_sock *	so
u32	gen
