u32
enum ipu_image_convert_type	type
const struct ipu_image_pixfmt *	fmt
enum ipu_rotate_mode	rot_mode
