u32
struct rnd_state *	rng
u32	ceil
