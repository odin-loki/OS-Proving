u16
u8	iv_offset
