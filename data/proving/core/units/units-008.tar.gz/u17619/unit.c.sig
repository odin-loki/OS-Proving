int
int	lastWrite
int	lastRead
int	ringSize
