daddr_t
daddr_t	radix
