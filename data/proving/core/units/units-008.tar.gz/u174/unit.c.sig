int
void *	start
size_t	len
int	flags
