int
unsigned char *	buf
int	pos
int	num
int	shift
