int
volatile uint64_t *	p
uint64_t *	cmpval
uint64_t	newval
