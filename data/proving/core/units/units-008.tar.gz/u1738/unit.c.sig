u32
unsigned short	perm
u32	flags
