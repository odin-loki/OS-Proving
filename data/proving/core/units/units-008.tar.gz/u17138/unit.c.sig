int
const efi_char16_t *	cmdline
int	cmdline_len
const efi_char16_t *	prefix
int	prefix_size
efi_char16_t *	result
int	result_len
