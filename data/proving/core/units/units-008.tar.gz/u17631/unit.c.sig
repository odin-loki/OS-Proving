unsigned short
unsigned int	iop_base
unsigned short	bus_type
