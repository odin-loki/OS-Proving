unsigned int
unsigned int	fin
unsigned int	fspi
unsigned int *	fres
