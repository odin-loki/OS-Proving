int
int	lba
