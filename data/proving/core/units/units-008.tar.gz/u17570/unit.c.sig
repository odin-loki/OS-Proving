int
struct cmdif *	cif
unsigned char *	intdec
unsigned int *	rate
