int
struct aa_ns *	ns
struct aa_loaddata *	rawdata
