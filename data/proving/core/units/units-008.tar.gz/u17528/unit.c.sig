int
u8	scaling_ratio
int	space
