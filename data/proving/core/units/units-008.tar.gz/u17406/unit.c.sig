int
struct bnx2fc_cmd *	io_req
