u64
unsigned int	threshold
unsigned int	freq_div
