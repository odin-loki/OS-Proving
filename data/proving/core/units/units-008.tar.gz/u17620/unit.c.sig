bool
u64	x86_arch_cap_msr
