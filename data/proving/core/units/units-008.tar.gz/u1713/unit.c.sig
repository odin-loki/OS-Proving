long
struct clk_pll14xx *	pll
int	mdiv
int	pdiv
int	sdiv
int	kdiv
unsigned long	prate
