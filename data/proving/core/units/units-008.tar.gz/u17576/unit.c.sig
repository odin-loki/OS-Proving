int
struct cphy *	phy
struct adapter *	adapter
int	phy_addr
const struct mdio_ops *	mdio_ops
