int
struct usb_serial_port *	port
unsigned	port_num
