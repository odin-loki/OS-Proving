int
u32	_num_fqids
