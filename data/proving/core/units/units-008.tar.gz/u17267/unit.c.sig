u32
struct ath_hw *	ah
u32	usecs
