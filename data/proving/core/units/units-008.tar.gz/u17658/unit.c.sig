int
struct ceph_connection *	con
