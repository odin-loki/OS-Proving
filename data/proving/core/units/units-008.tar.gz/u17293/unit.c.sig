lba_t
lba_t	n
