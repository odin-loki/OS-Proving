ahd_mode_state
struct ahd_softc *	ahd
ahd_mode	src
ahd_mode	dst
