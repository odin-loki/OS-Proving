int
u_daddr_t	mask
