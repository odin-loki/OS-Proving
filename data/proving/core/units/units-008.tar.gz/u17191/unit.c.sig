int
struct xhci_hcd *	xhci
struct xhci_virt_ep *	ep
u32	trb_comp_code
