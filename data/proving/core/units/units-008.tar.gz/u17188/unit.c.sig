u16
int	channel
long	volt
u8	bypass_attn
