int
struct nand_device *	nand
