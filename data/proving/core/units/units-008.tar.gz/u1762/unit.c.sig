s32
u32	radians
u32	twopi
