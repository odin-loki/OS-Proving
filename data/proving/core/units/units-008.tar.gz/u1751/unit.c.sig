bool
struct ccu_common *	common
unsigned long	target_rate
unsigned long	current_rate
unsigned long	best_rate
