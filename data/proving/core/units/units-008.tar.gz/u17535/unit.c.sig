int
struct fuse_conn *	fc
struct iovec *	dst
void *	src
size_t	transferred
unsigned	count
bool	is_compat
