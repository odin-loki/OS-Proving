uint32_t
fxp_t	a
