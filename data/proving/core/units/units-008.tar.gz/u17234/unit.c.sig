u16
u16	idx
u16	inc
u8	speed
