u16
struct madera_pin_private *	priv
unsigned int	milliamps
