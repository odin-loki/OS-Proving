int
struct ncsi_dev *	nd
