int
int	index
int	n_bd
