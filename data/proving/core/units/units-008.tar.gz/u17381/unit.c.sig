unsigned long
struct bxe_softc *	sc
struct bxe_fastpath *	fp
uint8_t	zero_stats
