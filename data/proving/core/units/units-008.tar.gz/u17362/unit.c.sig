int
struct smb_hdr *	smb
