bool
unsigned	ivalid
bool	trust_local_mtime
