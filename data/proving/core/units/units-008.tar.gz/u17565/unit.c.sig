int
struct ucred *	cred
struct vnode *	vp
struct label *	vplabel
struct image_params *	imgp
struct label *	execlabel
