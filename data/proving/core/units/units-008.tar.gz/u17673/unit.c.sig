int
struct device *	dev
struct device_node *	node
u8 *	mode_mask
u8 *	mode_val
