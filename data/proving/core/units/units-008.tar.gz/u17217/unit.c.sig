int
u32	device_handle
u16 *	flags
