int
struct xe_tile *	tile
struct xe_svm_range *	range
const struct drm_gpusvm_ctx *	ctx
