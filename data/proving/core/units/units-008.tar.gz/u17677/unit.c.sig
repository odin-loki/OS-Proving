u8
u8	type1
u8	type2
