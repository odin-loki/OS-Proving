int
const struct net_device *	dev
u16	msti
u8 *	state
