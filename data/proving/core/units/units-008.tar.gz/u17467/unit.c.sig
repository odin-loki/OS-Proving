int
struct socket *	so
int	flags
struct mbuf *	m
struct sockaddr *	sa
struct mbuf *	control
struct thread *	td
