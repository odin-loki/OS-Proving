u32
struct pl08x_driver_data *	pl08x
u32	cctl
u8	srcwidth
u8	dstwidth
size_t	tsize
