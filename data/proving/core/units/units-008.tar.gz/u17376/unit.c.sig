int
struct w1_slave *	sl
int *	conv_time
