int
ocs_t *	ocs
