int
struct hfi1_ibdev *	ibd
