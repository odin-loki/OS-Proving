int
struct hdlcdrv_state *	s
unsigned int	bits
int	num
