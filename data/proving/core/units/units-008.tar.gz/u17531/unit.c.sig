int
struct ubifs_info *	c
