int
struct pruss *	pruss
enum pruss_pru_id	pru_id
enum pruss_gpi_mode	mode
