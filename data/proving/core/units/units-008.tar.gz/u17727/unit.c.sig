unsigned
unsigned	code
int	len
