u32
u32	a
int	exp
u32	fwl
