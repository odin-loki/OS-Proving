ssize_t
struct file *	file
const char *	data
size_t	count
loff_t *	ppos
