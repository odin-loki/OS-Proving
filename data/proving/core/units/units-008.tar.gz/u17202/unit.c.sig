int
struct service_processor *	sp
