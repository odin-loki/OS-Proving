int
struct hci_dev *	hdev
u32	dev_id
