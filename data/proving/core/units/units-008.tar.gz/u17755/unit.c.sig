u64
struct vsock_sock *	vsk
