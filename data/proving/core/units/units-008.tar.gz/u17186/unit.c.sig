int
struct usb_hcd *	hcd
struct usb_device *	udev
struct usb_host_endpoint **	eps
unsigned int	num_eps
unsigned int	num_streams
gfp_t	mem_flags
