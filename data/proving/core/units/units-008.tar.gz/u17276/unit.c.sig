bool
struct vhost_virtqueue *	vq
int	pkts
int	total_len
