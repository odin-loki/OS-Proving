int
u16	duration
