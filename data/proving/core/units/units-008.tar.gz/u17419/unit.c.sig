int
struct cs42l43 *	cs42l43
unsigned int	mcu_rev
unsigned int	bios_rev
