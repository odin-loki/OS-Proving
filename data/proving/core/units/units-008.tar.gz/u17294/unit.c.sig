int
struct shash_desc *	desc
struct shash_desc *	fbdesc
int	err
