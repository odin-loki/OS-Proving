int
const struct option *	opt
const char *	reason
int	flags
