unsigned int
u32 *	dst
const u8 *	src
unsigned int	len
