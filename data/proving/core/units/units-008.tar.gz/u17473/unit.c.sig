bool
struct xz_dec *	s
struct xz_buf *	b
