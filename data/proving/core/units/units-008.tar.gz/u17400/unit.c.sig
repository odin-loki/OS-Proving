int
struct tcpcb *	tp
struct socket *	so
uint32_t	recwin
int32_t	maxseg
