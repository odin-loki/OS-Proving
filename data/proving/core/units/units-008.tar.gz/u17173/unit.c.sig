bool
u16	chid
