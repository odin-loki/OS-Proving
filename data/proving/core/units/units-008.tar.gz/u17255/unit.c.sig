bool
unsigned long	next_pfn
