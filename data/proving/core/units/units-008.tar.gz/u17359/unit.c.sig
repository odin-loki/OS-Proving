long
const struct hp_wmi_numeric_sensor *	nsensor
