int
struct b53_device *	dev
int	port
