int
long	err_code
