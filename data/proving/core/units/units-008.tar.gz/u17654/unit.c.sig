int
struct bunzip_data *	bd
char *	outbuf
int	len
