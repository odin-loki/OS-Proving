int
int	fildes
int	req
char *	arg
