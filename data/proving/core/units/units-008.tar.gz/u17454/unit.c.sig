int
uint32_t	mode
