bool
u32	iv
int	keylen
