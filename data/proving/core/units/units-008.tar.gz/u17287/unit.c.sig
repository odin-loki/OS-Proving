u32
u32	srate
enum stv090x_rolloff	rolloff
