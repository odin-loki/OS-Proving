s64
s16	ambient_new_raw
s16	ambient_old_raw
s16	Gb
