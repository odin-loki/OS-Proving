int
struct dm_pool_metadata *	pmd
bool	format_device
