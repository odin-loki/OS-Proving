unsigned int
struct max77686_data *	max77686
int	id
