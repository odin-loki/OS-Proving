int
struct device *	dev
struct clk *	clk
struct notifier_block *	nb
