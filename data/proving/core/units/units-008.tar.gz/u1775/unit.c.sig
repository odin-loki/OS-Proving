int
struct pci_dev *	pdev
int	bar
struct ahci_host_priv *	hpriv
