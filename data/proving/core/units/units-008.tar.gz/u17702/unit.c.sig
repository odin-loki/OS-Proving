u16
struct brcms_phy *	pi
u32	f_kHz
u16	max_val
u8	dac_test_mode
