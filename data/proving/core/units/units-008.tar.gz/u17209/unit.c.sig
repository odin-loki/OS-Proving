int
IAL_ADAPTER_T *	pAdapter
MV_U8	channelNum
