int
struct kvm_vcpu *	vcpu
struct msr_data *	msr_info
