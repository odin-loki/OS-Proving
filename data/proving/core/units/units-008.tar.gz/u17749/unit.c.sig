int
u_int	fpflags
