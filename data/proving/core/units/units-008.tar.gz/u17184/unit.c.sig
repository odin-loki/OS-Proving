int
struct snd_msnd *	chip
int	start
