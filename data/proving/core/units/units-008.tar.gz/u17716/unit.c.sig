int
struct irdma_sc_ceq *	ceq
struct irdma_sc_cq *	cq
