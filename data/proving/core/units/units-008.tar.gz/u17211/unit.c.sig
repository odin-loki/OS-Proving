int
struct snd_i2c_device *	cs8427
struct snd_pcm_substream *	play_substream
struct snd_pcm_substream *	cap_substream
