int
struct snd_ac97 *	ac97
