u32
struct dib0090_state *	state
