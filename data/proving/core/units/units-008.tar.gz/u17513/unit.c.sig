bool
uintptr_t	patchpoint
uintptr_t	target
