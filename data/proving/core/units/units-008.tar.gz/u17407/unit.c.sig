acpi_status
u16	timeout
