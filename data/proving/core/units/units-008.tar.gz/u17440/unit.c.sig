int
void *	rom_start
struct controller *	ctrl
