u8
u8	mgmt_addr_type
