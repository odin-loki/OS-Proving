u64
int	r
