int
int	pqi_status
