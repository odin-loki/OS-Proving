bool
struct pci_dev *	dev
u8	pin
