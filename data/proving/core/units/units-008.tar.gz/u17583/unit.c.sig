int
struct sock *	sk
sockptr_t	optval
int	optlen
