int
struct octeon_device *	oct
void *	conf
