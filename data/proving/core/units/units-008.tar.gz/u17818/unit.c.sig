int
uint64_t	bitmap
int	start
int	idx
