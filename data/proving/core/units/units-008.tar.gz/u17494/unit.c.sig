bool
struct mbox_chan *	chan
