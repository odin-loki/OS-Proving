int
struct regulator_dev *	rdev
int	min_uA
int	max_uA
