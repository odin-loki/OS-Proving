u32
u32	hopnum
u32	count
