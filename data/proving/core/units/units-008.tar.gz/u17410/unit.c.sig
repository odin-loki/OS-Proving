int
int	offs
