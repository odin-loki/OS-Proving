int32_t
ocs_dma_t *	dma
