int
struct kingdisplay_panel *	kingdisplay
