s32
s32	a
s32	b
s64	freq
int	def
