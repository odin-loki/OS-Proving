unsigned short
struct SiS_Private *	SiS_Pr
