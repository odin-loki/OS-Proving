int
struct zcomp_params *	params
