unsigned long
unsigned long	gfn
