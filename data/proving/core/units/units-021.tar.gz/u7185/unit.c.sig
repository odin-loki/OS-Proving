unsigned int
unsigned long	prev_offset
unsigned long	offset
int	hits
int	max_pages
int	prev_win
