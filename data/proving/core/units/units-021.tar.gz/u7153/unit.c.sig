OSAL_INLINE enum _ecore_status_t
struct ecore_dev OSAL_UNUSED *	p_dev
int OSAL_UNUSED	vfid
OSAL_UNUSED u32	rate
