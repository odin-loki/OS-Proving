int
int	msr
