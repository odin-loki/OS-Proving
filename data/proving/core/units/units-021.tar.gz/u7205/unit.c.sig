u32
struct mlx5_eswitch *	esw
struct mlx5_esw_sched_node *	parent
