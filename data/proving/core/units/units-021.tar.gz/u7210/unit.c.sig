u8
struct rt2x00_dev *	rt2x00dev
bool	bw40
u8	filter_target
