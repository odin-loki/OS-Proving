int
struct sk_buff *	skb
const struct nf_queue_entry *	entry
