div_t
int	numer
int	denom
