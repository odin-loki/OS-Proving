int
struct snd_soc_dai *	cpu_dai
int	len
