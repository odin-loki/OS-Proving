int
struct the_nilfs *	nilfs
__u64 *	segnumv
size_t	nsegs
