int
int	argc
const char **	argv
const struct option *	options
?	?
?	?
int	flags
