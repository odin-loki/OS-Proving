int
struct ad7173_state *	st
bool	differential
unsigned int	ain0
unsigned int	ain1
