unsigned long
unsigned long	ref_clk
unsigned long	nr
unsigned long	nf
unsigned long	od
