u8
u8	mgmt_class
