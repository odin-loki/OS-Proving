int
const char *	path
struct open_file *	f
