int
unsigned long	period
