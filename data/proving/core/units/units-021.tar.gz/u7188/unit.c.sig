bool
u32	cpuid
