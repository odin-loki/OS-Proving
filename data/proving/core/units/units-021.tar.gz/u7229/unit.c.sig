ssize_t
struct fuse_dev *	fud
struct fuse_copy_state *	cs
size_t	nbytes
