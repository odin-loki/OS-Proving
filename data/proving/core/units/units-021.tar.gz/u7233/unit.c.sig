int
struct dm_thin_device *	td
