unsigned long
unsigned long	rnd
