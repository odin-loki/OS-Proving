unsigned char
unsigned int	period
unsigned int	offset
unsigned int	fast
const struct sx_period *	sx_table
