uint32_t
struct amdgpu_device *	adev
