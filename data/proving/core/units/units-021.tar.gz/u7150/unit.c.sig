int
struct iscsi_bus_flash_conn *	fnode_conn
