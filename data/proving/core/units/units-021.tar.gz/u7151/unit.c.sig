int
struct ps2mult *	psm
int	i
