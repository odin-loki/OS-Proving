int
struct vmw_cursor_plane *	vcp
struct vmw_plane_state *	vps
