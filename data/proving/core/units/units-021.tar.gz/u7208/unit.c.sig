LogEst
LogEst	a
LogEst	b
