int
int	size
u32	data_width1
u32	data_width2
