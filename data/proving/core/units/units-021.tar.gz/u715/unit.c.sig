u32
int	level
