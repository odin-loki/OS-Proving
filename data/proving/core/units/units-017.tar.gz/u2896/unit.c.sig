u16
u16	rp
u16	wp
u16	size
