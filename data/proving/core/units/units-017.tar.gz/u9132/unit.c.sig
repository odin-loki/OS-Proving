int
struct domain_device *	found_dev
