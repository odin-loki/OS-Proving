int
struct wfx_dev *	wdev
const struct wfx_hif_msg *	hif
const void *	buf
