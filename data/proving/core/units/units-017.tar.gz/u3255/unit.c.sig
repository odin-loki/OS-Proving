int
const struct rt_addrinfo *	info
uint32_t	default_weight
