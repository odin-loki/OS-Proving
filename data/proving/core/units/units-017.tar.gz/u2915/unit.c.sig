int
struct ov965x *	ov965x
int	auto_gain
