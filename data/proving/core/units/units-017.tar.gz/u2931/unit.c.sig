__always_inline __attribute_const__ int
__u64	x
