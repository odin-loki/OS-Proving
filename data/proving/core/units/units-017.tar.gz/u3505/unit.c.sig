int32_t
ocs_node_t *	node
