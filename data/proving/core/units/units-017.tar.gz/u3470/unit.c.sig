int
u16	event_idx
u16	new_idx
u16	old
