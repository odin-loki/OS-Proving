int
struct radeon_device *	rdev
struct radeon_ib *	ib
