unsigned char
int	a
int	b
