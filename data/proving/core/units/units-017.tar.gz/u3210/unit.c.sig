int
struct fc_lport *	lport
