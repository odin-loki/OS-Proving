void
unsigned	seed
