int
const char *	input
int	output_fd
