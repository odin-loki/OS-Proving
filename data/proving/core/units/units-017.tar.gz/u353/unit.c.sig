int
struct most_interface *	iface
int	channel_id
struct most_channel_config *	cfg
char *	name
char *	args
