int
struct exynos5_dmc *	dmc
unsigned long	target_volt
