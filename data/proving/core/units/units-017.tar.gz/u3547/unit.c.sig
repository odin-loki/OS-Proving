bool
u8	cond
