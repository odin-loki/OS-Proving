bool
int	ver
u32	size
