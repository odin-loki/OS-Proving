unsigned long
struct map_pci_info *	map
unsigned long	ofs
