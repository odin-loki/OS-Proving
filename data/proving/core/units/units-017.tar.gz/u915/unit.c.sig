int
struct amdgpu_device *	adev
struct amdgpu_bo *	bo
uint64_t	saddr
uint64_t	offset
uint64_t	size
