u64
struct ddr_pmu *	pmu
int	counter
