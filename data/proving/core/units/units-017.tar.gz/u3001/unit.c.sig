bool
u16	nfp_mac_idx
