u32
struct device *	dev
u32	divisor
