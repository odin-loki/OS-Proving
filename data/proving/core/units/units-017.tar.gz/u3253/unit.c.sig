int
void *	th
int	len
