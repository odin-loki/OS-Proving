int
struct arm_ccn *	ccn
int	region
void *	base
u32	type
u32	id
