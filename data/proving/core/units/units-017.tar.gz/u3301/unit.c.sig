int
struct crypto_aead *	cipher
const u8 *	key
unsigned int	keylen
