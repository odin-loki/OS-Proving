int
int	vol
