unsigned int
unsigned int	div
