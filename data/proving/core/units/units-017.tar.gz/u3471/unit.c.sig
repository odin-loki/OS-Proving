int
struct rsnd_priv *	priv
int	enable
