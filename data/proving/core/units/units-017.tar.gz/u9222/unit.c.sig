void
struct bnxt_re_list_node *	new
struct bnxt_re_list_node *	prev
struct bnxt_re_list_node *	next
