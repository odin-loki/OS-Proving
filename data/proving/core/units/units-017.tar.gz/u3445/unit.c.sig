int
struct ucred *	cr1
struct ucred *	cr2
