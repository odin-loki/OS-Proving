int
struct lt9611 *	lt9611
