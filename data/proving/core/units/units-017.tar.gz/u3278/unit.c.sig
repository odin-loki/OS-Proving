int
unsigned long	code
