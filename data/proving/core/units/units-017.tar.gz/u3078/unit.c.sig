int
struct rcar_dmac_chan *	chan
gfp_t	gfp
