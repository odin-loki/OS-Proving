int
struct lanai_dev *	lanai
struct lanai_buffer *	buf
int	max_sdu
int	multiplier
const char *	name
