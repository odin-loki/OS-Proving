int
struct iosm_mux *	ipc_mux
struct mux_session *	session
struct sk_buff_head *	ul_list
int	max_nr_of_pkts
