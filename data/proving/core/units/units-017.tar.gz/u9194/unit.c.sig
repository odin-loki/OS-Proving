int
struct video_device *	vdev
