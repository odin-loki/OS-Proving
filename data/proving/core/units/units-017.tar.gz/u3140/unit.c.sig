u8
u16	lcladv
u16	rmtadv
