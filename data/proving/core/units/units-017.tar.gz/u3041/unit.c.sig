int
struct cmac *	mac
