bool
enum cip_sfc	sfc
