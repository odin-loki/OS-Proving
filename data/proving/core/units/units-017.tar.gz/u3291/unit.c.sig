enum ib_mtu
u16	mtu
