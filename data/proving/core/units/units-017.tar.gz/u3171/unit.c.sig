int
struct hid_device *	hid
