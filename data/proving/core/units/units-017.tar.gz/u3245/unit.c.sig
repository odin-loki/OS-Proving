int
struct ocelot *	ocelot
int	port
