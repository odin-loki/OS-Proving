bool
unsigned long	oldflags
unsigned long	newflags
bool	ignore_access
