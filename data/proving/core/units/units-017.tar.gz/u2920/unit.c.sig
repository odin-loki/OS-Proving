long
s16	reg
