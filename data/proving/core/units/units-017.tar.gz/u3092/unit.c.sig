int
u32	c1
u32	c2
