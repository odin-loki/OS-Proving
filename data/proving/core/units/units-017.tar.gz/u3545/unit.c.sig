int
struct net *	net
const struct in6_addr *	addr
__u32	scope_id
