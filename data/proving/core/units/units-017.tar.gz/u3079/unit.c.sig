int
struct rvu *	rvu
int	pcifunc
