int
struct bonding *	bond
const struct bond_option *	opt
