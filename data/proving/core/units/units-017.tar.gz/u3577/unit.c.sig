int
unsigned long *	llc_occupancy
