u32
u32	hfreq
