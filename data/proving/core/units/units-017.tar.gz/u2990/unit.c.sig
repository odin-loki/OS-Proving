uint32_t
volatile uint32_t *	p
