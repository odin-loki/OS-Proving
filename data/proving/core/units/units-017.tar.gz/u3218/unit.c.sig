int
struct kvm *	kvm
struct kvm_memory_slot *	slot
gfn_t	gfn
kvm_pfn_t *	pfn
struct page **	page
int *	max_order
