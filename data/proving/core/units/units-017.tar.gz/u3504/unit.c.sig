u64
const s64 *	link_freq_menu_items
u32	f_index
u8	nlanes
