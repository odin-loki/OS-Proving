int
int	buf_idx
