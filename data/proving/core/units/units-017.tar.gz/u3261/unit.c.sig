int
struct hci_dev *	hdev
u8	instance
