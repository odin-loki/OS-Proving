int
struct iommu_resv_region *	new
struct list_head *	regions
