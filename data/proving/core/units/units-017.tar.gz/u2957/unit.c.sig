int
struct ice_vf *	vf
u8 *	msg
