int
struct intel_vgpu *	vgpu
