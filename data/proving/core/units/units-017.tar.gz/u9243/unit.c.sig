uint8_t
struct backlight_device *	bd
