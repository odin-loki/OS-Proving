uint64_t
uint64_t	dividend
uint32_t	divisor
uint32_t *	remainder
