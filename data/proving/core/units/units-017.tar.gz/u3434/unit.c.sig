uint32_t
struct hn_softc *	sc
