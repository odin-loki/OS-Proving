int
struct tty_struct *	tty
struct usb_serial_port *	port
