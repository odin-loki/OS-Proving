int
struct tsl2591_chip *	chip
const u32	als_integration_time
