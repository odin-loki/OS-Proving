int
void *	addr
