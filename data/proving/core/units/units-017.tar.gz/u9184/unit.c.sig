int
int	val
int	reg
int	pwm
