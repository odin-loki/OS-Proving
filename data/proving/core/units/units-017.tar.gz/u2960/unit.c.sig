int
struct gpmi_nand_data *	this
const struct nand_sdr_timings *	sdr
