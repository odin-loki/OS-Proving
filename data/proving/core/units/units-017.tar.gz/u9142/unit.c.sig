int
int	brightness
