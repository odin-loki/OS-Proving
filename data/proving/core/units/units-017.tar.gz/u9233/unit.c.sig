unsigned int
unsigned int	x
unsigned int	fract_bits
