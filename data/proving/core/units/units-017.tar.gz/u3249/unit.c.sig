int
u8	type
u8	code
int *	err
