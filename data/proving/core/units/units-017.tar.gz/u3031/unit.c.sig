u16
u16	sb_cryp_sel
