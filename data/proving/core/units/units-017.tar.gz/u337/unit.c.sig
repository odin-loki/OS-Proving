u16
struct hpi_adapter_obj *	pao
int	dsp_index
