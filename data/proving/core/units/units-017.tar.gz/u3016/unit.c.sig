int
struct s2io_nic *	nic
struct ring_info *	ring
int	from_card_up
