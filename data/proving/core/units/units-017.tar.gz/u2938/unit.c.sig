int
struct fb_info *	info
int	user
