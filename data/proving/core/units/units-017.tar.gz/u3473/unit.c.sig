u64
u64	value
u64	ema_old
