ssize_t
struct address_space *	mapping
const char *	buf
size_t	count
struct cache_detail *	cd
