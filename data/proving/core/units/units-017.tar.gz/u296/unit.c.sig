int
struct mbuf *	m0
int	sanitize
