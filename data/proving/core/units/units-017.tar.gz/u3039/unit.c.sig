unsigned long
u64	xloops
