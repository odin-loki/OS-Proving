bool
u32	ptype
