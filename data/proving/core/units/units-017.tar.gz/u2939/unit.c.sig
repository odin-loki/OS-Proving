enum g_raid3_zones
size_t	nbytes
