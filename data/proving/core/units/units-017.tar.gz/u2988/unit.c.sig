int
struct vfe_device *	vfe
u8	wm
