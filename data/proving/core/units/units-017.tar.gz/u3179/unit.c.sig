int
struct sdw_master_runtime *	m_rt
unsigned int	num_ports
