int
struct ptp_clock_info *	ptp_info
long	scaled_ppm
