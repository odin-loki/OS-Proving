int
struct thc_device *	dev
struct thc_dma_configuration *	read_config
void *	read_buff
size_t *	read_len
int *	read_finished
