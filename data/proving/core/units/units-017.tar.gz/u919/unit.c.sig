bool
int	kexec_image_type
