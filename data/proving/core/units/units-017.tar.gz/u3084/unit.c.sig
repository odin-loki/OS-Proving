int
void *	priv
unsigned long	new_count
