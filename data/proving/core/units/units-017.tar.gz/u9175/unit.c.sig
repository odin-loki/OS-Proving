int
int	raw_uva
int	comp1
int	comp2
