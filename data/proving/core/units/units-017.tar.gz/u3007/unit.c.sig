int
u8	reg
