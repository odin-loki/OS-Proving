int
u8	cb_mode
