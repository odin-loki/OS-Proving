unsigned int
u16	prepost_bits
