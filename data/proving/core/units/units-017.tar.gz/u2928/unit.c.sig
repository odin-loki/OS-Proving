int
struct io_uring *	ring
struct io_uring_cqe **	cqe_ptr
