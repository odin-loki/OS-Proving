int
struct rcar_csi2 *	priv
