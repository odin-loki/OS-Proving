int
struct tty_struct *	tty
speed_t	newspd
