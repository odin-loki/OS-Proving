u32
u64	v
u32	d
