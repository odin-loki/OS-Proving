int
struct tcpcb *	tp
