int
u32	fqid
