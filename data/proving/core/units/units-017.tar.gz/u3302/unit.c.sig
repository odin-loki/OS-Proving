int
double	ratio
