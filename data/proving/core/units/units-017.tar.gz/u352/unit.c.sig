int
const struct matrox_fb_info *	minfo
unsigned int	freq
unsigned int	fmax
int *	in
int *	feed
int *	post
