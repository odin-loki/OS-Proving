int
enum iwl_amsdu_size	rb_size
