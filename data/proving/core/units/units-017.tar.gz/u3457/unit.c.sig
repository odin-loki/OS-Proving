int
struct vmci_softc *	sc
bus_size_t	size
bus_size_t	align
struct vmci_dma_alloc *	dma
