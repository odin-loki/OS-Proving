int
struct hdac_bus *	bus
