uint32_t
const struct gve_tx_ring *	tx
