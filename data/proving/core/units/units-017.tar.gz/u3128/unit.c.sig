int
struct iwx_softc *	sc
