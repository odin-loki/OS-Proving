bool
struct ilist *	l
