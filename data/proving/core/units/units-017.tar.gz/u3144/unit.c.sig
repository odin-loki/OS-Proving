int32_t
uint8_t	res
bool	hi_precision
