int
struct isc_device *	isc
u32	ver
