int
struct ath_softc *	sc
int	dowait
