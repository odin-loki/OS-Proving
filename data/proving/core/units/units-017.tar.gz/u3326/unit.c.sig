int
void *	skbdata
u16	attrtype
u16	dlen
const void *	dval
