int
struct netup_unidvb_dev *	dev
int	num
struct pci_dev *	pci_dev
