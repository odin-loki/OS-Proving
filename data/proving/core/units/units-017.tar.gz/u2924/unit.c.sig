ocs_hw_rtn_e
ocs_hw_t *	hw
ocs_hw_io_t *	io
ocs_hw_io_type_e	type
