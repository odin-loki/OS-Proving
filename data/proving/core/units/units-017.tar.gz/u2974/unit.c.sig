unsigned int
int	ib_max
