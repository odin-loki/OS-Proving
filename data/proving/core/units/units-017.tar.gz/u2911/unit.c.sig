int
struct wcn36xx *	wcn
struct platform_device *	pdev
