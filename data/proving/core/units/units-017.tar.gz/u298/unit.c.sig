int
struct cdx_device *	cdx_dev
int	num
