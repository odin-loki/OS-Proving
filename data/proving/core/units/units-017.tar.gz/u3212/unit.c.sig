unsigned
unsigned	seconds
