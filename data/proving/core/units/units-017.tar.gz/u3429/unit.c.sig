u64
u64	num
u32	base
