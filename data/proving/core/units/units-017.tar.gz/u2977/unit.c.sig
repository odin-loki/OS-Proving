unsigned long
struct clk_hw *	hwclk
unsigned long	parent_rate
