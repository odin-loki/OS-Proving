U32
size_t	dstSize
size_t	cSrcSize
