int
path_id_t	pathid
