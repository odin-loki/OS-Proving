int
struct sysctl_oid *	oidp
void *	arg1
intmax_t	arg2
struct sysctl_req *	req
