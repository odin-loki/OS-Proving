int
struct intel_pmc_dev *	pmc
u64 *	data
