int
vortex_t *	vortex
unsigned char	mix
unsigned char	ch
