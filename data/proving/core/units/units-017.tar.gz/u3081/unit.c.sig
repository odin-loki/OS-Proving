int
struct net_device *	netdev
struct ethtool_ringparam *	ring
struct kernel_ethtool_ringparam *	kernel_ring
struct netlink_ext_ack *	extack
