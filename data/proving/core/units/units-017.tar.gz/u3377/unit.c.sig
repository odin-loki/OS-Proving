int
struct rc_map_list *	map
