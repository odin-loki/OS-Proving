unsigned int
struct oxu_hcd *	oxu
unsigned int	portsc
