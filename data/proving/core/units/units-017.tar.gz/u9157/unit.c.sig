int
struct alx_priv *	alx
struct alx_rx_queue *	rxq
int	offset
