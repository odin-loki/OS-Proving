int
qla_host_t *	ha
struct mbuf *	mp
uint32_t *	op_code
uint32_t *	tcp_hdr_off
