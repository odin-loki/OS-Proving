int
unsigned int	mask
