u32
u16	width
u16	height
u8	bytespp
