unsigned int
unsigned int	seconds
