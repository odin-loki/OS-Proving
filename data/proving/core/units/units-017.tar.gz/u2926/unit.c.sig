int
struct kraken3_data *	priv
