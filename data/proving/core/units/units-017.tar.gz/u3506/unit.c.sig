int
struct regulator_dev *	rdev
unsigned int	from
unsigned int	to
