int
unsigned int	command
