int
struct hns_nic_ring_data *	ring_data
int	budget
void *	v
