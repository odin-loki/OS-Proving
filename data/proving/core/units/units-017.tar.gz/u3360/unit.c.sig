long
struct bpf_arena *	arena
long	uaddr
long	page_cnt
int	node_id
