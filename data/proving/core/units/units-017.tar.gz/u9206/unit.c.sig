int
struct cache_args *	ca
struct dm_arg_set *	as
char **	error
