int
struct vkms_writeback_job *	active_wb
struct vkms_crtc_state *	crtc_state
u32 *	crc32
