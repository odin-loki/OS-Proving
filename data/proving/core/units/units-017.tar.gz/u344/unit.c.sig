int
struct CHIPSTATE *	chip
