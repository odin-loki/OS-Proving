int
struct qedi_ctx *	qedi
