bool
struct sk_buff *	skb
int	count
