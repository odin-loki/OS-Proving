bool
int	dword_off
