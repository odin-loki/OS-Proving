int
vmci_mutex *	mutex
char *	name
