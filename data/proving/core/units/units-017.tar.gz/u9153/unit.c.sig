int
struct ehci_qtd *	qtd
dma_addr_t	buf
size_t	len
int	token
int	maxpacket
