int
struct ucred *	cred
struct socket *	so
struct label *	solabel
