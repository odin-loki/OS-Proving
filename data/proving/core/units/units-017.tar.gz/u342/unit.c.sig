int
struct kvm_memory_slot *	a
struct kvm_memory_slot *	b
