u32
struct rtw89_pci_tx_ring *	ring
