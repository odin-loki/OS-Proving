uint32_t
uint64_t	n
uint32_t	d
