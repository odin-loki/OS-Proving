int
struct intel_vgpu *	vgpu
intel_engine_mask_t	engine_mask
