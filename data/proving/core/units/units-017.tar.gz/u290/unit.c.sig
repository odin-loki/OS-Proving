int
const char *	pathname
int	flags
