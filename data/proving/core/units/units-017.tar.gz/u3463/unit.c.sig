bool
u16	last_used_idx
