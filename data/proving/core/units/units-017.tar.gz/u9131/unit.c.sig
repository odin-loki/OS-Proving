int
struct shash_desc *	desc
