int
u64	start
u64	size
