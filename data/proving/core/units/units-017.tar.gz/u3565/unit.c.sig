u64
struct bpf_arena *	arena
