int
struct coresight_device *	csdev
u8	traceid
int	port_num
bool	enable
