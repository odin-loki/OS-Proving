elink_status_t
struct bxe_softc *	sc
const uint8_t	cos_entry
const uint32_t	min_w_val_nig
const uint32_t	min_w_val_pbf
const uint16_t	total_bw
const uint8_t	bw
const uint8_t	port
