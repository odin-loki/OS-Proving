int
void *	buf
int	bufsize
