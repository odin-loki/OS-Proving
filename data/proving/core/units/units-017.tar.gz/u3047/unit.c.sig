int
struct nand_chip *	chip
const u8 *	data
u8 *	ecc
