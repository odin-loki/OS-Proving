unsigned int
unsigned int	level
int	dir_level
