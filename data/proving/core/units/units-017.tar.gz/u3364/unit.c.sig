bool
struct hl_device *	hdev
u32	err_val
u32	sts_val
