int
long *	msgtyp
int	msgflg
