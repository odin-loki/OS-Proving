int
struct smscore_device_t *	coredev
struct device *	device
int	arrival
