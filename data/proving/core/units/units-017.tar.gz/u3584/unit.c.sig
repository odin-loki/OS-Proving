int
tid_t	tid
struct inode *	inode
struct inode *	dir
