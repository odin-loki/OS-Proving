int
struct intel_connector *	connector
enum pipe	pipe
