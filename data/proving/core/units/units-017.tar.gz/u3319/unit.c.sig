int
struct sec_req *	req
struct bd_status *	status
