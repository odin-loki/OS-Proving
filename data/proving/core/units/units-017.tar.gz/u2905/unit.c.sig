int
struct device *	dev
long	offset
