int
struct tb_port *	port
int	min_hopid
int	max_hopid
