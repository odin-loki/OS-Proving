u64
struct kvm_vcpu *	vcpu
bool	host_initiated
