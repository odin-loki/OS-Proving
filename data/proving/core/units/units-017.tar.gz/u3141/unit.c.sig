int
u8	error_code
