int
struct spi_nor *	nor
loff_t	ofs
u64	len
