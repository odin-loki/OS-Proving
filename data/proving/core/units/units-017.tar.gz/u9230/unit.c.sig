int
int	lmsize
