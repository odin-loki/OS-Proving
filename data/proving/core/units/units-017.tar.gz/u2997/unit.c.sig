int
struct platform_device *	pdev
int	vid_num
