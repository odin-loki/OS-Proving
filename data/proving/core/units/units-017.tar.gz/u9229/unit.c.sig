int
struct fsl_dcu_drm_device *	fsl_dev
