int
struct sk_buff *	to
struct sk_buff *	from
int	pcount
int	shiftlen
