int
struct rtw89_dev *	rtwdev
struct rtw89_vif_link *	rtwvif_link
bool	qos
bool	ps
int	timeout
