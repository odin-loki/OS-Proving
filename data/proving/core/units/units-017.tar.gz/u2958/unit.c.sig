int
struct gpio_chip *	chip
unsigned int	offset
int	value
