int
struct minstrel_ht_sta *	mi
int	type
u32	fast_rate_dur
u32	slow_rate_dur
