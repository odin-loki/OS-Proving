int
struct mtd_info *	mtd
loff_t	addr
int	status
