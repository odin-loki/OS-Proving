unsigned int
struct xhci_hcd *	xhci
struct urb *	urb
unsigned int	total_packet_count
