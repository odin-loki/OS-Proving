int
struct enetc_si *	si
int	idx
