bool
void *	hdr
struct nl_pstate *	npt
