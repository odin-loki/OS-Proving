unsigned int
unsigned int	nareas
unsigned long	nslots
