int
struct icp_qat_fw_loader_handle
          *	handle
unsigned char	ae
unsigned short	absreg_num
unsigned short *	relreg
unsigned char *	ctx
