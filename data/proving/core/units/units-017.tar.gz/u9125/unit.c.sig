u32
int	freq
int *	freq_out
