long
long	j
