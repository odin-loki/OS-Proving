bool
int	mtu
