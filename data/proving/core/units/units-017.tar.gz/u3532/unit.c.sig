size_t
void*	dst
size_t	dstCapacity
const ZSTD_CCtx_params*	params
U64	pledgedSrcSize
U32	dictID
