int
struct mtd_info *	mtd
int	section
struct mtd_oob_region *	region
