int
struct fw_card *	card
int	address
