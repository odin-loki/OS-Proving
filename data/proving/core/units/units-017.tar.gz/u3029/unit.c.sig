int
struct ab8500_fg *	di
int	curr_ua
