int
struct atl1c_adapter *	adapter
u32	queue
bool	napi_mode
