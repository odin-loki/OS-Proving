unsigned int
unsigned int	srate
