int
const struct nft_ctx *	ctx
u32	type
