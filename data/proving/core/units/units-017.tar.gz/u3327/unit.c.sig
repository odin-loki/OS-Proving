u32
struct fhci_usb *	usb
enum fhci_mem_alloc	data_mem
u32	ring_len
