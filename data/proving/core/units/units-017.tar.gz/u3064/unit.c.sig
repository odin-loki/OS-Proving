enum iavf_status
struct iavf_hw *	hw
struct iavf_virt_mem *	mem
