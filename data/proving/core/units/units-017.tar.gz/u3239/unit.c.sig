__END_DECLS void
struct _citrus_db_locator *	dl
