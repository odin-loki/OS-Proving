int
long	flags
