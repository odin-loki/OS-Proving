void
struct share_check *	sc
int	oldcount
int	newcount
const struct prelim_ref *	newref
