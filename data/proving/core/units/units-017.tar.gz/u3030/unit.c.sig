bool
unsigned long	addr
int	size
