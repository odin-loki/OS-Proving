int
struct era *	era
struct rpc *	rpc
