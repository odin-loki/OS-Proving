int
struct amd64_pvt *	pvt
u16	pci_id1
u16	pci_id2
