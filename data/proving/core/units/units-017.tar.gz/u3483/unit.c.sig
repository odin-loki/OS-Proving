int
struct host1x_cdma *	cdma
