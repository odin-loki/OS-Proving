u64
struct ntb_dev *	ntb
