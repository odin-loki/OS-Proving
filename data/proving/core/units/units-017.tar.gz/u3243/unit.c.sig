int
struct hda_codec *	codec
hda_nid_t	pin
