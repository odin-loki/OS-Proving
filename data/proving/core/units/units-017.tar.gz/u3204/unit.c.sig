int
struct oxygen *	chip
