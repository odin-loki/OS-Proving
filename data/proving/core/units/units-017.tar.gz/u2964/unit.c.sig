int
struct xe_tile *	tile
struct xe_vram_region *	vr
