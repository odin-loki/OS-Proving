int
void *	gunzip_buf
unsigned int	sz
const void *	buf
unsigned int	len
