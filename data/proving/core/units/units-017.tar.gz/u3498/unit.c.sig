int
char *	_dst
char *	_src
size_t	len
