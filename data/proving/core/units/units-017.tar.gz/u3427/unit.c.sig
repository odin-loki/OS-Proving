u8
const u8	c1
const u8	c2
const u8	c3
