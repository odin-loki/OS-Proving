int
const struct hte_ts_desc *	desc
struct hte_clk_info *	ci
