long
int	ppb
