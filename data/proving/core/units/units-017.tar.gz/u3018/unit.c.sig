int
struct mlx5ctl_dev *	mcdev
u32	cap
