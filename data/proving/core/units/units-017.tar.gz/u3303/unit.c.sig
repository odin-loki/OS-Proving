int
int	sg_id
