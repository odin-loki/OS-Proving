int
int	clear_ins
