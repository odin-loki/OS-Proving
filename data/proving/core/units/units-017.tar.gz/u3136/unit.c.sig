int
int	nr
