int
const struct dm_block_validator *	v
struct dm_block *	b
size_t	sb_block_size
