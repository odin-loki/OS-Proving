u8
struct radeon_device *	rdev
u32	mclk
