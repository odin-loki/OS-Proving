u16
u16	link_speed
