int
struct ipc_namespace *	ns
int	semid
int	cmd
struct semid64_ds *	semid64
