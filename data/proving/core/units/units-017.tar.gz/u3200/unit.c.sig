int
if_t	ifp
union if_snd_tag_alloc_params *	params
struct m_snd_tag **	pt
