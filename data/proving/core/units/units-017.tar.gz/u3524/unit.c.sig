int
struct adapter *	sc
