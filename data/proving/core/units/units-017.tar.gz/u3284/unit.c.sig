int64_t
const ktime_t	kt
int64_t	div
