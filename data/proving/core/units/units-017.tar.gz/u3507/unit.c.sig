int
struct ath12k_base *	ab
struct hal_srng *	srng
bool	sync_hw_ptr
