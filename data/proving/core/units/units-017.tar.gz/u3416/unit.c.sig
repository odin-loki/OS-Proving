bool
u32	user
