int
off_t	mem_size
_Bool	hugetlb
