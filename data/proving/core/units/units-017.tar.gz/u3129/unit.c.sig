bool
u64	filter_event
u64	umask
