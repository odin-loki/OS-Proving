int
struct atl1c_adapter *	adapter
