ssize_t
struct xdr_stream *	xdr
__u32 *	array
size_t	array_size
