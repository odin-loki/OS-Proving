int
struct p9_client *	client
struct p9_req_t *	req
