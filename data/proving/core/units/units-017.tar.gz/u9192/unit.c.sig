int
unsigned int	num_ghes
