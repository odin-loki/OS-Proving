int
struct rman *	rm
