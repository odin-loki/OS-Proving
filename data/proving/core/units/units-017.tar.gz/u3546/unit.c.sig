size_t
const ZSTD_CDict*	cdict
