unsigned
size_t const	nbSeq
