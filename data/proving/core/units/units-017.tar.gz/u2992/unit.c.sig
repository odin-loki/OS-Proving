int
struct stv *	state
struct dtv_frontend_properties *	p
