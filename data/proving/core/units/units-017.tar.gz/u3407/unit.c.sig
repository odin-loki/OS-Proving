bool
struct swap_info_struct *	si
unsigned long	offset
int	nr_pages
bool *	has_cache
