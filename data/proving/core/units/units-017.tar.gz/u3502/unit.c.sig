int
HTAB *	hashp
int	do_free
int	to_disk
