ptrdiff_t
const void *	a
const void *	b
