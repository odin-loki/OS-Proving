bool
struct sk_buff *	skb
int	nexthdr
int	offset
