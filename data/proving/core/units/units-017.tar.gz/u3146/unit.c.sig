u64
struct btrfs_device *	device
u64	hole_start
u64	hole_end
u64	num_bytes
