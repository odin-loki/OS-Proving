bool
s32	value
