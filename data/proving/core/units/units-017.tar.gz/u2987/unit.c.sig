u64
u64	cntr_mask
