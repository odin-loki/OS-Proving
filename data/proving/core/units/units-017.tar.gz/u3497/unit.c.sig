u16
u16	crc
u8	c
