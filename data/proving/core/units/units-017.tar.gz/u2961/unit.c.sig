int
u32	val
