u_daddr_t
int	n
int	count
