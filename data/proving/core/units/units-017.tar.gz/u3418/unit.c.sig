int
ispsoftc_t *	isp
int	chan
