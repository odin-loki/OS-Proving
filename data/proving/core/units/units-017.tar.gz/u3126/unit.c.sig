int
struct jffs2_sb_info *	c
void *	buf
uint32_t	ofs
uint32_t	len
