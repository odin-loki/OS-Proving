bool
struct inode *	inode
struct nfs_readdir_descriptor *	desc
unsigned int	cache_misses
bool	force_clear
