int
struct mxc_isi_dev *	isi
struct v4l2_device *	v4l2_dev
