int
u32	buffer_size
u32	wr_idx
u32	rd_idx
