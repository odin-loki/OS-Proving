int
struct ef4_nic *	efx
struct ef4_self_tests *	tests
