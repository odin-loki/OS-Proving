int
u_int	freq
u_int	flags
