int
struct list_head *	queue
