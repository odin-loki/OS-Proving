int
struct bitstream *	bs
u64	in
