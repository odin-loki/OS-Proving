unsigned int
unsigned int	n
unsigned int	d
