unsigned long
unsigned long	paddr
int	pnode
int	chiplet
