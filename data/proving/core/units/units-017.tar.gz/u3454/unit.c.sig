int
struct cdrom_device_info *	cdi
unsigned long	speed
