int
struct stm32_hash_dev *	hdev
