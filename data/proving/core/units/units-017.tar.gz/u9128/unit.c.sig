int
struct ice_vf *	vf
u16	vsi_id
