int
phys_addr_t	addr
unsigned int	mask
unsigned int	val
