int
struct qedf_ctx *	qedf
struct qedf_rport *	fcport
