int
struct drm_dp_aux *	aux
struct drm_edp_backlight_info *	bl
u32	max_luminance
u16	driver_pwm_freq_hz
?	?
u32 *	current_level
u8 *	current_mode
bool	need_luminance
