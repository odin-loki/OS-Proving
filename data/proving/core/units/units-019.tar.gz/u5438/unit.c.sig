bool
struct mlx5e_ptpsq *	ptpsq
