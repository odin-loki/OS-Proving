unsigned long
struct shrinker *	shrink
struct shrink_control *	sc
