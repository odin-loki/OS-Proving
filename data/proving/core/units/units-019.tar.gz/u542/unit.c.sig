unsigned int
int	port
unsigned int	da
int	reg
