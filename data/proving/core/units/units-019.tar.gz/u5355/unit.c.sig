int
struct snd_hwdep *	hw
struct file *	file
