int
int	cpu
int	pid
