void
struct gsserrmap__head *	head
