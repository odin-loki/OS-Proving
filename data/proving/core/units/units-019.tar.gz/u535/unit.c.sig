int
struct mcs *	mcs
bool	set
