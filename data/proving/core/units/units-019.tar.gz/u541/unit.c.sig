int
struct mlx5_core_dev *	dev
u8 *	mac
