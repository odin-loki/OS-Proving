int
long	w
