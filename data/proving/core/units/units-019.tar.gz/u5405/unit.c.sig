u32
struct ath11k *	ar
struct ieee80211_sta *	sta
