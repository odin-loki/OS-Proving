int
struct mlx4_dev *	dev
u32	qp_num
union ib_flow_spec *	ib_spec
struct _rule_hw *	mlx4_spec
