int
struct sock *	sk
struct sockaddr *	addrs
int	addrs_size
int	op
