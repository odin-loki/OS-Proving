struct hisi_reset_controller *
struct platform_device *	pdev
