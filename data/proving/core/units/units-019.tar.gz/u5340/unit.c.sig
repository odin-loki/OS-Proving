int
struct strparser *	strp
int	err
