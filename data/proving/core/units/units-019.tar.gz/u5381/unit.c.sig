bool
struct qed_hwfn *	p_hwfn
u32	cid
u8	vfid
enum protocol_type *	p_type
struct qed_cid_acquired_map **	pp_map
