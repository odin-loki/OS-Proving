u32
struct intel_vgpu *	vgpu
int	pipe
u32	tiled
int	stride_mask
int	bpp
