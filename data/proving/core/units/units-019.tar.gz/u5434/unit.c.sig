u32
u32	rx_buffer_size
bool	aggr_hard_limit
