int
struct qcom_glink *	glink
size_t	avail
