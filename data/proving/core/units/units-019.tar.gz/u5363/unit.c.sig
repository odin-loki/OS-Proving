int
struct xillyfifo *	fifo
const void *	data
unsigned int	len
?	?
