unsigned int
struct device_node *	np
