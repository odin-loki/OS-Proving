u64
u64	val
u8	bits
