int
struct hdmi_spd_infoframe *	frame
void *	buffer
