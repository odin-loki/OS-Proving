int
unsigned int	pin
unsigned int	gpio_offset
