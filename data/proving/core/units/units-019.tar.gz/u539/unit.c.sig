unsigned long
struct clk_hw *	hw
unsigned long	xtal_clk
