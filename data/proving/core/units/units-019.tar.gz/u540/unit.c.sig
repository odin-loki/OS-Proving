int
uint32_t	chanerr
