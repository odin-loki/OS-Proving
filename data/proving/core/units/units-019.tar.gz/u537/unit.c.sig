int
const struct krb5_enctype *	krb5
struct crypto_shash *	shash
const struct krb5_buffer *	metadata
void **	_data
unsigned int *	_len
u32 *	_error_code
