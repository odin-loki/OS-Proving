int
struct mm_struct *	oldmm
struct mm_struct *	mm
