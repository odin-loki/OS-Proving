int
struct bhnd_nvram_io *	io
size_t	offset
void **	ptr
size_t	nbytes
size_t *	navail
