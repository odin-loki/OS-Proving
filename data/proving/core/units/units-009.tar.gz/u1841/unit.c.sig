u32
u16	speed_ability
