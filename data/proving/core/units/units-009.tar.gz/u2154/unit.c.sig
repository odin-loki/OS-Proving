int32_t
void *	arg
ocs_hw_sequence_t *	seq
