u8
enum ib_gid_type	gid_type
