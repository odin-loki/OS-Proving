int
struct nh_control *	ctl
