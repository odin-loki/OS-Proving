int
struct acpi_battery *	battery
union acpi_object *	package
const struct acpi_offsets *	offsets
int	num
