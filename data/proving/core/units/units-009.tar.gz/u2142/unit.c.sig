u32
struct wfx_dev *	wdev
u32	rates
