u_long
int	xres_virtual
int	bpp
