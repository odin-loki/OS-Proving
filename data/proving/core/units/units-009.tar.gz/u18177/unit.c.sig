u16
u16	var
u16	mask
u8	shift
