int
struct Scsi_Host *	host
