int
void *	nvram_start
size_t	res_size
