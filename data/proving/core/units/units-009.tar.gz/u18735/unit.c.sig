int
struct nci_dev *	ndev
