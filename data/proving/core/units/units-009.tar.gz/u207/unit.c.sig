int
struct mhi_controller *	mhi_cntrl
