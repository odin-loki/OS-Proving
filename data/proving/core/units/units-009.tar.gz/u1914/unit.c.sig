_Bool
atomic_t *	ptr
int *	oldp
int	new
