uint8_t
uint8_t	capacity
uint8_t	min_in
uint8_t	max_in
