int
struct geli_dev *	gdev
