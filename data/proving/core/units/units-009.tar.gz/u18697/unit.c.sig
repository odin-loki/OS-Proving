int
struct uart_port *	port
struct serial_struct *	serinfo
