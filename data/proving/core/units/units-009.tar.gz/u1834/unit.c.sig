u32
struct dma_chan *	chan
dma_addr_t	addr
