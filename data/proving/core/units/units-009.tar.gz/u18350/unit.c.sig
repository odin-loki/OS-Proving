int
struct pm860x_battery_info *	info
