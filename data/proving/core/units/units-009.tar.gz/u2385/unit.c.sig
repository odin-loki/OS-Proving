int
struct devlink_dpipe_entry *	entry
struct devlink_dpipe_value *	match_values
struct devlink_dpipe_match *	matches
struct devlink_dpipe_value *	action_value
struct devlink_dpipe_action *	action
int	type
