int
int	caps
