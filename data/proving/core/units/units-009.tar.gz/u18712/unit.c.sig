int
struct xe_guc *	guc
u32 *	msg
u32	len
