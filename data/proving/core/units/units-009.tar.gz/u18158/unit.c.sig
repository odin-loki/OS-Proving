int
int	fd
u_int	version
