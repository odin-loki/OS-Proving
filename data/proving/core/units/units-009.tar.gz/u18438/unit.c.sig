int
void *	arg
uint16_t	txqid
bool	clear
