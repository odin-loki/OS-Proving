u32
u32	baudrate
u32	clockrate
