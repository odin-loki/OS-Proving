int
struct optee *	optee
u_int	key
u32	timeout
