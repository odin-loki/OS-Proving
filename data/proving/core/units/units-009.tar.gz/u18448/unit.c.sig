int
int	mirror
int	num_copies
