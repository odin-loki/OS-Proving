int
struct gendisk *	disk
