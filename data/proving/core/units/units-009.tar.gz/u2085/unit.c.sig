int
struct crypto_aead *	tfm
const u8 *	key
u32	keylen
