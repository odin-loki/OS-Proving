u32
u32	csr_msg
enum gen2_csr_pos	offset
