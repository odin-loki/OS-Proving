int
struct ocrdma_dev *	dev
struct ib_wc *	ibwc
struct ocrdma_cqe *	cqe
