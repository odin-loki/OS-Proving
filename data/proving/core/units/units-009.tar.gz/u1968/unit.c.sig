int
u8	val
u8	mask
