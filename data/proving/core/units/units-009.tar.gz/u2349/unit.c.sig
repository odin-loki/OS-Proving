int
volatile int *	p
