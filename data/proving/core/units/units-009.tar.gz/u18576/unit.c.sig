int
struct ipw2100_priv *	priv
int	i
