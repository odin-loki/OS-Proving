u32
struct device *	dev
u32	clk_high_low_mask
u32	divisor
