int
struct drm_device *	dev
int	object_count
struct drm_mode_object **	objects
bool	universal_planes
