int
void *	aptr
int	pin
