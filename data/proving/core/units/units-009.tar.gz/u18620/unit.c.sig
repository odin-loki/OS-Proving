_Bool
enum pmu_errata	errata
