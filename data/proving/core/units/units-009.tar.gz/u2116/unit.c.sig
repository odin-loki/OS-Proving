int
struct bcma_device *	dev
u16	reg
u32	bitmask
int	timeout
