unsigned long
struct inno_hdmi_phy *	inno
unsigned long	rate
