int
const struct fwnode_handle *	fwnode
const char *	name
size_t	index
struct fwnode_reference_args *	args
