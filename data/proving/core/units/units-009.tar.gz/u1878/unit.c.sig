int
int	dev_idx
int	sd
int	fid
int	pid
