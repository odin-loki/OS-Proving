int
hcb_p	np
