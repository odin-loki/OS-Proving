unsigned long long
struct f2fs_sb_info *	sbi
unsigned long long	new
unsigned long long	old
