int
struct seq_file *	m
struct hist_trigger_data *	hist_data
