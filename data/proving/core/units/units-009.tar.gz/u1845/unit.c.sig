int
u16	size
