u32
u32	encoding
