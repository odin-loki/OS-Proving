acpi_status
struct acpi_table_desc *	initial_table_array
u32	initial_table_count
u8	allow_resize
