bool
struct safexcel_crypto_priv *	priv
int	fpp
