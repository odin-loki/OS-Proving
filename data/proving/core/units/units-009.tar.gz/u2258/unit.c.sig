u32
u32	value
bool	input
bool	output
