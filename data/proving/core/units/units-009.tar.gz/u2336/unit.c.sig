unsigned int
unsigned int	limit
