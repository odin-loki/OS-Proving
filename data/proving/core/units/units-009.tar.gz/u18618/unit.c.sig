unsigned long
unsigned long	dt_ptr
