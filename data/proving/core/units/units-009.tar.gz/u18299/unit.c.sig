bool
u32	offset
