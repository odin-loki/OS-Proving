int
struct mtk_eint *	eint
unsigned long	eint_n
