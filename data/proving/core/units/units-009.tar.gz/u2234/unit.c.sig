bool
int	reg_idx
