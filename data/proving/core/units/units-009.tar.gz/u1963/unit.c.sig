z_size_t
z_streamp	strm
z_size_t	sourceLen
