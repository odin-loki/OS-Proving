unsigned long
unsigned int	nr_to_scan
