int8_t
uint32_t	caps
bool	unset_means_none
