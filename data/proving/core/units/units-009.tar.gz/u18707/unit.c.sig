int
union hdmi_infoframe *	frame
const void *	buffer
size_t	size
