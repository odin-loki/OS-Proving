int
struct ipu_dc *	dc
struct ipu_di *	di
bool	interlaced
u32	bus_format
u32	width
