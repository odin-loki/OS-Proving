int
const unsigned int	xid
struct cifs_tcon *	tcon
struct cifs_sb_info *	cifs_sb
const char *	full_path
