int
struct device *	dev
struct tegra_devfreq *	tegra
