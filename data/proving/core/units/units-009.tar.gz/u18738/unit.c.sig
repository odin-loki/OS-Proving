int
struct ib_mad_agent *	agent
enum ib_qp_type	qp_type
