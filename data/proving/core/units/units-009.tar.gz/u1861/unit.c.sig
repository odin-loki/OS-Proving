int
struct sdw_slave *	slave
const struct sdw_device_id *	id
