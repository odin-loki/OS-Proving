int
struct mmc_host *	mmc
u32	opcode
int *	cmd_error
