int
struct hp_82341_priv *	hp_priv
