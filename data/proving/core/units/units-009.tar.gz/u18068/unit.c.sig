bool
unsigned int	obit
