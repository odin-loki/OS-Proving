void
struct inv_sensors_timestamp *	ts
