int
struct sk_buff *	msg
const struct vdpa_mgmt_dev *	mdev
