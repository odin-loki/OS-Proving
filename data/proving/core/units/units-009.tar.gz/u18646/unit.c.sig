u8
struct snd_soc_component *	comp
u32	mclk_rate
u32	dmic_clk_rate
