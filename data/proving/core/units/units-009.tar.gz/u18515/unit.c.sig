int
unsigned int	addr
unsigned short	flags
