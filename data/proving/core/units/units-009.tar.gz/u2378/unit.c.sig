int
int	ssize
int	max_sector
int	max_size
