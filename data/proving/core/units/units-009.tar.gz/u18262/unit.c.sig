int
unsigned long	cycles
struct clock_event_device *	dev
