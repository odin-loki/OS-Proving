int
void *	frD
void *	frB
