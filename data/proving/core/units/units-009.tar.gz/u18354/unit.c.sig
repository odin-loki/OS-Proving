int
int	max_link_rate
int	max_lanes
