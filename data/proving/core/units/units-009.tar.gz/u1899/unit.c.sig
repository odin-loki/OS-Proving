int
struct crypto_cipher *	tfm
const u8 *	key
unsigned int	keylen
