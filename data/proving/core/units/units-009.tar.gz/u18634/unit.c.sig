u8
u8	umr_fence_cap
