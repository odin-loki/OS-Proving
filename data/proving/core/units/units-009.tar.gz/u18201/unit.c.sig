int
struct memory_bitmap *	bm
unsigned int *	nr_highmem_p
