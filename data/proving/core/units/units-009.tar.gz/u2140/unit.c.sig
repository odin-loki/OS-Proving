int
int	old
int	new
int	weight
