int
struct device *	dev
struct clk *	clk
