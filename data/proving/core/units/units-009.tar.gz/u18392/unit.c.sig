int
struct counter_device *	counter
struct counter_count *	count
u64	val
