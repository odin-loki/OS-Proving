u8
u8	ringsize
u8	first
u8	last
