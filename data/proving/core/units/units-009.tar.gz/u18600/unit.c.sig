u64
uint64_t	dividend
uint32_t	divisor
