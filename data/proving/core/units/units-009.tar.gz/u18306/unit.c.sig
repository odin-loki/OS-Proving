int
struct icp_qat_fw_loader_handle *	handle
struct icp_qat_suof_img_hdr *	img_hdr
