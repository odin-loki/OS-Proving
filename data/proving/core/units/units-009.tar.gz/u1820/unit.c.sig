uint64_t
struct pcg_state_128*	rng
