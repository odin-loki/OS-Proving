u32
struct stv0900_internal *	intp
int	demod
