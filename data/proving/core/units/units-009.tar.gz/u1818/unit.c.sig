int
struct rvu *	rvu
struct rvu_block *	block
struct npa_aq_inst_s *	inst
