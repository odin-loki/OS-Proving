size_t
size_t	_bit
