int
int	cs
int	reg
int	st_bit
int	end_bit
int	max
int	time
enum gpmc_clk_domain	cd
const char *	name
