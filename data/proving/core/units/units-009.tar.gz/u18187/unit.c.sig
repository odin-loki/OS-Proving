int32_t
int	sigma
