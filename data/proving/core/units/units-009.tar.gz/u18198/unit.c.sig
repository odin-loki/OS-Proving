int
int	p
