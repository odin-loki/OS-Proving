u16
long	temp
bool	extended
