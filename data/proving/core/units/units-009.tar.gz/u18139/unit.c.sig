int
u32	table_type
u32	hop_num
