int
uint32_t	caps
enum ibv_qp_type	qpt
