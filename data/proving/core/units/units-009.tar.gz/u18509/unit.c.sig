u32
u32	from
u32	to
u8 *	cidr
