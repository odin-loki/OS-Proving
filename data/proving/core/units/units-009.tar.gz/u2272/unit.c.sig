int
struct socket *	sock
