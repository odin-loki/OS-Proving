bool
uint16_t	holemask
