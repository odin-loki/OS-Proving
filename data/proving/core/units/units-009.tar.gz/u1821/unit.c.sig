unsigned int
unsigned int	al_enr
