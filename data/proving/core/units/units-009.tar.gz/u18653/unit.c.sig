int
struct dib7000p_state *	st
u8	num
u8	dir
u8	val
