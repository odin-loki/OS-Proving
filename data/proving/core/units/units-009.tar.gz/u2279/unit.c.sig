bool
struct sk_buff *	skb
unsigned int *	bd_size
unsigned int	bd_num
u8	max_non_tso_bd_num
