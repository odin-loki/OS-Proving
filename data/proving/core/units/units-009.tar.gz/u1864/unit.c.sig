bool
unsigned int	freq
