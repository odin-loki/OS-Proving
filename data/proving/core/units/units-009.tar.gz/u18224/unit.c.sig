int
struct snd_pcm *	pcm
int	type
struct device *	data
size_t	size
