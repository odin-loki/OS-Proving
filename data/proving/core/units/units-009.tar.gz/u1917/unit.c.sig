int
struct nvif_object *	parent
const char *	name
u32	handle
nvif_event_func	func
bool	wait
struct nvif_event_v0 *	args
u32	argc
struct nvif_event *	event
