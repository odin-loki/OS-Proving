int
device_t	bus
device_t	dev
struct ppb_microseq *	loop
int	opcode
