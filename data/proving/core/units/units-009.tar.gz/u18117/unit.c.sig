int
struct thread *	td
char *	xfpustate
size_t	xfpustate_size
