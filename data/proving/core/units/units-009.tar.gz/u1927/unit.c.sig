int
struct virtqueue *	vq
int	indirect_size
