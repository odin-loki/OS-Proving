unsigned int
unsigned int	ngpio
