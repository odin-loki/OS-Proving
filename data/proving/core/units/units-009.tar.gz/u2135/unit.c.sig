int
int	cpu
u64	dl_bw
