int
struct kvm_ioapic *	ioapic
int	irq
bool	line_status
