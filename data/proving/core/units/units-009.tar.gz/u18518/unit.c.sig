bool
u8	pktid
