int
struct hinic_pf_to_mgmt *	pf_to_mgmt
