unsigned int
struct gfar_private *	priv
unsigned int	ticks
