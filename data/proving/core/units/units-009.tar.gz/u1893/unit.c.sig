unsigned int
unsigned int	mask
unsigned int	true_val
unsigned int	false_val
