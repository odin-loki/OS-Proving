int
struct stmmac_priv *	priv
int	limit
u32	queue
