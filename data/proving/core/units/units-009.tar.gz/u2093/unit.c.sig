int
struct cfg80211_registered_device *	rdev
enum nl80211_iftype	iftype
u32	beacon_int
