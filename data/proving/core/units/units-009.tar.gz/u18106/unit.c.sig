int
struct i3c_hci *	hci
struct device *	dev
struct hci_xfer *	xfer_list
int	n
