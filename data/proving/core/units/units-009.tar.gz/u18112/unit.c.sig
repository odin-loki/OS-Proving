int
PVBUS_EXT	vbus_ext
