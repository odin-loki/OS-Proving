int
unsigned long	sysclk
int	div
