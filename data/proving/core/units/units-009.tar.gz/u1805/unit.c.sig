int
int	integer_part
int	fractional
