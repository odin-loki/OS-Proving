int
int	a
int	b
u16	timeout
u16	threshold
