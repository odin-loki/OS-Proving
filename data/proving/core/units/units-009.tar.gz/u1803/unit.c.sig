uint32_t
struct amdgpu_device *	adev
uint64_t	mca_addr
uint64_t	retired_page
