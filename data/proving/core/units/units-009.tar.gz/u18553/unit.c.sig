int
struct vm_area_struct *	vma
void *	cpu_addr
size_t	size
int *	ret
