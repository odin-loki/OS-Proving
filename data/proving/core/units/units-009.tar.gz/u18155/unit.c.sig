int
struct ice_vf *	vf
struct ice_vsi *	vsi
