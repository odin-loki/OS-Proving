int
struct gpio_rcar_priv *	p
unsigned int *	npins
