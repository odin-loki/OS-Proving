CK_CC_INLINE uint32_t
uint32_t	v
