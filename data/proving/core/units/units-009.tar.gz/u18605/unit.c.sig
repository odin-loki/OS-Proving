bool
gpa_t	gpa
