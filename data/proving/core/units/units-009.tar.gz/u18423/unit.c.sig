int
struct btrfs_fs_info *	fs_info
u64	start
u64	end
const bool	return_free_space
