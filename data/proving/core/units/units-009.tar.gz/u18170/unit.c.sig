int
struct bpf_prog_list *	pl
struct hlist_head *	progs
struct bpf_prog *	prog
struct bpf_cgroup_link *	link
u32	flags
u32	id_or_fd
