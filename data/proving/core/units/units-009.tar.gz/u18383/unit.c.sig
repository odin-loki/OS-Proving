int
struct sfxge_softc *	sc
