int
struct net_device *	dev
int	sset
