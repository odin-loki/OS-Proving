bool
unsigned int	sta
