int
struct net *	net
unsigned int	cmd
unsigned long	arg
