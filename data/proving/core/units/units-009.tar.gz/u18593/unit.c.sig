int
struct fw_device *	dfwdev
