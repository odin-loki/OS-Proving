int
struct gcr3_tbl_info *	gcr3_info
struct amd_iommu *	iommu
int	pasids
