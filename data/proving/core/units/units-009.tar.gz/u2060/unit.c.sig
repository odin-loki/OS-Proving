hbsdctrl_feature_cb_res_t
hbsdctrl_ctx_t *	ctx
hbsdctrl_feature_t *	feature
const void *	arg1
void *	arg2
