unsigned int
struct cifs_tcon *	tcon
struct smb3_fs_context *	ctx
