int
struct mts64 *	mts
