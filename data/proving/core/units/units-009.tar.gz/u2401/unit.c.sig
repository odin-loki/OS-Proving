u64
struct xe_vm *	vm
u64	addr
u64	end
struct xe_vma *	vma
