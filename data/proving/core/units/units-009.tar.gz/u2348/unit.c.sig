int
const struct posix_acl *	acl
umode_t *	mode_p
