int
struct agp_kern_info *	info
