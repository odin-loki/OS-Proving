u32
int	value
