int
int	index
int	count
