int
struct bpf_local_storage_map *	smap
void *	owner
u32	size
