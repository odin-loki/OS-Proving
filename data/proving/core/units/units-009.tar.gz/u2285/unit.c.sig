u8
enum ib_port_state	state
