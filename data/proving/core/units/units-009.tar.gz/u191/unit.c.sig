int
struct netc_cbdr *	cbdr
struct device *	dev
const struct netc_cbdr_regs *	regs
