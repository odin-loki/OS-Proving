u32
u32	rpu_enabled
