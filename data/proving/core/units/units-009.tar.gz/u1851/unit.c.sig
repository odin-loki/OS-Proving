int
sqlite3_file *	id
int	lockType
