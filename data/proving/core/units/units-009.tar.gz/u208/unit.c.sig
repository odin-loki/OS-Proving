bits32
bits32	a0
bits32	a1
bits32	b
