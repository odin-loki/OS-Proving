bool
u32	msg
enum gen2_csr_pos	offset
