int
int	totlen
int	len
