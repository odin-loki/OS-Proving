int
struct mvs_info *	mvi
struct sas_task *	task
u32	slot_idx
