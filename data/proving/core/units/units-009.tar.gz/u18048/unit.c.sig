int
struct ring_buf *	r
