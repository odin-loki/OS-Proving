int
struct fw_iso_context *	ctx
u64 *	channels
