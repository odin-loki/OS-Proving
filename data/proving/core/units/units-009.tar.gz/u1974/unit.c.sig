int
int	audit_fd
struct audit_filter *	filter
