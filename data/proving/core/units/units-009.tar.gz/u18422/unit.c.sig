int
struct ppb_microseq *	msq
int	nbparam
?	?
