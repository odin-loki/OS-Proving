int
struct irq_data *	d
