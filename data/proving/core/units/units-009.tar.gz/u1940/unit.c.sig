int
uint32_t	bits
