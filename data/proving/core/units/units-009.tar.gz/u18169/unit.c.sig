bool
struct aa_ext *	e
size_t	size
