int
u8	power_byte
