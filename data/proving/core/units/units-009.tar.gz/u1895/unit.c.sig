int
struct cdnsp_device *	pdev
struct cdnsp_request *	preq
unsigned int	num_trbs
