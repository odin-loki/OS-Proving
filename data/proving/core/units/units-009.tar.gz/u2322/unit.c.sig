int
struct smc_link *	lnk
