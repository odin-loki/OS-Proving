u32
struct denali_controller *	denali
u32	irq_mask
