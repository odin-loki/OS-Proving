bool
u8	addr
