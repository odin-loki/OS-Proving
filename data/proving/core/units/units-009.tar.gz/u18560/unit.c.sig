int
struct spinand_device *	spinand
u8	status
