int
struct gspca_dev *	gspca_dev
const struct usb_device_id *	id
