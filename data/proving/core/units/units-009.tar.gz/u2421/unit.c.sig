int
locale_t	locale
const char * restrict	fmt
va_list	ap
