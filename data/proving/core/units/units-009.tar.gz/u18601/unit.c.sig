int
struct bcma_drv_cc *	cc
