bool
u64	size
