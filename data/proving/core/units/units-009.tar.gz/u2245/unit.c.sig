u32
s32	a
s32	b
s64	link_freq
s32	accinv
