int
struct nci_dev *	ndev
struct sk_buff *	skb
