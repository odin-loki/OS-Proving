u_int32_t
u_int32_t	gen
u_int32_t	expo
u_int32_t	mod
