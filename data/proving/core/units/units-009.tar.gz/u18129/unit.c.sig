int
struct igc_adapter *	adapter
struct igc_nfc_rule *	rule
