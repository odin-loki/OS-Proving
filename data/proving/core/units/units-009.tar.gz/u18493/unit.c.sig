void
struct fsi_gpio_msg *	msg
uint64_t	data
int	bits
