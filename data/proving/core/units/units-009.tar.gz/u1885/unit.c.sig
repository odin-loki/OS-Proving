int
struct hte_ts_desc *	desc
u32	line_id
unsigned long	edge_flags
const char *	name
void *	data
