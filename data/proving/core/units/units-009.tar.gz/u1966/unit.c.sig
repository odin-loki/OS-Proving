int
struct vge_softc *	sc
