u32
struct drm_i915_error_state_buf *	m
u32	start
u32 *	dump
u32	count
