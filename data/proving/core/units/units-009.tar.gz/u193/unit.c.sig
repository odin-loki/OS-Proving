int
struct sound_unit **	list
const struct file_operations *	fops
int	index
int	low
int	top
const char *	name
umode_t	mode
struct device *	dev
