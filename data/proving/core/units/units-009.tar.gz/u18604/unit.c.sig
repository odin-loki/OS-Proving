int
struct cdx_mcdi *	cdx
unsigned int	mcdi_err
