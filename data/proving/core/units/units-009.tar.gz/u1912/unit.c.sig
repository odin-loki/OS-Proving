unsigned long
unsigned long	set
unsigned long	unset
unsigned long	mask
