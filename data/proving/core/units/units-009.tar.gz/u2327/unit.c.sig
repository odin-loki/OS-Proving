int
struct pmc_mdep *	pmc_mdep
