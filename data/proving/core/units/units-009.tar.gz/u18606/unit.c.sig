int
struct iwx_softc *	sc
struct iwx_tx_ring *	ring
int	qid
