bool
u16	regd
