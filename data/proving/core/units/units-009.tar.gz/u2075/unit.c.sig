int
enum hybrid_pmu_type	pmus
