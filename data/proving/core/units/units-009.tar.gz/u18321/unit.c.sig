char
unsigned char	c
