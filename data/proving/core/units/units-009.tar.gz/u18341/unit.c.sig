int
adapter_t *	adapter
struct vpd_params *	p
