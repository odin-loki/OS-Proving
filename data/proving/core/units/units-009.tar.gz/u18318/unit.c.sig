int
struct manager *	mgr
struct channel_req *	crq
