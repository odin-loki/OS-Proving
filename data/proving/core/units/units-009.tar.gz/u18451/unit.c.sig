int
u32	iomode
