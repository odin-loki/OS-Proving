u16
struct rtw89_dev *	rtwdev
struct rtw89_bb_ctx *	bb
u16	report
u16	score
