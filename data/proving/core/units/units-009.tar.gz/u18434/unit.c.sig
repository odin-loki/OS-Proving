int
struct ata_port *	ap
struct ata_link *	link
