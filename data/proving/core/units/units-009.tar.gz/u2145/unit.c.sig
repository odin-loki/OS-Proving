bool
u16	vid
