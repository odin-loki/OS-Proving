int
struct ttm_resource_manager *	man
struct ttm_buffer_object *	tbo
const struct ttm_place *	place
struct ttm_resource **	res
