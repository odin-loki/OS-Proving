int
struct wx *	wx
u32 *	msgbuf
u16	vf
