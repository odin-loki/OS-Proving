int
struct ixgbe_adapter *	adapter
int	pb
