enum drm_mode_status
const struct drm_bridge *	bridge
const struct drm_display_mode *	mode
unsigned long long	tmds_rate
