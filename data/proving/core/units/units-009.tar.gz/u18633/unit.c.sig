int
struct device *	dev
void *	ioregs
