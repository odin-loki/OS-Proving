int
struct pci_dev *	pdev
struct flexcop_dma *	dma
u32	size
