int
struct cphy *	phy
int	mmd
int	reg
unsigned int	val
