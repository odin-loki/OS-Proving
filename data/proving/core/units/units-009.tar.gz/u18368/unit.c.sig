int
struct qaic_device *	qdev
void *	trans
struct wrapper_list *	wrappers
u32 *	user_len
