int
handle_t *	handle
int	check_cred
int	extend_cred
int	revoke_cred
