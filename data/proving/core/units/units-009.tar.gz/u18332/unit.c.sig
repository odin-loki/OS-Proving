int
struct ixl_pf_qmgr *	qmgr
struct ixl_pf_qtag *	qtag
