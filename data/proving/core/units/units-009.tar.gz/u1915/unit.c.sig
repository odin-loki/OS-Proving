int
struct amdtp_stream *	s
struct fw_unit *	unit
enum amdtp_stream_direction	dir
