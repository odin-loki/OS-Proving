bool
struct radeon_device *	rdev
int	state_index
int	mode_index
union pplib_clock_info *	clock_info
