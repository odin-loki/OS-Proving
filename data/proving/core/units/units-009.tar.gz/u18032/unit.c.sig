void
u8 *	byte
u8	val
