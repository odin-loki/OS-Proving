int
unsigned long	pfn
size_t	size
