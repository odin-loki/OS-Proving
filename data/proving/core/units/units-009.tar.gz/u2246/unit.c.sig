int
adapter_t *	adapter
u32	offset
