int
struct dpaa2_caam_priv *	priv
u16	token
