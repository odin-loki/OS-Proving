int
FILE *	file
keymap_t *	keymap
accentmap_t *	accentmap
