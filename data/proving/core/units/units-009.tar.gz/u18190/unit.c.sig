int
struct rvt_qp *	qp
struct rvt_swqe *	wqe
bool *	call_send
