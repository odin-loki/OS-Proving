int
struct pruss *	pruss
enum pruss_mem	mem_id
struct pruss_mem_region *	region
