void
u32	version
enum arm_smccc_conduit	conduit
