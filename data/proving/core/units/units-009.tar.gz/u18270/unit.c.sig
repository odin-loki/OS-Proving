int
struct ubi_device *	ubi
const struct ubi_ainf_peb *	aeb
int	pnum
const struct ubi_vid_hdr *	vid_hdr
