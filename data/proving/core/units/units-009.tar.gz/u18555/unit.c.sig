int
struct asd_ha_struct *	asd_ha
const u8	phy_mask
