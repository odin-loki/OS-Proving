int
struct gf100_gr *	gr
