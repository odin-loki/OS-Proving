int
struct snd_es18xx *	chip
unsigned long	mpu_port
unsigned long	fm_port
