int
uint32_t	cts_in_wticks
