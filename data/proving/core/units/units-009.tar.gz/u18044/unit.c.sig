int
struct sig_alg *	alg
