int
struct msm_gpu_submitqueue *	queue
struct drm_msm_submitqueue_query *	args
