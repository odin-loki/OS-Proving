int
char *	str
int	used
