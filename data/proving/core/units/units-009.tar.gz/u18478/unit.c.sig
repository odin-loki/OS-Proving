u32
u32 *	free_buff_ring
u32	limit
