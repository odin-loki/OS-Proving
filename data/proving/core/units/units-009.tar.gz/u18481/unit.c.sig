unsigned long
unsigned long	addr
unsigned long	end
u64	pfn
unsigned int	max_page_shift
