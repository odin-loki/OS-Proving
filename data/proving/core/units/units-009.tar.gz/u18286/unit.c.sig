int
cap_user_header_t	header
unsigned *	tocopy
