int
int	msec
int *	c1p
int *	c2p
