uint8_t
struct nct_softc *	sc
reg_t	reg
uint8_t	grpnum
