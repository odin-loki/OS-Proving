int
const struct ismt_desc *	desc
union i2c_smbus_data *	data
struct ismt_priv *	priv
int	size
char	read_write
