unsigned short
const void *	buf
int	offset
int	mode
