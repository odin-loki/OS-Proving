u64
unsigned int	lightness
