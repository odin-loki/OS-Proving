int
struct rtw89_dev *	rtwdev
u8	mac_idx
enum rtw89_mac_hwmod_sel	sel
