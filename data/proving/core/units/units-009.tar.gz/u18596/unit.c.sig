enum typec_pwr_opmode
unsigned int	status
