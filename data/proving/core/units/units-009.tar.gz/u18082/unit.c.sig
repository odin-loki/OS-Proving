int
u32	addr
void *	rxbuf
size_t	len
