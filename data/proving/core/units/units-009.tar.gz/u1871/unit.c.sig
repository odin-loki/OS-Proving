u32
struct sun4i_spi *	sspi
