u8
struct mwifiex_private *	priv
u8	rx_rate
u8	rate_info
