unsigned int
u8	flags
unsigned int	byte_len
