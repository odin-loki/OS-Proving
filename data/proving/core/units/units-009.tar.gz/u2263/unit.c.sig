bool
u32	s1
u32	s2
