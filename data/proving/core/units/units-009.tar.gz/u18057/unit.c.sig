bool
unsigned short	id
unsigned short	svendor
unsigned short	sdevice
