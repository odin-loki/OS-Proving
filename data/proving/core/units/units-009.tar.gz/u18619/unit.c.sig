u32
struct ssb_extif *	extif
u32	ticks
