int
const struct pinctrl_setting *	setting
