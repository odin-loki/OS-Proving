rman_res_t
int	type
rman_res_t	start
rman_res_t	end
rman_res_t	count
