int
struct siw_cq *	cq
struct ib_wc *	wc
