int
struct block_allocator *	allocator
physical_block_number_t	pbn
