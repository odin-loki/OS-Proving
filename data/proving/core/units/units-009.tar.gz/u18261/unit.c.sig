int
struct net *	net
struct notifier_block *	nb
struct netlink_ext_ack *	extack
