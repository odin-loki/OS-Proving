int
struct nvkm_mmu *	mmu
bool	managed
u64	addr
u64	size
void *	argv
u32	argc
struct lock_class_key *	key
const char *	name
struct nvkm_vmm **	pvmm
