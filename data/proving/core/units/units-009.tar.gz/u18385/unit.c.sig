int
int	eclass
int	eno
