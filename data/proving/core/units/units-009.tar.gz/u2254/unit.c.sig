int
const struct device_node *	device
int	index
struct of_phandle_args *	out_irq
