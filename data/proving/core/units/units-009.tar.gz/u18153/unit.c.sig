int
struct nvif_chan *	chan
u32	nr
