int
struct device *	dev
bool	on
