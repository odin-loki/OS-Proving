bool
u64	address
