int
struct ena_adapter *	adapter
int	qid
