int
u64	sts_data
int	lro_pkt
