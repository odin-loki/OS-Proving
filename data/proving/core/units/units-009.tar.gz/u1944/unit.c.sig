int
struct radeon_device *	rdev
u32	engine_clock
RV770_SMC_SCLK_VALUE *	sclk
