bool
unsigned int	sgl_nents
unsigned int	authsize
u32	last_entry_data_size
