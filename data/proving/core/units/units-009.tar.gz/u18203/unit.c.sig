u32
u32	numerator
u32	denominator
