unsigned long
unsigned long	nr
void *	ufdset
unsigned long *	fdset
