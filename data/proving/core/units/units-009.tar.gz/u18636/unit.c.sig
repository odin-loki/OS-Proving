unsigned int
struct net_device *	netdev
unsigned int	budget
unsigned int *	freeq_consumed
