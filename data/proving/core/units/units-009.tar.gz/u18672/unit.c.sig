int
struct ath5k_hw *	ah
int	offset
