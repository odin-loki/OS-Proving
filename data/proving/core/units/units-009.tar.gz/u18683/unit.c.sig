int
struct baycom_state *	bc
const char *	modestr
