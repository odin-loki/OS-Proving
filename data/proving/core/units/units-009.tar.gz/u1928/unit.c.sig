int
struct nvkm_chan *	chan
u64	offset
u64	length
u32	devm
bool	priv
