u64
struct clocksource *	cs
