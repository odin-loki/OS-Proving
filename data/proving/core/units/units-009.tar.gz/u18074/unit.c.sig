unsigned int
unsigned int	avail
unsigned int	needed
