unsigned int
const struct tbnet_ring *	ring
