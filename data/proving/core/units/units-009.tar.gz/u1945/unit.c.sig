int
struct fw_card *	card
struct fw_packet *	packet
