unsigned int
struct irq_desc *	desc
const struct cpumask *	cpumask
