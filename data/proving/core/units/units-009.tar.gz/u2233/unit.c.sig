unsigned int
int	val
int	val2
int	osr
