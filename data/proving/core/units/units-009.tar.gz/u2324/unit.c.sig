unsigned int
u64	fence
