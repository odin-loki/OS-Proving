int
struct hwspinlock *	lock
