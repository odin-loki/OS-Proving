int
struct mc13xxx_regulator_priv *	priv
u32	mask
u32	val
