bool
const struct request_sock_queue *	queue
