int
struct cyttsp5 *	ts
struct cyttsp5_hid_desc *	desc
