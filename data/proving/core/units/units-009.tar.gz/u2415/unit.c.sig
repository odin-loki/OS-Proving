int
struct ipu_smfc *	smfc
