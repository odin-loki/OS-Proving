unsigned long
struct tdfx_par *	par
unsigned short	dev_id
