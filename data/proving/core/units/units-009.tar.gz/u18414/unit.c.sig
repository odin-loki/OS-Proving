int
struct intel_uncore_type **	types
int	id
unsigned int	cpu
