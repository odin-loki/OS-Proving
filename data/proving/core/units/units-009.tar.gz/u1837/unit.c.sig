int
struct mii_bus *	bus
