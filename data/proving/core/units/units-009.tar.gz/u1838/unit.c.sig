u32
unsigned int	id
int	upd
