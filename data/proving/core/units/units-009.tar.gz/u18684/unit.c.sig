u32
const u64	val
const u32	resolution
