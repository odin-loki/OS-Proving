unsigned int
unsigned int	node_id
