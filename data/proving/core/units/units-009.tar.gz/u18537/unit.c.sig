int
struct timespec *	ts
int	base
