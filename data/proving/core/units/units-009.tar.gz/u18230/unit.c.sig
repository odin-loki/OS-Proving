int
struct lpfc_hba *	phba
struct scsi_cmnd *	sc
uint32_t *	reftag
uint16_t *	apptag
uint32_t	new_guard
