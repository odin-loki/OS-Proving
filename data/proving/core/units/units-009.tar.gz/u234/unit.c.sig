int
const struct qm_dqrr_entry *	e
