int
struct mhi_device *	mhi_dev
unsigned int	flags
