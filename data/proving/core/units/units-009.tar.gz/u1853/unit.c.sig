bool
s8	reg
