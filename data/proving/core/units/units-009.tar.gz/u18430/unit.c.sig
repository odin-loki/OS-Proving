u8
u32	rate_n_flags
