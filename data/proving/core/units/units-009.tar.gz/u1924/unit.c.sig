int
u8	reg
int	nr
int	mode
