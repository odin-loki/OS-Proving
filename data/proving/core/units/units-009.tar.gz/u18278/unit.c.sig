uint64_t
int	size
