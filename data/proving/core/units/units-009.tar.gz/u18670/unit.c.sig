void
int *	pos
unsigned char *	bmask
