bool
u64	segment_pa
u64	segment_size
u64	pa
