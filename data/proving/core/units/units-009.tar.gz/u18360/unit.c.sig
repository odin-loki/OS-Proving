int
const struct ltc2983_data *	st
const u32	result
const u32	hard_mask
const u32	soft_mask
