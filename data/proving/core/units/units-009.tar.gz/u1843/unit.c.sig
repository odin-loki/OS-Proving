void
struct venus_inst *	inst
u32 *	min_coreid
u32 *	min_load
bool	low_power
