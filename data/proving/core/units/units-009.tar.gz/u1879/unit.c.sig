uint64_t
unsigned long	j
