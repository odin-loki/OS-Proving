unsigned int
u32	arch_flags
