int
struct ceph_connection *	con
u32	front_crc
u32	middle_crc
u32	data_crc
