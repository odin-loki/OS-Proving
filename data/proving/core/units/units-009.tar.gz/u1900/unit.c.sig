int
struct hl_device *	hdev
u64	qman_base
u16	event_type
