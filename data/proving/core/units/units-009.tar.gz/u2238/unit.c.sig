int
struct ipv6hdr *	ip6h
uint16_t	payload_len
