int
struct inode *	inode
u64	flush_tid
