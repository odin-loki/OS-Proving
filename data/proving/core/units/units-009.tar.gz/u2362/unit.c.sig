ssize_t
struct file *	filp
const char *	buf
size_t	siz
loff_t *	ppos
