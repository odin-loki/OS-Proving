int
struct net_bridge *	br
u32 *	count
