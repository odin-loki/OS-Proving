int
struct uverbs_attr_bundle *	attrs
