int
struct snd_emu8000 *	emu
int	mode
const void *	buf
long	len
