u32
u32	adc
u32	calib
