int
struct platform_device *	pdev
struct stm32_rtc *	rtc
