int
const int	c
