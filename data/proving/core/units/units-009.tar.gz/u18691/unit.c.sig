int
struct phy_device *	phydev
char *	pin_name
int	gpios
