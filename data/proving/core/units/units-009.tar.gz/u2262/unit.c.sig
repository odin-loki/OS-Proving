u32
enum sparx5_cal_bw	speed
