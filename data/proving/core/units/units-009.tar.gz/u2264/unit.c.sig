int
__u64	sum_llc_val
int	no_of_bits
unsigned long	cache_span
unsigned long	min_diff_percent
unsigned long	num_of_runs
_Bool	platform
__s64 *	prev_avg_llc_val
