qidx_t
int	size
qidx_t	cidx
qidx_t	pidx
uint8_t	gen
