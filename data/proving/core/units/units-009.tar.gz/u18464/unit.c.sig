bool
u16	speed
