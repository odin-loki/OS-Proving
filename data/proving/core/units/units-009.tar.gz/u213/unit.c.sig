int
struct smb_ntsd *	pnntsd
__u32	acllen
struct inode *	inode
const char *	path
int	aclflag
