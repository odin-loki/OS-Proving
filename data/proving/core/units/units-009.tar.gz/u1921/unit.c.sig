int
struct vsock_sock *	vsk
int	val
