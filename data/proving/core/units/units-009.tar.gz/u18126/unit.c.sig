int
u8	rd
u8	rs
u8	sz
bool	sign
struct rv_jit_context *	ctx
