int
speed_t	baudrate
speed_t	clockrate
