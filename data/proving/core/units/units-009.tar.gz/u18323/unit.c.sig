int
u16	sq1
u16	sq2
