u8
int	size
bool	is_smcd
bool	is_rmb
