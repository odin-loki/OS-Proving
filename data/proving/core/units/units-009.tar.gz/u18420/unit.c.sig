__u8
__u32	elbaf
