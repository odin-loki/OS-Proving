u8
struct mt7601u_dev *	dev
u8	rate
bool	is_probe
