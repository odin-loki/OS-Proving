int
int	width
int	height
