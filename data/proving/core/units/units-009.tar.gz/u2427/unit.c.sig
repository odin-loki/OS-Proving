int
u32	reg
