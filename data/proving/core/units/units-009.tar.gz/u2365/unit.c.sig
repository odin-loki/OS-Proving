int
const char *	match
int *	value
