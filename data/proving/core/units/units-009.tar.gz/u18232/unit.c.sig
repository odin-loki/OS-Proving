u32
const struct nvkm_ram_func *	func
u32	fbpao
struct nvkm_device *	device
int	fbp
int *	pltcs
