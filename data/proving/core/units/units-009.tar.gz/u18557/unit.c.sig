void
int	eval
const char *	fmt
?	?
