int
struct device *	dev
const char *	compatible
struct power_supply_battery_info **	info
