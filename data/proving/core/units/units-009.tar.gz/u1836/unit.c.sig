int
struct aw_ccung_softc *	sc
