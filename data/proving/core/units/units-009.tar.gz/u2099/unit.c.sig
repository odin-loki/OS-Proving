int
u64	size
u64	blk_size
const enum string_size_units	units
char *	buf
int	len
