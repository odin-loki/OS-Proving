unsigned char
short	sample
