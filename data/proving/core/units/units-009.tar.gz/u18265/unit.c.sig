unsigned int
snd_pcm_format_t	format
snd_pcm_subformat_t	subformat
unsigned int	maxbits
